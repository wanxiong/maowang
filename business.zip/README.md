### 安装依赖

yarn install

### 本地

yarn run start

### 说明

```
react + mobx + react-router-dom + ezrd + axios + MD5 + SHA1 + ezrpc
除登陆相关接口，所有接口需要签名验证，本地token不存在默认不是登陆状态，
```

###  补充
```
开放平台 ErrorCode = 200 ---- 成功
开放平台 ErrorCode = 401 ---- 没有权限或者登陆过期
```
###  登陆权限路由说明
```
Menu.js 区分两套路由，一个平台级账号、一个商户账号，目前由前台配置，新建东西方便，后期可能改成API动态返回
```

# 目录结构
- **src**  

  -  assets------------------      存储静态图片资源，目前放在[EZR / EZP.Static](https://192.168.12.190/FE-PC/business)
  -  components---------  存储共用组件或者页面局部组件
  -  config-----------------  API域名
  -  model-----------------  请求的controler层
  -  services---------------  接口请求定义
  -  styles------------------  less样式和基础公用样式存放处
  -  utils--------------------  工具函数,权限组件，接口共通处
  -  view-------------------  视图组件
  -  Menu.js--------------  路由配置

###  eslint自动检查和fix
```
  yarn run eslint --fix
```
- **克隆Ip**  
```git@192.168.12.190:FE-PC/business.git```

- **测试地址Ip**  
- [测试ip](http://192.168.56.42:808)

- **测试地址域名**  
- [测试环境](http://test.ezrpro.com:9091)

- **生产地址**  
- [线上环境](https://union.ezrpro.com)


###  发布目前只有一个云

- [发布工具已迁移到新的发布工具](http://log-ops.ezrpro.cn/#/login)，对应的云为ucloud，不在有测试审核一说,生产审核找老大批准

###  已部署灰度环境

- [对应切换的灰度地址](http://bandmaster.ezrpro.in/)，灰度切换地址


