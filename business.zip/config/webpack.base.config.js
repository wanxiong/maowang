const webpack = require('webpack');
const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const IncludeAssetsPlugin = require('html-webpack-include-assets-plugin');
const {
  env,
  basePath,
  srcDir,
  publicPath,
  outDir
} = require('../project.config');

const fonts = [
  ['otf', 'font/opentype'],
  ['ttf', 'application/octet-stream'],
  ['eot', 'application/vnd.ms-fontobject'],
  ['svg', 'image/svg+xml'],
  ['woff', 'application/font-woff'],
  ['woff2', 'application/font-woff2']
];


const base = {
  entry: {
    main: ['@babel/polyfill', `${srcDir}/App.jsx`]
  },
  output: {
    publicPath,
    path: outDir
  },
  resolve: {
    alias: {
      '@': srcDir
    },
    modules: [srcDir, 'node_modules'],
    extensions: ['.js', '.jsx', '.ts', '.tsx', '.json', '.less', '.css']
  },
  module: {
    rules: [

      {
        test: /(\.jsx|\.js|\.tsx|\.ts)$/,
        use: {
          loader: 'babel-loader?cacheDirectory'
        },
        include: srcDir,
        exclude: /node_modules/
      },
      {
        test: /\.(png|PNG|jpe?g|JPG|gif|GIF)(\?.*)?$/,
        use: {
          loader: 'url-loader',
          options: {
            limit: 10000,
            name: 'images/[name].[hash:5].[ext]'
          }
        }
      },
      {
        test: /\.(mp4|webm|ogg|mp3|wav|flac|aac)(\?.*)?$/,
        use: {
          loader: 'url-loader',
          options: {
            limit: 10000,
            name: 'media/[name].[hash:5].[ext]'
          }
        }
      },
      ...(() => {
        const rules = [];
        fonts.forEach((item) => {
          rules.push({
            test: new RegExp(`\\.${item[0]}$`),
            use: {
              loader: 'url-loader',
              options: {
                name: 'fonts/[name].[hash:5].[ext]',
                limit: 10000,
                mimetype: item[1]
              }
            }
          });
        });
        return rules;
      })()
    ]
  },
  performance: {
    hints: false
  },
  plugins: [
    new webpack.DefinePlugin({
      __ENV__: JSON.stringify(env)
    }),
    new webpack.DllReferencePlugin({
      context: basePath,
      manifest: path.resolve(basePath, 'dll', 'manifest.json')
    }),
    new HtmlWebpackPlugin({
      template: `${srcDir}/index.html`,
      inject: true,
      minify: {
        collapseWhitespace: true
      }
    }),
    new IncludeAssetsPlugin({
      assets: [{
        path: 'dll',
        glob: '*.js',
        globPath: path.join(basePath, 'dll')
      }],
      append: false
    })
  ]
};

module.exports = base;
