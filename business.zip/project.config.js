const path = require('path');

const NODE_ENV = process.env.NODE_ENV || 'development';

module.exports = {
  env: NODE_ENV,
  basePath: __dirname,
  srcDir: path.resolve(__dirname, 'src'),
  outDir: path.resolve(__dirname, 'dist'),
  publicPath:  './',
  esLint: false,
  vendor: ['react', 'react-dom', 'react-router-dom', 'react-loadable', 'mobx', 'mobx-react']
};
