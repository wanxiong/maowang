const ENV = process.env.NODE_ENV;
const BASE_URL = {
  // development: 'http://test.ezrpro.com:8088/',
  development: 'http://192.168.12.63/',
  production: '/'
  // production: 'http://union.ezrpro.com/'
};

export default {
  baseUrl: BASE_URL[ENV]
};

export const isDev = ENV === 'development'; // 是否是dev环境
