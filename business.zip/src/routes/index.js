// 品牌账号

import AssetManageList from '../view/accountManage/assetManageList';
import AssetManageRechargeDetail from '../view/accountManage/assetManageRechargeDetail';
import AssetManageZDetail from '../view/accountManage/assetManageZDetail';
import AssetManageBondDetail from '../view/accountManage/assetManageBondDetail';
import AccountShieldType from '../view/accountManage/accountShieldType';
import DownLoad from '../view/download/download';
import YiyeCouponList from '../view/purchase/yiyeCouponList';
import YiyeCouponDetail from '../view/purchase/yiyeCouponDetail';
import YiyePurchaseOrder from '../view/purchase/yiyePurchaseOrder';


// 平台账号

import WriteOffRate from '../view/transaction/writeOffRate';
import PlatformFee from '../view/transaction/platformFee';
import FreezeRatio from '../view/transaction/freezeRatio';
import AccountAudit from '../view/accountAudit/accountAudit';
import AccountAuditDetail from '../view/accountAudit/accountAuditDetail';
import AccountAuditStatus from '../view/accountAudit/accountAuditStatus';

// import DownLoad from '../view/download/download';

import GoodsManagement from '../view/supplier/goodsManagement';
import GoodsManagementAdd from '../view/supplier/goodsManagementAdd';
import SupplierManagement from '../view/supplier/supplierManage/list';
import SupplierEdit from '../view/supplier/supplierManage/edit';
import SaleOrder from '../view/supplier/saleOrder';
import BrandManagement from '../view/supplier/brandManage/list';
import SaleReportSupplier from '../view/supplier/saleReport/supplier';
import SaleReportYikeProduction from '../view/supplier/saleReport/product';
import SaleReportYikeBrand from '../view/supplier/saleReport/brand';

// 导入文件页面
import ImportYiye from '../view/import/importYiye';

// 商户资产相关页面
import MerchManageDetail from '../view/merchManage/merchManageDetail';
import MerchManageRechargeList from '../view/merchManage/merchManageRechargeList';
import MerchManageZDetail from '../view/merchManage/merchManageZDetail';

// 平台账号-账户信息
import SupAssetManageList from '../view/accountManage/supAssetManageList';
import SupAssetManageZDetail from '../view/accountManage/supAssetManageZDetail';
import SupAssetManageRechargeDetail from '../view/accountManage/supAssetManageRechargeDetail';
import SupCheckBrandIncome from '../view/accountManage/supCheckBrandIncome';

// 系统管理
import SystemRoleManage from '../view/systemManage/roleManage';
import SystemUserManage from '../view/systemManage/userManage';

//  渠道注册
import Channel from '../view/channel/channelRegisterList';
import ChannelAdd from '../view/channel/channelRegisterAdd';

import CouponCodeManageList from '../view/couponCode/couponCodeManageList';

// 新迁移路由
import BrandCouponList from '../view/purchase/brandCouponList';
import BrandCouponDetail from '../view/purchase/brandCouponDetail';
import BrandPurchaseOrder from '../view/purchase/brandPurchaseOrder';
import PlatformCoupon from '../view/purchase/platformCoupon';
import PlatformCouponDetail from '../view/purchase/platformCouponDetail';
import PurchaseOrderReport from '../view/purchase/purchaseOrderReport';

import ProvidePlatformCoupon from '../view/provide/providePlatformCoupon';
import ProvideCouponAdd from '../view/provide/provideCouponAdd';
import ProvideOrder from '../view/provide/provideOrder';
import ProvideOrderReport from '../view/provide/provideOrderReport';

import ProvidePageApply from '../view/provide/providePageApply';
import ProvidePageExamine from '../view/provide/providePageExamine';
import ProvidePageAuditFailure from '../view/provide/providePageAuditFailure';

import ImportSKU from '../view/import/importGoods';
import AccountInfo from '../view/accountManage/accountInfo';
import CouponCodeAdd from '../view/couponCode/couponCodeAdd';

// 收费方案
import CouponWriteOff from '../view/chargingScheme/couponWriteOff';
import CouponLX from '../view/chargingScheme/couponLX';
import CouponCodeScheme from '../view/chargingScheme/couponCode';
import ChannelLaunch from '../view/chargingScheme/channelLaunch';

export default {
  AssetManageList,
  AssetManageRechargeDetail,
  AssetManageZDetail,
  AssetManageBondDetail,
  AccountShieldType,
  DownLoad,
  YiyeCouponList,
  YiyeCouponDetail,
  YiyePurchaseOrder,
  WriteOffRate,
  PlatformFee,
  FreezeRatio,
  AccountAudit,
  AccountAuditDetail,
  AccountAuditStatus,
  GoodsManagement,
  GoodsManagementAdd,
  SupplierManagement,
  SupplierEdit,
  SaleOrder,
  BrandManagement,
  SaleReportSupplier,
  SaleReportYikeProduction,
  SaleReportYikeBrand,
  ImportYiye,
  MerchManageDetail,
  MerchManageRechargeList,
  MerchManageZDetail,
  SupAssetManageList,
  SupAssetManageZDetail,
  SupAssetManageRechargeDetail,
  SystemRoleManage,
  SystemUserManage,
  SupCheckBrandIncome,
  Channel,
  ChannelAdd,
  CouponCodeManageList,
  BrandCouponList,
  BrandCouponDetail,
  BrandPurchaseOrder,
  PlatformCoupon,
  PlatformCouponDetail,
  PurchaseOrderReport,
  ProvidePlatformCoupon,
  ProvideCouponAdd,
  ProvideOrder,
  ProvideOrderReport,
  ProvidePageApply,
  ProvidePageExamine,
  ProvidePageAuditFailure,
  ImportSKU,
  AccountInfo,
  CouponCodeAdd,
  CouponWriteOff,
  CouponLX,
  CouponCodeScheme,
  ChannelLaunch
};
