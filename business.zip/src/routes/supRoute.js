import WriteOffRate from '../view/transaction/writeOffRate';
import PlatformFee from '../view/transaction/platformFee';
import FreezeRatio from '../view/transaction/freezeRatio';
import AccountAudit from '../view/accountAudit/accountAudit';
import AccountAuditDetail from '../view/accountAudit/accountAuditDetail';
import AccountAuditStatus from '../view/accountAudit/accountAuditStatus';
import SupCheckBrandIncome from '../view/accountManage/supCheckBrandIncome';
import DownLoad from '../view/download/download';

import GoodsManagement from '../view/supplier/goodsManagement';
import GoodsManagementAdd from '../view/supplier/goodsManagementAdd';
import SupplierManagement from '../view/supplier/supplierManage/list';
import SupplierEdit from '../view/supplier/supplierManage/edit';
import SaleOrder from '../view/supplier/saleOrder';
import BrandManagement from '../view/supplier/brandManage/list';
import SaleReportSupplier from '../view/supplier/saleReport/supplier';
import SaleReportYikeProduction from '../view/supplier/saleReport/product';
import SaleReportYikeBrand from '../view/supplier/saleReport/brand';

// 导入文件页面
import ImportYiye from '../view/import/importYiye';

// 商户资产相关页面
import MerchManageDetail from '../view/merchManage/merchManageDetail';
import MerchManageRechargeList from '../view/merchManage/merchManageRechargeList';
import MerchManageZDetail from '../view/merchManage/merchManageZDetail';

// 平台账号-账户信息
import SupAssetManageList from '../view/accountManage/supAssetManageList';
import SupAssetManageZDetail from '../view/accountManage/supAssetManageZDetail';
import SupAssetManageRechargeDetail from '../view/accountManage/supAssetManageRechargeDetail';

// 系统管理
import SystemRoleManage from '../view/systemManage/roleManage';
import SystemUserManage from '../view/systemManage/userManage';

// 收费方案
import CouponWriteOff from '../view/chargingScheme/couponWriteOff';
import CouponLX from '../view/chargingScheme/couponLX';
import CouponCodeScheme from '../view/chargingScheme/couponCode';
import ChannelLaunch from '../view/chargingScheme/channelLaunch';

// 平台路由
const supRoutes = [
  {
    path: '/Yiye/Account/supAssetManageList',
    exact: true,
    name: '资产管理',
    icon: 'account-book',
    component: SupAssetManageList
  }, {
    path: '/Yiye/Account/supAssetManageZDetail',
    exact: true,
    name: '资产管理-Z币充值明细',
    hide: true,
    icon: 'account-book',
    component: SupAssetManageZDetail
  }, {
    path: '/Yiye/Account/supAssetManageRechargeDetail',
    exact: true,
    name: '资产管理-余额充值明细',
    hide: true,
    icon: 'account-book',
    component: SupAssetManageRechargeDetail
  }, {
    path: '/Yiye/Account/supCheckBrandIncome',
    exact: true,
    name: '资产管理-品牌收益核准',
    hide: true,
    icon: 'account-book',
    component: SupCheckBrandIncome
  }, {
    path: '/Yiye/Account/Audit',
    exact: true,
    name: '账户管理',
    icon: 'audit',
    component: AccountAudit
  }, {
    path: '/Yiye/Account/audit/detail/:id',
    exact: true,
    name: '账户管理-账户查看',
    hide: true,
    icon: 'account-book',
    component: AccountAuditDetail
  }, {
    path: '/Yiye/Account/audit/:id',
    exact: true,
    name: '账户管理-账户审核列表',
    hide: true,
    icon: 'account-book',
    component: AccountAuditStatus
  }, {
    path: '/Yiye/MerchManageDetail/:id/:name',
    exact: true,
    name: '账户管理-商户资产管理详情',
    icon: 'account-book',
    hide: true,
    component: MerchManageDetail
  }, {
    path: '/Yiye/MerchManage',
    exact: true,
    name: '账户管理-商户资产管理',
    hide: true,
    icon: 'account-book',
    subRoutes: [{
      path: '/RechargeList/:id',
      exact: true,
      name: '账户管理-商户资产管理商-户充值列表',
      hide: true,
      icon: 'home',
      component: MerchManageRechargeList
    }, {
      path: '/ZDetailList/:id',
      exact: true,
      name: '账户管理-商户资产管理商-Z币充值明细',
      hide: true,
      icon: 'home',
      component: MerchManageZDetail
    }]
  }, {
    path: '/Yiye/Transaction',
    exact: true,
    name: '券交易',
    icon: 'calendar',
    subRoutes: [{
      path: '/WriteOffRate',
      exact: true,
      name: '核销率',
      icon: 'home',
      component: WriteOffRate
    }, {
      path: '/PlatformFee',
      exact: true,
      name: '平台手续费优惠',
      icon: 'home',
      component: PlatformFee
    }, {
      path: '/FreezeRatio',
      exact: true,
      name: '冻结比列',
      icon: 'home',
      component: FreezeRatio
    }]
  }, {
    path: '/Yiye/Supplier',
    exact: true,
    name: '供应商',
    icon: 'folder-open',
    subRoutes: [{
      path: '/Management',
      exact: true,
      name: '供应商管理',
      icon: '',
      component: SupplierManagement
    }, {
      path: '/BrandManagement',
      exact: true,
      name: '品牌管理',
      icon: '',
      component: BrandManagement
    }, {
      path: '/GoodsManagement',
      exact: true,
      name: '权益商品管理',
      icon: '',
      component: GoodsManagement
    }, {
      path: '/GoodsManagementAdd',
      exact: true,
      name: '商品管理-新增/编辑',
      icon: '',
      hide: true,
      component: GoodsManagementAdd
    }, {
      path: '/Edit',
      exact: true,
      name: '供应商管理-新增/编辑',
      icon: '',
      hide: true,
      component: SupplierEdit
    }, {
      path: '/SaleOrder',
      exact: true,
      name: '销售订单',
      icon: '',
      component: SaleOrder
    }, {
      path: '/SaleReport',
      exact: true,
      name: '销售报表',
      icon: '',
      subRoutes: [{
        path: '/SaleReportSupplier',
        exact: true,
        name: '供应商',
        icon: '',
        component: SaleReportSupplier
      }, {
        path: 'SaleReportYikeBrand',
        exact: true,
        name: '驿业品牌',
        icon: '',
        component: SaleReportYikeBrand
      }, {
        path: 'SaleReportYikeProduction',
        exact: true,
        name: '权益商品',
        icon: '',
        component: SaleReportYikeProduction
      }]
    }]
  }, {
    path: '/Yiye/SystemManage',
    exact: true,
    name: '系统管理',
    icon: 'setting',
    subRoutes: [{
      path: '/RoleManage',
      exact: true,
      name: '角色管理',
      icon: '',
      component: SystemRoleManage
    }, {
      path: '/UserManage',
      exact: true,
      name: '用户管理',
      icon: '',
      component: SystemUserManage
    }]
  }, {
    path: '/Yiye/Download',
    exact: true,
    name: '下载中心',
    icon: 'download',
    component: DownLoad
  }, {
    path: '/Yiye/Import/CouponCode',
    exact: true,
    name: '导入券码',
    icon: '',
    hide: true,
    component: ImportYiye
  }, {
    path: '/Platform/ChargingScheme',
    exact: true,
    name: '平台收费方案',
    icon: 'pay-circle',
    subRoutes: [{
      path: '/CouponWriteOff',
      exact: true,
      name: '券核销收费方案',
      icon: '',
      component: CouponWriteOff
    }, {
      path: '/CouponLX',
      exact: true,
      name: '券拉新收费方案',
      icon: '',
      component: CouponLX
    }, {
      path: '/CouponCode',
      exact: true,
      name: '券码收费方案',
      icon: '',
      component: CouponCodeScheme
    }, {
      path: '/channelLaunch',
      exact: true,
      name: '渠道投放活动收费方案',
      icon: '',
      component: ChannelLaunch
    }]
  }
];

export default supRoutes;
