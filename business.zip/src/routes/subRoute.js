import AssetManageList from '../view/accountManage/assetManageList';
import AssetManageRechargeDetail from '../view/accountManage/assetManageRechargeDetail';
import AssetManageZDetail from '../view/accountManage/assetManageZDetail';
import AssetManageBondDetail from '../view/accountManage/assetManageBondDetail';
import AccountShieldType from '../view/accountManage/accountShieldType';
import DownLoad from '../view/download/download';
import Channel from '../view/channel/channelRegisterList';
import ChannelAdd from '../view/channel/channelRegisterAdd';

import YiyeCouponList from '../view/purchase/yiyeCouponList';
import YiyeCouponDetail from '../view/purchase/yiyeCouponDetail';
import YiyePurchaseOrder from '../view/purchase/yiyePurchaseOrder';

// 新迁移路由
import BrandCouponList from '../view/purchase/brandCouponList';
import BrandCouponDetail from '../view/purchase/brandCouponDetail';
import BrandPurchaseOrder from '../view/purchase/brandPurchaseOrder';
import PlatformCoupon from '../view/purchase/platformCoupon';
import PlatformCouponDetail from '../view/purchase/platformCouponDetail';
import PurchaseOrderReport from '../view/purchase/purchaseOrderReport';

import ProvidePlatformCoupon from '../view/provide/providePlatformCoupon';
import ProvideCouponAdd from '../view/provide/provideCouponAdd';
import ProvideOrder from '../view/provide/provideOrder';
import ProvideOrderReport from '../view/provide/provideOrderReport';

import ProvidePageApply from '../view/provide/providePageApply';
import ProvidePageExamine from '../view/provide/providePageExamine';
import ProvidePageAuditFailure from '../view/provide/providePageAuditFailure';

import ImportSKU from '../view/import/importGoods';
import AccountInfo from '../view/accountManage/accountInfo';

import CouponCodeManageList from '../view/couponCode/couponCodeManageList';
import CouponCodeAdd from '../view/couponCode/couponCodeAdd';

// 商户路由
const subRoutes = [
  {
    path: '/Yiye/Equity',
    exact: true,
    name: '权益中心',
    icon: 'shopping',
    subRoutes: [{
      path: '/Coupon/YiyeCoupon',
      exact: true,
      name: '权益超市',
      icon: '',
      component: YiyeCouponList
    }, {
      path: '/Coupon/YiyeCouponDetail',
      exact: true,
      name: '权益超市-商品详情',
      icon: 'home',
      hide: true,
      component: YiyeCouponDetail
    }, {
      path: '/Purchaseorder/YiyeOrder',
      exact: true,
      name: '采购单',
      icon: '',
      component: YiyePurchaseOrder
    }]
  }, {
    path: '/Yiye/Purchase',
    exact: true,
    name: '流量主',
    icon: 'shopping',
    subRoutes: [
      {
        path: '/Coupon/BrandCouponList',
        exact: true,
        name: '流量市场',
        icon: 'home',
        component: BrandCouponList
      }, {
        path: '/Coupon/BrandCoupondetail',
        exact: true,
        name: '流量市场-券详情',
        icon: 'home',
        hide: true,
        component: BrandCouponDetail
      }, {
        path: '/Purchaseorder/BrandOrder',
        exact: true,
        name: '流量交易单',
        icon: 'home',
        component: BrandPurchaseOrder
      }, {
        path: '/Platformcoupon',
        exact: true,
        name: '平台券',
        icon: 'home',
        component: PlatformCoupon
      }, {
        path: '/PlatformCouponDetail',
        exact: true,
        hide: true,
        name: '平台券--券详情',
        icon: 'home',
        component: PlatformCouponDetail
      }, {
        path: '/PurchaseOrderReport',
        exact: true,
        name: '流量收益报表',
        icon: 'home',
        component: PurchaseOrderReport
      }]
  }, {
    path: '/Yiye/Provide',
    exact: true,
    name: '广告主',
    icon: 'shop',
    subRoutes: [{
      path: '/Platformcoupon',
      exact: true,
      name: '引流券',
      icon: 'home',
      component: ProvidePlatformCoupon
    }, {
      path: '/PlatformcouponAdd',
      exact: true,
      hide: true,
      name: '引流券--新增引流券',
      icon: 'home',
      component: ProvideCouponAdd
    }, {
      path: '/Provideorder',
      exact: true,
      name: '流量交易单',
      icon: 'home',
      component: ProvideOrder
    }, {
      path: '/ProvideOrderReport',
      exact: true,
      name: '流量付费报表',
      icon: 'home',
      component: ProvideOrderReport
    }, {
      path: '/Page/Apply',
      exact: true,
      hide: true,
      name: '页面异常展示-入住申请',
      icon: 'home',
      component: ProvidePageApply
    }, {
      path: '/Page/Examine',
      exact: true,
      hide: true,
      name: '页面异常展示-待审核提示',
      icon: 'home',
      component: ProvidePageExamine
    }, {
      path: '/Page/AuditFailure',
      exact: true,
      hide: true,
      name: '页面异常展示-审核未通过',
      icon: 'home',
      component: ProvidePageAuditFailure
    }]
  }, {
    path: '/Yiye/Channel',
    exact: true,
    name: '渠道投放活动',
    icon: 'credit-card',
    subRoutes: [
      {
        path: '/List',
        exact: true,
        name: '渠道活动列表',
        icon: 'home',
        component: Channel
      },
      {
        path: '/AddOrEdit/:id',
        exact: true,
        name: '新建渠道',
        hide: true,
        icon: 'home',
        component: ChannelAdd
      }
    ]
  }, {
    path: '/Yiye/Account',
    exact: true,
    name: '账号管理',
    icon: 'account-book',
    subRoutes: [{
      path: '/Accountinfo',
      exact: true,
      name: '账户信息',
      icon: 'home',
      component: AccountInfo
    }, {
      path: '/AccountInfo/AssetManageList',
      exact: true,
      name: '资产管理',
      icon: 'home',
      component: AssetManageList
    }, {
      path: '/AccountInfo/AssetManageRechargeDetail',
      exact: true,
      name: '充值明细',
      icon: 'home',
      component: AssetManageRechargeDetail
    }, {
      path: '/AccountInfo/AssetManageBondDetail',
      exact: true,
      name: '保证金明细',
      icon: 'home',
      component: AssetManageBondDetail
    }, {
      path: '/AccountInfo/AssetManageZDetail',
      exact: true,
      name: 'Z币明细',
      icon: 'home',
      component: AssetManageZDetail
    }, {
      path: '/Shield',
      exact: true,
      name: '屏蔽类目',
      icon: 'home',
      component: AccountShieldType
    }]
  }, {
    path: '/Yiye/CouponCode',
    exact: true,
    name: '券码',
    icon: 'file-search',
    subRoutes: [{
      path: '/List',
      exact: true,
      name: '券码管理',
      icon: 'home',
      component: CouponCodeManageList
    }, {
      path: '/Add/:Id',
      exact: true,
      name: '券码新增',
      hide: true,
      icon: 'home',
      component: CouponCodeAdd
    }]
  }, {
    path: '/Yiye/ImportGoods',
    exact: true,
    name: '文件导入',
    icon: 'home',
    hide: true,
    component: ImportSKU
  }, {
    path: '/Yiye/Download',
    exact: true,
    name: '下载中心',
    icon: 'download',
    component: DownLoad
  }
];

export default subRoutes;
