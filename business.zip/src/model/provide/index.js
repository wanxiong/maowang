import {
  configure, observable, action, runInAction
} from 'mobx';
import {
  GetProvideCouponAddSave,
  GetProvidePlatformCouponList,
  GetProvidePlatformCouponStatus,
  GetProvideOrderList,
  GetProvideOrderShopStatus,
  GetProvideOrderSysStatus,
  GetProvideOrderExamineDetail,
  GetProvideOrderExamineSave,
  GetProvideOrderChangeReward,
  GetProvideOrderReportList,
  GetProvideOrderReportDetailList,
  GetProvideOrderReportDownLoad,
  GetProvideOrderDownLoad,
  GetDownloadProConsumeDtl,
  GetDownloadProConsumeNewDtl
} from '../../services/provide';
// 不允许在动作外部修改状态
configure({ enforceActions: 'never' });

class Provide {
  // 我要供货-平台券-列表字段
  @observable ProvidePlatformCouponList = {}

  // 我要供货-平台券-新建平台券-保存接口
  // 我要供货-平台券-列表字段
  @observable providePlatformCouponList = {
    PagedList: [],
    TotalRowsCount: 0
  }

  // 我要供货-供货报表-一览
  @observable provideOrderReportList = {
    PagedList: [],
    TotalRowsCount: 0,
    Data: {}
  }

  // 我要供货-供货报表-详情列表接口
  @observable provideOrderReportDetailList = {
    PagedList: [],
    TotalRowsCount: 0
  }

  // 我要供货-供货单-列表接口
  @observable provideOrderList = {
    PagedList: [],
    TotalRowsCount: 0
  }

  @action fetchProvideCouponAddSave = async (params) => {
    try {
      return await GetProvideCouponAddSave(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 我要供货-平台券-列表接口
  @action fetchProvidePlatformCouponList = async (params) => {
    try {
      const { Data } = await GetProvidePlatformCouponList(params);
      runInAction(() => {
        this.providePlatformCouponList = Data;
      });
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
    }
  }

  // 我要供货-平台券-上架/下架 || 我要采购-平台券-开启/禁用接口
  @action fetchProvidePlatformCouponStatus = async (params) => {
    try {
      return await GetProvidePlatformCouponStatus(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 我要供货-供货单-列表接口
  @action fetchProvideOrderList = async (params) => {
    try {
      const { Data } = await GetProvideOrderList(params);
      runInAction(() => {
        this.provideOrderList = Data;
      });
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
    }
  }

  // 我要供货-平台券-店铺状态
  @action fetchProvideOrderShopStatus = async (params) => {
    try {
      return await GetProvideOrderShopStatus(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 我要供货-平台券-新建平台券-适用门店
  @action fetchProvideOrderSysStatus = async (params) => {
    try {
      return await GetProvideOrderSysStatus(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 我要供货-供货单-审核--详情接口
  @action fetchProvideOrderExamineDetail = async (params) => {
    try {
      return await GetProvideOrderExamineDetail(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 我要供货-供货单-审核--保存
  @action fetchProvideOrderExamineSave = async (params) => {
    try {
      return await GetProvideOrderExamineSave(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 我要供货-供货单-改价
  @action fetchProvideOrderChangeReward = async (params) => {
    try {
      return await GetProvideOrderChangeReward(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 我要供货-供货报表-一览
  @action fetchProvideOrderReportList = async (params) => {
    try {
      const { Data } = await GetProvideOrderReportList(params);
      runInAction(() => {
        this.provideOrderReportList = Data;
      });
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
    }
  }

  // 我要供货-供货报表-详情列表接口
  @action fetchProvideOrderReportDetailList = async (params) => {
    try {
      const { Data } = await GetProvideOrderReportDetailList(params);
      runInAction(() => {
        this.provideOrderReportDetailList = Data;
      });
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
    }
  }

  // 我要供货-供货报表-导出
  @action fetchProvideOrderReportDownLoad = async (params) => {
    try {
      return await GetProvideOrderReportDownLoad(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 我要供货-供货单-导出
  @action fetchProvideOrderDownLoad = async (params) => {
    try {
      return await GetProvideOrderDownLoad(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 供货单-核销明细-导出
  @action fetchDownloadProConsumeDtl = async (params = {}) => {
    try {
      return await GetDownloadProConsumeDtl(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 供货单-供货报表-拉新明细下载
  @action fetchDownloadProConsumeNewDtl = async (params = {}) => {
    try {
      return await GetDownloadProConsumeNewDtl(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }
}

export default new Provide();
