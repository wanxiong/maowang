import {
  configure, observable, action, runInAction
} from 'mobx';
import {
  GetDownLoadTypeList,
  GetDownLoadList,
  GetDownLoad,
  GetDownLoadReset,
  GetDownLoadDelete,
  GetDownLoadCrm,
  GetDownLoadResetCrm,
  GetDownLoadDeleteCrm
} from '../../services/download';
// 不允许在动作外部修改状态
configure({ enforceActions: 'never' });

class CommonApi {
  @observable downLoadList = {
    PagedList: [],
    TotalRowsCount: 0
  }

  // 下载中心-下载类型列表接口
  @action fetchDownLoadTypeList = async (params) => {
    try {
      return await GetDownLoadTypeList(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 下载中心-列表接口
  @action fetchDownLoadList = async (params) => {
    try {
      const { Data } = await GetDownLoadList(params);
      runInAction(() => {
        this.downLoadList = Data;
      });
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
    }
  }

  // 下载中心-下载接口
  @action fetchDownLoad = async (params) => {
    try {
      return await GetDownLoad(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 下载中心-重新计算接口
  @action fetchDownLoadReset = async (params) => {
    try {
      return await GetDownLoadReset(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 下载中心-删除
  @action fetchDownLoadDelete = async (params) => {
    try {
      return await GetDownLoadDelete(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 下载中心-下载接口-crm
  @action fetchDownLoadCrm = async (params) => {
    try {
      return await GetDownLoadCrm(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 下载中心-重新计算接口-crm
  @action fetchDownLoadResetCrm = async (params) => {
    try {
      return await GetDownLoadResetCrm(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 下载中心-删除-crm
  @action fetchDownLoadDeleteCrm = async (params) => {
    try {
      return await GetDownLoadDeleteCrm(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }
}

export default new CommonApi();
