import {
  configure, action, runInAction, observable
} from 'mobx';
import moment from 'moment';
import {
  RequestChannelList,
  CreateNewChannel,
  EditNewChannel,
  GetChannelRegisterSetting,
  SaveChannelRegisterSetting,
  GetGiftbagsList,
  RequestNewChannelDetail,
  GetBrandMsgCfg,
  GetChannelExportDetail
} from '../../services/channel';
// 不允许在动作外部修改状态
configure({ enforceActions: 'never' });
const detailData = {
  Id: null,
  CopId: null,
  BrandId: null,
  ActName: "",
  IsSendReward: true,
  BackGrdColor: "",
  BackGrdImage: "",
  Remark: "",
  IsShowWxQrImg: true,
  Content: "",
  BeginDate: "",
  EndDate: "",
  PV: 0,
  RegNum: 0,
  SendNum: 0,
  PresentType: "CN",
  CouponGrpId: 0,
  CouponGrpName: "",
  Bonus: 0,
  CouponValidType: null,
  CouponValidStart: 0,
  CouponDuration: 0,
  CouponValidStartTime: "",
  CouponValidEndTime: "",
  CouponGuide: "",
  LimitNum: "",
  IsSendNote: true,
  SendNote: "",
  CreateUser: "",
  CreateDate: "",
  LastModifiedUser: null,
  LastModifiedDate: "",
  FullBackGrdImage: null,
  ActUrl: "",
  GiftDtl: null,
  CoupGrps: null,
  IsNewVipReward: false,
  LimitType: 2,
  SendMessageType: 1,
  RegisterPageName: '',
  IsDefaultField: true,
  CouponOrigin: 0,
  CouponType: ""
};


const list = [{
  key: 'telephone',
  name: '手机号',
  isOpen: true,
  FieldName: "手机号码",
  url: 'https://assets-img.ezrpro.com/yiye/pc/telephone.png',
  FieldValue: "MobileNo",
  SortIdx: 1,
  CanEmpty: false,
  MchId: 1
}, {
  key: 'password',
  name: '验证码',
  url: 'https://assets-img.ezrpro.com/yiye/pc/password.png',
  isOpen: true,
  FieldName: "验证码",
  FieldValue: "Password",
  SortIdx: 2,
  CanEmpty: false,
  MchId: 1
}, {
  key: 'name',
  name: '姓名',
  url: 'https://assets-img.ezrpro.com/yiye/pc/name.png',
  isOpen: false,
  FieldName: "姓名",
  FieldValue: "Name",
  SortIdx: 3,
  CanEmpty: true,
  MchId: 1
}, {
  key: 'location',
  name: '所在城市',
  url: 'https://assets-img.ezrpro.com/yiye/pc/location.png',
  isOpen: false,
  FieldName: "所在城市",
  FieldValue: "Address",
  SortIdx: 4,
  CanEmpty: true,
  MchId: 1
}, {
  key: 'birthday',
  name: '生日',
  url: 'https://assets-img.ezrpro.com/yiye/pc/birthday.png',
  isOpen: false,
  FieldName: "生日",
  FieldValue: "Birthday",
  SortIdx: 5,
  CanEmpty: true,
  MchId: 1
}, {
  key: 'sex',
  name: '性别',
  url: 'https://assets-img.ezrpro.com/yiye/pc/sex.png',
  isOpen: false,
  FieldName: "性别",
  FieldValue: "Sex",
  SortIdx: 6,
  CanEmpty: true,
  MchId: 1
}];

class AccountAudit {
    @observable channelList = {
      Data: [],
      PagedList: [],
      TotalRowsCount: 0
    }

    @observable channelListLoading = false

    @observable channelFormData = {}

    @observable channelCouponList = {
      Data: [],
      PagedList: [],
      TotalRowsCount: 0
    }

    @observable channelMobileList = []

    @observable channelDetail = []

    @observable channelMessageData = []

    // 列表
    @action fetchChannelList = async (params) => {
      this.channelListLoading = true;
      try {
        const { Data } = await RequestChannelList(params);
        runInAction(() => {
          this.channelList = Data;
          this.channelListLoading = false;
        });
      } catch (error) {
        runInAction(() => {
          this.channelListLoading = false;
        });
      }
    }

    // 新建
    @action fetchCreateNewChannel = async (params) => {
      try {
        const { Data } = await CreateNewChannel(params);
        runInAction(() => {
          this.merchantApplyList = Data;
        });
      } catch (error) {
        runInAction(() => {
          // console.log(error);
        });
      }
    }

    // RequestNewChannelDetail
    // 详情
    @action fetchChannelDetail = async (params) => {
      try {
        if (params.id === '0' || params.id === 0) {
          runInAction(() => {
            this.channelDetail = detailData;
          });
        } else {
          const { Data } = await RequestNewChannelDetail(params);
          runInAction(() => {
            if (Data.GiftDtl && Data.GiftDtl.length) {
              for (let i = 0; i < Data.GiftDtl.length; i++) {
                const isRandgeTime = Data.GiftDtl[i].CouponBeginDate.includes('0001-01-01');
                // eslint-disable-next-line max-len
                Data.GiftDtl[i].CouponTimes = isRandgeTime ? ['', ''] : [moment(Data.GiftDtl[i].CouponBeginDate).format('YYYY-MM-DD HH:mm:ss'), moment(Data.GiftDtl[i].CouponEndDate).format('YYYY-MM-DD HH:mm:ss')];
                Data.GiftDtl[i].CouponValidTypeTem = isRandgeTime ? 'CM' : 'TS';
              }
            }
            this.channelDetail = Data;
          });
        }
      } catch (error) {
        runInAction(() => {
          // console.log(error);
        });
      }
    }

    @action saveChannelDetail = (status) => {
      this.channelDetail = status;
    }

    // 编辑
    @action fetchEditNewChannel = async (params) => {
      try {
        return await EditNewChannel(params);
      } catch (error) {
        runInAction(() => {
          // console.log(error);
        });
        return false;
      }
    }

    // 账号设置
    @action fetchChannelRegisterSetting = async (params) => {
      const { Data } = await GetChannelRegisterSetting(params);
      try {
        runInAction(() => {
          const channelMobileList = Data;
          // console.log('Data ==== ', Data);
          // console.log('list ==== ', list);
          const listSource = JSON.parse(JSON.stringify(list));
          for (let i = 0; i < channelMobileList.length; i++) {
            for (let j = 0; j < listSource.length; j++) {
              const tempData = channelMobileList[i];
              const listItem = listSource[j];
              // console.log('tempData.FieldValue ==== ', tempData.FieldValue);
              // console.log('listItem.FieldValue ==== ', tempData.FieldValue);
              if (tempData.FieldName === listItem.FieldName) {
                // console.log('tempData.FieldValue ==== ', tempData.FieldName);
                listItem.FieldName = tempData.FieldName;
                listItem.FieldValue = tempData.FieldValue;
                listItem.SortIdx = tempData.SortIdx;
                listItem.CanEmpty = tempData.CanEmpty;
                listItem.isOpen = true;
                listSource[j] = listItem;
              }
            }
          }
          // console.log('list ==== ', listSource.map(e => e.isOpen));
          this.channelMobileList = listSource;
        });
      } catch (error) {
        runInAction(() => {
        });
      }
    }

    @action saveMobileList = async (params) => {
      try {
        runInAction(() => {
          this.channelMobileList = params;
        });
      } catch (error) {
        runInAction(() => {
          // console.log(error);
        });
      }
    }

    @action saveAccountSetting = async (params, awaiting = false) => {
      try {
        if (awaiting) {
          return await SaveChannelRegisterSetting(params);
        }
        return SaveChannelRegisterSetting(params);
      } catch (error) {
        runInAction(() => {
          // console.log(error);
        });
        return false;
      }
    }

    // 暂存Form列表状态
    @action saveFormState = async (params) => {
      try {
        runInAction(() => {
          this.channelFormData = params;
        });
      } catch (error) {
        runInAction(() => {
          // console.log(error);
        });
      }
    }

    // 券包
    @action fetchGiftbagsList = async (params) => {
      try {
        const { Data } = await GetGiftbagsList(params);
        runInAction(() => {
          this.channelCouponList = Data.Data;
        });
      } catch (error) {
        runInAction(() => {
          // console.log(error);
        });
      }
    }

    @action fetchBrandMsgCfg = async (params) => {
      try {
        const { Data } = await GetBrandMsgCfg(params);
        runInAction(() => {
          this.channelMessageData = Data;
        });
      } catch (error) {
        runInAction(() => {
          // console.log(error);
        });
      }
    }

    // 导出活动明细
    @action fetchChannelExportDetail = async (params = {}) => {
      try {
        return await GetChannelExportDetail(params);
      } catch (error) {
        return false;
      }
    }
}

export default new AccountAudit();
