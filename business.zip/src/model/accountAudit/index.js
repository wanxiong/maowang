import {
  configure, action, runInAction, observable
} from 'mobx';
import {
  GetMerchantApplyList,
  GetMerchantApplyCheck,
  GetMerchantEnable,
  GetMerchantChangeAccountType,
  GetCrmBrandInfo,
  MerchantInsertOfInitWithCrm
} from '../../services/accountAudit';
// 不允许在动作外部修改状态
configure({ enforceActions: 'never' });

class AccountAudit {
  @observable merchantApplyList = {
    Data: [],
    Count: 0
  }

  // 审核品牌商入住申请
  @action fetchMerchantApplyCheck = async (params) => {
    try {
      return await GetMerchantApplyCheck(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 商户审核列表
  @action fetchMerchantApplyList = async (params) => {
    try {
      const { Data } = await GetMerchantApplyList(params);
      runInAction(() => {
        this.merchantApplyList = Data;
      });
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
    }
  }

  // 商户审核--启用/禁用
  @action fetchMerchantEnable = async (params) => {
    try {
      return await GetMerchantEnable(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 商户审核--担保账户/普通账户 切换
  @action fetchMerchantChangeAccountType = async (params) => {
    try {
      return await GetMerchantChangeAccountType(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 账户审核-初始化品牌客户-查看对应的品牌信息
  @action fetchCrmBrandInfo = async (params) => {
    try {
      return await GetCrmBrandInfo(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 账户审核-平台初始化商户数据带初始化券平台
  @action fetchMerchantInsertOfInitWithCrm = async (params) => {
    try {
      return await MerchantInsertOfInitWithCrm(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }
}

export default new AccountAudit();
