import {
  configure, observable, action, runInAction
} from 'mobx';
import {
  GetExportCenterGoodsLogList,
  GetExportCenterSkuLogList,
  GetExportCenterGoodsList,
  GetExportCenterUploadSku,
  GetExportCenterUploadNumber,
  DeleteProData,
  DeleteSkuData,
  GetCouponCodeUpload,
  GetCouponCodeUploadList,
  GetCouponCodeDownExcel,
  GetDownExcelDefaultGet,
  GetUploadExcelDefaultPost,
  GetDownExcelDefaultPost
} from '../../services/importCenter';
// 不允许在动作外部修改状态
configure({ enforceActions: 'never' });

class ImportCenter {
  @observable importList = {
    PagedList: [],
    TotalRowsCount: 0
  }

  @observable recordList = []

  @observable couponCodeUploadList = []

  // 导入中心-商品券导入日志
  @action fetchExportCenterGoodsLogList = async (params) => {
    try {
      const { Data } = await GetExportCenterGoodsLogList(params);
      runInAction(() => {
        this.recordList = Data;
      });
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
    }
  }

  // 导入中心-sku导入日志
  @action fetchExportCenterSkuLogList = async (params) => {
    try {
      const { Data } = await GetExportCenterSkuLogList(params);
      runInAction(() => {
        this.recordList = Data;
      });
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
    }
  }

  // 导入中心-商品券导入-导入明细
  @action fetchExportCenterGoodsList = async (params) => {
    try {
      const { Data } = await GetExportCenterGoodsList(params);
      runInAction(() => {
        this.importList = Data;
      });
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
    }
  }

  // 导入中心-商品券导入-按SKU
  @action fetchExportCenterUploadSku = async (params) => {
    try {
      return await GetExportCenterUploadSku(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 导入中心-商品券导入-按商品||货号
  @action fetchExportCenterUploadNumber = async (params) => {
    try {
      return await GetExportCenterUploadNumber(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 删除货号
  @action fetchDeleteProData = async (params) => {
    try {
      return await DeleteProData(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 删除sku
  @action fetchDeleteSkuData = async (params) => {
    try {
      return await DeleteSkuData(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 销售订单-导入券码 => 导出页面-文件上传
  @action fetchCouponCodeUpload = async (params, fileObj) => {
    try {
      return await GetCouponCodeUpload(params, fileObj);
    } catch (error) {
      return false;
    }
  }

  // 销售订单-导入券码 => 导出页面-文件上传列表
  @action fetchCouponCodeUploadList = async (params) => {
    try {
      const { Data } = await GetCouponCodeUploadList(params);
      runInAction(() => {
        this.couponCodeUploadList = Data;
      });
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
    }
  }

  // 销售订单-导入券码 => 导出页面-模板下载
  @action fetchCouponCodeDownExcel = async (params) => {
    try {
      return await GetCouponCodeDownExcel(params);
    } catch (error) {
      return false;
    }
  }

  //  文件下载-通用get
  @action fetchDownExcelDefaultGet = async (url, params = {}) => {
    try {
      return await GetDownExcelDefaultGet(url, params);
    } catch (error) {
      return false;
    }
  }

  //  文件下载-通用post
  @action fetchUploadExcelDefaultPost = async (url = '', params = {}, fileObj) => {
    try {
      return await GetUploadExcelDefaultPost(url, params, fileObj);
    } catch (error) {
      return false;
    }
  }

  //  文件下载-通用post
  @action fetchDownExcelDefaultPost = async (url, params = {}) => {
    try {
      return await GetDownExcelDefaultPost(url, params);
    } catch (error) {
      return false;
    }
  }
}

export default new ImportCenter();
