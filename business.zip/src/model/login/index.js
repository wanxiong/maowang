import {
  configure, action, runInAction
} from 'mobx';
import {
  GetLogin, GetResetPassword, GetVerifyCode, GetLogout, GetMerchantSelf
} from '../../services/login';
// 不允许在动作外部修改状态
configure({ enforceActions: 'never' });

class Login {
  // 登陆接口
  @action fetchLogin = async (params) => {
    try {
      return await GetLogin(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 重置密码接口
  @action fetchResetPassword = async (params) => {
    try {
      return await GetResetPassword(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 发送验证码--供重置密码用
  @action fetchGetVerifyCode = async (params) => {
    try {
      return await GetVerifyCode(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 退出操作
  @action fetchLogout = async (params) => {
    try {
      return await GetLogout(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 获取当前账户类型---如商户还是平台
  @action fetchMerchantSelf = async (params) => {
    try {
      return await GetMerchantSelf(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }
}

export default new Login();
