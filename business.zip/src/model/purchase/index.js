import {
  configure, observable, action, runInAction
} from 'mobx';
import {
  GetPurchaseCouponList,
  GetPurchaseApply,
  GetPurchaseOrderList,
  GetPurchaseOrderDelete,
  GetPurchasePlatformCouponList,
  GetPurchaseCouponListBrand,
  GetPurchaseCouponCategory,
  GetPurchaseCouponBrandByCate,
  GetPurchaseCouponListDetail,
  GetPurchaseCouponDetailCity,
  GetPurchaseOrderReportList,
  GetPurchaseOrderReportDownLoad,
  GetPurchaseOrderDownLoad,
  GetDownloadPurConsumeDtl,
  GetUnionProGrpList,
  GetProBrandList,
  GetProPgTagList
} from '../../services/purchase';
// 不允许在动作外部修改状态
configure({ enforceActions: 'never' });

class Purchase {
  //
  @observable purchaseOrderList = {
    PagedList: [],
    TotalRowsCount: 0
  }

  // 我要采购-优惠券-列表接口
  @observable purchaseCouponList = {
    PagedList: [],
    TotalRowsCount: 0
  }

  @observable purchasePlatformCouponList = {
    PagedList: [],
    TotalRowsCount: 0
  }

  @observable purchaseOrderReportList = {
    PagedList: [],
    TotalRowsCount: 0,
    Data: {}
  }

  // 我要采购-驿业券-列表接口
  @observable yiyeCouponList = {
    PagedList: [],
    TotalRowsCount: 0
  }

  // 我要采购-优惠券-列表接口
  @action fetchPurchaseCouponList = async (params) => {
    try {
      const { Data } = await GetPurchaseCouponList(params);
      runInAction(() => {
        this.purchaseCouponList = Data;
      });
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
    }
  }

  // 我要采购-优惠券-商品详情-申请采购接口
  @action fetchPurchaseApply = async (params) => {
    try {
      return await GetPurchaseApply(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 我要采购-采购单-列表接口
  @action fetchPurchaseOrderList = async (params) => {
    try {
      const { Data } = await GetPurchaseOrderList(params);
      runInAction(() => {
        this.purchaseOrderList = Data;
      });
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
    }
  }

  // 我要采购-采购单-删除接口
  @action fetchPurchaseOrderDelete = async (params) => {
    try {
      return await GetPurchaseOrderDelete(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 我要采购-平台券-列表接口
  @action fetchPurchasePlatformCouponList = async (params) => {
    try {
      const { Data } = await GetPurchasePlatformCouponList(params);
      runInAction(() => {
        this.purchasePlatformCouponList = Data;
      });
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
    }
  }

  // 我要采购-优惠券-品牌列表
  @action fetchPurchaseCouponListBrandList = async (params = {}) => {
    try {
      return await GetPurchaseCouponListBrand(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 我要采购-优惠券-类目列表
  @action fetchPurchaseCouponCategoryList = async (params = {}) => {
    try {
      return await GetPurchaseCouponCategory(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 我要采购-优惠券-根据类目获取品牌列表
  @action fetchPurchaseCouponBrandByCateList = async (params = {}) => {
    try {
      return await GetPurchaseCouponBrandByCate(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 我要采购-优惠券-优惠券详情
  @action fetchPurchaseCouponListDetail = async (params = {}) => {
    try {
      return await GetPurchaseCouponListDetail(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 我要采购-券详情-门店分布
  @action fetchPurchaseCouponDetailCity = async (params = {}) => {
    try {
      return await GetPurchaseCouponDetailCity(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 我要采购-券详情-门店分布
  @action fetchPurchaseOrderReportList = async (params = {}) => {
    try {
      const { Data } = await GetPurchaseOrderReportList(params);
      runInAction(() => {
        this.purchaseOrderReportList = Data;
      });
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
    }
  }

  // 我要采购-采购报表-导出
  @action fetchPurchaseOrderReportDownLoad = async (params = {}) => {
    try {
      return await GetPurchaseOrderReportDownLoad(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 我要采购-采购单-导出
  @action fetchPurchaseOrderDownLoad = async (params = {}) => {
    try {
      return await GetPurchaseOrderDownLoad(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 采购单-核销明细-导出
  @action fetchGetDownloadPurConsumeDtl = async (params = {}) => {
    try {
      return await GetDownloadPurConsumeDtl(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 我要采购-驿业券列表
  @action fetchUnionProGrpList = async (params = {}) => {
    try {
      const { Data } = await GetUnionProGrpList(params);
      runInAction(() => {
        this.yiyeCouponList = Data;
      });
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
    }
  }

  // 获取商品品牌列表
  @action fetchProBrandList = async (params) => {
    try {
      return await GetProBrandList(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 获得商品权益标签列表/我要采购-驿业券列表-类型
  @action fetchProPgTagList = async (params) => {
    try {
      return await GetProPgTagList(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }
}

export default new Purchase();
