import {
  configure, observable, action, runInAction
} from 'mobx';
import {
  GetBaseCouponList,
  GetMerchantBrandList,
  GetProductBrandList,
  GetBasePromotionCouponList
} from '../../services/common';
// 不允许在动作外部修改状态
configure({ enforceActions: 'never' });

class CommonApi {
  @observable miniProgramWxOpenCfg = {}

  // 获取券模板列表一览
  @action fetchBaseCouponList = async (params) => {
    try {
      return await GetBaseCouponList(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 获取商户所有品牌信息接口
  @action fetchMerchantBrandList = async (params) => {
    try {
      return await GetMerchantBrandList(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 获取驿业品牌列表
  @action fetchProductBrandList = async (params) => {
    try {
      return await GetProductBrandList(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 获取促销券一览接口
  @action fetchBasePromotionCouponList = async (params) => {
    try {
      return await GetBasePromotionCouponList(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }
}

export default new CommonApi();
