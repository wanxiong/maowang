import {
  configure, action, runInAction, observable
} from 'mobx';
import {
  GetMerchantWriteRateList,
  GetMerchantWriteRateEdit,
  GetMerchantPlatformFeeList,
  GetMerchantPlatformFeeEdit,
  GetMerchantPlatformFeeEnable,
  GetMerchantFreezeRatioList,
  GetMerchantFreezeRatioEnable,
  GetMerchantFreezeRatioEdit,
  GetMerchantDefaultSettingFee,
  GetMerchantDefaultExport,
  GetMerchantWriteRateAdd
} from '../../services/transaction';
// 不允许在动作外部修改状态
configure({ enforceActions: 'never' });

class Transaction {
  // 券交易-核销率列表-列表字段
  @observable merchantWriteRateList = {
    Data: [],
    Count: 0
  }

  // 券交易-平台手续费优惠-列表字段
  @observable merchantPlatformFeeList = {
    Data: [],
    Count: 0
  }

  // 券交易-冻结比列--列表接口
  @observable merchantFreezeRatioList = {
    Data: [],
    Count: 0
  }

  // 券交易-核销率列表
  @action fetchMerchantWriteRateList = async (params) => {
    try {
      const { Data } = await GetMerchantWriteRateList(params);
      runInAction(() => {
        this.merchantWriteRateList = Data;
      });
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
    }
  }

  // 核销率-核销编辑接口
  @action fetchMerchantWriteRateEdit = async (params) => {
    try {
      return await GetMerchantWriteRateEdit(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 券交易-平台手续费优惠-列表接口
  @action fetchMerchantPlatformFeeList = async (params) => {
    try {
      const { Data } = await GetMerchantPlatformFeeList(params);
      runInAction(() => {
        this.merchantPlatformFeeList = Data;
      });
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
    }
  }

  // 券交易-平台手续费优惠-新增/编辑
  @action fetchMerchantPlatformFeeEdit = async (params) => {
    try {
      return await GetMerchantPlatformFeeEdit(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 券交易-平台手续费优惠--禁用/启用
  @action fetchMerchantPlatformFeeEnable = async (params) => {
    try {
      return await GetMerchantPlatformFeeEnable(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 券交易-冻结比列--列表接口
  @action fetchMerchantFreezeRatioList = async (params) => {
    try {
      const { Data } = await GetMerchantFreezeRatioList(params);
      runInAction(() => {
        this.merchantFreezeRatioList = Data;
      });
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
    }
  }

  // 券交易-冻结比列--列表接口
  @action fetchMerchantFreezeRatioEnable = async (params) => {
    try {
      return await GetMerchantFreezeRatioEnable(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 券交易-冻结比列-新增/编辑
  @action fetchMerchantFreezeRatioEdit = async (params) => {
    try {
      return await GetMerchantFreezeRatioEdit(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 平台默认---手续费/核销率/冻结比例
  @action fetchMerchantDefaultSettingFee = async (params) => {
    try {
      return await GetMerchantDefaultSettingFee(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 核销率--- 列表导出
  @action fetchMerchantDefaultExport = async (params) => {
    try {
      return await GetMerchantDefaultExport(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 核销率--- 新增/编辑
  @action fetchMerchantWriteRateAdd = async (params) => {
    try {
      return await GetMerchantWriteRateAdd(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }
}

export default new Transaction();
