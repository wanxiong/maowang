import accountStore from './account';
import CommonApi from './common';
import loginStore from './login';
import transactionStore from './transaction';
import accountAuditStore from './accountAudit';
import downloadStore from './download';
import purchaseStore from './purchase';
import provideStore from './provide';
import supplierStore from './supplier';
import supplierManagement from './supplier/supplierManagement';
import supplierSaleReport from './supplier/saleReport/saleReport';
import importCenterStore from './importCenter';
import brandManagement from './supplier/brandManagement';
import supplierSaleReportProduction from './supplier/saleReport/production';
import supplierSaleReportBrand from './supplier/saleReport/brand';
import systemManageStore from './systemManage';
import channel from './channel';
import CouponCodeStore from './couponCode';

export {
  CommonApi,
  accountStore,
  loginStore,
  transactionStore,
  accountAuditStore,
  downloadStore,
  purchaseStore,
  provideStore,
  supplierStore,
  supplierManagement,
  supplierSaleReport,
  supplierSaleReportProduction,
  supplierSaleReportBrand,
  brandManagement,
  importCenterStore,
  systemManageStore,
  channel,
  CouponCodeStore
};
