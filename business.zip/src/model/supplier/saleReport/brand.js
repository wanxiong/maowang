import {
  configure, action, runInAction, observable
} from 'mobx';
import {
  GetBrandSaleReportList
} from '../../../services/saleReport';
// 不允许在动作外部修改状态
configure({ enforceActions: 'never' });

class SupplierBrandSaleReportList {
        @observable totalRowsCount = 0;

        @observable queryPageList = [];

        @observable totalData = {};

         @action SaleReportBrandList = async (params) => {
           try {
             const { Data: { Data, TotalRowsCount, PagedList } } = await GetBrandSaleReportList(params);
             runInAction(() => {
               this.queryPageList = PagedList;
               this.totalRowsCount = TotalRowsCount;
               this.totalData = Data;
             });
           } catch (error) {
             runInAction(() => {
               // console.log(error);
             });
           }
         }
}

export default new SupplierBrandSaleReportList();
