import {
  configure, action, runInAction, observable
} from 'mobx';
import {
  GetCouponSaleReportList
} from '../../../services/saleReport';
// 不允许在动作外部修改状态
configure({ enforceActions: 'never' });

class SupplierProductionSaleReportList {
      @observable totalRowsCount = 0;

      @observable queryPageList = [];

      @observable totalData = {};

       @action SaleReportProductionList = async (params) => {
         try {
           const { Data: { Data, TotalRowsCount, PagedList } } = await GetCouponSaleReportList(params);
           runInAction(() => {
             this.queryPageList = PagedList;
             this.totalRowsCount = TotalRowsCount;
             this.totalData = Data;
           });
         } catch (error) {
           runInAction(() => {
             // console.log(error);
           });
         }
       }
}

export default new SupplierProductionSaleReportList();
