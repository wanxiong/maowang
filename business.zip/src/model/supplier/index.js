import {
  configure, action, runInAction, observable
} from 'mobx';
import {
  GetSupplierGoodsList,
  GetSupplierUploadImg,
  GetQueryAllSupplier,
  GetSupplierSaleOrderList
} from '../../services/supplier';
// 不允许在动作外部修改状态
configure({ enforceActions: 'never' });

class Supplier {
  // 商品管理数据
  @observable supplierGoodsList = {
    PagedList: [],
    TotalRowsCount: 0
  }

  // 供应商-销售订单-列表-数据
  @observable supplierSaleOrderList = {
    PagedList: [],
    TotalRowsCount: 0
  }

   // 供应商-商品管理-列表接口
   @action fetchSupplierGoodsList = async (params) => {
     try {
       const { Data } = await GetSupplierGoodsList(params);
       runInAction(() => {
         this.supplierGoodsList = Data;
       });
     } catch (error) {
       runInAction(() => {
         // console.log(error);
       });
     }
   }

  // 供应商-商品管理-新增-上传商品图片
  @action fetchSupplierUploadImg = async (params) => {
    try {
      return await GetSupplierUploadImg(params);
    } catch (error) {
      return false;
    }
  }

  // 供应商-商品管理-获取所有供应商
  @action fetchQueryAllSupplier = async (params) => {
    try {
      return await GetQueryAllSupplier(params);
    } catch (error) {
      return false;
    }
  }

  // 供应商-销售订单-列表
  @action fetchSupplierSaleOrderList = async (params) => {
    try {
      const { Data } = await GetSupplierSaleOrderList(params);
      runInAction(() => {
        this.supplierSaleOrderList = Data;
      });
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
    }
  }
}

export default new Supplier();
