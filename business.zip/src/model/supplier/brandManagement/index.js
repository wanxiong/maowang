import {
  configure, action, runInAction, observable
} from 'mobx';
import {
  QueryByPage
} from '../../../services/brandManagement';
// 不允许在动作外部修改状态
configure({ enforceActions: 'never' });

class BrandManagement {
  @observable TotalRowsCount = 0;

  @observable queryPageList = [];

   // 供应商-商品管理-列表接口
   @action QueryByPage = async (params) => {
     try {
       const { Data: { Data, Count } } = await QueryByPage(params);
       runInAction(() => {
         this.queryPageList = Data;
         this.TotalRowsCount = Count;
       });
     } catch (error) {
       runInAction(() => {
         // console.log(error);
       });
     }
   }
}

export default new BrandManagement();
