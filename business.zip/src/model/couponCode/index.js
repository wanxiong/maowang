import {
  configure, observable, action, runInAction
} from 'mobx';
import {
  GetCouponCodeList,
  GetCouponCodeDetil,
  GetCouponCodeExport,
  GetCouponListAddStock,
  GetCouponSaveData,
  GetCouponListAddDetail,
  GetCouponYyStock
} from '../../services/couponCode';
// 不允许在动作外部修改状态
configure({ enforceActions: 'never' });

class CouponCode {
  @observable couponCodeList = {
    PagedList: [],
    TotalRowsCount: 0
  }

  // 券码管理-列表接口
  @action fetchCouponCodeList = async (params) => {
    try {
      const { Data } = await GetCouponCodeList(params);
      runInAction(() => {
        this.couponCodeList = Data;
      });
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
    }
  }

  // 券码管理-详情接口
  @action fetchCouponCodeDetil = async (params) => {
    try {
      return await GetCouponCodeDetil(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 券码管理-导出接口
  @action fetchCouponCodeExport = async (params) => {
    try {
      return await GetCouponCodeExport(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 券码管理-增加制券
  @action fetchCouponListAddStock = async (params) => {
    try {
      return await GetCouponListAddStock(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 券码管理-增加制券
  @action fetchCouponSaveData = async (params) => {
    try {
      return await GetCouponSaveData(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 券码管理-详情
  @action fetchCouponListAddDetail = async (params) => {
    try {
      return await GetCouponListAddDetail(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 券码管理-权益券库存显示
  @action fetchCouponYyStock = async (params) => {
    try {
      return await GetCouponYyStock(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }
}


export default new CouponCode();
