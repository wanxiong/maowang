import {
  configure, action, runInAction, observable
} from 'mobx';
import {
  GetSysRoleList,
  GetSysRoleAdd,
  GetSysRoleDel,
  GetSysRoleEdit,
  GetSysUserAdd,
  GetSysRoleDetail,
  GetSysUserList,
  GetSysUserUpdateStatus,
  GetSysUserUpdate,
  GetSysUserModifyPassword
} from '../../services/systemManage';
// 不允许在动作外部修改状态
configure({ enforceActions: 'never' });

class SystemManage {
  // 系统管理-角色管理-列表字段
  @observable sysRoleList = {
    Data: [],
    Count: 0
  }

  // 系统管理-用户管理-列表字段
  @observable sysUserList = {
    Data: [],
    Count: 0
  }

  // 系统管理-角色管理--列表接口
  @action fetchSysRoleList = async (params) => {
    try {
      const { Data } = await GetSysRoleList(params);
      runInAction(() => {
        this.sysRoleList = Data;
      });
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
    }
  }

  // 系统管理-角色管理--全部
  @action fetchSysRoleListAll = async (params) => {
    try {
      return await GetSysRoleList(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 系统管理-角色管理--新增
  @action fetchSysRoleAdd = async (params) => {
    try {
      return await GetSysRoleAdd(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 系统管理-角色管理--删除
  @action fetchSysRoleDel = async (params) => {
    try {
      return await GetSysRoleDel(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 系统管理-角色管理--编辑
  @action fetchSysRoleEdit = async (params) => {
    try {
      return await GetSysRoleEdit(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 系统管理-角色管理--详情
  @action fetchSysRoleDetail = async (params) => {
    try {
      return await GetSysRoleDetail(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 系统管理-用户管理--新增
  @action fetchSysUserAdd = async (params) => {
    try {
      return await GetSysUserAdd(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 系统管理-角色管理--列表接口
  @action fetchSysUserList = async (params) => {
    try {
      const { Data } = await GetSysUserList(params);
      runInAction(() => {
        this.sysUserList = Data;
      });
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
    }
  }

   // 系统管理-用户管理-冻结/启动/等状态接口
   @action fetchSysUserUpdateStatus = async (params) => {
     try {
       return await GetSysUserUpdateStatus(params);
     } catch (error) {
       runInAction(() => {
         // console.log(error);
       });
       return false;
     }
   }

  // 系统管理-用户管理-编辑接口
  @action fetchSysUserUpdate = async (params) => {
    try {
      return await GetSysUserUpdate(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 系统管理-用户管理-修改他人密码
  @action fetchSysUserModifyPassword = async (params) => {
    try {
      return await GetSysUserModifyPassword(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }
}

export default new SystemManage();
