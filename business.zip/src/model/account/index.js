import {
  configure, action, runInAction, observable
} from 'mobx';
import {
  GetAccountInfoSave,
  GetAccountInfoIndustryList,
  GetAccountInfoSelectAll,
  GetVerifyMerchant,
  BusinessLicenseUpload,
  GetBusinessLicense,
  GetAssetRechargeList,
  GetAssetRechargeCheck,
  GetAssetZDetailList,
  GetAssetBondDetailList,
  GetAssetBankSelectAll,
  GetAssetRechargeBankApply,
  GetAssetAccount,
  GetAssetRechargeBond,
  GetAssetRechargeZ,
  GetAccountShieldSetting,
  GetAccountShieldStatus,
  GetAccountShieldItem,
  GetAccountShieldItemList,
  GetAccountShieldDelItem,
  GetMerchantStatus,
  GetAssetAccountPlatformFee,
  GetAssetRechargeBankUpdate,
  GetAccountBrandList,
  GetAssetRechargeBankImageUpdate,
  GetAssetRechargeBankDetail,
  GetAccountRechargeExport,
  GetAccountRechargeBondExport,
  GetAccountRechargeZGive,
  GetAccountTradeNo,
  GetAccountRechargeZExport,
  GetAccountSelfMenuList,
  GetAccountAllMenuList,
  CheckBrandIncome,
  CheckBrandIncomeList,
  GetTotalBrandIncome
} from '../../services/account';
// 不允许在动作外部修改状态
configure({ enforceActions: 'never' });

class Account {
  @observable assetRechargeList = {
    Data: [],
    Count: 0
  }

  @observable assetZList = {
    Data: [],
    Count: 0
  }

  @observable assetBondList = {
    Dtls: [],
    Count: 0
  }

  @observable checkBrandIncomeList = {
    Data: '',
    PagedList: [],
    TotalRowsCount: 0,
    isRequest: false
  }

  @observable checkTotalBrandIncome = {
    Data: ''
  }

  // 账户管理-账户信息-保存接口
  @action fetchAccountInfoSave = async (params = {}) => {
    try {
      return await GetAccountInfoSave(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 获取账户信息一所属行业接口
  @action fetchAccountInfoIndustryList = async (params = {}) => {
    try {
      return await GetAccountInfoIndustryList(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 获取账户信息一经营类目
  @action fetchAccountInfoSelectAll = async (params = {}) => {
    try {
      return await GetAccountInfoSelectAll(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 获取商户门店状态接口
  @action fetchVerifyMerchant = async (params = {}) => {
    try {
      return await GetVerifyMerchant(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 获取商户店铺状态
  @action fetchMerchantStatus = async (params = {}) => {
    try {
      return await GetMerchantStatus(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 商户营业执照上传图片接口
  @action fetchBusinessLicenseUpload = async (params = {}) => {
    try {
      return await BusinessLicenseUpload(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 商户营业执照获取接口
  @action fetchGetBusinessLicense = async (params = {}) => {
    try {
      return await GetBusinessLicense(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 商户余额充值明细申请列表
  @action fetchGetAssetRechargeList = async (params = {}) => {
    try {
      const { Data } = await GetAssetRechargeList(params);
      runInAction(() => {
        this.assetRechargeList = Data;
      });
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
    }
  }

  // 商户余额充值明细审核
  @action fetchAssetRechargeCheck = async (params = {}) => {
    try {
      return await GetAssetRechargeCheck(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 资产管理-Z币-明细列表
  @action fetchGetAssetZDetailList = async (params = {}) => {
    try {
      const { Data } = await GetAssetZDetailList(params);
      runInAction(() => {
        this.assetZList = Data;
      });
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
    }
  }

  // 资产管理-保证金-明细列表
  @action fetchGetAssetBondDetailList = async (params = {}) => {
    try {
      const { Data } = await GetAssetBondDetailList(params);
      runInAction(() => {
        this.assetBondList = Data;
      });
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
    }
  }

  // 资产管理-保证金-明细列表
  @action fetchGetAssetBankSelectAll = async (params = {}) => {
    try {
      return await GetAssetBankSelectAll(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 资产管理-充值-商户充值余额申请
  @action fetchGetAssetRechargeBankApply = async (params = {}) => {
    try {
      return await GetAssetRechargeBankApply(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 资产管理-充值-商户充值余额修改
  @action fetchAssetRechargeBankUpdate = async (params = {}) => {
    try {
      return await GetAssetRechargeBankUpdate(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 资产管理-充值-商户充值银行流水截图修改
  @action fetchAssetRechargeBankImageUpdate = async (params = {}) => {
    try {
      return await GetAssetRechargeBankImageUpdate(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

   // 资产管理-充值-商户充值余额详情查询
   @action fetchAssetRechargeBankDetail = async (params = {}) => {
     try {
       return await GetAssetRechargeBankDetail(params);
     } catch (error) {
       runInAction(() => {
         // console.log(error);
       });
       return false;
     }
   }

  // 资产管理-查询财务账号信息
  @action fetchGetAssetAccount = async (params = {}) => {
    try {
      return await GetAssetAccount(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 资产管理-查询财务账号信息
  @action fetchAssetAccountPlatformFee = async (params = {}) => {
    try {
      return await GetAssetAccountPlatformFee(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 资产管理-商户缴纳保证金
  @action fetchGetAssetRechargeBond = async (params = {}) => {
    try {
      return await GetAssetRechargeBond(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 资产管理-商户充值Z币
  @action fetchGetAssetRechargeZ = async (params = {}) => {
    try {
      return await GetAssetRechargeZ(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 账号管理-商户屏蔽设置
  @action fetchGetAccountShieldSetting = async (params = {}) => {
    try {
      return await GetAccountShieldSetting(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 账号管理-商户屏蔽设置查询
  @action fetchGetAccountShieldStatus = async (params = {}) => {
    try {
      return await GetAccountShieldStatus(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 账号管理-商户屏蔽类目/品牌添加
  @action fetchGetAccountShieldItem = async (params = {}) => {
    try {
      return await GetAccountShieldItem(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 账号管理-商户屏蔽类目-品牌-列表查询
  @action fetchGetAccountShieldItemList = async (params = {}) => {
    try {
      return await GetAccountShieldItemList(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 账号管理-商户屏蔽类目-品牌-删除
  @action fetchGetAccountShieldDelItem = async (params = {}) => {
    try {
      return await GetAccountShieldDelItem(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 账号管理-商户屏蔽品牌-列表查询
  @action fetchAccountBrandList = async (params = {}) => {
    try {
      return await GetAccountBrandList(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 账号管理-余额充值明细-导出
  @action fetchAccountRechargeExport = async (params = {}) => {
    try {
      return await GetAccountRechargeExport(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 账号管理-保证金-导出
  @action fetchAccountRechargeBondExport = async (params = {}) => {
    try {
      return await GetAccountRechargeBondExport(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 资产管理-Zb-赠送
  @action fetchAccountRechargeZGive = async (params = {}) => {
    try {
      return await GetAccountRechargeZGive(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 资产管理-Zb-获取平台内部交易号
  @action fetchAccountTradeNo = async (params = {}) => {
    try {
      return await GetAccountTradeNo(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 账号管理-保证金-导出
  @action fetchAccountRechargeZExport = async (params = {}) => {
    try {
      return await GetAccountRechargeZExport(params);
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  // 获取当前用户菜单结构
  @action fetchAccountSelfMenuList = async (params = {}) => {
    try {
      const data = await GetAccountSelfMenuList(params);
      if (data && !data.IsError) {
        const mentList = data.Data.MenuDtos || [];
        const lowerCase = (dataList) => {
          if (!dataList.length) return [];
          const list = dataList.map((item) => {
            const obj = {};
            // eslint-disable-next-line
            for (const attr in item) {
              if (Object.prototype.toString.call(item[attr]) === '[object Array]') {
                obj[attr.substring(0, 1).toLowerCase() + attr.substring(1, attr.length)] = lowerCase(item[attr]);
              } else {
                obj[attr.substring(0, 1).toLowerCase() + attr.substring(1, attr.length)] = item[attr];
              }
            }
            return obj;
          });
          return list;
        };
        data.Data.MenuDtos = lowerCase(mentList);
        return data;
      }
      return data;
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  @action fetchCheckBrandIncomeList = async (params = {}) => {
    try {
      const { Data } = await CheckBrandIncomeList(params);
      runInAction(() => {
        this.checkBrandIncomeList.Data = Data.Data;
        this.checkBrandIncomeList.PagedList = Data.PagedList;
        this.checkBrandIncomeList.TotalRowsCount = Data.TotalRowsCount;
      });
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
    }
  }

  // 获取所有菜单结构
  @action fetchAccountAllMenuList = async (params = {}) => {
    try {
      return await GetAccountAllMenuList(params);
      // return false;
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
      return false;
    }
  }

  @action fetchCheckBrandIncome = async (params = {}) => {
    try {
      const { Data } = await CheckBrandIncome(params);
      runInAction(() => {
        this.checkBrandIncomeList.isRequest = !!Data;
      });
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
    }
  }

  @action fetchGetTotalBrandIncome = async (params = {}) => {
    try {
      const { Data } = await GetTotalBrandIncome(params);
      runInAction(() => {
        this.checkTotalBrandIncome.Data = Data;
      });
    } catch (error) {
      runInAction(() => {
        // console.log(error);
      });
    }
  }
}

export default new Account();
