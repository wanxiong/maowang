export default (base64, type, opacity = 0.9) => new Promise((resolve) => {
  const img = new Image();
  img.src = base64;
  img.onload = () => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const maxWidth = 800;
    const maxHeight = 800;
    const w = img.width;
    const h = img.height;
    let targetWidth = w;
    let targetHeight = h;
    if (w > maxWidth || h > maxHeight) {
      if (w / h > maxWidth / maxHeight) {
        // 更宽，按照宽度限定尺寸
        targetWidth = maxWidth;
        targetHeight = Math.round(maxWidth * (h / w));
      } else {
        targetHeight = maxHeight;
        targetWidth = Math.round(maxHeight * (w / h));
      }
    }
    const quality = opacity;
    canvas.width = targetWidth;
    canvas.height = targetHeight;
    ctx.drawImage(img, 0, 0, targetWidth, targetHeight);
    const prebase64 = canvas.toDataURL(type, quality);
    resolve(prebase64);
  };
});
