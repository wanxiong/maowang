import { createHashHistory } from 'history';
import {
  divide, BigNumber, number, multiply
} from 'mathjs';
import { isDev } from '../config/index';
import { LoginToken } from '../components/base/constant';

// math.add( ) 加
// math.subtract( )减
// math.divide( ) 除
// math.multiply( )乘
// console.log(multiply(1.1, 2.2))
// console.log(multiply(BigNumber(1.1), BigNumber(2.2)))
// console.log(number(multiply(BigNumber(1.1), BigNumber(2.2))))
// console.log(number(divide(BigNumber(300.03), BigNumber(10000))))

const history = createHashHistory();
/**
 * 获取URL参数
*/
/* eslint-disable */
export const getUrlParams = () => {
  const { href } = window.location;
  const i = href.lastIndexOf('\/');
  const str = href.substring(i + 1, href.length);
  return str;
};
/**
 * 生成唯一标识
*/
export const guid = () => {
  const S4 = () => (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
  return (`${S4() + S4()}-${S4()}-${S4()}-${S4()}-${S4()}${S4()}${S4()}`);
};
/**
 * 去除字符串两边的空格
*/
export const trim = (str) => {
  if (typeof str !== 'string') {
    throw new Error('str is not string');
  }
  return str.replace(/(^\s*)|(\s*$)/g, "");
};
/**
 * 判断数组是否有重复的值
*/
export const isRepeat = (arr) => {
  const hash = {};
  if (Object.prototype.toString.apply(arr) !== '[object Array]') {
    throw new Error('arr is not Array');
  }
  for (const i in arr) {
    if (hash[arr[i]]) {
      return true;
    }
    hash[arr[i]] = true;
  }
  return false;
};

/**
 * 导出Excel
 * @params { Object Obj }           对应的字段名
 * @params { String reqMethod }     form表单请求类型
 * @params { String url }           请求的接口路径
*/
export const outExcel = (obj, reqMethod, url) => {
  const formElement = window.document.createElement("form");
  formElement.method = reqMethod;
  formElement.action = url;
  for (const i in obj) {
    const tmpInput = window.document.createElement("input");
    tmpInput.type = "hidden";
    tmpInput.name = i;
    tmpInput.value = obj[i];
    formElement.append(tmpInput);
  }
  window.document.body.appendChild(formElement);
  formElement.submit();
  window.document.body.removeChild(formElement);
  // formElement.remove();
  // formElement.submit();
    
};

/**  时间转换成时间戳  Date(1528953453022+0800)/
*@params { String date }
*@params { String nowDate }			服务器的当前时间
*/
export const formatDateDiff = function (date, nowDate) {
  const t1 = date.slice(6, 19);
  const t2 = nowDate.slice(6, 19);
  const NewDtime1 = new Date(parseInt(t1));
  const NewDtime2 = new Date(parseInt(t2));
  return (NewDtime1 - NewDtime2);
};

/**  时间转换成时间戳  Date(1528953453022+0800)/
*@params { String date }
*/
export const formatDateStamp = function (timeStamp) {
  const t = timeStamp.slice(6, 19);
  return t;
};
/** 获取cookie
 * @params {String Name} 需要查找得cookie名字
 *
*/
export const getCookie = (name) => {
  const reg = new RegExp(`(^| )${name}=([^;]*)(;|$)`);
  const arr = document.cookie.match(reg);
  if (arr) {
    return unescape(arr[2]);
  }
  return null;
};
/** 设置cookie
 * @params {String Name} 需要查找得cookie名字
 *
*/
export const setCookie = (name, value, day = 30) => {
  let exp = new Date(); 
  exp.setTime(exp.getTime() + day * 24 * 60 * 60 * 1000); 
  document.cookie = name + "="+ escape (value) + ";expires=" + exp.toGMTString(); 
};
/** 删除cookie
 * @params {String Name} 需要删除的cookie名字
 *
*/
export const delCookie = (name) => {
  let exp = new Date();
  exp.setTime(exp.getTime() - 1);
  let cval= getCookie(name);
  if(cval) {
    document.cookie= name + "=" + cval + ";expires=" + exp.toGMTString();
  }
};

/** 乘法精度问题
 * @params {Number arg1} 参数1
 * @params {Number arg2} 参数2
 *
*/
export const multiplication = (arg1, arg2) => {
  let str = number(multiply(BigNumber(arg1), BigNumber(arg2)))
  return str;
  // let m = 0; const s1 = arg1.toString(); const
  //   s2 = arg2.toString();
  // try {
  //   m += s1.split(".")[1].length;
  // } catch (e) {
  //   //
  // }
  // try {
  //   m += s2.split(".")[1].length;
  // } catch (e) {
  //   //
  // }
  // return Number(s1.replace(".", "")) * Number(s2.replace(".", "")) / Math.pow(10, m);
};

/** 除法精度问题
 * @params {Number arg1} 参数1
 * @params {Number arg2} 参数2
 *
*/
export const division = (arg1, arg2) => {
  let str = number(divide(BigNumber(arg1), BigNumber(arg2)))
  return str
  
};

/** textarea 入库换行问题
 * @params {Number arg1} 参数1
 *
*/
export const textAreaBr = (str) => {
  if (typeof str !== 'string') {
    throw new Error('str not a string');
  } else {
    return str.replace(/\r\n/g, '<br/>').replace(/\n/g, '<br/>');
  }
};

/** 路由跳转
 * @params {String path } 跳转对应的相对路径
 * @params {Boolean absolutePath } 跳转对应的路径是否是绝对路径 默认false
 *
*/
export const goPage = (path, absolutePath = false) => {
  if (absolutePath) {
    window.location.href = path;
  } else {
    if (!isDev) { // 本地单页面 嵌入多页面 统一处理
      history.push(path);
    } else {
      window.location.href = `${window.location.origin + window.location.pathname}#${path}`;
    }
  }
}

/** 获取MchId
 *
*/
export const getMchId = () => {
  const loginInfo = localStorage.getItem(LoginToken);
    try {
      const parseInfo = JSON.parse(loginInfo);
      return parseInfo.MchId || '';
    } catch (error) {
      return ''
    }
}

/** 验证邮箱
 *
*/
export const checkEmail = (email = '') => {
  let reg = /^(\w-*\.*)+@(\w-?)+(\.\w{2,})+$/;
  return reg.test(email);
}

/** 验证密码数组和字母组合长度为6-20位数
 *
*/
export const checkPassword = (password = '') => {
  let reg = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{8,20}$/;
  return reg.test(password);
}

/** 验证手机号
 *
*/
export const checkMobile = (mobile = '') => {
  let reg = /^1[3456789]\d{9}$/;
  return reg.test(mobile);
}

/** 下载文件
 * @params {String Url }      下载文件对应的URL
 * @params {String download } 下载文件对应的名字
 *
*/
export const downLoadUrl = (url, filename = 'download') => {
  let eleLink = document.createElement('a');
  eleLink.download = filename;
  eleLink.style.display = 'none';
  // 字符内容转变成blob地址
  // var blob = new Blob([content]);
  // eleLink.href = URL.createObjectURL(blob);
  eleLink.href = url;
  // 触发点击
  document.body.appendChild(eleLink);
  eleLink.click();
  // 然后移除
  document.body.removeChild(eleLink);
}

/** 解析URL参数变成对象         xxxx=xxxx&xxxx=xxxx
 * @params {String Url }      URL地址或者?拼接参数
 * @params {String flag }     是否携带问号字符串
 *
*/
export const getUrlkey = (url, flag = true) => {
  // console.log(url)
  let params = {};
  let urls = [];
  let arr = [];
  if (flag) {
    if (url.indexOf('?') === -1) {
      return {};
    }
    urls = url.split("?");
  }
  arr = urls[1].split("&");
  if (!arr.length) {
    return;
  }
  for (let i = 0, l = arr.length; i < l; i++) {
    let a = arr[i].split("=");
    params[a[0]] = decodeURIComponent(a[1]);
  }
  return params;

}
/** 文件流下载
 * @params {String blob }     文件流对象
 * @params {String name }     文件名称加后缀
 *
*/
export const downBlob = (blob, name) => {
  let a = window.document.createElement('a');
  let url = window.URL.createObjectURL(blob);
  a.href = url;
  a.download = name;
  a.click();
  window.URL.revokeObjectURL(url);
  a = null
}

/** 获取当前时间的前后时间日期-目前只支持天，不支持月和年
 * @params {String  date }     时间日期对象/默认当天，可不传递
 * @params {String  day }      具体的事件天数差/整数向前-负数向后
 * @params {String  formart  } 转换的格式/默认 -
 * @params {String  timeTail  } 时分秒默认/ 00:00:00
*/
export const dateDistance = (date = new Date(), day = 0, formart = '-', timeTail = '00:00:00') => {
  let nowDay = date.getDate();
  date.setDate(nowDay - day);
  let y = date.getFullYear(); 
  let m = (date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : (date.getMonth() + 1)
  let d = date.getDate() < 10 ? '0' + date.getDate() : date.getDate()
  return y + formart + m + formart + d + ' ' + timeTail
}

/**是否是空时间                 0001-01-01T
 * @params {String star }      开始时间
 * @params {String end }       结束时间
 *
*/
export const isEmptyTime = (start, end) => {
  let defaultTime = '0001-01-01T';
  if (!start || !end) {
    return true;
  }
  if (start.indexOf(defaultTime) !== -1 && end.indexOf(defaultTime) !== -1) {
    return true;
  } if (start && end) {
    return false;
  }
  return true;
}

/** 时间差格式 只支持到天         2019-02-01
 * @params {String star }      开始时间
 * @params {String end }       结束时间
 * @params {String sep }       分隔符 默认 -
 *
*/
export const dateDiffDay = (star, end, sep = '-') => {
  let separator = sep; //日期分隔符
  let startDates = star.split(separator);  
  let endDates = end.split(separator);  
  let startDate = new Date(startDates[0], startDates[1]-1, startDates[2]);  
  let endDate = new Date(endDates[0], endDates[1]-1, endDates[2]);  
  return parseInt(Math.abs(endDate - startDate ) / 1000 / 60 / 60 /24) + 1;
}