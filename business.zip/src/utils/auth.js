import { LoginToken, LoginTYPE } from '../components/base/constant';
// 是否本地有缓存的token
export default () => {
  const loginInfo = localStorage.getItem(LoginToken);
  const loginType = localStorage.getItem(LoginTYPE);
  let token = '';
  let logintype = '';
  // 正常操作
  try {
    token = JSON.parse(loginInfo);
    logintype = JSON.parse(loginType);
  } catch (error) {
    token = '';
  }
  if (token && token.Token && logintype) {
    const dom = document.getElementById('app');
    if (dom && dom.scrollIntoView) {
      dom.scrollIntoView();
    }
    return true;
  }
  return false;
};
