import { GetProvideOrderShopStatus } from '../services/provide';
import { GetVerifyMerchant } from '../services/account';
import { goPage } from './common';
import { LoginToken } from '../components/base/constant';
/** 用户店铺状态
 * @params { Boolean flag } 是否自定义结构 默认false
 *
*/
export const shopStatus = async () => {
  const status = await GetProvideOrderShopStatus();
  return status;
  // window.location.href = `${window.location.origin + window.location.pathname}#/Yiye/Provide/Page/Examine`;
};
/* eslint-disable */
/** 用户店铺状态装饰器,用来判断当前账户的状态是否符合入住条件
 * @parmas { String type }  验证权限的页面 分采购和供货页面 provide | purchase
*/
export const checkShopStatus = function (type) {
  return function (target, name, descriptor) {
    const oldFunc = descriptor.value;
    descriptor.value = async function (args) {
      const loginInfo = localStorage.getItem(LoginToken);
      let Id = '';
      if (loginInfo) {
        try {
          const parseInfo = JSON.parse(loginInfo);
          Id = parseInfo.MchId;
        } catch (err) {
          // 
        }
      }
      const status = await GetVerifyMerchant({ MchId: Id});
      if (!status.IsError) {
        // if (type === pageShopStatus[0] && !status.Data.CouponSupplyPower) { // 供货
        //   goPage('/Yiye/Provide/Page/Apply');
        // } else if (type === pageShopStatus[1] && !status.Data.CouponPurchasePower) { // 采购
        //   goPage('/Yiye/Provide/Page/Apply');
        // } else if (status.Data.Status === 1 || status.Data.Status === -2) {
        if (status.Data.Status === 1 || status.Data.Status === -2) {
          //  待审核-审核未通过
          goPage('/Yiye/Provide/Page/Examine');
        } else if (status.Data.Status === 0) {
          //  商户初始化
          goPage('/Yiye/Provide/Page/Apply');
        }
      } else {
        // 接口出错了
        // Notify.error(status.ErrorMsg)
      }
      oldFunc.apply(this, args);
    };
    // return descriptor;
  };
};
/* eslint-enable */
