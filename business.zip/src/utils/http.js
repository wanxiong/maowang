/*
 * @Author: kusty
 * @Date: 2018-09-02 14:18:50
 * @Last Modified by: kusty
 * @Last Modified time: 2018-12-20 20:05:43
 */
import axios from 'axios';
import { Notify } from 'ezrd';
import { createHashHistory } from 'history';
import sha1 from 'js-sha1';
import { LoginToken } from '../components/base/constant';
import { delCookie } from './common';

const history = createHashHistory();

function MyError(res) {
  this.name = "MyError";
  this.message = res.ErrorMsg || "自定义异常的默认消息";
  this.status = res.status || '';
}
MyError.prototype = Object.create(Error.prototype);
MyError.prototype.constructor = MyError;

axios.interceptors.request.use(config => config,
  error => Promise.reject(error));

export default class Http {
  static async request(method, url, data, config = {}) {
    const param = {
      url,
      method,
      data,
      ...config
    };
    try {
      const res = await axios.request(param);
      if (this.isSuccess(res)) {
        if (res.data.type === 'application/octet-stream') {
          return res.data;
        }
        return this.handleData(res.data);
      }
      throw new MyError(res.data);
    } catch (error) {
      // 原来是API返回http级别的报错捕捉，现在换成http 200 捕捉
      if (error.response && error.response.status === 401) {
        localStorage.clear();
        delCookie('MerchantId');
        history.push('/login');
        Notify.error(error.response.data.ErrorMsg);
      } else {
        Notify.error(error.message);
      }
      return {
        IsError: true,
        Data: {
          Count: 0,
          Data: [],
          Dtls: []
        }
      };
    }
  }

  static isSuccess(res) {
    const code = res.status;
    if (code !== 200) {
      return false;
    }
    return true;
  }

  static handleData(data) {
    if ((data.ErrorCode === 0 || data.ErrorCode === 200) && !data.IsError) {
      return data;
    }
    Notify.error(data.ErrorMsg);
    const customData = data.Data
      ? data
      : Object.assign(data,
        {
          Data: {
            Count: 0,
            Data: [],
            Dtls: []
          }
        });
    return customData;
  }

  static get(url, data = {}, config = {}, loading = true) {
    const auth = this.setAuth();
    const newConfig = Object.assign(auth, config);
    return this.request('GET', url, data, newConfig, loading);
  }

  static post(url, data, config = {}, loading = true) {
    const auth = this.setAuth();
    const newConfig = Object.assign(auth, config);
    return this.request('POST', url, data, newConfig, loading);
  }

  static setAuth = () => {
    const loginInfo = localStorage.getItem(LoginToken);
    let token = '';
    if (loginInfo) {
      try {
        const parseInfo = JSON.parse(loginInfo);
        token = parseInfo.Token || '';
        const Id = parseInfo.MchId;
        const TimeStamp = parseInt((new Date().getTime()) / 1000, 0);
        const Secret = parseInfo.SignSec;
        return {
          headers: {
            Authorization: `Bearer ${token}`,
            Sign: sha1(`MerchantId=${Id}&TimeStamp=${TimeStamp}&Secret=${Secret}`).toLocaleUpperCase(),
            TimeStamp,
            MerchantId: Id,
            NonceStr: '',
            UserId: parseInfo.UserId,
            SystemCode: ''
          }
        };
      } catch (error) {
        return {
        };
      }
    }
    return {};
  }

  // 上传文件
  static postUpload(url, data = {}, config = {}) {
    const formData = new FormData();
    Object.keys(data).forEach((item) => {
      formData.append(item, data[item]);
    });
    const auth = this.setAuth();
    auth.headers['Content-Type'] = 'multipart/form-data';
    const newConfig = Object.assign(auth, config);
    return this.request('POST', url, formData, newConfig);
  }
}
