import * as React from 'react';
import * as ReactDOM from 'react-dom';
import {
  Route, Switch, HashRouter, Redirect
} from 'react-router-dom';
import { Provider } from 'mobx-react';
import * as store from './model';
import Layout from './Layout';
import Login from './view/login';
import PrivateRoute from './privateRoute';

import 'ezrd/css/index.css';
import './styles/global.less';
import './styles/base/index.less';
import './styles/login.less';
import './styles/transaction.less';
import './styles/base/merchant.less';
import './styles/account.less';
import './styles/assetManage.less';
import './styles/header.less';
import './styles/accountAudit.less';
import './styles/download.less';
import './styles/coupon.less';
import './styles/couponDetail.less';
import './styles/supplier.less';
import './styles/import.less';
import './styles/saleReport.less';
import './styles/systemManage.less';
import './styles/supCheckBrandIncome.less';
import './styles/channel.less';
import './styles/provide.less';
import './styles/importGoods.less';
import './styles/couponCode.less';
import './styles/chargingScheme.less';

ReactDOM.render(
  <HashRouter>
    <Provider {...store}>
      <Switch>
        <Route
          path="/login"
          component={Login}
        />
        <PrivateRoute
          path="/"
          component={Layout}
        />
        <Redirect to="/" />
      </Switch>
    </Provider>
  </HashRouter>,
  document.getElementById('app')
);

if (module.hot) {
  module.hot.accept();
}
