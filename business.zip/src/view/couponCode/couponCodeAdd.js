import * as React from 'react';
import {
  Breadcrumb, Form, Title, Icon, Pop, Radio, Button, Notify
} from 'ezrd';
import { observer, inject } from 'mobx-react';
import { toLongDate } from 'ezrd/lib/utils/datetime';
import moment from 'moment';
import { couponDefaultPage } from '../../components/base/constant';
import { ConstFormDay, ConstFormValidDate } from '../../components/base/constForm';
import ConstCouponListForm from '../../components/base/constCouponListForm';
import DefaultTipDialog from '../../components/transaction/defaultTipDialog';
import { multiplication } from '../../utils/common';

const classNamePre = 'yiye-coupon-code-add';

const {
  Field, FormInputField, createForm, FormDateRangePickerField, FormRadioGroupField
} = Form;

@inject('CouponCodeStore')
@observer
class CouponCodeAddForm extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      breadList: [],
      loading: false,
      detail: '',
      showTipDialog: false,
      stockNum: '',
      stockText: '',
      showDialopContent: '',
      showDialogZb: false,
      ...couponDefaultPage
    };
  }

componentDidMount = () => {
  const { match } = this.props;
  const id = match.params.Id;
  // 设置折线图的宽度
  let bUrl = [];
  if (id === '0') {
    bUrl = [
      { name: '券码管理', href: "#/Yiye/CouponCode/List" },
      { name: '券码新增', strong: true }
    ];
  } else {
    bUrl = [
      { name: '券码管理', href: "#/Yiye/CouponCode/List" },
      { name: '券码查看', strong: true }
    ];
    this.initDetail(id);
  }
  this.setState({
    breadList: bUrl
  });
}

initDetail = async (id) => {
  const { CouponCodeStore } = this.props;
  const status = await CouponCodeStore.fetchCouponListAddDetail({
    id
  });
  // if (status && !status.IsError) {
  this.setState({
    detail: status.Data
  });
  // }
}

// 保存
onSave = () => {
  const { ezrdForm } = this.props;
  ezrdForm.setFormDirty(true);
  if (ezrdForm.isValid()) {
    const price = 0.08;
    const num = ezrdForm.getFormValues().MakeQty;
    const actName = ezrdForm.getFormValues().ActName;
    const total = multiplication(price, num);
    const txt = `本次制券将消耗${total}Z币（单价：${price}Z币/个），确定生成“${actName}”券码${num}个吗？`;
    this.setState({
      showTipDialog: true,
      showDialopContent: txt
    });
  }
}

submit = async () => {
  const { stockNum } = this.state;
  const { CouponCodeStore, ezrdForm } = this.props;
  const values = ezrdForm.getFormValues();
  const params = {
    CouponGrpId: values.CouponData.Id,
    CouponGrpName: values.CouponData.CouponName,
    CouponOrigin: values.CouponData.CouponOrigin,
    CouponType: values.CouponData.CouponType,
    CouponBeginDate: values.CouponData.CouponOrigin,
    UnionCouponType: values.CouponData.UnionCouponType,
    CouponRemark: values.CouponRemark,
    ExchangeBeginDate: values.ExchangeDate[0],
    ExchangeEndDate: values.ExchangeDate[1],
    MakeType: values.MakeType,
    MakeQty: values.MakeQty,
    ActName: values.ActName
  };
  // 券有效期存在 传递自定义
  if (values.CusValidVay) {
    if (values.CusValidVay.type === '1') { // 自领取日
      const [day] = values.CusValidVay.data;
      params.CouponValidType = 1;
      params.CouponValidDays = day;
    } else {
      params.CouponValidType = 2;
      const [, time] = values.CusValidVay.data;
      const [start, end] = time;
      params.CouponBeginDate = start;
      params.CouponEndDate = end;
    }
  } else { // 不存在即异业券 梭哈
    params.CouponValidType = '';
    params.CouponBeginDate = '';
    params.CouponEndDate = '';
  }
  // 判断激活有效期可自定义区间的逻辑判断  1 - 2
  if (values.CusValidVay && values.ExchangeDate && values.CusValidVay.type === '2') {
    const t = values.CusValidVay.data;
    const exStart = moment(values.ExchangeDate[0]).valueOf();
    const exEnd = moment(values.ExchangeDate[1]).valueOf();
    const start = moment(t[1][0]).valueOf();
    const end = moment(t[1][1]).valueOf();
    if (start > exStart) { // 激活有效期开始时间不能大于自定义开始时间
      Notify.error('激活有效期开始时间必须在券有效期时间内');
      return;
    } if (end < exEnd) {
      Notify.error('激活有效期结束时间必须在券有效期时间内');
      return;
    }
  }
  // 判断是否库存足够且是YY情况下拦截一层
  if (stockNum !== -1) {
    if (values.MakeQty > stockNum) {
      Notify.error(`制券所需“${values.CouponData.CouponName}”库存不足，请补充权益券库存`);
      return;
    }
  }
  //
  this.setState({ loading: true });
  const status = await CouponCodeStore.fetchCouponSaveData(params);
  if (status && !status.IsError) {
    Notify.success('新建券码成功');
    window.history.back();
  }
  this.setState({ loading: true });
}

// 自定义券模板的回调
cuoponTplCallBack = (info) => {
  const { ezrdForm } = this.props;
  //
  ezrdForm.setFieldsValue({ CouponData: info });
  if (info.CouponType === 'YY' && info.CouponOrigin === 1) {
    this.getCouponYYStock(info.Id, info.CouponName);
  } else {
    this.setState({
      stockNum: -1,
      stockText: ''
    });
  }
}

// 获取库存
getCouponYYStock = async (id, text) => {
  const { CouponCodeStore } = this.props;
  const status = await CouponCodeStore.fetchCouponYyStock({
    CouponGrpId: id
  });
  if (status && !status.IsError) {
    this.setState({
      stockNum: status.Data,
      stockText: `制券所需“${text}”库存剩余${status.Data}个`
    });
  }
  // fetchCouponYyStock
}

// 最终确定框
confirmTip = (flag) => {
  this.setState({
    showTipDialog: false
  });
  if (flag) {
    this.submit();
  }
}

// Zb不足弹出框
confirmZb = (flag) => {
  const { history } = this.props;
  this.setState({
    showDialogZb: false
  });
  if (flag) {
    history.push('/Yiye/Account/AccountInfo/AssetManageZDetail');
  }
}

render() {
  const {
    breadList, loading, detail, showTipDialog, showDialopContent, showDialogZb, stockText
  } = this.state;
  const { ezrdForm } = this.props;
  return (
    <div className={`${classNamePre}`}>
      <div className={`${classNamePre}-bread yiye-global-bread`}>
        <Breadcrumb breads={breadList} />
      </div>
      <div className={`${classNamePre}-pro`}>
        <Form horizontal>
          <div className={`${classNamePre}-base`}>
            {/* 基础设置 */}
            <Title
              titleDesc="基础设置"
              className={`${classNamePre}-top-title`}
            >
              <FormInputField
                name="ActName"
                type="text"
                label="券码名称"
                required
                width={320}
                maxLength={20}
                disabled={!!detail}
                value={detail ? detail.ActName : ''}
                showCount
                helpDesc="为了提高券码名称的可读性，建议使用券码兑换优惠券的名称，如：海澜之家100元无门槛优惠券"
                validations={{
                  required: true
                }}
                validationErrors={{
                  required: '券码名称不能为空'
                }}
              />
              <Field
                name="CouponData"
                type="text"
                label="优惠券"
                disabled={!!detail}
                // tabsType={['defaultTab']}
                customCallBack={this.cuoponTplCallBack}
                component={ConstCouponListForm}
                required
                value={
                  detail
                    ? {
                      Id: detail.CouponGrpId,
                      CouponName: detail.CouponGrpName,
                      CouponOrigin: detail.CouponOrigin,
                      CouponType: detail.CouponType,
                      UnionCouponType: detail.UnionCouponType
                    }
                    : ''
                }
                validations={{ required: true }}
                validationErrors={{ required: '请选择优惠券' }}
              />
              {/** GrpCouponValidType 等于0可以隐藏并且是YY异业  */}
              {
                /* eslint-disable */
                (
                  (ezrdForm.getFormValues().CouponData && ezrdForm.getFormValues().CouponData.CouponType === 'YY' && ezrdForm.getFormValues().CouponData.GrpCouponValidType === 0)
                    ||
                  (ezrdForm.getFormValues().CouponData && ezrdForm.getFormValues().CouponData.CouponType === 'YY' && ezrdForm.getFormValues().CouponData.CouponOrigin === 1)
                )
                  ? (null)
                  : (!ezrdForm.getFormValues().CouponData || ezrdForm.getFormValues().CouponData.CouponOrigin === 0)
                    ? (
                      <Field
                        name="CusValidVay"
                        type="text"
                        label={(
                          <span>券有效期</span>
                          )}
                        component={ConstFormValidDate}
                        min={0}
                        disabled={detail ?  true : false}
                        value={
                          detail
                            ? {
                              type: detail.CouponValidType + '',
                              data: detail.CouponValidType === 1
                                ? [`${detail.CouponValidDays}` || '', ['', '']]
                                : ['', [detail.CouponBeginDate || '', detail.CouponEndDate || '']]
                            }
                            : {
                              type: '',
                              data: ['', ['', '']]
                            }
                        }
                        startTxt="自领取之日起"
                        endTxt="天内有效"
                        required
                        validations={{
                          required(values, value) {
                            return !!value.type;
                          },
                          valueOne(values, value) {
                            if (value.type && value.type === '1' && !(`${value.data[0]}`)) {
                              return false;
                            }
                            return true;
                          },
                          valueTwo(values, value) {
                            if (value.type && value.type === '2' && (!value.data[1][0] || !value.data[1][1])) {
                              return false;
                            }
                            return true;
                          }
                        }}
                        validationErrors={{ required: '券有效期不能为空', valueOne: '自领取日不能为空', valueTwo: '请输入开始时间和结束时间' }}
                      />
                    )
                    : (
                      <Field
                        name="CusValidVay"
                        type="text"
                        label={(
                          <span>券有效期</span>
                          )}
                        component={ConstFormValidDate}
                        disabled={true}
                        min={0}
                        value={
                          detail
                            ? (
                              {
                                type: detail.CouponValidType + '',
                                data: detail.CouponValidType === 1
                                  ? [`${detail.CouponValidDays}` || '', ['', '']]
                                  : ['', [detail.CouponBeginDate || '', detail.CouponEndDate || '']]
                              }
                            )
                            : (
                                {
                                  type: (toLongDate(ezrdForm.getFormValues().CouponData.CouponBeginDate) && toLongDate(ezrdForm.getFormValues().CouponData.CouponEndDate)) ? '2' : '1',
                                  data: (!toLongDate(ezrdForm.getFormValues().CouponData.CouponBeginDate) && !toLongDate(ezrdForm.getFormValues().CouponData.CouponEndDate))
                                    ? [`${ezrdForm.getFormValues().CouponData.CouponValidDays}`, ['', '']]
                                    : ['', [toLongDate(ezrdForm.getFormValues().CouponData.CouponBeginDate), toLongDate(ezrdForm.getFormValues().CouponData.CouponEndDate)]]
                                }
                                )
                        }
                        startTxt="自领取之日起"
                        endTxt="天内有效"
                        required
                      />
                    )
                /* eslint-enable */
              }
              {
                (ezrdForm.getFormValues().CouponData && ezrdForm.getFormValues().CouponData.CouponType !== 'YY' && ezrdForm.getFormValues().CouponData.CouponOrigin === 1)
                  ? (
                    <FormInputField
                      name="CouponRemark"
                      type="textarea"
                      width={320}
                      label="券说明"
                      value={
                        detail
                          ? detail.CouponRemark || ''
                          : (ezrdForm.getFormValues().CouponData && ezrdForm.getFormValues().CouponData.Guide) || ''
                      }
                      maxLength={512}
                      showCount
                      disabled
                    />
                  )
                  : (
                    <FormInputField
                      name="CouponRemark"
                      type="textarea"
                      width={320}
                      label="券说明"
                      disabled
                      value={
                        detail
                          ? detail.CouponRemark
                          : (ezrdForm.getFormValues().CouponData && ezrdForm.getFormValues().CouponData.Guide) || ''
                      }
                      maxLength={512}
                      showCount
                    />
                  )
              }

              <FormDateRangePickerField
                label="激活有效期"
                name="ExchangeDate"
                required
                min={`${moment().format('YYYY-MM-DD')}`}
                width={200}
                dateFormat="YYYY-MM-DD"
                value={
                  detail ? [detail.ExchangeBeginDate, detail.ExchangeEndDate] : ''
                }
                disabled={!!detail}
                validations={{
                  required: true,
                  checkStart(values, value) {
                    if (!value[0] && !value[1]) {
                      return true;
                    }
                    return !!value[0];
                  },
                  checkEnd(values, value) {
                    if (!value[0] && !value[1]) {
                      return true;
                    }
                    return !!value[1];
                  }
                }}
                validationErrors={{
                  required: '激活有效期不能为空',
                  checkStart: '请选择开始日期',
                  checkEnd: '请选择结束日期'
                }}
              />
            </Title>
            {/* 制券设置 */}
            <Title
              titleDesc="制券设置"
              className={`${classNamePre}-top-title`}
            >
              <FormRadioGroupField
                name="MakeType"
                value={
                  detail ? `${detail.MakeType}` : '0'
                }
                disabled={
                  detail ? true : ''
                }
                label={(
                  <span>
                    制券方式&nbsp;
                    <Pop
                      trigger="hover"
                      content="批量制券支持导出所有券号，需要提供制券数量"
                      position="right-center"
                      centerArrow
                    >
                      <Icon
                        style={{ color: '#999' }}
                        type="info"
                        ezrd
                      />
                    </Pop>
                  </span>
                )}
              >
                <Radio value="0">批量制券</Radio>
                {/** <Radio value="1">批次号发券</Radio> */}
              </FormRadioGroupField>
              <Field
                name="MakeQty"
                label="制券数量"
                component={ConstFormDay}
                endTxt="个"
                value={
                  detail ? `${detail.MakeQty}` : ''
                }
                required
                disabled={!!detail}
                validations={{ required: true }}
                validationErrors={{ required: '制券数量不能为空' }}
                min={1}
                width={100}
                max={1000000}
              />
            </Title>
          </div>
          { /** 保存按钮 */}
          {
            detail
              ? (
                <div className="yiye-bottom-edit-group-btn">

                  <Button
                    type="primary"
                    size="middle"
                    outline
                    onClick={() => window.history.back()}
                  >
                  返回
                  </Button>
                </div>
              )
              : (
                <div className="yiye-bottom-edit-group-btn">
                  <Button
                    type="primary"
                    size="middle"
                    outline
                    style={{ 'margin-right': '20px' }}
                    loading={loading}
                    onClick={() => window.history.back()}
                  >
                  取消
                  </Button>
                  <Button
                    type="primary"
                    size="middle"
                    loading={loading}

                    onClick={() => this.onSave()}
                  >
                  提交
                  </Button>
                </div>
              )
          }
        </Form>
      </div>
      { /** 弹出框 */}
      <DefaultTipDialog
        title="确定制券信息"
        content={(
          <div>
            <div style={{ color: 'red' }}>{stockText}</div>
            <div>{showDialopContent}</div>
          </div>
        )}
        showEnableVisible={showTipDialog}
        confirmEnable={this.confirmTip}
        loading={false}
      />
      {/** ZB不足充值框 */}
      <DefaultTipDialog
        title="制券Z币不足"
        content="Z币金额不足，请充值Z币后再制券"
        showEnableVisible={showDialogZb}
        confirmEnable={this.confirmZb}
        confirmText="去充值"
      />
    </div>
  );
}
}

const CouponCodeAdd = createForm()(CouponCodeAddForm);

export default CouponCodeAdd;
