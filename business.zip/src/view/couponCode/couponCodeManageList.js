import * as React from 'react';
import {
  Table, Dialog, Button, Notify, Input
} from 'ezrd';
import moment from 'moment';
import { observer, inject } from 'mobx-react';
import { couponDefaultPage } from '../../components/base/constant';
import CouponCodeListSearch from '../../components/couponCode/couponCodeListSearch';
import { trim } from '../../utils/common';
import CouponCodeListAdd from '../../components/couponCode/couponCodeListAdd';

const classNamePre = 'yiye-coupon-code';

@inject('CouponCodeStore')
@observer
class CouponCodeManageList extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      ...couponDefaultPage,
      visible: false,
      taskName: `${moment().format('YYYY-MM-DD')}券码管理导出`,
      exportData: '',
      showAdd: false,
      addLoading: false,
      stockNum: ''
    };
  }

componentDidMount = () => {
  this.initData();
}

// 搜索按钮的回调
onSearch = (data, flag) => {
  const params = {
    Id: data.couponNum,
    StartDate: data.time[0],
    EndDate: data.time[1],
    Status: data.status,
    ActName: data.couponName
  };
  if (flag !== 0) {
    this.setState({ current: 1 }, () => {
      this.initData(params);
    });
    return;
  }
  this.initData(params);
}

// 分页的回调
onChange = (data) => {
  let { current } = this.state;
  const { pageSize } = this.state;
  if (data.pageSize) {
    if (data.pageSize === pageSize) {
      return;
    }
    current = 1;
  }
  this.setState({
    pageSize: data.pageSize || pageSize,
    current: data.current || current
  }, () => {
    this.searchDom.onSearch(0);
  });
}

// 初始化数据
initData = (params = {}) => {
  const { CouponCodeStore } = this.props;
  const { pageSize, current } = this.state;
  CouponCodeStore.fetchCouponCodeList({
    PageSize: pageSize,
    PageIndex: current,
    Id: '',
    StartDate: '',
    EndDate: '',
    Status: '-1',
    ActName: '',
    json: '',
    ...params
  });
}

// 查看详情
goDetail = (data) => {
  const { history } = this.props;
  history.push(`/Yiye/CouponCode/Add/${data.Id}`);
}

// 导出券码
exportCode = (data) => {
  this.setState({ visible: true, exportData: data });
}

closeDialog = () => {
  this.setState({ visible: false });
}

// 导出接口
confirm = async () => {
  const { CouponCodeStore, history } = this.props;
  const { taskName, exportData } = this.state;
  if (!trim(taskName)) {
    Notify.error('请输入导出数据的文件名称');
    return;
  }
  this.setState({ exportLoading: true });
  const status = await CouponCodeStore.fetchCouponCodeExport({
    TaskName: taskName,
    Type: 10,
    Querys: {
      ActId: exportData.Id
    }
  });
  if (!status.IsError) {
    this.closeDialog();
    history.push('/Yiye/Download');
  }
  this.setState({ exportLoading: false });
}

// 普通input框的事件回调
onChangeInput = (type, e) => {
  this.setState({
    [type]: e.target.value
  });
}

// 增加制券
addCoupon = (data) => {
  this.setState({
    showAdd: true,
    json: data,
    stockNum: ''
  });
  this.getCouponYYStock(data.CouponGrpId);
}

// 增加制券的回调
addConfirm = async (flag, v, fn) => {
  if (!flag) {
    this.setState({
      showAdd: false
    });
    fn();
  } else {
    this.setState({
      addLoading: true
    });
    const { CouponCodeStore } = this.props;
    const { json } = this.state;
    const status = await CouponCodeStore.fetchCouponListAddStock({
      ActId: json.Id,
      CouponGrpId: json.CouponGrpId,
      MakeQty: v.value
    });
    if (!status.IsError) {
      Notify.success('制券成功');
      this.setState({
        showAdd: false
      });
      fn();
      this.searchDom.onSearch(0);
    }
    this.setState({
      addLoading: false
    });
  }
}

// 新建券码
addCouponCode = () => {
  const { history } = this.props;
  history.push('/Yiye/CouponCode/Add/0');
}

// 获取库存
getCouponYYStock = async (id) => {
  const { CouponCodeStore } = this.props;
  const status = await CouponCodeStore.fetchCouponYyStock({
    CouponGrpId: id
  });
  if (status && !status.IsError) {
    this.setState({
      stockNum: status.Data
    });
  }
  // fetchCouponYyStock
}

render() {
  const { CouponCodeStore: { couponCodeList } } = this.props;
  const { TotalRowsCount, PagedList } = couponCodeList;
  const {
    current, pageSizeList, visible, exportLoading, taskName, showAdd, addLoading, json, stockNum
  } = this.state;
  const columns = [
    {
      title: '批次号',
      width: '200px',
      bodyRender: data => <div>{data.BatchCode}</div>
    },
    {
      title: '创建时间',
      bodyRender: data => <div>{moment(data.CreateDate).format('YYYY-MM-DD HH:mm:ss')}</div>
    },
    {
      title: '券码名称',
      name: 'ActName'
    },
    {
      title: '制券数',
      name: 'TotalCount'
    },
    {
      title: '库存',
      name: 'StockQty'
    },
    {
      title: '激活数',
      name: 'ActivedQty'
    },
    {
      title: '激活券核销数',
      name: 'ConsumeQty'
    },
    {
      title: '状态',
      width: '100px',
      name: 'StatusText'
    },
    {
      title: '操作',
      width: '200px',
      bodyRender: (data) => {
        if (data.Status === 1 || data.Status === 4 || data.Status === 0) { // 制券中
          return (
            <div className={`${classNamePre}-btn-span`}>
              <span
                className="yiye-outline btn-default-color yiye-cursor"
                role="button"
                tabIndex="0"
                onClick={() => this.goDetail(data)}
              >
              查看
              </span>
            </div>
          );
        } if (data.Status === 2 || data.Status === 3) { // 已生效 // 未生效
          return (
            <div className={`${classNamePre}-btn-span`}>
              <span
                className="yiye-outline btn-default-color yiye-cursor"
                role="button"
                tabIndex="0"
                onClick={() => this.goDetail(data)}
              >
              查看
              </span>
              <span
                className="yiye-outline btn-default-color yiye-cursor"
                role="button"
                tabIndex="0"
                onClick={() => this.addCoupon(data)}
              >
              增加制券
              </span>
              <span
                className="yiye-outline btn-default-color yiye-cursor"
                role="button"
                tabIndex="0"
                onClick={() => this.exportCode(data)}
              >
              导出券码
              </span>
            </div>
          );
        }
        return '--';
      }
    }
  ];
  return (
    <div className={`${classNamePre}`}>
      {/* 检索区域 */}
      <CouponCodeListSearch
        ref={(ref) => { this.searchDom = ref; }}
        onSearch={this.onSearch}
      />
      {/** 表格区域 */}
      <div className={`${classNamePre}-contain`}>
        <div className={`${classNamePre}-contain-add`}>
          <Button onClick={this.addCouponCode}>新建券码</Button>
        </div>
        <Table
          columns={columns}
          datasets={PagedList}
          rowKey="Id"
          pageInfo={{
            totalItem: TotalRowsCount,
            current,
            pageSize: pageSizeList
          }}
          onChange={this.onChange}
        />
      </div>
      {/** 增加知券 */}
      <CouponCodeListAdd
        showEnableVisible={showAdd}
        confirmEnable={this.addConfirm}
        loading={addLoading}
        data={json}
        stockNum={stockNum}
      />
      {/** 导出弹框 */}
      <Dialog
        title="导出数据的文件名称"
        visible={visible}
        onClose={() => this.closeDialog()}
        style={{ width: '600px' }}
        maskClosable={false}
        footer={(
          <div>
            <Button
              outline
              loading={exportLoading}
              onClick={() => this.closeDialog()}
            >
              取消
            </Button>
            <Button
              loading={exportLoading}
              onClick={() => this.confirm()}
            >
              确定
            </Button>
          </div>
        )}
      >
        <Input
          signleBorder
          placeholder="请输入导出数据的文件名称"
          showClear
          maxLength={30}
          width="100%"
          value={taskName}
          onChange={event => this.onChangeInput('taskName', event)}
        />
      </Dialog>
    </div>
  );
}
}

export default CouponCodeManageList;
