import * as React from 'react';
import {
  Tabs, Button, DateRangePicker, Table, Notify, Breadcrumb
} from 'ezrd';
import { observer, inject } from 'mobx-react';
import moment from 'moment';
import { couponDefaultPage } from '../../components/base/constant';
// 新建
// import ConstFormUploadFile from '../../components/base/fileUpload';
import {
  uploadUrl, uploadSkuUrl, downExcelSkuUrl, downExcelUrl
} from '../../services/importCenter';
import ConstUploadFile from '../../components/base/constUploadFile';
import { dateDiffDay, downBlob } from '../../utils/common';

const { TabPanel } = Tabs;
const classNamePre = 'yiye-import-sku';

const columns = [
  {
    title: '上传用户',
    bodyRender: data => <div>{data.UserName}</div>
  },

  {
    title: '上传文件',
    name: 'FileName'
  },
  {
    title: '上传时间',
    bodyRender: data => (
      moment(data.ImportTime).format('YYYY-MM-DD HH:mm:ss')
    )
  },
  {
    title: '文件大小（MB）',
    name: 'FileSize'
  },
  {
    title: '处理行数',
    name: 'ExecRows',
    width: '120px'
  },
  {
    title: '处理状态',
    width: '120px',
    name: 'ExecStatusName'
  },
  {
    title: '处理完成时间',
    bodyRender: data => (
      moment(data.ExecTime).format('YYYY-MM-DD HH:mm:ss')
    )
  },
  {
    title: '返回信息',
    bodyRender: (data) => {
      if (data.ExecStatus === -1 || data.ExecStatus === 2) {
        return <div>{data.ExecStatusName}</div>;
      }
      return <span>--</span>;
    }
  },
  {
    title: '下载',
    bodyRender: (data) => {
      if (data.ExecStatus === -2 || data.ExecStatus === -3) {
        return <a href={data.ExecMsg}>下载</a>;
      }
      return <span>--</span>;
    }
  }
];

// 注入
@inject('importCenterStore')
@observer
export default class ImportSku extends React.Component {
  constructor(props) {
    super(props);
    const storage = window.localStorage;
    this.info = JSON.parse(storage.getItem('yiye-import-center-par') ? storage.getItem('yiye-import-center-par') : "");
  }

  state = {
    activeId: '1',
    JobBegDate: moment().format('YYYY-MM-DD'),
    JobDate: moment().format('YYYY-MM-DD'),
    breadList: [
      { name: '引流券', href: "#/Yiye/Provide/Platformcoupon" },
      { name: '文件导入', strong: true }
    ],
    ...couponDefaultPage
  }

  async componentDidMount() {
    // 获取localstorage中的值
    if (this.info) {
      const { pageSize, current } = this.state;
      this.getGoodsList(current, pageSize);
    }
  }

  // 上传
  onChange = (info) => {
    if (info.IsError === false) {
      Notify.success('上传成功');
      this.onTabChange('2');
    } else if (info.IsError === true) {
      Notify.error(info.ErrorMsg);
    }
  }

  // 上传失败
  static onError() {
    Notify.error('请求出错了');
  }

  // 获取商品
  getGoodsList(current, pageSize) {
    const { importCenterStore } = this.props;
    // const { pageSize, current } = this.state;
    importCenterStore.fetchExportCenterGoodsList({
      CouponGrpId: this.info.couponGrpId,
      ProType: this.info.ProType,
      PageIndex: current,
      PageSize: pageSize
    });
  }

  // 获取日志
  getRecordList() {
    const { importCenterStore } = this.props;
    const {
      pageSize, current, JobDate, JobBegDate
    } = this.state;
    if (JobBegDate && JobDate) {
      const day = dateDiffDay(JobBegDate, JobDate);
      if (day > 30) {
        Notify.error('查询时间段不能超过了30天');
        return;
      }
    }

    if (this.info.ProType === 0) {
      importCenterStore.fetchExportCenterGoodsLogList({
        CouponGrpId: this.info.couponGrpId,
        PageIndex: current,
        PageSize: pageSize,
        JobBegDate,
        JobDate
      });
    } else {
      importCenterStore.fetchExportCenterSkuLogList({
        CouponGrpId: this.info.couponGrpId,
        PageIndex: current,
        PageSize: pageSize,
        JobBegDate,
        JobDate
      });
    }
  }

  // tab切换
  onTabChange = (id) => {
    this.setState({
      activeId: id
    }, () => {
      const { activeId, pageSize, current } = this.state;
      // 根据当前切换状态，请求接口
      if (activeId === '1') {
        this.getGoodsList(current, pageSize);
      } else {
        this.getRecordList();
      }
    });
  }

  // 日期选择
  onChangeRange = (val) => {
    if (val) {
      this.setState({
        JobBegDate: val[0],
        JobDate: val[1]
      });
    }
  }

  // 查询
  search = () => {
    this.getRecordList();
  }

  // post下载excel模版
  downExcel = async () => {
    const { importCenterStore } = this.props;
    const url = this.info.ProType === 0 ? downExcelUrl : downExcelSkuUrl;
    const blob = await importCenterStore.fetchDownExcelDefaultPost(url, {});
    downBlob(blob, `商品.xlsx`);
    // return;
    //
    // const formElement = document.createElement('form');
    // formElement.style.display = "display:none;";
    // formElement.method = 'post';
    // formElement.action = this.info.ProType === 0 ? downExcelUrl : downExcelSkuUrl;
    // formElement.target = 'callBackTarget';
    // const inputElement = document.createElement('input');
    // inputElement.type = 'hidden';
    // inputElement.name = "params";
    // // inputElement.value = params;
    // formElement.appendChild(inputElement);
    // document.body.appendChild(formElement);
    // formElement.submit();
    // document.body.removeChild(formElement);
    // downExcel()
  }

  // 删除
  deleteSKU = async (id) => {
    const { importCenterStore } = this.props;
    const res = await importCenterStore.fetchDeleteSkuData({
      id
    });
    if (!res.IsError) {
      // 提示成功
      Notify.success('删除成功');
      const { pageSize } = this.state;
      this.getGoodsList(1, pageSize);
    } else {
      Notify.error('删除失败');
    }
  }

  // 删除商品
  deleteGood = async (id) => {
    const { importCenterStore } = this.props;
    const res = await importCenterStore.fetchDeleteProData({
      id
    });
    if (!res.IsError) {
      // 提示成功
      Notify.success('删除成功');
      const { pageSize } = this.state;
      this.getGoodsList(1, pageSize);
    } else {
      Notify.error('删除失败');
    }
  }

  // tab切换
  onChangeTable = (conf) => {
    const {
      pageSize, current
    } = this.state;
    this.setState({
      current: conf.current ? conf.current : current,
      pageSize: conf.pageSize ? conf.pageSize : pageSize
    }, () => {
      this.getGoodsList(current, pageSize);
    });
  }

  beforeUpload = (file) => {
    const { importCenterStore } = this.props;
    let url = '';
    url = this.info.ProType === 0 ? `${uploadUrl}` : `${uploadSkuUrl}`;
    importCenterStore.fetchUploadExcelDefaultPost(url, {
      id: this.info.couponGrpId,
      couponProIsExclude: this.info.couponProIsExclude
    }, { file }).then((res) => {
      if (!res.IsError) {
        Notify.success('上传成功');
        this.onTabChange('2');
        // const { activeId, pageSize, current } = this.state;
        // // 根据当前切换状态，请求接口
        // if (activeId === '1') {
        //   this.getGoodsList(current, pageSize);
        // } else {
        //   this.getRecordList();
        // }
      } else {
        Notify.error(res.ErrorMsg);
      }
    }).catch(() => {});

    return false;
  }

  render() {
    const goodColumns = [
      {
        title: '导入时间',
        bodyRender: data => <div>{moment(data.CreateDate).format('YYYY-MM-DD HH:mm:ss')}</div>
      },
      // {
      //   title: '商品名称',
      //   name: 'ProName'
      // },
      {
        title: 'SKU',
        name: "Sku"
      },
      {
        title: '操作',
        bodyRender: data => (
          <Button
            isText
            outline
            onClick={() => { this.deleteSKU(data.Id); }}
          >
          删除
          </Button>
        )
      }
    ];

    const goodColumns2 = [
      {
        title: '导入时间',
        bodyRender: data => <div>{moment(data.CreateDate).format('YYYY-MM-DD HH:mm:ss')}</div>
      },
      // {
      //   title: '商品名称',
      //   name: 'ProName'
      // },
      {
        title: '商品货号',
        name: "ProdNo"
      },
      {
        title: '操作',
        bodyRender: data => (
          <Button
            isText
            outline
            onClick={() => { this.deleteGood(data.Id); }}
          >
          删除
          </Button>
        )
      }
    ];

    const {
      current, pageSizeList, activeId, JobBegDate, JobDate, breadList
    } = this.state;
    const { importCenterStore: { importList, recordList } } = this.props;
    const { TotalRowsCount, PagedList } = importList;

    return (
      <div className={`${classNamePre}`}>
        <div className={`${classNamePre}-bread yiye-global-bread`}>
          <Breadcrumb breads={breadList} />
        </div>
        <div className={`${classNamePre}-top-box`}>
          <div className={`${classNamePre}-upload-file`}>
            {
              // <ConstFormUploadFile
              //   onSuccess={this.onChange}
              //   onError={this.onError}
              //   id={this.info.couponGrpId}
              //   couponProIsExclude={this.info.couponProIsExclude}
              //   ProType={this.info.ProType}
              // >
              //   选择文件导入
              // </ConstFormUploadFile>
            }
            <ConstUploadFile
              text="选择文件导入"
              beforeUpload={this.beforeUpload}
              url={
                this.info.ProType === 0
                  ? `${uploadUrl}?id=${this.info.couponGrpId}&couponProIsExclude=${this.info.couponProIsExclude}`
                  : `${uploadSkuUrl}?id=${this.info.couponGrpId}&couponProIsExclude=${this.info.couponProIsExclude}`
              }
              accept=".xlsx"
            />
          </div>
          <Button onClick={this.downExcel}>下载Excel模版</Button>
        </div>

        {
          activeId === '2' ? (
            <div className={`${classNamePre}-search-time`}>
              <DateRangePicker
                className="ezrd-picker-demo"
                value={[JobBegDate, JobDate]}
                defaultValue={["2016-01-01", "2017-01-01"]}
                onChange={this.onChangeRange}
              />
              <Button onClick={this.search}>查询</Button>
            </div>
          ) : null
        }

        <div className={`${classNamePre}-tab`}>
          <Tabs
            type="top"
            activeId={activeId}
            onChange={this.onTabChange}
            borderRadius
            style={{ backgroundColor: '#fff' }}
          >
            <TabPanel
              tab="导入商品"
              id="1"
            >
              {
                this.info.ProType === 0 ? (
                  <Table
                    columns={goodColumns2}
                    datasets={PagedList}
                    rowKey="id"
                    pageInfo={{
                      totalItem: TotalRowsCount,
                      current,
                      pageSize: pageSizeList
                    }}
                    onChange={this.onChangeTable}
                  />
                ) : (
                  <Table
                    columns={goodColumns}
                    datasets={PagedList}
                    rowKey="id"
                    pageInfo={{
                      totalItem: TotalRowsCount,
                      current,
                      pageSize: pageSizeList
                    }}
                    onChange={this.onChangeTable}
                  />
                )
              }
            </TabPanel>
            <TabPanel
              tab="上传日志"
              id="2"
            >
              <Table
                columns={columns}
                datasets={recordList}
                onChange={this.onChange}
              />
            </TabPanel>
          </Tabs>
        </div>
      </div>
    );
  }
}
