import * as React from 'react';
import {
  Breadcrumb, Table, Notify
} from 'ezrd';
import moment from 'moment';
import { observer, inject } from 'mobx-react';
import ImportYiyeSearch from '../../components/import/importYiyeSearch';
import { sessSupplierCouponCodeKey } from '../../components/base/constant';
import ConstUploadFile from '../../components/base/constUploadFile';
import { downExcelCouponCodeUploadUrl } from '../../services/importCenter';
import { downBlob } from '../../utils/common';
// 新建
const classNamePre = 'yiye-import-coupon-code';

@inject('supplierStore')
@inject('importCenterStore')
@observer
class ImportYiye extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      breadList: [
        { name: '销售订单', href: "#/Yiye/Supplier/SaleOrder" },
        { name: '导入券码', strong: true }
      ],
      params: {}
    };
  }

  componentDidMount() {
    let params = {};
    try {
      params = JSON.parse(localStorage.getItem(sessSupplierCouponCodeKey));
    } catch (error) {
    //
    }
    this.setState({
      params
    }, () => {
      this.initData();
    });
  }

initData = async (data = {}) => {
  const { importCenterStore } = this.props;
  const { pageSize, current, params } = this.state;
  await importCenterStore.fetchCouponCodeUploadList({
    PageSize: pageSize,
    PageIndex: current,
    JobBegDate: moment().format("YYYY-MM-DD"),
    JobDate: moment().format("YYYY-MM-DD"),
    CouponGrpId: params.CouponGrpId,
    purchaseOrderId: params.PurchaseOrderId,
    ...data
  });
}

// 搜索按钮的回调
onSearch = (data, flag) => {
  if (flag !== 0) {
    this.setState({ current: 1 }, () => {
      this.initData(data);
    });
    return;
  }
  this.initData(data);
}

// 分页的回调
onChange = (data) => {
  let { current } = this.state;
  const { pageSize } = this.state;
  if (data.pageSize) {
    if (data.pageSize === pageSize) {
      return;
    }
    current = 1;
  }
  this.setState({
    pageSize: data.pageSize || pageSize,
    current: data.current || current
  }, () => {
    this.searchDom.onSearch(0);
  });
}

beforeUpload = (file) => {
  const { importCenterStore } = this.props;
  const { params } = this.state;
  importCenterStore.fetchCouponCodeUpload({
    CouponGrpId: params.CouponGrpId,
    purchaseOrderId: params.PurchaseOrderId
  }, { file }).then((res) => {
    if (!res.IsError) {
      Notify.success('文件导入成功');
      this.searchDom.onSearch();
    }
  }).catch(() => {});
  return false;
}

// 下载失败原因
downloadErr = async (data) => {
  const { importCenterStore } = this.props;
  const blob = await importCenterStore.fetchDownExcelDefaultGet(data.ExecMsg);
  downBlob(blob, `${data.FileName.replace('.xlsx', '')}-失败原因.xlsx`);
}

render() {
  const {
    breadList
  } = this.state;
  const { importCenterStore } = this.props;
  const { couponCodeUploadList } = importCenterStore;
  const columns = [
    // {
    //   title: '上传用户',
    //   bodyRender: data => <div>{data.UserName}</div>
    // },
    {
      title: '上传文件',
      name: 'FileName'
    },
    {
      title: '上传时间',
      bodyRender: data => (
        moment(data.ImportTime).format('YYYY-MM-DD HH:mm:ss')
      )
    },
    {
      title: '文件大小（MB）',
      name: 'FileSize'
    },
    {
      title: '处理行数',
      name: 'ExecRows',
      width: '120px'
    },
    {
      title: '处理状态',
      width: '120px',
      name: 'ExecStatusName'
    },
    {
      title: '处理完成时间',
      bodyRender: data => (
        moment(data.ExecTime).format('YYYY-MM-DD HH:mm:ss')
      )
    },
    {
      title: '返回信息',
      bodyRender: (data) => {
        if (data.ExecStatus === -3) {
          // return (
          //   <Button
          //     onClick={() => this.downloadErr(data)}
          //     isText
          //   >
          //   失败原因
          //   </Button>
          // );
          return (
            <a
              href={data.ExecMsg}
              rel="noopener noreferrer"
              target="_blank"
            >
            失败原因
            </a>
          );
        }
        return data.ExecMsg;
      }
    }
  ];
  return (
    <div className={`${classNamePre}`}>
      <div className="yiye-global-bread">
        <Breadcrumb breads={breadList} />
      </div>
      <div className="yiye-global-top-title">
        <div>驿业券券号不得超过20位</div>
      </div>
      {/** 搜索页面 */}
      <div>
        <ImportYiyeSearch
          ref={(ref) => { this.searchDom = ref; }}
          onSearch={this.onSearch}
          importCenterStore={importCenterStore}
        />
      </div>
      <div className={`${classNamePre}-contain`}>
        {/** 新增导入 */}
        <div className={`${classNamePre}-contain-import`}>
          <ConstUploadFile
            text="选择文件导入"
            beforeUpload={this.beforeUpload}
            url={downExcelCouponCodeUploadUrl}
            accept=".xlsx"
          />
        </div>
        {/** 内容 */}
        <div className={`${classNamePre}-contain-table`}>
          <Table
            columns={columns}
            datasets={couponCodeUploadList}
            rowKey="Id"
            onChange={this.onChange}
          />
        </div>
      </div>
    </div>
  );
}
}

export default ImportYiye;
