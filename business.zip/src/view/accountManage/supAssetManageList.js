import * as React from 'react';
import { observer, inject } from 'mobx-react';
import { Link } from 'react-router-dom';
import {
  Title, Pop, Icon
} from 'ezrd';
import moment from 'moment';
import {
  couponDefaultPage,
  defaultCategorySettingType
} from '../../components/base/constant';
import { getMchId, multiplication } from '../../utils/common';

const classNamePre = 'yiye-asset-manage-list';

@inject('accountStore')
@observer
export default class SupAssetManageList extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      ...couponDefaultPage,
      emptyTime: '0001-01-01 00:00:00',
      assetData: {},
      platformFee: {}
    };
  }

  componentWillMount() {
    this.initData();
  }

  initData = async () => {
    const { accountStore } = this.props;
    accountStore.fetchGetTotalBrandIncome();
    const status = await accountStore.fetchGetAssetAccount({
      MchId: getMchId()
    });
    if (!status.IsError) {
      this.setState({
        assetData: status.Data
      });
    }
    const platformFeeStatus = await accountStore.fetchAssetAccountPlatformFee({
      MchId: getMchId(),
      SettingType: defaultCategorySettingType.coupon
    });

    if (platformFeeStatus && !platformFeeStatus.IsError && platformFeeStatus.Data) {
      this.setState({
        platformFee: platformFeeStatus.Data
      });
    }
  }

  // 数字回显操作
  numberTrans = (value = 0, isPerce) => {
    if (value === 0) {
      return '--';
    }
    if (isPerce) {
      const n = multiplication(value, 100);

      return `${n.toFixed(2)}%`;
    }
    return value.toFixed(2);
  }

  // 时间格式化
  initDateTipTpl = (start, end) => {
    const { emptyTime } = this.state;
    if (start && end) {
      let startDate = null; let endDate = null;
      if (start === emptyTime) {
        startDate = '--';
      } else {
        startDate = moment(start).format('YYYY-MM-DD HH:mm:ss');
      }
      if (end === emptyTime) {
        endDate = '--';
      } else {
        endDate = moment(end).format('YYYY-MM-DD HH:mm:ss');
      }
      return `优惠有效期：${startDate} 至 ${endDate}`;
    }
    return `优惠有效期：-- 至 --`;
  }

  render() {
    const {
      assetData, platformFee
    } = this.state;
    const { accountStore } = this.props;
    return (
      <div className={`${classNamePre}`}>
        <div className={`${classNamePre}-top`}>
          <Title
            titleDesc="充值资金"
            className={`${classNamePre}-top-title`}
          >
            <div className={`${classNamePre}-con`}>
              <div>
                <div className={`${classNamePre}-con-top`}>
                  <span>余额(元)</span>
                  <Pop
                    trigger="hover"
                    position="top-left"
                    content="先将资金充值到余额，再根据业务需要充值到Z币和保证金"
                  >
                    <Icon
                      type="info"
                      ezrd
                    />
                  </Pop>
                  <Link
                    to="/Yiye/Account/supAssetManageRechargeDetail"
                  >
                  充值/明细
                  </Link>
                </div>
                <div className={`${classNamePre}-con-money`}>{ this.numberTrans(assetData.CashReserve) }</div>
              </div>
              <div>
                <div className={`${classNamePre}-con-bottom`}>
                  <span>保证金(元)</span>
                  {
                    // <Link
                    //   to="/Yiye/Account/AccountInfo/AssetManageBondDetail"
                    // >
                    //   充值/明细
                    // </Link>
                  }
                </div>
                <div className={`${classNamePre}-con-money`}>{ this.numberTrans(assetData.CashDeposit) }</div>
              </div>
            </div>
          </Title>
        </div>
        <div className={`${classNamePre}-center`}>
          <Title
            titleDesc="虚拟资产"
            className={`${classNamePre}-top-title`}
          >
            <div className={`${classNamePre}-con`}>
              <div>
                <div className={`${classNamePre}-con-top`}>
                  <span>Z币(元)</span>
                  <Pop
                    trigger="hover"
                    position="top-left"
                    content="含充值及在平台赚取的费用，可任意在平台消费"
                  >
                    <Icon
                      type="info"
                      ezrd
                    />
                  </Pop>
                  <Link
                    to="/Yiye/Account/supAssetManageZDetail"
                  >
                    充值/明细
                  </Link>
                </div>
                <div className={`${classNamePre}-con-money`}>{ this.numberTrans(assetData.Zb) }</div>
              </div>
              {
                // <div>
                //   <div className={`${classNamePre}-con-bottom`}>
                //     <span>待提取收益(Z币)</span>
                //     <Pop
                //       trigger="hover"
                //       position="top-center"
                //       content="在平台赚取的费用，需提取到Z币账户中才能在平台使用"
                //     >
                //       <Icon
                //         type="info"
                //         ezrd
                //       />
                //     </Pop>
                //     {
                //       <Link
                //         to="/Yiye/Account/AccountInfo/AssetManageZDetail"
                //       >
                //       申请提取收益
                //       </Link>
                //     }
                //   </div>
                //   <div className={`${classNamePre}-con-money`}>{ this.numberTrans(assetData.CashFrozen) }</div>
                // </div>
              }
              {
                <div>
                  <div className={`${classNamePre}-con-bottom`}>
                    <span>品牌收益核准(Z币)</span>
                    <Pop
                      trigger="hover"
                      position="top-center"
                      content="品牌客户在驿业平台获取的Z币收益"
                    >
                      <Icon
                        type="info"
                        ezrd
                      />
                    </Pop>
                    <Link
                      to="/Yiye/Account/SupCheckBrandIncome"
                    >
                      品牌收益核准
                    </Link>
                  </div>
                  <div className={`${classNamePre}-con-money`}>{ accountStore.checkTotalBrandIncome.Data && accountStore.checkTotalBrandIncome.Data.toFixed(2) }</div>
                </div>
              }
            </div>
          </Title>
        </div>
        <div className={`${classNamePre}-bottom`}>
          <Title
            titleDesc={(
              <div>
                <span>平台手续费</span>
                <span className={`${classNamePre}-top-title-sub`}>发布的优惠券，被采购核销后平台需要收取的手续费</span>
              </div>
            )}
            className={`${classNamePre}-top-title`}
          >
            <div className={`${classNamePre}-con`}>
              <ul>
                <li>
                  <div className={`${classNamePre}-con-top`}>
                    <span>供券方手续费(Z币)</span>
                    <Pop
                      trigger="hover"
                      position="top-left"
                      content="每核销一张券平台扣取金额"
                    >
                      <Icon
                        type="info"
                        ezrd
                      />
                    </Pop>
                  </div>
                  <div className={`${classNamePre}-con-money`}>{ this.numberTrans(platformFee.DefaultFee) }</div>
                </li>
                {
                  // <li>
                  //   <div className={`${classNamePre}-con-top`}>
                  //     <span>供券方优惠手续费(Z币)</span>
                  //     <Pop
                  //       trigger="hover"
                  //       position="top-center"
                  //       content={this.initDateTipTpl(platformFee.PreferentialStartDate, platformFee.PreferentialEndDate)}
                  //     >
                  //       <Icon
                  //         type="info"
                  //         ezrd
                  //       />
                  //     </Pop>
                  //   </div>
                  //   <div className={`${classNamePre}-con-money`}>{ this.numberTrans(platformFee.PreferentialFee) }</div>
                  // </li>
                }

                <li>
                  <div className={`${classNamePre}-con-top`}>
                    <span>采购方手续费(Z币)</span>
                    <Pop
                      trigger="hover"
                      position="top-center"
                      content="平台按核销券奖励佣金金额比例提成"
                    >
                      <Icon
                        type="info"
                        ezrd
                      />
                    </Pop>
                  </div>
                  <div className={`${classNamePre}-con-money`}>{ this.numberTrans(platformFee.DefaultRate, true) }</div>
                </li>
                {
                  // <li>
                  //   <div className={`${classNamePre}-con-top`}>
                  //     <span>采购方优惠手续费(Z币)</span>
                  //     <Pop
                  //       trigger="hover"
                  //       position="top-right"
                  //       content={this.initDateTipTpl(platformFee.PreferentialStartDate, platformFee.PreferentialEndDate)}
                  //     >
                  //       <Icon
                  //         type="info"
                  //         ezrd
                  //       />
                  //     </Pop>
                  //   </div>
                  //   <div className={`${classNamePre}-con-money`}>{ this.numberTrans(platformFee.PreferentialRate, true) }</div>
                  // </li>
                }
              </ul>
            </div>
          </Title>
        </div>
      </div>
    );
  }
}
