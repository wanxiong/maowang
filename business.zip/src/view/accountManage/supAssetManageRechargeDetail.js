import * as React from 'react';
import {
  Icon, Table, Pop, Notify
} from 'ezrd';
import { observer, inject } from 'mobx-react';
import { toJS } from 'mobx';
import moment from 'moment';
import SupAssetManageSearch from '../../components/assetManage/supAssetManageSearch';
import { assetManageRechargeDetailStatus, couponDefaultPage, defaultRechargeDetailStatus } from '../../components/base/constant';
import RechargeDialog from '../../components/assetManage/rechargeDialog';
import DefaultTipDialog from '../../components/transaction/defaultTipDialog';
// 新建
const classNamePre = 'yiye-asset-manage-recharge';

@inject('accountStore')
@observer
export default class SupAssetManageRechargeDetail extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      showDialog: false,
      loading: false,
      // money: 0, // 账户余额
      title: '余额充值审核',
      bankList: [],
      isUpdate: false, // 更新数据源的状态 是编辑还是新增
      updateJson: {}, // 更新数据的数据源
      showFinillyDialog: false, // 显示最终的审核确定弹框
      ...couponDefaultPage
    };
  }

  async componentDidMount() {
    this.initData({
      Status: defaultRechargeDetailStatus
    });
    this.initBankList();
  }

  componentWillUnmount() {
    const { accountStore } = this.props;
    accountStore.assetRechargeList = {
      Data: [],
      Count: 0
    };
  }

initData = async (params = {}) => {
  const { accountStore } = this.props;
  const { pageSize, current } = this.state;
  if (!params.MchId) {
    return;
  }
  await accountStore.fetchGetAssetRechargeList({
    MchId: '',
    PageSize: pageSize,
    Page: current,
    ...params
  });
}

// 分页的回调
onChange = (data) => {
  let { current } = this.state;
  const { pageSize } = this.state;
  if (data.pageSize) {
    if (data.pageSize === pageSize) {
      return;
    }
    current = 1;
  }
  this.setState({
    pageSize: data.pageSize || pageSize,
    current: data.current || current
  }, () => {
    this.searchDom.onSearch(0);
  });
}

// 搜索按钮的回调
onSearch = (data, flag) => {
  const params = {
    EndDate: data.EndDate,
    StartDate: data.StartDate,
    Status: data.Status,
    MchId: data.brandId || 0
  };
  if (flag !== 0) {
    this.setState({ current: 1 }, () => {
      this.initData(params);
    });
    return;
  }
  this.initData(params);
}

// 获取银行
initBankList= async () => {
  const { accountStore } = this.props;
  const { Data } = await accountStore.fetchGetAssetBankSelectAll({});
  this.setState({
    bankList: Data || []
  });
}

// 打开充值弹出框
openDialog = (flag, data) => {
  let txt = '';
  if (flag) {
    txt = '余额充值审核';
  } else if (data.Status === 2) {
    txt = '已入账';
  } else if (data.Status === -2) {
    txt = '审核失败';
  }
  this.setState({
    showDialog: true, isUpdate: flag, updateJson: toJS(data), title: txt, isShowRemark: !flag
  });
}

onClose = () => {
  this.setState({ showDialog: false });
}

// 详情
examine = async (flag, json) => {
  const { accountStore } = this.props;
  this.openDialog(flag, json);
  const status = await accountStore.fetchAssetRechargeBankDetail({
    Id: json.Id,
    MchId: json.MchId
  });
  if (status && !status.IsError) {
    this.setState({
      updateJson: toJS(status.Data)
    });
  }
}

// 审核
rechargeCheck = async (params, fn) => {
  const { accountStore } = this.props;
  const status = await accountStore.fetchAssetRechargeCheck(params);
  if (!status.IsError) {
    Notify.success('审核成功');
    fn();
  }
  this.setState({ loading: false });
}

// 提交
onConfirm = async (data, fn, isUpdate) => {
  // 来自查看
  if (!isUpdate) {
    this.setState({ showDialog: false });
    fn();
    return;
  }
  const customFn = async () => {
    const { updateJson } = this.state;
    this.setState({ loading: true });
    const params = {
      Id: updateJson.Id,
      IsPass: data.auditStatus,
      Remark: data.remark,
      MchId: updateJson.MchId
    };
    this.rechargeCheck(params, () => {
      this.setState({ showDialog: false });
      fn();
      this.searchDom.onSearch(0);
    });
  };
  // 如果是拒绝
  if (data.auditStatus !== '1') {
    customFn();
    return;
  }
  this.setState({
    showFinillyDialog: true,
    showFinillyDialogData: customFn
  });
}


finillyConfirm = (flag, custom) => {
  if (!flag) {
    this.setState({
      showFinillyDialog: false
    });
  } else {
    this.setState({
      showFinillyDialog: false
    });
    custom();
  }
}

// 模板
initStatusTpl = (data) => {
  if (data.Status === 0) {
    // 0:审核中
    // 审核状态；[-3:入账失败;-2:审核未通过;-1:取消;0:审核中;1:审核通过;2:已入账;]
    return (
      <span>待审核</span>
    );
  } if (data.Status === 2) {
    // 2:已入账
    return (
      <span>已入账</span>
    );
  } if (data.Status === -2) {
    // 审核未通过
    return (
      <React.Fragment>
        <span style={{ 'margin-right': '3px' }}>审核失败</span>
        <Pop
          trigger="hover"
          position="left-center"
          content={data.Remark}
        >
          <Icon
            type="info"
            ezrd
          />
        </Pop>
      </React.Fragment>
    );
  }
  return null;
}

render() {
  const {
    current, pageSizeList, showDialog, bankList, loading, isShowRemark, updateJson, isUpdate, title, showFinillyDialog, showFinillyDialogData
  } = this.state;
  const { accountStore, history } = this.props;
  const { assetRechargeList } = accountStore;
  const { Data, Count } = assetRechargeList;
  const columns = [
    {
      title: '品牌',
      name: 'MchName'
    },
    {
      title: '充值时间',
      bodyRender: data => <div>{moment(data.CreateOn).format('YYYY-MM-DD HH:mm:ss')}</div>
    },
    {
      title: '金额(元)',
      bodyRender: data => <div>{data.CashCount.toFixed(2)}</div>
    },
    {
      title: '转账银行',
      width: '120px',
      name: 'BankName'
    },
    {
      title: '转账流水号',
      width: '320px',
      bodyRender: data => <div style={{ 'word-break': 'break-word' }}>{data.BankRecordNo}</div>
    },
    {
      title: '状态',
      width: '140px',
      bodyRender: data => this.initStatusTpl(toJS(data))
    },
    {
      title: '操作',
      width: '140px',
      bodyRender: (data) => {
        if (data.Status === 0) {
          // 审核中
          return (
            <span
              role="button"
              tabIndex="0"
              className="yiye-outline btn-default-color yiye-cursor"
              onClick={() => this.examine(true, data)}
            >
              审核
            </span>
          );
        } if (data.Status === 2) {
          // 已入账
          return (
            <span
              role="button"
              tabIndex="0"
              className="yiye-outline btn-default-color yiye-cursor"
              onClick={() => this.examine(false, data)}
            >
              查看
            </span>
          );
        } if (data.Status === -2) {
          // 审核未通过
          return (
            <span
              role="button"
              tabIndex="0"
              className="yiye-outline btn-default-color yiye-cursor"
              onClick={() => this.examine(false, data)}
            >
              查看
            </span>
          );
        }
        return '--';
      }
    }
  ];
  return (
    <div className={`${classNamePre}`}>
      {/* 搜索区域 */}
      <div style={{ 'margin-top': '20px' }}>
        <SupAssetManageSearch
          data={assetManageRechargeDetailStatus}
          defautlSelect={defaultRechargeDetailStatus}
          typeName="充值明细"
          downloadStore={accountStore}
          history={history}
          downloadType="recharge"
          ref={(ref) => { this.searchDom = ref; }}
          onSearch={this.onSearch}
          filtersId={1}
          DateRangePickerText="充值时间："
        />
      </div>
      <div className={`${classNamePre}-contain`}>
        {/* table展示区域 */}
        <div className={`${classNamePre}-contain-table`}>
          <Table
            columns={columns}
            datasets={Data}
            rowKey="Id"
            pageInfo={{
              totalItem: Count,
              current,
              pageSize: pageSizeList
            }}
            onChange={this.onChange}
          />
        </div>
      </div>
      {/* 充值弹出框 */}
      <RechargeDialog
        show={showDialog}
        onClose={this.onClose}
        selectList={bankList}
        title={title}
        isShowAudit={isUpdate}
        isShowBank
        loading={loading}
        isUpdate={isUpdate}
        onConfirm={this.onConfirm}
        updateJson={updateJson}
        disabled
        footerGrp={isUpdate ? 'default' : 'look'}
        isShowRemark={isShowRemark}
        showMoney={false}
      />
      {/** 最终确认弹出框 */}
      <DefaultTipDialog
        showEnableVisible={showFinillyDialog}
        content="通过审核后，金额将入账到品牌客户账户，请确认操作"
        loading={false}
        confirmEnable={this.finillyConfirm}
        title="确定通过审核吗？"
        customFlag={showFinillyDialogData}
      />
    </div>
  );
}
}
