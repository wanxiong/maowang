import * as React from 'react';
import {
  Button, Icon, Table, Pop, Notify
} from 'ezrd';
import { observer, inject } from 'mobx-react';
import { toJS } from 'mobx';
import moment from 'moment';
import AssetManageSearch from '../../components/assetManage/assetManageSearch';
import { assetManageRechargeDetailStatus, couponDefaultPage, defaultRechargeDetailStatus } from '../../components/base/constant';
import { getMchId } from '../../utils/common';
import RechargeDialog from '../../components/assetManage/rechargeDialog';
// 新建
const classNamePre = 'yiye-asset-manage-recharge';

@inject('accountStore')
@observer
export default class AssetManageRechargeDetail extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      showDialog: false,
      loading: false,
      money: 0, // 账户余额
      bankList: [],
      isUpdate: false, // 更新数据源的状态 是编辑还是新增
      updateJson: {}, // 更新数据的数据源
      ...couponDefaultPage
    };
  }

  async componentDidMount() {
    this.initData({
      Status: defaultRechargeDetailStatus
    });
    this.initBankList();
  }

initData = async (params = {}) => {
  const { accountStore } = this.props;
  const { pageSize, current } = this.state;
  await accountStore.fetchGetAssetRechargeList({
    MchId: getMchId(),
    PageSize: pageSize,
    Page: current,
    ...params
  });
  this.initAccountMoney();
}

// 分页的回调
onChange = (data) => {
  let { current } = this.state;
  const { pageSize } = this.state;
  if (data.pageSize) {
    if (data.pageSize === pageSize) {
      return;
    }
    current = 1;
  }
  this.setState({
    pageSize: data.pageSize || pageSize,
    current: data.current || current
  }, () => {
    this.searchDom.onSearch(0);
  });
}

// 搜索按钮的回调
onSearch = (data, flag) => {
  if (flag !== 0) {
    this.setState({ current: 1 }, () => {
      this.initData(data);
    });
    return;
  }
  this.initData(data);
}

// 获取银行
initBankList= async () => {
  const { accountStore } = this.props;
  const { Data } = await accountStore.fetchGetAssetBankSelectAll({});
  this.setState({
    bankList: Data || []
  });
}

// 新增转账
initBankApply = async (params) => {
  const { accountStore } = this.props;
  const status = await accountStore.fetchGetAssetRechargeBankApply(params);
  if (!status.IsError) {
    Notify.success('转账成功');
    return 1;
  }
  return 0;
}

// 修改转账
updateBankApply = async (params) => {
  const { accountStore } = this.props;
  const status = await accountStore.fetchAssetRechargeBankUpdate(params);
  if (!status.IsError) {
    Notify.success('更新成功');
    return 1;
  }
  return 0;
}

// 获取财务信息
initAccountMoney = async () => {
  const { accountStore } = this.props;
  const { Data } = await accountStore.fetchGetAssetAccount({ MchId: getMchId() });
  this.setState({ money: Data.CashReserve });
}

// 打开充值弹出框
openDialog = (flag, data) => {
  this.setState({ showDialog: true, isUpdate: flag, updateJson: toJS(data) });
}

onClose = () => {
  this.setState({ showDialog: false });
}

// 修改银行流水图片
uodateBankImage = async (params) => {
  const { accountStore } = this.props;
  const status = await accountStore.fetchAssetRechargeBankImageUpdate(params);
  if (!status.IsError) {
    return 1;
  }
  return 0;
}

// 详情
bankDetail = async (flag, json) => {
  const { accountStore } = this.props;
  const status = await accountStore.fetchAssetRechargeBankDetail({
    Id: json.Id,
    MchId: getMchId()
  });
  if (status && !status.IsError) {
    this.openDialog(flag, status.Data);
  }
}

// 提交
onConfirm = async (data, fn, edit) => {
  const { updateJson } = this.state;
  this.setState({ loading: true });
  const params = {
    CashCount: data.moneyValue || '',
    BankName: data.selectChangeValue,
    BankRecordNo: data.flowValue,
    ImageData: data.file.src,
    MchId: getMchId()
  };
  if (edit) {
    params.Id = updateJson.Id;
    if (await this.updateBankApply(params)) {
      this.setState({ showDialog: false });
      fn();
      this.searchDom.onSearch(0);
    }
  } else if (await this.initBankApply(params)) {
    this.setState({ showDialog: false });
    fn();
    this.searchDom.onSearch(0);
  }
  this.setState({ loading: false });
}

// 金额的状态模板
initStatusTpl = (data) => {
  if (data.Status === 0) {
    // 0:审核中
    // 审核状态；[-3:入账失败;-2:审核未通过;-1:取消;0:审核中;1:审核通过;2:已入账;]
    return (
      <span>待审核</span>
    );
  } if (data.Status === 2) {
    // 2:已入账
    return (
      <span>已入账</span>
    );
  } if (data.Status === -2) {
    // 审核未通过
    return (
      <React.Fragment>
        <span style={{ 'margin-right': '3px' }}>审核失败</span>
        <Pop
          trigger="hover"
          position="left-center"
          content={data.Remark}
        >
          <Icon
            type="info"
            ezrd
          />
        </Pop>
      </React.Fragment>
    );
  }
  return null;
}

render() {
  const {
    current, pageSizeList, showDialog, bankList, loading, money, updateJson, isUpdate
  } = this.state;
  const { accountStore, history } = this.props;
  const { assetRechargeList } = accountStore;
  const { Data, Count } = assetRechargeList;
  const columns = [
    {
      title: '新增时间',
      bodyRender: data => <div>{moment(data.CreateOn).format('YYYY-MM-DD HH:mm:ss')}</div>
    },
    {
      title: '金额',
      bodyRender: data => <div>{data.CashCount.toFixed(2)}</div>
    },
    {
      title: '转账银行',
      name: 'BankName'
    },
    {
      title: '转账流水号',
      width: '320px',
      bodyRender: data => <div style={{ 'word-break': 'break-word' }}>{data.BankRecordNo}</div>
    },
    {
      title: '状态',
      bodyRender: data => this.initStatusTpl(toJS(data))
    },
    {
      title: '操作',
      bodyRender: (data) => {
        if (data.Status === 0) {
          return (
            <span
              role="button"
              tabIndex="0"
              className="yiye-outline btn-default-color yiye-cursor"
              onClick={() => this.bankDetail(true, data)}
            >
              修改
            </span>
          );
        }
        return '--';
      }
    }
  ];
  return (
    <div className={`${classNamePre}`}>
      {/* 公司基本账户信息 */}
      {
        // <div>
        //   <Alert
        //     className={`${classNamePre}-title`}
        //     type="warning"
        //     rounded
        //   >
        //   转账名称：上海驿氪信息科技有限公司，账号：12323213232132，开户行：上海宁波；
        //   </Alert>
        // </div>
      }
      {/* 搜索区域 */}
      <div style={{ 'margin-top': '20px' }}>
        <AssetManageSearch
          data={assetManageRechargeDetailStatus}
          defautlSelect={defaultRechargeDetailStatus}
          typeName="充值明细"
          downloadStore={accountStore}
          history={history}
          downloadType="recharge"
          ref={(ref) => { this.searchDom = ref; }}
          onSearch={this.onSearch}
        />
      </div>
      <div className={`${classNamePre}-contain`}>
        <div>
          <Button
            type="primary"
            size="middle"
            onClick={() => this.openDialog(false, {})}
          >
          新增金额
          </Button>
        </div>
        {/* table展示区域 */}
        <div className={`${classNamePre}-contain-table`}>
          <Table
            columns={columns}
            datasets={Data}
            rowKey="Id"
            pageInfo={{
              totalItem: Count,
              current,
              pageSize: pageSizeList
            }}
            onChange={this.onChange}
          />
        </div>
      </div>
      {/* 充值弹出框 */}
      <RechargeDialog
        show={showDialog}
        onClose={this.onClose}
        selectList={bankList}
        money={money}
        isShowBank
        loading={loading}
        isUpdate={isUpdate}
        onConfirm={this.onConfirm}
        updateJson={updateJson}
      />
    </div>
  );
}
}
