import * as React from 'react';
import {
  Button, Table, Notify
} from 'ezrd';
import { observer, inject } from 'mobx-react';
import AssetManageSearch from '../../components/assetManage/assetManageSearch';
import RechargeDialog from '../../components/assetManage/rechargeDialog';
import {
  assetManageZDetailStatus, couponDefaultPage, defaultZDetailStatus, defaultRechargeApiType
} from '../../components/base/constant';
import { getMchId } from '../../utils/common';
// 新建

const classNamePre = 'yiye-asset-manage-z-detail';

@inject('accountStore')
@observer
export default class AssetManageZDetail extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      showDialog: false,
      loading: false,
      money: 0, // 账户余额
      ...couponDefaultPage
    };
  }

  async componentDidMount() {
    this.initData({
      TradeType: defaultZDetailStatus
    });
  }

initData = async (params = {}) => {
  const { accountStore } = this.props;
  const { pageSize, current } = this.state;
  await accountStore.fetchGetAssetZDetailList({
    MchId: getMchId(),
    PageSize: pageSize,
    Page: current,
    ...params
  });
  this.initAccountMoney();
}

 // 分页的回调
 onChange = (data) => {
   let { current } = this.state;
   const { pageSize } = this.state;
   if (data.pageSize) {
     if (data.pageSize === pageSize) {
       return;
     }
     current = 1;
   }
   this.setState({
     pageSize: data.pageSize || pageSize,
     current: data.current || current
   }, () => {
     this.searchDom.onSearch(0);
   });
 }

// 搜索按钮的回调
onSearch = (data, flag) => {
  if (flag !== 0) {
    this.setState({ current: 1 }, () => {
      this.initData(data);
    });
    return;
  }
  this.initData(data);
}

// 获取财务信息
initAccountMoney = async () => {
  const { accountStore } = this.props;
  const { Data } = await accountStore.fetchGetAssetAccount({ MchId: getMchId() });
  this.setState({ money: Data.CashReserve });
}

// Z币充值接口
initRechargeZ = async (params, fn) => {
  const { accountStore } = this.props;
  const status = await accountStore.fetchGetAssetRechargeZ(params);
  if (!status.IsError) {
    Notify.success('充值Z币成功');
    fn();
  }
  this.setState({ loading: false });
}

// 打开充值弹出框
openDialog = () => {
  this.setState({ showDialog: true });
}

onClose = () => {
  this.setState({ showDialog: false });
}

// 提交
onConfirm = async (data, fn) => {
  this.setState({ loading: true });
  const params = {
    TradeCount: data.moneyValue,
    TradeType: defaultRechargeApiType.ZType,
    MchId: getMchId()
  };
  this.initRechargeZ(params, () => {
    this.setState({ showDialog: false });
    fn();
    this.searchDom.onSearch(0);
  });
}

render() {
  const {
    current, pageSizeList, showDialog, loading, money
  } = this.state;
  const { history, accountStore } = this.props;
  const { assetZList } = accountStore;
  const { Data, Count } = assetZList;
  const statusList = {};
  assetManageZDetailStatus.forEach((item) => {
    statusList[item.id] = item.name;
  });
  const columns = [
    {
      title: '交易时间',
      bodyRender: data => <div>{data.CreateOn}</div>
    },
    {
      title: '交易类型',
      bodyRender: data => (
        <div>{ statusList[data.TradeType] }</div>
      )
    },
    {
      title: '交易金额',
      bodyRender: data => (
        <div className={`${classNamePre}-recharge`}>
          {data.TradeCount}
        </div>
      )
    },
    {
      title: '交易单号',
      name: 'ETradeNo'
    }
  ];
  return (
    <div className={`${classNamePre}`}>
      {/* 搜索区域 */}
      <div style={{ 'margin-top': '20px' }}>
        <AssetManageSearch
          data={assetManageZDetailStatus}
          statusKey="TradeType"
          defautlSelect={defaultZDetailStatus}
          ref={(ref) => { this.searchDom = ref; }}
          onSearch={this.onSearch}
          typeName="充值Z币/明细"
          DateRangePickerText="交易时间："
          typeSelectText="交易类型："
          downloadType="rechargeZB"
          downloadStore={accountStore}
          history={history}
        />
      </div>
      <div className={`${classNamePre}-contain`}>
        <div>
          <Button
            type="primary"
            size="middle"
            onClick={this.openDialog}
          >
          充值Z币
          </Button>
        </div>
        {/* table展示区域 */}
        <div className={`${classNamePre}-contain-table`}>
          <Table
            columns={columns}
            datasets={Data}
            rowKey="Id"
            pageInfo={{
              totalItem: Count,
              current,
              pageSize: pageSizeList
            }}
            onChange={this.onChange}
          />
        </div>
      </div>
      {/* 充值弹出框 */}
      <RechargeDialog
        show={showDialog}
        onClose={this.onClose}
        loading={loading}
        money={money}
        title="充值Z币"
        history={history}
        url="/Yiye/Account/AccountInfo/AssetManageRechargeDetail"
        onConfirm={this.onConfirm}
        moneyTitle="充值Z币金额"
        moneyCkeckText="充值Z币金额"
      />
    </div>
  );
}
}
