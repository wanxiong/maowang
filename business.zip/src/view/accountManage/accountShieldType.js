import * as React from 'react';
import {
  Switch, Title, Notify, Radio
} from 'ezrd';
import { observer, inject } from 'mobx-react';
import {
  couponDefaultPage,
  defaultCategorySettingType
} from '../../components/base/constant';

import { getMchId } from '../../utils/common';
import AccountShieldCategory from '../../components/assetManage/accountShieldCategory';
import AccountShieldBrand from '../../components/assetManage/accountShieldBrand';
// 新建

const RadioGroup = Radio.Group;
const classNamePre = 'yiye-account-shield';

@inject('accountStore')
@observer
export default class AccountShieldType extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      radioValue: '1',
      switchStatus: false,
      // loading: false,
      isFlagSetting: false,
      category: [],
      categoryParentIndex: {}, // 类目或者行业的数据源，一级索引
      categoryChildIndex: {}, // 类目或者行业的数据源，二级索引
      categoryValue: [], //  已选择的类目
      industry: [], // 行业数据
      brandValue: '', // 品牌输入
      ...couponDefaultPage
    };
  }

  async componentDidMount() {
    // 获取类目
    await this.initCategory();
    // 获取类目状态
    this.initCategoryStatus();
    // 获取已添加的类目
    this.initShieldList();
    // 获取行业、
    this.initIndustry();
  }

  // 经营类目的回调
  onChangeCategory = () => {
    // console.log(data);
  }

  // 切换屏蔽类型
  onChangeRadio = (e) => {
    this.setState({ radioValue: e.target.value, brandValue: '' });
  }

  // 切换开启类目
  onChangeSwitch = (checked) => {
    this.initCategorySwitch(checked);
  }

  // 开启或者关闭类目
  initCategorySwitch = async (checked) => {
    const { accountStore } = this.props;
    const { isFlagSetting } = this.state;
    if (isFlagSetting) return;
    this.setState({ isFlagSetting: true });
    const status = await accountStore.fetchGetAccountShieldSetting({
      MchId: getMchId(),
      IsOn: checked ? 1 : 0,
      SettingType: defaultCategorySettingType.coupon
    });
    this.setState({ isFlagSetting: false });
    if (status && !status.IsError) {
      if (checked) {
        Notify.success('设置成功');
      }
      this.setState({ switchStatus: checked });
    }
  }

  // 获取类目状态
  initCategoryStatus = async () => {
    const { accountStore } = this.props;
    const status = await accountStore.fetchGetAccountShieldStatus({
      MchId: getMchId(),
      SettingType: defaultCategorySettingType.coupon
    });
    // isOn = 0 禁用，isOn=1 启用。
    if (!status.IsError) {
      if (status.Data) {
        this.setState({ switchStatus: status.Data.IsOn === 1 });
      }
    }
  }

  // 行业初始化接口
  initIndustry = async () => {
    const { accountStore } = this.props;
    const { Data } = await accountStore.fetchAccountInfoIndustryList({});
    const data = Data.filter(item => item.ParentId === 0);
    this.setState({ industry: data });
  }

  // 获取类目
  initCategory = async () => {
    const { accountStore } = this.props;
    const { Data } = await accountStore.fetchAccountInfoSelectAll({});
    const parent = [];
    const children = [];
    // 后台啥都不给，一波吐槽
    const parentIndex = {};
    const childrenIndex = {};
    Data.forEach((item) => {
      if (item.ParentId === 0) { // 一级别
        parent.push(item);
        parentIndex[item.Id] = item;
      } else {
        children.push(item);
        childrenIndex[item.Id] = item;
      }
    });
    const newArr = parent.map((item) => {
      const obj = {
        id: item.Id,
        title: item.Name,
        ParentId: item.ParentId,
        children: []
      };
      for (let i = 0; i < children.length; i++) {
        if (children[i].ParentId === item.Id) {
          obj.children.push({
            id: children[i].Id,
            title: children[i].Name,
            ParentId: children[i].ParentId
          });
        }
      }
      return obj;
    });
    this.setState({ category: newArr || [], categoryChildIndex: childrenIndex, categoryParentIndex: parentIndex });
  }

  // 添加屏蔽类目的回调
  onAddCategory = async (data, fn) => {
    const { accountStore } = this.props;
    const { radioValue, categoryValue } = this.state;
    // this.setState({ loading: true });
    const params = {
      MchId: getMchId(),
      SettingType: defaultCategorySettingType.coupon,
      SelectedType: radioValue,
      SelectedIds: `${data[1].id}`
    };
    const status = await accountStore.fetchGetAccountShieldItem(params);
    if (!status.IsError) {
      Notify.success('新增成功');
      // 按照道理来讲 这应该不需要调用接口，就本地操作
      this.initShieldList();
      // categoryValue.push([{
      //   id: data[0].id,
      //   Name: data[0].title
      // }, {
      //   id: data[1].id,
      //   Name: data[1].title
      // }]);
      fn();
    }
    this.setState({ categoryValue });
  }

  // 获取屏蔽的类目或者品牌
  initShieldList = async () => {
    const { accountStore } = this.props;
    const { radioValue, categoryChildIndex, categoryParentIndex } = this.state;
    const params = {
      MchId: getMchId(),
      SettingType: defaultCategorySettingType.coupon,
      PageSize: 999999,
      Page: 1,
      SelectedType: radioValue
    };
    const status = await accountStore.fetchGetAccountShieldItemList(params);
    if (!status.IsError) {
      // 后端返回的就是二级索引，此处解释一万个再奔腾。。。
      const arr = [];
      const data = status.Data.Data || [];
      for (let i = 0; i < data.length; i++) {
        // 存在二级请求数据处理并且添加一级请求
        const item = categoryChildIndex[data[i].SelectedId];
        if (item) {
          const parentItem = categoryParentIndex[item.ParentId];
          arr.push([{
            id: item.Id,
            Name: parentItem.Name
          }, {
            id: item.Id,
            Name: item.Name
          }]);
        }
      }
      this.setState({ categoryValue: arr });
    }
  }

  // 品牌的输入
  onChangeBrand = (v) => {
    this.setState({ brandValue: v });
  }

  // 删除品牌或者类目
  onRemoveItem = async (data, index) => {
    const { accountStore } = this.props;
    const { radioValue, categoryValue } = this.state;
    // this.setState({ loading: true });
    const params = {
      MchId: getMchId(),
      SettingType: defaultCategorySettingType.coupon,
      SelectedType: radioValue,
      SelectedId: data[1].id
    };
    const status = await accountStore.fetchGetAccountShieldDelItem(params);
    if (!status.IsError) {
      Notify.success('删除成功');
      categoryValue.splice(index, 1);
      this.setState({ categoryValue });
    }
    // this.setState({ loading: false });
  }

  // 模板的渲染
  initShieldTpl = () => {
    const {
      category, categoryValue, radioValue, brandValue, industry
    } = this.state;
    const { accountStore } = this.props;
    if (radioValue === '1') {
      return (
        <AccountShieldCategory
          category={category}
          classNamePre={classNamePre}
          chooseCateList={categoryValue}
          onConfirm={this.onAddCategory}
          onRemoveItem={this.onRemoveItem}
        />
      );
    }
    return (
      <AccountShieldBrand
        brandValue={brandValue}
        accountStore={accountStore}
        radioValue={radioValue}
        industry={industry}
        onChangeBrand={this.onChangeBrand}
        classNamePre={classNamePre}
      />
    );
  }

  render() {
    const { radioValue, switchStatus } = this.state;
    return (
      <div className={`${classNamePre}`}>
        <Title
          className={`${classNamePre}-conatain`}
          titleDesc="屏蔽设置"
        >
          {/* 屏蔽类目操作区域 */}
          <div className={`${classNamePre}-conatain-menu`}>
            <span>屏蔽状态</span>
            <div>
              <Switch
                checked={switchStatus}
                onChange={this.onChangeSwitch}
              />
            </div>
            <span>启用后可屏蔽指定的经营类目或品牌使其不可见我发布的券</span>
          </div>
          {
          switchStatus
            ? (
              <React.Fragment>
                {/* 屏蔽类型 */}
                <div className={`${classNamePre}-conatain-menu-check`}>
                  <RadioGroup
                    onChange={this.onChangeRadio}
                    value={radioValue}
                    className={`${classNamePre}-conatain-menu-radio`}
                  >
                    <Radio value="1">按经营类目</Radio>
                    <Radio value="2">按品牌</Radio>
                  </RadioGroup>
                </div>
              </React.Fragment>
            )
            : null
        }
        </Title>
        {
          switchStatus
            ? this.initShieldTpl()
            : null
        }
      </div>
    );
  }
}
