import * as React from 'react';
import {
  Button, Table, Notify
} from 'ezrd';
import { observer, inject } from 'mobx-react';
import AssetManageSearch from '../../components/assetManage/assetManageSearch';
import {
  assetManageBondDetailStatus, couponDefaultPage, defaultBondDetailStatus, defaultRechargeApiType
} from '../../components/base/constant';
import { getMchId } from '../../utils/common';
import RechargeDialog from '../../components/assetManage/rechargeDialog';
// 新建

const classNamePre = 'yiye-asset-manage-bond-detail';

@inject('accountStore')
@observer
export default class AssetManageBondDetail extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      showDialog: false,
      loading: false,
      money: 0, // 账户余额
      ...couponDefaultPage
    };
  }

  async componentDidMount() {
    this.initData({
      tradetype: defaultBondDetailStatus
    });
  }

initData = async (params = {}) => {
  const { accountStore } = this.props;
  const { pageSize, current } = this.state;
  await accountStore.fetchGetAssetBondDetailList({
    MchId: getMchId(),
    PageSize: pageSize,
    Page: current,
    ...params
  });
  this.initAccountMoney();
}

// 分页的回调
onChange = (data) => {
  let { current } = this.state;
  const { pageSize } = this.state;
  if (data.pageSize) {
    if (data.pageSize === pageSize) {
      return;
    }
    current = 1;
  }
  this.setState({
    pageSize: data.pageSize || pageSize,
    current: data.current || current
  }, () => {
    this.searchDom.onSearch(0);
  });
}

// 搜索按钮的回调
onSearch = (data, flag) => {
  if (flag !== 0) {
    this.setState({ current: 1 }, () => {
      this.initData(data);
    });
    return;
  }
  this.initData(data);
}

// 打开充值弹出框
openDialog = () => {
  this.setState({ showDialog: true });
}

onClose = () => {
  this.setState({ showDialog: false });
}

// 保证金充值接口
initRechargeBond = async (params, fn) => {
  const { accountStore } = this.props;
  const status = await accountStore.fetchGetAssetRechargeBond(params);
  if (!status.IsError) {
    Notify.success('充值保证金成功');
    fn();
  }
  this.setState({ loading: false });
}

// 获取财务信息
initAccountMoney = async () => {
  const { accountStore } = this.props;
  const { Data } = await accountStore.fetchGetAssetAccount({ MchId: getMchId() });
  this.setState({ money: Data.CashReserve });
}

// 提交
onConfirm = async (data, fn) => {
  this.setState({ loading: true });
  const params = {
    TradeCount: data.moneyValue,
    TradeType: defaultRechargeApiType.BondType,
    MchId: getMchId()
  };
  this.initRechargeBond(params, () => {
    this.setState({ showDialog: false });
    fn();
    this.searchDom.onSearch(0);
  });
}

render() {
  const {
    current, pageSizeList, showDialog, loading, money
  } = this.state;
  const { history, accountStore } = this.props;
  const { assetBondList } = accountStore;
  const { Data, Count } = assetBondList;
  const columns = [
    {
      title: '变更时间',
      bodyRender: data => <div>{data.CreateOn}</div>
    },
    {
      title: '类型',
      bodyRender: (data) => {
        if (defaultRechargeApiType.BondType === data.TradeType) {
          return ('充值');
        }
        return '--';
      }
    },
    {
      title: '金额',
      bodyRender: data => (
        <div className={`${classNamePre}-recharge`}>
          +
          {data.TradeCount}
        </div>
      )
    }
  ];
  return (
    <div className={`${classNamePre}`}>
      {/* 搜索区域 */}
      <div style={{ 'margin-top': '20px' }}>
        <AssetManageSearch
          data={assetManageBondDetailStatus}
          statusKey="tradetype"
          defautlSelect={defaultBondDetailStatus}
          typeName="保证金明细"
          typeSelectText="类型："
          downloadStore={accountStore}
          history={history}
          downloadType="rechargeBond"
          ref={(ref) => { this.searchDom = ref; }}
          onSearch={this.onSearch}
        />
      </div>
      <div className={`${classNamePre}-contain`}>
        <div>
          <Button
            type="primary"
            size="middle"
            onClick={this.openDialog}
          >
          充值
          </Button>
        </div>
        {/* table展示区域 */}
        <div className={`${classNamePre}-contain-table`}>
          <Table
            columns={columns}
            datasets={Data}
            rowKey="Id"
            pageInfo={{
              totalItem: Count,
              current,
              pageSize: pageSizeList
            }}
            onChange={this.onChange}
          />
        </div>
      </div>
      {/* 充值弹出框 */}
      <RechargeDialog
        show={showDialog}
        onClose={this.onClose}
        loading={loading}
        history={history}
        isCheckNumber
        money={money}
        url="/Yiye/Account/AccountInfo/AssetManageRechargeDetail"
        title="新增充值"
        onConfirm={this.onConfirm}
      />
    </div>
  );
}
}
