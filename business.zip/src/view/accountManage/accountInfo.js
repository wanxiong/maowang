import * as React from 'react';
import {
  Form, Button, Notify
} from 'ezrd';
import { observer, inject } from 'mobx-react';
import { ConstFormBetween, ConstFormSelectIndustry, ConstFormCascaderCategory } from '../../components/base/constForm';
import { ConstFormUpload } from '../../components/base/constFormImage';
import { Editor } from '../../components/base/constEdit';
import { getMchId, guid } from '../../utils/common';
import { shopStatus } from '../../utils/commonApi';

const {
  Field, FormInputField, createForm, FormCheckboxField
} = Form;

const classNamePre = 'yiye-account-info';

// const Data = [
//   {
//     Id: 1, ParentId: 0, Name: "服装业", Sort: 1, CreatedByUser: null, CreateOn: null, LastModifiedByUser: null, LastModifiedOn: null, Disable: null, Remark: null
//   },
//   {
//     Id: 2, ParentId: 1, Name: "童装", Sort: 1, CreatedByUser: null, CreateOn: null, LastModifiedByUser: null, LastModifiedOn: null, Disable: null, Remark: null
//   },
//   {
//     Id: 3, ParentId: 0, Name: "食品业", Sort: 2, CreatedByUser: null, CreateOn: null, LastModifiedByUser: null, LastModifiedOn: null, Disable: null, Remark: null
//   },
//   {
//     Id: 4, ParentId: 3, Name: "爆米花", Sort: 2, CreatedByUser: null, CreateOn: null, LastModifiedByUser: null, LastModifiedOn: null, Disable: null, Remark: null
//   },
//   {
//     Id: 5, ParentId: 3, Name: "炸猪蹄", Sort: 2, CreatedByUser: null, CreateOn: null, LastModifiedByUser: null, LastModifiedOn: null, Disable: null, Remark: null
//   }
// ];
// 注入
@inject('supplierStore')
@inject('accountStore')
@observer
class AccountInfoForm extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      industry: [],
      editData: {},
      category: [],
      loading: false,
      BusinessLicenseUrl: '',
      Remark: '', // 账户信息审核被拒绝时的理由----只有审核被拒
      infoTip: false, // 是否显示完善信息文字
      isEdit: false // 是否可以编辑
    };
  }

  async componentDidMount() {
    const { Data } = await shopStatus(true);
    let infoTip = false;
    let isEdit = false;
    let remark = '';
    if (Data.Status === 2 || Data.Status === -1 || Data.Status === -3) {
      // 2 营业中 -1品牌歇业 -3平台禁用
      isEdit = true;
    } else if (Data.Status === 1 || Data.Status === 0) {
      infoTip = true;
    } else if (Data.Status === -2) {
      remark = Data.Remark;
      infoTip = true;
    }
    this.setState({
      editData: Data,
      infoTip,
      isEdit,
      Remark: remark
    });
    this.initIndustry();
    this.initCategory();
    this.initBusinessLicense();
  }

  // 上传图片接口
  uploadImg = async (params) => {
    const { supplierStore } = this.props;
    const status = await supplierStore.fetchSupplierUploadImg(params);
    if (!status.IsError && status.Data) {
      return status.Data.pathfull;
    }
    return null;
  }

  /* eslint-disable */
  onSave = async (value) => {
    const { accountStore, history } = this.props;
    // 先上传图片
    this.setState({ loading: true });
    const businessLicense = value.BusinessLicense;
    if (value.BusinessLicense) {
      const data = await accountStore.fetchBusinessLicenseUpload({
        MchId: getMchId(),
        BusinessLicenseImage: businessLicense.src
      });
      if (data.IsError) {
        this.setState({ loading: false });
        return;
      }
    }
    delete value.BusinessLicense;
    //
    if (value.AgeRange) {
      const { AgeRange } = value;
      value.AgeRange = AgeRange.join('-');
    }
    // 品牌logo得处理
    // if (Object.prototype.toString.call(value.Logo) === '[object Object]') {
    //   const logo = value.Logo;
    //   value.Logo = logo.url;
    //   value.ShortLogo = logo.filePath;
    // }
    let imgUrl = '';
    if (value.Logo.data && value.Logo.data[0].file) {
      imgUrl = await this.uploadImg({ file: value.Logo.data[0].file });
      if (!imgUrl) {
        this.state({
          loading: false
        })
      }
    } else {
      imgUrl = value.Logo.src;
    }
    value.Logo = imgUrl;
    value.ShortLogo = imgUrl;

    value.About = value.About.text;
    const { CommodityTypeIds } = value;
    value.CommodityTypeJson = JSON.stringify(CommodityTypeIds);
    let str = '';
    CommodityTypeIds.forEach((item) => {
      str += `${item[1].id},`;
    });
    value.CommodityTypeIds = str.substring(0, str.length - 1);
    value.Id = getMchId();
    value.MchId = getMchId();
    value.ShopStatus = value.ShopStatus ? 0 : 1;
    const data = await accountStore.fetchAccountInfoSave(value);
    if (!data.IsError) {
      Notify.success('保存成功');
      history.push('/Yiye/Purchase/Coupon/BrandCouponList');
    } else {
      this.setState({ loading: false });
      // Notify.error(data.ErrorMsg);
    }
  }
  /* eslint-enable */
  // 所属行业初始化接口

  initIndustry = async () => {
    const { accountStore } = this.props;
    const { Data } = await accountStore.fetchAccountInfoIndustryList({});
    const data = Data.filter(item => item.ParentId === 0);
    this.setState({ industry: data });
  }

  initCategory = async () => {
    const { accountStore } = this.props;
    const { Data } = await accountStore.fetchAccountInfoSelectAll({});
    const parent = [];
    const children = [];
    Data.forEach((item) => {
      if (item.ParentId === 0) { // 一级别
        parent.push(item);
      } else {
        children.push(item);
      }
    });
    const newArr = parent.map((item) => {
      const obj = {
        id: item.Id,
        title: item.Name,
        ParentId: item.ParentId,
        children: []
      };
      for (let i = 0; i < children.length; i++) {
        if (children[i].ParentId === item.Id) {
          obj.children.push({
            id: children[i].Id,
            title: children[i].Name,
            ParentId: children[i].ParentId
          });
        }
      }
      return obj;
    });
    this.setState({ category: newArr || [] });
  }

  // 获取营业执照图片接口
  initBusinessLicense = async () => {
    const { accountStore } = this.props;
    const data = await accountStore.fetchGetBusinessLicense({
      MchId: getMchId()
    });
    if (!data.IsError) {
      if (data.Data && data.Data.BusinessLicenseImage) {
        this.setState({ BusinessLicenseUrl: data.Data.BusinessLicenseImage });
      }
    }
  }

  // 保存接口的初始校验
  onValid = async () => {
    const { ezrdForm } = this.props;
    ezrdForm.setFormDirty(true);
    if (ezrdForm.isValid()) {
      this.onSave(ezrdForm.getFormValues());
    }
  }

  render() {
    const { accountStore } = this.props;
    const {
      industry, editData, infoTip, isEdit, category, Remark, loading, BusinessLicenseUrl
    } = this.state;
    return (
      <div className={`${classNamePre}`}>
        {/* 头部显示 */}
        {
          infoTip
            ? (
              <div className={`${classNamePre}-title`}>
                <div>
                  {
                    Remark || '请完善账户信息，可加快平台审核速度'
                  }
                </div>
              </div>
            )
            : null
        }
        <div className={`${classNamePre}-pro`}>
          <Form horizontal>
            {/* 基础配置 */}
            <div className={`${classNamePre}-base`}>
              <div className={`${classNamePre}-base-title`}>
                基础配置
                <span />
              </div>
              <FormInputField
                name="MerchantName"
                type="text"
                label="品牌"
                required
                showCount
                width={320}
                maxLength={30}
                value={editData.MerchantName ? editData.MerchantName : ''}
                placeholder="品牌简介"
                validations={{ required: true }}
                validationErrors={{ required: '请输入品牌名称' }}
              />
              <FormInputField
                name="OrganizationName"
                type="text"
                label="公司名称"
                maxLength={30}
                showCount
                width={320}
                required
                value={editData.OrganizationName ? editData.OrganizationName : ''}
                placeholder="公司名称与营业执照一致"
                validations={{ required: true }}
                validationErrors={{ required: '请输入公司名称' }}
              />
              <Field
                name="IndustryId"
                type="text"
                label="所属行业"
                component={ConstFormSelectIndustry}
                parent={industry}
                disabled={isEdit}
                required
                helpDesc="请根据你的营业执照和实际售卖商品来选择行业，审核通过后不可修改"
                value={editData.IndustryId ? editData.IndustryId : ''}
                validations={{ required: true }}
                validationErrors={{ required: '所属行业不能为空' }}
              />
              <Field
                name="CommodityTypeIds"
                type="text"
                label="经营类目"
                component={ConstFormCascaderCategory}
                accountStore={accountStore}
                data={category}
                value={
                  editData.CommodityTypeJson ? JSON.parse(editData.CommodityTypeJson) : []
                }
                className={`${classNamePre}-category`}
                required
                validations={{
                  required(values, value) {
                    if (value.length) {
                      return true;
                    }
                    return false;
                  }
                }}
                validationErrors={{ required: '经营类目不能为空' }}
              />
              <Field
                name="Logo"
                type="text"
                label="品牌LOGO"
                component={ConstFormUpload}
                // value={editData.Logo ? editData.Logo : ''}
                value={editData.Logo ? { src: editData.Logo } : {}}
                guid={guid()}
                openBase64={false}
                required
                tips="建议尺寸：800 x 800 像素"
                validations={{ required: true }}
                validationErrors={{ required: '品牌LOGO不能为空' }}
              />
              <Field
                name="BusinessLicense"
                type="text"
                label="营业执照"
                component={ConstFormUpload}
                value={
                  BusinessLicenseUrl
                    ? { src: BusinessLicenseUrl }
                    : {}
                }
                validations={{
                  required(values, value) {
                    if (value.src) {
                      return true;
                    }
                    return false;
                  }
                }}
                required
                validationErrors={{ required: '营业执照不能为空' }}
              />

              <Field
                name="About"
                type="text"
                label="品牌简介"
                component={Editor}
                className={`${classNamePre}-edit-con`}
                value={editData.About ? { text: editData.About, init: true } : { text: '', init: false }}
                required
                validations={{
                  required(values, value) {
                    if (value.isEmpty) {
                      return false;
                    }
                    return true;
                  }
                }}
                validationErrors={{ required: '品牌简介不能为空' }}
              />
              <Field
                name="AgeRange"
                type="text"
                label="品牌人群年龄"
                component={ConstFormBetween}
                value={
                  editData.AgeRange
                    ? [editData.AgeRange.split('-')[0], editData.AgeRange.split('-')[1]]
                    : ''
                }
                centerTxt="至"
                max2={100}
                min={1}
                min2={1}
                endTxt="岁"
                tip=""
                validations={{
                  required(values, value) {
                    if (!value) {
                      return true;
                    }
                    if ((value[0] === '' && value[1] === '') || (value[0] === '' && !value[1]) || (!value[0] && value[1] === '')) {
                      return true;
                    }
                    return !!value[0] && !!value[1];
                  },
                  regSection(values, value) {
                    if (value[0] > value[1]) {
                      return false;
                    }
                    return true;
                  }
                }}
                validationErrors={{ required: '品牌人群年龄不能为空', regSection: '请填写正确的人群年龄区间' }}
              />
              <FormCheckboxField
                name="ShopStatus"
                label="店铺状态:"
                helpDesc="下架后，店铺及商品将歇业，无法再被浏览"
                value={!editData.ShopStatus}
              >
                下架店铺
              </FormCheckboxField>
            </div>
            {/* 运营人员信息 */}
            <div className={`${classNamePre}-person`}>
              <div className={`${classNamePre}-base-title`}>
                运营人员信息
                <span />
              </div>
              <FormInputField
                name="ContactName"
                type="text"
                label="负责人"
                required
                placeholder="姓名"
                width={320}
                showCount
                maxLength={10}
                value={editData.ContactName ? editData.ContactName : ''}
                validations={{ required: true, matchRegex: /^[\u4e00-\u9fa5]+$/ }}
                validationErrors={{ required: '请输入负责人姓名', matchRegex: '请输入正确格式得姓名' }}
              />
              <FormInputField
                name="ContactMobile"
                type="text"
                label="手机号"
                required
                width={320}
                placeholder="手机号"
                maxLength={11}
                showCount
                value={editData.ContactMobile ? editData.ContactMobile : ''}
                validations={{ required: true, matchRegex: /^1[3456789]\d{9}$/ }}
                validationErrors={{ required: '请输入手机号', matchRegex: '请输入正确格式的手机号' }}
              />
              <FormInputField
                name="ContactEmail"
                type="text"
                label="邮箱"
                required
                width={320}
                maxLength={32}
                showCount
                placeholder="邮箱"
                value={editData.ContactEmail ? editData.ContactEmail : ''}
                validations={{
                  isEmail: true,
                  required: true
                }}
                validationErrors={{
                  isEmail: '请填写正确的邮件',
                  required: '请输入邮箱'
                }}
              />
            </div>
            <div className={`${classNamePre}-group-btn`}>
              <Button
                type="primary"
                size="middle"
                loading={loading}
                onClick={this.onValid}
              >
              保存
              </Button>
            </div>
          </Form>
        </div>
      </div>
    );
  }
}

const AccountInfo = createForm()(AccountInfoForm);

export default AccountInfo;
