import * as React from 'react';
import {
  DateRangePicker, Button, Select, Dialog, Pagination
} from 'ezrd';
import moment from 'moment';
import { observer, inject } from 'mobx-react';
import { couponDefaultPage } from "../../components/base/constant";
import ConstBrandSelect from '../../components/base/constBrandSelect';

const data = [
  { value: '', text: '全部' },
  { value: '0', text: '待核准' },
  { value: '1', text: '已入账' }
];
const preClassName = 'supCheckBrandIncome';

@inject('accountStore')
@observer export default class SupCheckBrandIncome extends React.Component {
  static defaultProps = {
    showTime: true, // 是否显示时间筛选
    format: 'YYYY-MM-DD HH:mm:ss'
  }

  constructor(props) {
    super(props);
    this.state = {
      ...couponDefaultPage,
      time: [moment().subtract(3, 'months').format(props.format), moment().format(props.format)],
      startTime: moment().subtract(3, 'months').format(props.format),
      endTime: moment().format(props.format),
      id: '0',
      // 采购方收益审核状态 0 未审核 1 已审核
      selectedValue: '0',
      isShowMoneyDialog: false,
      isShowMoneyAlertTextDialog: false,
      selectedData: ''
    };
  }

  componentDidMount() {
    // console.log('accountStore ====', this.props.accountStore);
    this.requestData();
  }

  requestData = () => {
    const { accountStore } = this.props;
    const {
      pageSize, current, id, startTime, endTime, selectedValue
    } = this.state;
    const params = {
      PageIndex: current,
      PageSize: pageSize,
      PurchaseMchId: id,
      BeginDate: startTime,
      EndDate: endTime,
      AuditStatus: selectedValue
    };
    accountStore.fetchCheckBrandIncomeList(params);
  }

  renderHeaderView = () => {
    const { time, selectedValue } = this.state;
    const {
      format, showTime
    } = this.props;
    return (
      <div className={`${preClassName}-headerView`}>
        <div>
          <div>
            <ConstBrandSelect
              onChange={this.onChange}
              width="240px"
              textLable="采购品牌："
            />
          </div>
          <div>
            <span>采购时间：</span>
            <DateRangePicker
              width={190}
              value={time}
              format={format}
              showTime={showTime}
              onChange={this.onTimeChange}
            />
          </div>
          <div>
            <span>状态：</span>
            <Select
              data={data}
              width={120}
              showClear={false}
              onChange={this.selectChangeHandler}
              value={selectedValue}
              autoWidth
            />
          </div>
        </div>
        <div>
          <Button
            type="primary"
            className={`${preClassName}-btn`}
            onClick={this.onSearch}
          >
          查询
          </Button>
        </div>
      </div>
    );
  }

  onTimeChange = (value) => {
    this.setState({
      time: value,
      startTime: value[0],
      endTime: value[1]
    });
  };

  onChange = (id) => {
    this.setState({ id });
  }

  selectChangeHandler = (event, selected) => {
    this.setState({
      selectedValue: selected.value // or selected[your optionValue]
    });
  }

  onSearch = () => {
    const { current } = this.state;
    if (current === 1) {
      this.requestData();
    } else {
      this.setState({
        current: 1
      }, () => {
        this.requestData();
      });
    }
  }

  renderMyTableView = () => {
    const { accountStore } = this.props;
    const {
      current, pageSizeList
    } = this.state;
    const Data = accountStore.checkBrandIncomeList.PagedList;
    return (
      <div className={`${preClassName}-pro-box`}>
        <div className={`${preClassName}-pro-head`}>
          <span>采购品牌</span>
          <span>核销奖励/核销订单比例</span>
          <span>核销量（张）</span>
          <span>拉新奖励(Z币)</span>
          <span>拉新数(人)</span>
          <span>收益（Z币）</span>
          <span>状态</span>
          <span>操作</span>
        </div>
        {
            Data.map(item => (
              <div
                key={item.Id}
                className={`${preClassName}-pro-item`}
              >
                <div>
                  {' '}
                  采购时间：
                  {moment(item.BuyTime).format('YYYY-MM-DD HH:mm:ss')}

                  ，采购单号：
                  {item.PurchaseNo}
                  ，
                  {`【${item.CouponTypeName}】${item.CouponGrpName}(ID：${item.PlatformCouponGrpId})`}
                </div>
                <div className={`${preClassName}-off-pro`}>
                  <ul>
                    <li>{item.PurchaseMchName}</li>
                    <li>{item.RewardWray === 0 ? item.RewordMoney.toFixed(2) : `${(item.RewordMoney * 100).toFixed(2)}%`}</li>
                    <li>{item.ConsumeQty}</li>
                    <li>{item.NewVipReward.toFixed(2)}</li>
                    <li>{item.NewVipQty}</li>
                    <li>{item.PurchaseTotalAmount.toFixed(2)}</li>
                    <li>{item.AuditStatus === 0 ? '待核准' : '已入账'}</li>
                    <li>
                      <div>
                        {item.AuditStatus === 0 ? (
                          <Button
                            onClick={() => this.triggerMoneyDialog(true, item)}
                            isText
                          >
核准
                          </Button>
                        ) : <span>-</span>}

                      </div>

                    </li>
                  </ul>
                </div>

              </div>
            ))
          }
        {/* 分页区域 */}
        <Pagination
          current={current}
          totalItem={accountStore.checkBrandIncomeList.TotalRowsCount}
          onChange={this.onPageChange}
          pageSize={pageSizeList}
          onPageSizeChange={this.onPageSizeChange}
        />
      </div>
    );
  }

  // 每页大小的回调
  onPageSizeChange = (pageSize) => {
    this.setState({
      pageSize,
      current: 1
    }, () => this.requestData());
  };

  // 分页的回调
  onPageChange = (res) => {
    const { current } = this.state;
    this.setState({
      current: res || current
    }, () => this.requestData());
  }

  check = (res) => {
    const { accountStore } = this.props;
    const params = {
      PurchaseOrderId: res.PurchaseOrderId,
      PurchaseMchId: res.PurchaseMchId,
      PurchaseTotalAmount: res.PurchaseTotalAmount
    };
    const result = accountStore.fetchCheckBrandIncome(params);
    if (result) {
      setTimeout(() => {
        this.requestData();
      }, 1000);
    }
  }

  renderMoneyDialogView = () => {
    const { isShowMoneyDialog, selectedData } = this.state;
    return (
      <Dialog
        title="核准品牌收益"
        visible={isShowMoneyDialog}
        footer={(
          <div>
            <Button
              outline
              onClick={() => this.triggerMoneyDialog(false)}
            >
取消

            </Button>
            <Button onClick={() => { this.triggerMoneyDialog(false); this.triggerAlertTextDialog(true); }}>核准通过</Button>
          </div>
)}
      >
        <div className={`${preClassName}-dialog`}>
          <div className={`${preClassName}-dialog-span`}>品牌：</div>
          <span>{selectedData.PurchaseMchName || ''}</span>
        </div>
        <div className={`${preClassName}-dialog`}>
          <div className={`${preClassName}-dialog-span`}>核准收益：</div>
          <span>{selectedData.PurchaseTotalAmount && selectedData.PurchaseTotalAmount.toFixed(2)}</span>
          <span className={`${preClassName}-dialog-money-span`}>Z币</span>
        </div>
      </Dialog>
    );
  }

  renderAlertTextDialogView = () => {
    const { isShowMoneyAlertTextDialog, selectedData } = this.state;
    return (
      <Dialog
        title="确定核准通过吗？"
        visible={isShowMoneyAlertTextDialog}
        footer={(
          <div>
            <Button
              outline
              onClick={() => { this.triggerAlertTextDialog(false); }}
            >
取消

            </Button>
            <Button onClick={() => { this.triggerAlertTextDialog(false); this.check(selectedData); }}>确定</Button>
          </div>
)}
      >
        <span>核准通过后，Z币将入账到品牌的Z币账户，请确认操作</span>
      </Dialog>
    );
  }

  triggerMoneyDialog = (isShow, selectedData) => {
    if (selectedData) {
      this.setState({
        isShowMoneyDialog: isShow,
        selectedData
      });
    } else {
      this.setState({
        isShowMoneyDialog: isShow
      });
    }
  }

  triggerAlertTextDialog = (isShow, selectedData) => {
    if (selectedData) {
      this.setState({
        isShowMoneyAlertTextDialog: isShow,
        selectedData
      });
    } else {
      this.setState({
        isShowMoneyAlertTextDialog: isShow
      });
    }
  }


  render() {
    return (
      <div className={preClassName}>
        {this.renderHeaderView()}
        {/* {this.renderTabView()} */}
        {this.renderMyTableView()}
        {this.renderMoneyDialogView()}
        {this.renderAlertTextDialogView()}
      </div>
    );
  }
}
