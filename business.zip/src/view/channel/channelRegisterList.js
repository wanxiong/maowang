import React, { Component } from 'react';
import {
  Card,
  Table,
  Button,
  Dialog,
  Notify,
  Input
} from 'ezrd';
import QRCode from 'qrcode';
import { observer, inject } from 'mobx-react';
import moment from 'moment';
import { couponDefaultPage } from '../../components/base/constant';
import { trim } from '../../utils/common';

const { openDialog, closeDialog } = Dialog;
const dialogId = 'coupon_dialog';

@inject('channel')
@observer
export default class ChannelList extends Component {
  state = {
    showDownload: false,
    loading: false,
    taskName: '',
    // data: '',
    ...couponDefaultPage
  }

  componentWillMount() {
    this.fetchChannelList();
  }

  fetchChannelList = async () => {
    const { current, pageSize } = this.state;
    const obj = {
      PageIndex: current,
      PageSize: pageSize
    };
    const { channel } = this.props;
    channel.fetchChannelList(obj);
  }

  addNewChannel = () => {
    const { history } = this.props;
    history.push('/Yiye/Channel/AddOrEdit/0');
  }

  goEdit = (id) => {
    const { history } = this.props;
    history.push(`/Yiye/Channel/AddOrEdit/${id}`);
  }

  copy = () => {
    document.getElementById('input_url').select();
    document.execCommand('copy');
    Notify.success('复制成功');
  }

  // 导出明细
  exportDetail = (data = '') => {
    this.openExport(true, data);
  }

  openExport = (flag, data) => {
    if (flag) {
      this.setState({
        showDownload: flag,
        data,
        taskName: moment().format('YYYY-MM-DD') + data.ActName
      });
      return;
    }
    this.setState({
      showDownload: flag
    });
  }

  // 普通input框的事件回调
  onChangeInput = (type, e) => {
    this.setState({
      [type]: e.target.value
    });
  }

  confirm = async () => {
    const {
      taskName, data
    } = this.state;
    const {
      history, channel
    } = this.props;
    if (!trim(taskName)) {
      Notify.error('请输入导出数据的文件名称');
      return;
    }
    this.setState({ loading: true });

    const status = await channel.fetchChannelExportDetail({
      TaskName: taskName,
      Type: 8,
      Querys: {
        Id: data.Id
      }
    });
    this.setState({ loading: false });
    if (!status.IsError) {
      this.openExport(false);
      history.push('/Yiye/Download');
    }
  }

  showQRCode = async (data) => {
    const {
      ActUrl
    } = data;
    const qrLink = await QRCode.toDataURL(ActUrl);
    openDialog({
      dialogId, // id is used to close the dialog
      title: '链接',
      children: (
        <div>
          <div
            style={{ display: 'flex', justifyContent: 'space-between' }}
          >
            <span style={{ flex: 1, marginRight: '5px' }}>
              <input
                id="input_url"
                defaultValue={ActUrl}
                style={{ width: "100%" }}
              />
            </span>
            <span>
              <Button onClick={this.copy}>复制链接</Button>
            </span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'center' }}>
            <img
              src={qrLink}
              alt=""
            />
          </div>
          <p style={{ textAlign: 'center' }}>右击-图片另存为，可以保存二维码图片</p>
        </div>
      ),
      footer: (
        <Button
          type="primary"
          onClick={() => closeDialog(dialogId)}
        >
          关闭
        </Button>
      )
    });
  }

  pageChange = (data) => {
    if (data.pageSize) {
      this.setState({
        current: 1,
        pageSize: data.pageSize
      }, () => this.fetchChannelList());
    }
    if (data.current) {
      this.setState({
        current: data.current
      }, () => this.fetchChannelList());
    }
  }

  render() {
    const {
      pageSizeList, current, showDownload, loading, taskName
    } = this.state;
    const { channel } = this.props;
    const { channelList, channelListLoading } = channel;
    const columns = [{
      title: '创建时间',
      bodyRender: data => (
        moment(data.CreateDate).format('YYYY-MM-DD HH:mm:ss')
      )
    }, {
      title: '活动名称',
      name: 'ActName'
    }, {
      title: 'PV',
      name: 'PV'
    },
    // {
    //   title: 'UV',
    //   name: 'UV'
    // },
    {
      title: '参与人数',
      name: 'JoinNum'
    }, {
      title: '注册人数',
      name: 'RegNum'
    }, {
      title: '操作',
      bodyRender: data => (
        <div>
          <Button
            isText
            onClick={() => this.goEdit(data.Id)}
            style={{ marginRight: '5px' }}
          >
            编辑
          </Button>
          <Button
            isText
            onClick={() => this.showQRCode(data)}
          >
            链接
          </Button>
          <Button
            isText
            onClick={() => this.exportDetail(data)}
          >
            活动明细
          </Button>

        </div>
      )
    }];
    return (
      <div>
        <div>
          <div style={{ padding: '10px' }}>
            <Button
              onClick={this.addNewChannel}
              type="primary"
            >
            新建活动
            </Button>
          </div>
          <Card>
            <Table
              columns={columns}
              datasets={channelList.PagedList || []}
              pageInfo={{
                totalItem: channelList.TotalRowsCount || 0,
                current,
                pageSize: pageSizeList
              }}
              loading={channelListLoading}
              onChange={this.pageChange}
            />
          </Card>
        </div>
        {/** 导出明细 */}
        <Dialog
          title="导出数据的文件名称"
          visible={showDownload}
          onClose={() => this.openExport(false)}
          style={{ width: '600px' }}
          maskClosable={false}
          footer={(
            <div>
              <Button
                outline
                loading={loading}
                onClick={() => this.openExport(false)}
              >
                取消
              </Button>
              <Button
                loading={loading}
                onClick={() => this.confirm()}
              >
                确定
              </Button>
            </div>
          )}
        >
          <Input
            signleBorder
            placeholder="请输入导出数据的文件名称"
            showClear
            maxLength={30}
            width="100%"
            value={taskName}
            onChange={event => this.onChangeInput('taskName', event)}
          />
        </Dialog>
      </div>
    );
  }
}
