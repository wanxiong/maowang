import React from 'react';
import {
  Tabs,
  Notify,
  Breadcrumb
} from 'ezrd';
import ChannelForm from '../../components/channel/channelForm';
import DecorationWeb from '../../components/channel/channelDesign';
// import { getDetailById } from '@/services/channel/pages';
// import 'ezrd/css/index.css';
// import 'ezrpc/css/material-selector.css';
// import 'ezrpc/css/material-uploader.css';
// import '@/common.css';

const { TabPanel } = Tabs;

export default class Channel extends React.Component {
  channelFormRef = '';

  decorationWebRef = '';

  state = {
    activeId: '1',
    // channelFormRef: {},
    // id: '',
    brandId: '',
    CouponGrpId: '',
    data: {},
    bUrl: [
      { name: '渠道活动列表', href: "#/Yiye/Channel/List" },
      { name: '新建渠道', strong: true }
    ]
  }

  componentDidMount() {
    const { match } = this.props;
    const { params } = match;
    const { id } = params;
    const titleStr = id !== '0' ? '渠道编辑' : '新建渠道';
    const bUrl = [
      { name: '渠道活动列表', href: "#/Yiye/Channel/List" },
      { name: `${titleStr}`, strong: true }
    ];
    this.setState({
      bUrl
    });
    // console.log(this.props);
    // const { match } = this.props;
    // const { params } = match;
    // const { id } = params;
    // this.setState({ id });
    // console.log(id);
    // window.location.hash.match(/id\=(\d+)/g);
    // let sessionStore;
    // try {
    //   sessionStore = JSON.parse(sessionStorage.__channelId || "{}");
    // } catch (err) {
    //   throw new Error('JOSN pasrse error');
    // }
    // const {
    //   id,
    //   brandId,
    //   CouponGrpId
    // } = sessionStore;
    // if (id) {
    //   this._fetchDetails(id);
    //   this.setState({ id, brandId, CouponGrpId });
    // }
  }

  componentWillUnmount() {
    // sessionStorage.removeItem('__channelId');
  }


  _fetchDetails = async () => {
    // const { Data: data } = await getDetailById({ Id: id }).catch((err) => { throw new Error(err); });
    // this.setState({ data });
    // this.channelFormRef.setFormValue(data);
  }

  onTabChange = (id) => {
    // if (id === '2' && !this.channelFormRef.props.ezrdForm.isValid()) {
    //   Notify.error('请先完善渠道设置');
    //   return;
    // }
    if (!this.checkGiftCouponBagsRequire(id)) return;
    this.setState({
      activeId: id
    }, this.setDecorationWebFormValue);
  }

  checkGiftCouponBagsRequire = (id) => {
    const { ezrdForm } = this.channelFormRef.props;
    const data = ezrdForm.getFormValues();
    const {
      PresentType,
      giftCoupon
    } = data;
    if (PresentType === 'GB' && id === '2') {
      const {
        giftbagsList
      } = giftCoupon;
      // const status = true;
      // eslint-disable-next-line no-restricted-syntax
      // for (const v of giftbagsList) {
      //   if (v.CouponValidTypeTem === 'CM') {
      //     status = status && (!!v.CouponValidDays || v.CouponValidDays === 0);
      //   } else {
      //     const [first, second] = v.CouponTimes;
      //     status = status && !!first && !!second;
      //   }
      //   // 展示的项
      //   const isShow = !((v.CouponOrigin === 0 && v.CouponType === 'YY' && v.GrpCouponValidType === 0)
      //   || (v.CouponOrigin === 1 && v.CouponType === 'YY' && v.GrpCouponValidType === 0));
      //   if (!status && isShow) {
      //     Notify.error('请完善券包信息');
      //     return false;
      //   }
      //   return status;
      // }
      const errorArr = giftbagsList.filter(e => this.checkArr(e));
      // console.log('errorArr', errorArr);
      if (errorArr.length) {
        Notify.error('请完善券包信息');
        return false;
      }
    }
    return true;
  }

  checkArr = (v) => {
    const isShow = !((v.CouponOrigin === 0 && v.CouponType === 'YY' && v.GrpCouponValidType === 0)
        || (v.CouponOrigin === 1 && v.CouponType === 'YY' && v.GrpCouponValidType === 0));
    if (isShow && v.CouponValidTypeTem === 'CM') {
      // console.log('CM', v.CouponValidDays);
      return !`${v.CouponValidDays}`;
    } if (isShow && v.CouponValidTypeTem === 'TS') {
      const [first, second] = v.CouponTimes;
      // console.log('TS', first, second);
      return !first || !second;
    }
    return false;
  }

  setDecorationWebFormValue = () => {
    const { data } = this.state;
    // console.log('data = ', data);
    if (JSON.stringify(data) !== '{}') {
      this.decorationWebRef.setFormValue(data);
    }
  }

  setActiveTab = (id) => {
    if (!this.checkGiftCouponBagsRequire(id)) return;
    this.setState({
      activeId: id
    }, this.setDecorationWebFormValue);
  }

  getChannelFormRef = (ref) => {
    this.channelFormRef = ref;
  }

  getDecorationWebRef = (ref) => {
    this.decorationWebRef = ref;
  }

  render() {
    const { match, history } = this.props;
    const { params } = match;
    const { id } = params;
    const {
      data,
      brandId,
      CouponGrpId,
      activeId,
      bUrl
    } = this.state;
    return (
      <div>
        <div className="-bread yiye-global-bread">
          <Breadcrumb breads={bUrl} />
        </div>
        <Tabs
          className="default-fff"
          type="slider"
          activeId={activeId}
          onChange={this.onTabChange}
        >
          <TabPanel
            tab="渠道设置"
            id="1"
          >
            {/* <Card> */}
            <ChannelForm
              changeTab={this.setActiveTab}
              getRef={this.getChannelFormRef}
              id={id}
              data={data}
            />
            {/* </Card> */}
          </TabPanel>
          <TabPanel
            tab="网页装修"
            id="2"
          >
            {/* <Card> */}
            <DecorationWeb
              changeTab={this.setActiveTab}
              getRef={this.getDecorationWebRef}
              channelRef={this.channelFormRef}
              id={id}
              history={history}
              brandId={brandId}
              CouponGrpId={CouponGrpId}
              data={data}
            />
            {/* </Card> */}
          </TabPanel>
        </Tabs>
      </div>
    );
  }
}

// ReactDOM.render(
//   <Provider couponStore={couponStore} giftCouponStore={giftCouponStore} >
//     <Channel name="abc" />
//   </Provider>,
//   document.getElementById('app')
// );
