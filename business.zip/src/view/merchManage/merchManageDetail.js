import * as React from 'react';
import { observer, inject } from 'mobx-react';
import { Link } from 'react-router-dom';
import {
  Title, Pop, Icon, Notify
} from 'ezrd';
// import moment from 'moment';
import {
  couponDefaultPage,
  defaultRechargeApiType
} from '../../components/base/constant';
import { getMchId, multiplication } from '../../utils/common';
import GiveZDialog from '../../components/assetManage/giveZDialog';

const classNamePre = 'yiye-asset-manage-list';

@inject('accountStore')
@observer
export default class MerchManageDetail extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      ...couponDefaultPage,
      showDialog: false,
      loading: false,
      assetData: {},
      id: '',
      merchName: ''
    };
  }

  componentWillMount() {
    const { match: { params } } = this.props;
    if (!params.id) return;
    this.setState({
      id: params.id,
      merchName: params.name || ''
    });
    this.initData(params.id);
  }

  initData = async (mchId) => {
    const { accountStore } = this.props;
    const status = await accountStore.fetchGetAssetAccount({
      MchId: mchId
    });
    if (!status.IsError) {
      this.setState({
        assetData: status.Data
      });
    }
  }

  // 数字回显操作
  numberTrans = (value = 0, isPerce) => {
    if (value === 0) {
      return '--';
    }
    if (isPerce) {
      const n = multiplication(value, 100);

      return `${n.toFixed(2)}%`;
    }
    return value.toFixed(2);
  }

  // 打开充值弹出框
  openDialog = () => {
    this.setState({ showDialog: true });
  }

  onClose = () => {
    this.setState({ showDialog: false });
  }

  // Z币赠送接口
  gaveRechargeZ = async (params, fn) => {
    const { accountStore } = this.props;
    const status = await accountStore.fetchAccountRechargeZGive(params);
    if (!status.IsError) {
      Notify.success('Z币赠送成功');
      fn();
    }
    this.setState({ loading: false });
  }

  // 提交
  onConfirm = async (data, fn) => {
    this.setState({ loading: true });
    this.getTradeNo(data, fn);
  }

  // 获取交易编号
  getTradeNo = async (data, fn) => {
    const { accountStore } = this.props;
    const { id } = this.state;
    const status = await accountStore.fetchAccountTradeNo({
      TradeType: defaultRechargeApiType.ZGive,
      MchId: getMchId()
    });
    if (!status.IsError) {
      const tradeId = status.Data;
      const params = {
        TradeCount: data.moneyValue,
        TradeType: defaultRechargeApiType.ZGive,
        TradeMchId: id,
        ETradeNo: tradeId,
        MchId: getMchId()
      };
      this.gaveRechargeZ(params, () => {
        this.setState({ showDialog: false });
        fn();
        // 赠送ZB延迟
        this.initData(id);
      });
    } else {
      this.setState({ showDialog: false });
    }
  }

  render() {
    const {
      assetData, showDialog, loading, merchName, id
    } = this.state;
    return (
      <div className={`${classNamePre}`}>
        <div className={`${classNamePre}-top`}>
          <Title
            titleDesc="品牌信息"
            className={`${classNamePre}-top-title`}
          >
            <div className={`${classNamePre}-top-merch-name`}>
              <span>品牌商户：</span>
              <span>{merchName}</span>
            </div>
          </Title>
        </div>
        <div className={`${classNamePre}-top`}>
          <Title
            titleDesc="充值资金"
            className={`${classNamePre}-top-title`}
          >
            <div className={`${classNamePre}-con`}>
              <div>
                <div className={`${classNamePre}-con-top`}>
                  <span>余额(元)</span>
                  <Pop
                    trigger="hover"
                    position="top-left"
                    content="先将资金充值到余额，再根据业务需要充值到Z币和保证金"
                  >
                    <Icon
                      type="info"
                      ezrd
                    />
                  </Pop>
                  <Link
                    to={`/Yiye/MerchManage/RechargeList/${id || ''}`}
                  >
                  充值/明细
                  </Link>
                </div>
                <div className={`${classNamePre}-con-money`}>{ this.numberTrans(assetData.CashReserve) }</div>
              </div>
              <div>
                <div className={`${classNamePre}-con-bottom`}>
                  <span>保证金(元)</span>
                </div>
                <div className={`${classNamePre}-con-money`}>{ this.numberTrans(assetData.CashDeposit) }</div>
              </div>
            </div>
          </Title>
        </div>
        <div className={`${classNamePre}-center`}>
          <Title
            titleDesc="虚拟资产"
            className={`${classNamePre}-top-title`}
          >
            <div className={`${classNamePre}-con`}>
              <div>
                <div className={`${classNamePre}-con-top`}>
                  <span>Z币(元)</span>
                  <Pop
                    trigger="hover"
                    position="top-left"
                    content="含充值及在平台赚取的费用，可任意在平台消费"
                  >
                    <Icon
                      type="info"
                      ezrd
                    />
                  </Pop>
                  {
                    // <span
                    //   role="button"
                    //   tabIndex="0"
                    //   className="yiye-outline btn-default-color yiye-cursor"
                    //   onClick={() => this.openDialog()}
                    // >
                    // 赠送
                    // </span>
                  }
                  <Link
                    to={`/Yiye/MerchManage/ZDetailList/${id}`}
                  >
                  充值/明细
                  </Link>
                </div>
                <div className={`${classNamePre}-con-money`}>{ this.numberTrans(assetData.Zb) }</div>
              </div>
              <div>
                <div className={`${classNamePre}-con-bottom`}>
                  <span>冻结金额(元)</span>
                  <Pop
                    trigger="hover"
                    position="top-center"
                    content="冻结金额会在冻结期结束后释放，具体时间可在采购单中查询。"
                  >
                    <Icon
                      type="info"
                      ezrd
                    />
                  </Pop>
                </div>
                <div className={`${classNamePre}-con-money`}>{ this.numberTrans(assetData.CashFrozen) }</div>
              </div>
            </div>
          </Title>
        </div>
        {/* 充值弹出框 */}
        <GiveZDialog
          show={showDialog}
          onClose={this.onClose}
          loading={loading}
          title="赠送"
          onConfirm={this.onConfirm}
        />
      </div>
    );
  }
}
