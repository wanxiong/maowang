import * as React from 'react';
import {
  Button, Table, Notify
} from 'ezrd';
import { observer, inject } from 'mobx-react';
import AssetManageSearch from '../../components/assetManage/assetManageSearch';
import MerchManageZDetailDialog from '../../components/merchManage/merchManageZDetailDialog';
import {
  assetManageZDetailStatus, couponDefaultPage, defaultZDetailStatus, defaultRechargeApiType
} from '../../components/base/constant';
import { getMchId, dateDistance } from '../../utils/common';
// 新建

const classNamePre = 'yiye-asset-manage-z-detail';

@inject('accountStore')
@observer
export default class MerchManageZDetail extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      showDialog: false,
      loading: false,
      id: prop.match.params.id,
      ...couponDefaultPage
    };
  }

  async componentDidMount() {
    // this.initData({
    //   TradeType: defaultZDetailStatus
    // });
    this.searchDom.onSearch(0);
  }

initData = async (params = {}) => {
  const { accountStore } = this.props;
  const { pageSize, current, id } = this.state;
  await accountStore.fetchGetAssetZDetailList({
    MchId: id,
    PageSize: pageSize,
    Page: current,
    ...params
  });
}

// 分页的回调
onChange = (data) => {
  let { current } = this.state;
  const { pageSize } = this.state;
  if (data.pageSize) {
    if (data.pageSize === pageSize) {
      return;
    }
    current = 1;
  }
  this.setState({
    pageSize: data.pageSize || pageSize,
    current: data.current || current
  }, () => {
    this.searchDom.onSearch(0);
  });
}

// 搜索按钮的回调
onSearch = (data, flag) => {
  if (flag !== 0) {
    this.setState({ current: 1 }, () => {
      this.initData(data);
    });
    return;
  }
  this.initData(data);
}

// Z币充值接口
initRechargeZ = async (params, fn) => {
  const { accountStore } = this.props;
  const status = await accountStore.fetchGetAssetRechargeZ(params);
  if (!status.IsError) {
    Notify.success('充值Z币成功');
    fn();
  }
  this.setState({ loading: false });
}

// 打开充值弹出框
openDialog = () => {
  this.setState({ showDialog: true });
}

onClose = () => {
  this.setState({ showDialog: false });
}

// 提交
onConfirm = async (data, fn) => {
  this.setState({ loading: true });
  this.getTradeNo(data, fn);
}

// 获取交易编号
getTradeNo = async (data, fn) => {
  const { accountStore } = this.props;
  const { id } = this.state;
  const status = await accountStore.fetchAccountTradeNo({
    TradeType: defaultRechargeApiType.ZGive,
    MchId: getMchId()
  });
  if (!status.IsError) {
    const tradeId = status.Data;
    const params = {
      TradeCount: data.money,
      TradeType: defaultRechargeApiType.ZGive,
      TradeMchId: id,
      ETradeNo: tradeId,
      MchId: getMchId()
    };
    this.gaveRechargeZ(params, () => {
      this.setState({ showDialog: false });
      fn();
      // 赠送ZB延迟
      this.initData();
    });
  } else {
    this.setState({ showDialog: false });
  }
}

// Z币赠送接口
gaveRechargeZ = async (params, fn) => {
  const { accountStore } = this.props;
  const status = await accountStore.fetchAccountRechargeZGive(params);
  if (!status.IsError) {
    Notify.success('赠送Z币成功');
    fn();
  }
  this.setState({ loading: false });
}

render() {
  const {
    current, pageSizeList, showDialog, loading, id
  } = this.state;
  const { accountStore, history } = this.props;
  const { assetZList } = accountStore;
  const { Data, Count } = assetZList;
  const statusList = {};
  assetManageZDetailStatus.forEach((item) => {
    statusList[item.id] = item.name;
  });
  const columns = [
    {
      title: '交易时间',
      bodyRender: data => <div>{data.CreateOn}</div>
    },
    {
      title: '交易类型',
      bodyRender: data => (
        <div>{ statusList[data.TradeType] }</div>
      )
    },
    {
      title: '交易金额',
      bodyRender: data => (
        <div className={`${classNamePre}-recharge`}>
          {data.TradeCount}
        </div>
      )
    },
    {
      title: '交易单号',
      name: 'ETradeNo'
    }
  ];
  return (
    <div className={`${classNamePre}`}>
      {/* 搜索区域 */}
      <div style={{ 'margin-top': '20px' }}>
        <AssetManageSearch
          data={assetManageZDetailStatus}
          statusKey="TradeType"
          defautlSelect={defaultZDetailStatus}
          ref={(ref) => { this.searchDom = ref; }}
          onSearch={this.onSearch}
          DateRangePickerText="交易时间："
          typeSelectText="交易类型："
          typeName="充值Z币/明细"
          downloadType="rechargeZB"
          history={history}
          downloadStore={accountStore}
          mchId={id}
          defaultDate={[dateDistance(new Date(), 90, '-'), dateDistance(new Date(), 0, '-', '23:59:59')]}
        />
      </div>
      <div className={`${classNamePre}-contain`}>
        <div>
          <Button
            type="primary"
            size="middle"
            onClick={this.openDialog}
          >
          赠送Z币
          </Button>
        </div>
        {/* table展示区域 */}
        <div className={`${classNamePre}-contain-table`}>
          <Table
            columns={columns}
            datasets={Data}
            rowKey="Id"
            pageInfo={{
              totalItem: Count,
              current,
              pageSize: pageSizeList
            }}
            onChange={this.onChange}
          />
        </div>
      </div>
      {/* 充值弹出框 */}
      <MerchManageZDetailDialog
        show={showDialog}
        close={this.onClose}
        confirm={this.onConfirm}
        text="赠送Z币"
        min={0.01}
        decimalMoney={2}
        loading={loading}
      />
    </div>
  );
}
}
