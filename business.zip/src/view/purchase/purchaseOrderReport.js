import * as React from 'react';
import {
  Pagination,
  Dialog,
  Button,
  Input
} from 'ezrd';
import { observer, inject } from 'mobx-react';
import moment from 'moment';
import { couponDefaultPage } from '../../components/base/constant';
import { checkShopStatus } from '../../utils/commonApi';
import OrderReportCount from '../../components/base/orderReportCount';
import OrderReportSearch from '../../components/base/orderReportSearch';
import { goPage, division } from '../../utils/common';

const classNamePre = 'yiye-purchase-order-report';
// 注入
@inject('purchaseStore')
@observer
export default class PurchaseOrderReport extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      visible: false, // 弹窗显示
      loading: false, // 弹窗按钮loading
      TaskName: `${moment().format('YYYY-MM-DD')}核销明细`, // 弹窗输入框名称
      ...couponDefaultPage
    };
  }

  @checkShopStatus('provide')
  async componentDidMount() {
    this.initData({});
  }

  // initData
  initData = (params = {}) => {
    const { purchaseStore } = this.props;
    const { pageSize, current } = this.state;
    purchaseStore.fetchPurchaseOrderReportList({
      PageIndex: current,
      PageSize: pageSize,
      ...params
    });
  }

  // 点击查询的事件
  onHandleSearch = (data, flag) => {
    if (flag !== 0) {
      this.setState({ current: 1 }, () => {
        this.initData({
          CouponGrpId: data.couponId, // 券ID
          CouponGrpName: data.couponName, // 券名称
          ProvideMchName: data.brandName, // 品牌
          BeginDate: data.rangeValue[0], // 开始时间
          EndDate: data.rangeValue[1] // 结束时间
        });
      });
      return;
    }
    this.initData({
      CouponGrpId: data.couponId, // 券ID
      CouponGrpName: data.couponName, // 券名称
      ProvideMchName: data.brandName, // 品牌
      BeginDate: data.rangeValue[0], // 开始时间
      EndDate: data.rangeValue[1] // 结束时间
    });
  }

  // 导出事件
  onHandleExport = async () => {
  }

  // 每页大小的回调
  onPageSizeChange = (pageSize) => {
    this.setState({
      pageSize
    }, () => {
      this.searchDom.onSearch(0);
    });
  };

  // 分页的回调
  onChange = (data) => {
    const { current } = this.state;
    this.setState({
      current: data || current
    }, () => {
      this.searchDom.onSearch(0);
    });
  }

  // // 查看明细
  // goDetail = () => {
  //   goPage('/Yiye/Purchase/PurchaseOrderReportDetail');
  // }

  // 显示弹窗
  goDownload = (OrderId) => {
    this.setState({ visible: true, OrderId });
  }

  // 关闭弹窗
  closeDialog = () => {
    this.setState({
      visible: false,
      TaskName: `${moment().format('YYYY-MM-DD')}核销明细`
    });
  }

  // 弹窗确认
  confirm = async () => {
    const { purchaseStore } = this.props;
    const { TaskName, OrderId } = this.state;
    this.setState({ loading: true });
    const res = await purchaseStore.fetchGetDownloadPurConsumeDtl({ TaskName, Querys: { OrderId } });
    this.setState({ visible: false, loading: false, TaskName: `${moment().format('YYYY-MM-DD')}核销明细` });
    if (!res.IsError) {
      goPage('/Yiye/Download');
    }
  }

  // 输入框输入
  onChangeInput = (type, e) => {
    this.setState({
      [type]: e.target.value
    });
  }

  // title列表组件需要函数
  titleFun = (key, number, fixed = 0, pass = false) => {
    const { purchaseStore } = this.props;
    const { purchaseOrderReportList: { Data } } = purchaseStore;
    if (!Data[key] && Data[key] !== 0) {
      return '';
    }
    if (pass) {
      return Data[key];
    }
    if (number) {
      if (!fixed) {
        return division(Data[key], number);
      }
      return division(Data[key], number).toFixed(fixed);
    }
    return Data[key].toFixed(fixed);
  }

  render() {
    const {
      current, pageSizeList, visible, loading, TaskName
    } = this.state;
    const { purchaseStore } = this.props;
    const { purchaseOrderReportList: { TotalRowsCount, PagedList } } = purchaseStore;
    return (
      <div className={`${classNamePre}`}>
        {/* 全部数据总和 */}
        <OrderReportCount
          titleList={['采购量(万)', '发放量(万)', '核销量(百)', '应收Z币(元)', '平台手续费(元)', '实收Z币(元)']}
          keyList={[
            this.titleFun('TotalProvideQty', 10000),
            this.titleFun('TotalUseQty', 10000),
            this.titleFun('TotalConsumeQty', 100),
            this.titleFun('TotalPurchaseAmount', 0, 2),
            this.titleFun('TotalPurchasePlatformAmount', 0, 2),
            this.titleFun('TotalRealityAmount', 0, 2)
          ]}
        />
        <OrderReportSearch
          onSearch={this.onHandleSearch}
          onExport={this.onHandleExport}
          exportText="导出采购报表"
          typeName="流量收益报表"
          type="purchaseStore"
          defaultTime={[`${new Date().getFullYear()}-01-01`, `${new Date().getFullYear()}-12-31`]}
          // ref={(ref) => { this.searchDom = ref; }}
          getRef={(ref) => { this.searchDom = ref; }}
        />
        {/* */}
        <div className={`${classNamePre}-pro`}>
          <div className={`${classNamePre}-pro-head`}>
            <span>供应品牌</span>
            <span>采购量(万)</span>
            <span>发放量(万)</span>
            <span>领取数(人)</span>
            <span>领取数(张)</span>
            <span>核销量(百)</span>
            <span>应收Z币</span>
            <span>平台手续费</span>
            <span>实收Z币</span>
            <span>操作</span>
          </div>
          {
            PagedList.map(item => (
              <div
                className={`${classNamePre}-pro-item`}
                key={item.Id}
              >
                <div className={`${classNamePre}-pro-item-title`}>
                  <div>
                    采购时间：
                    {moment(item.BuyTime).format('YYYY-MM-DD HH:mm')}
                    ，【
                    {item.CouponType}
                    】
                    {item.CouponName}
                    （ID：
                    {item.PlatformCouponGrpId}
                    ）,
                    {' '}
                    采购单号：
                    {item.PurchaseNo}
                  </div>
                </div>
                <ul>
                  <li>{item.ProvideMchName}</li>
                  <li>{division(item.PurchaseQty, 10000)}</li>
                  <li>{division(item.UsedQty, 10000)}</li>
                  <li>{item.ReceiveCouponPQty}</li>
                  <li>{item.ReceiveCouponQty}</li>
                  <li>{division(item.ConsumeQty, 100)}</li>
                  <li>{item.PurchaseAmount.toFixed(2)}</li>
                  <li>{item.PurchasePlatformAmount.toFixed(2)}</li>
                  <li>{item.RealityAmount.toFixed(2)}</li>
                  <li>
                    {
                      // <span
                      //   role="button"
                      //   tabIndex="0"
                      //   className="yiye-outline btn-default-color"
                      //   onClick={() => this.goDetail(item)}
                      // >
                      // 核销明细
                      // </span>
                    }

                    <span
                      role="button"
                      tabIndex="0"
                      className="yiye-outline btn-default-color yiye-cursor"
                      onClick={() => this.goDownload(item.PurchaseOrderId)}
                    >
                      导出核销明细
                    </span>
                  </li>
                </ul>
              </div>
            ))
          }
          {/* 分页区域 */}
          <Pagination
            current={current}
            totalItem={TotalRowsCount}
            onChange={this.onChange}
            pageSize={pageSizeList}
            onPageSizeChange={this.onPageSizeChange}
          />
          {/* 导出明细名称弹窗 */}
          <Dialog
            title="导出数据的文件名称"
            visible={visible}
            onClose={() => this.closeDialog()}
            style={{ width: '600px' }}
            maskClosable={false}
            footer={(
              <div>
                <Button
                  outline
                  loading={loading}
                  onClick={() => this.closeDialog()}
                >
                  取消
                </Button>
                <Button
                  loading={loading}
                  onClick={() => this.confirm()}
                >
                  确定
                </Button>
              </div>
            )}
          >
            <Input
              signleBorder
              placeholder="请输入导出数据的文件名称"
              showClear
              maxLength={30}
              width="100%"
              value={TaskName}
              onChange={event => this.onChangeInput('TaskName', event)}
            />
          </Dialog>
        </div>
      </div>
    );
  }
}
