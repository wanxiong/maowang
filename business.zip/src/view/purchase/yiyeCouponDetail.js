import * as React from 'react';
import {
  Dialog, Notify, Button, NumberInput, Tabs, Breadcrumb
} from 'ezrd';
import moment from 'moment';
import { observer, inject } from 'mobx-react';
import { textAreaBr } from '../../utils/common';
import { sessPurchaseNewYiyeCouponDtlKey } from '../../components/base/constant';

const { openDialog, closeDialog } = Dialog;
const { TabPanel } = Tabs;
const classNamePre = 'yiye-coupon-det';

// 注入
@inject('purchaseStore')
@observer
class YiyeCouponDetail extends React.Component {
  constructor(prop) {
    super(prop);

    this.state = {
      data: '',
      params: {},
      activeId: '1',
      breadList: [],
      loading: false,
      purchaseNum: '' // 采购数量
    };
  }

componentDidMount = () => {
  let obj = {};
  try {
    obj = JSON.parse(localStorage.getItem(sessPurchaseNewYiyeCouponDtlKey));
  } catch (error) {
    //
  }
  let bUrl = [];
  if (obj.BuyCount) {
    bUrl = [
      { name: '采购单', href: "#/Yiye/Equity/Purchaseorder/YiyeOrder" },
      { name: '采购单详情', strong: true }
    ];
  } else {
    bUrl = [
      { name: '权益超市', href: "#/Yiye/Equity/Coupon/YiyeCoupon" },
      { name: '权益商品详情', strong: true }
    ];
  }
  this.setState({
    params: obj,
    breadList: bUrl
  }, () => {
    this.initDetail();
  });
}

goDetail = (id) => {
  const { history } = this.props;
  closeDialog(id);
  history.push('/Yiye/Equity/Purchaseorder/YiyeOrder');
}

close = (id, historyId) => {
  const { history } = this.props;
  closeDialog(id);
  if (historyId) {
    history.goBack(historyId);
  }
}

// 初始化详情
initDetail = async () => {
  const { purchaseStore } = this.props;
  const { params } = this.state;

  const status = await purchaseStore.fetchPurchaseCouponListDetail({
    CouponGrpId: params.CouponGrpId,
    MchId: params.MchId
  });
  if (status.ErrorCode === 0 && !status.IsError) {
    this.setState({ data: status.Data });
  } else {
    Notify.error(status.ErrorMsg);
  }
}

// 采购数量的输入框
onChangeNum = (e) => {
  const v = e.target.value;
  this.setState({ purchaseNum: v });
}

onTabChange = (id) => {
  this.setState({
    activeId: id
  });
}

goRecharge = (id) => {
  const { history } = this.props;
  closeDialog(id);
  history.push('/Yiye/Account/AccountInfo/AssetManageList');
}

// 申请采购
purchase = async () => {
  const { purchaseStore } = this.props;
  const { purchaseNum, params } = this.state;
  if (!purchaseNum) {
    Notify.error('请输入采购数量');
    return;
  }
  this.setState({
    loading: true
  });
  //
  const statu = await purchaseStore.fetchPurchaseApply({
    CouponGrpId: params.CouponGrpId,
    BuyCount: purchaseNum,
    UnionCouponType: 1
  });
  this.setState({
    loading: false
  });
  // ErrorCode
  if (statu.ErrorCode === 3) {
    openDialog({
      dialogId: 2,
      title: statu.ErrorMsg,
      footer: (
        <React.Fragment>
          <Button
            type="primary"
            outline
            onClick={() => this.close(2)}
          >
          继续逛逛
          </Button>
          <Button
            type="primary"
            onClick={event => this.goRecharge(2, event)}
          >
          去充值
          </Button>
        </React.Fragment>
      )
    });
  } else if (statu.IsError) {
    // Notify.error(statu.ErrorMsg);
  } else {
    openDialog({
      dialogId: 1,
      title: '采购申请已提交',
      children: '平台将在24小时内完成备货制券，届时请注意在采购单中查询驿业券采购状态',
      footer: (
        <React.Fragment>
          <Button
            type="primary"
            outline
            onClick={() => this.close(1, 1)}
          >
            继续逛逛
          </Button>
          <Button
            type="primary"
            onClick={event => this.goDetail(1, event)}
          >
            查看采购单
          </Button>
        </React.Fragment>
      )
    });
  }
}

initTimeTpl = (item) => {
  if (item.CouponTradeCfg && item.CouponTradeCfg.RechargeBeginDate && item.CouponTradeCfg.RechargeBeginDate.indexOf('0001-01-01') === -1) {
    return (
      <div style={{ 'margin-bottom': '0px' }}>
        <span className={`${classNamePre}-goods-ordernew-bold`}>
        兑换有效期
        </span>
        <span>
          {moment(item.CouponTradeCfg.RechargeBeginDate).format('YYYY-MM-DD HH:mm:ss')}
          至
          {moment(item.CouponTradeCfg.RechargeEndDate).format('YYYY-MM-DD HH:mm:ss')}
          兑换有效
        </span>
      </div>
    );
  }
  return null;
}

render() {
  const {
    data, purchaseNum, params, activeId, breadList, loading
  } = this.state;
  return (
    <div className={`${classNamePre}-wrapper`}>
      <div className={`${classNamePre}-bread yiye-global-bread`}>
        <Breadcrumb breads={breadList} />
      </div>
      {
        data && (
          <React.Fragment>
            <div className={`${classNamePre}-goods`}>
              <div className={`${classNamePre}-goods-img`}>
                <img
                  src={data.ProductPic}
                  alt="logo"
                />
              </div>
              <div className={`${classNamePre}-goods-info`}>
                <div className={`${classNamePre}-goods-activitynew`}>
                  <span>
              [
                    {data.MchName}
              ]
                    {data.CouponName}
                  </span>
                </div>
                <div className={`${classNamePre}-goods-activitynew-subtitle`}>
                  {
              data.SubTitle
            }
                </div>
                <div className={`${classNamePre}-goods-order ${classNamePre}-goods-ordernew`}>
                  <div style={{ 'margin-bottom': '15px' }}>
                    <span className={`${classNamePre}-goods-ordernew-bold`}>
                价格
                    </span>
                    <span className={`${classNamePre}-goods-order-zb`}>
                      {data.CouponTradeCfg && data.CouponTradeCfg.SellPrice && data.CouponTradeCfg.SellPrice.toFixed(2)}
                      <font>Z币</font>
                    </span>
                  </div>
                  <div style={{ 'margin-bottom': '15px' }}>
                    <span className={`${classNamePre}-goods-ordernew-bold`}>
                产品类型
                    </span>
                    <span>
                      {data.UnionCouponOriginTypeName}
                    </span>
                  </div>
                  {
              this.initTimeTpl(data)
            }
                </div>
                <div className={`${classNamePre}-goods-purchase`}>
                  <span>数量</span>
                  {
              params.BuyCount
                ? (
                  params.BuyCount
                )
                : (
                  <NumberInput
                    min={1}
                    width={95}
                    value={purchaseNum}
                    onChange={this.onChangeNum}
                    decimal={0}
                    maxLength={9}
                    placeholder="请输入数量"
                  />
                )
            }
            张
                </div>
                {
            params.BuyCount
              ? null
              : (
                <div className={`${classNamePre}-goods-btn`}>
                  <Button
                    type="primary"
                    onClick={this.purchase}
                    size="large"
                    loading={loading}
                  >
                  立即采购
                  </Button>
                </div>
              )
          }
              </div>
            </div>
          </React.Fragment>
        )
    }
      <div className={`${classNamePre}-info`}>
        <Tabs
          activeId={activeId}
          onChange={this.onTabChange}
          type="top"
          noneBorder
          borderRadius
        >
          <TabPanel
            tab="商品详情"
            id="1"
          >
            <div style={{ padding: '20px' }}>
              {/* eslint-disable */}
              <p dangerouslySetInnerHTML={{ __html: textAreaBr(data.Guide || '') }} />
              {/* eslint-enable */}
            </div>
          </TabPanel>
          <TabPanel
            tab="品牌介绍"
            id="2"
          >
            {/* eslint-disable */}
            <div
              className={`${classNamePre}-info-about`}
              dangerouslySetInnerHTML={{ __html: data.MchAbout }}
            />
            {/* eslint-enable */}
          </TabPanel>
        </Tabs>
      </div>
    </div>
  );
}
}

export default YiyeCouponDetail;
