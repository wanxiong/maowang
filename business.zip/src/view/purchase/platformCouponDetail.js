import * as React from 'react';
import { Breadcrumb } from 'ezrd';
import { observer, inject } from 'mobx-react';
import ConstCouponDetail from '../../components/base/constCouponDetail';
import { sessPurchaseCouponDtlKey } from '.../../components/base/constant';
// 新建
const classNamePre = 'yiye-purchase-platform-detail';

let obj = {};
try {
  obj = JSON.parse(localStorage.getItem(sessPurchaseCouponDtlKey));
} catch (error) {
//
}

@inject('purchaseStore')
@observer
export default class PlatformCouponDetail extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      params: obj,
      detail: {},
      breadList: [
        { name: '平台券', href: "#/Yiye/Purchase/Platformcoupon" },
        { name: '平台券详情', strong: true }]
    };
  }

  componentDidMount() {
    this.initDetail(obj);
  }

// 初始化详情
initDetail = async (params) => {
  const { purchaseStore } = this.props;
  const status = await purchaseStore.fetchPurchaseCouponListDetail({
    CouponGrpId: params.CouponTradeCfg.CouponGrpId,
    MchId: params.MchId
  });
  if (status.ErrorCode === 0 && !status.IsError) {
    this.setState({ detail: status.Data });
  } else {
    // Notify.error(status.ErrorMsg);
  }
}


render() {
  const { purchaseStore } = this.props;
  const { params, detail, breadList } = this.state;
  return (
    <div className={`${classNamePre}`}>
      <div className={`${classNamePre}-bread yiye-global-bread`}>
        <Breadcrumb breads={breadList} />
      </div>
      <div className={`${classNamePre}-con`}>
        <ConstCouponDetail
          couponDetail={params}
          MchId={params.MchId}
          detail={detail}
          purchaseStore={purchaseStore}
        />
      </div>
    </div>
  );
}
}
