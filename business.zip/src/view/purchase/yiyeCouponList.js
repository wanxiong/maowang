import * as React from 'react';
import {
  Button, Pagination, Icon
} from 'ezrd';
import { observer, inject } from 'mobx-react';
import cx from 'classnames';
import moment from 'moment';
import { couponDefaultPage, sessPurchaseNewYiyeCouponDtlKey } from '../../components/base/constant';
import { checkShopStatus } from '../../utils/commonApi';
// 新建

const classNamePre = 'yiye-coupon';
// 注入
@inject('purchaseStore')
@observer
class YiyeCouponList extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      category: [
        {
          title: '品牌',
          type: 0,
          index: -1,
          params: 'LM',
          all: '全部',
          children: []
        }, {
          title: '类型',
          type: 1,
          index: -1,
          params: 'PP',
          all: '全部',
          children: []
        }
      ],
      reCategory: {},
      ...couponDefaultPage,
      rankNum: 0,
      royalty: -1,
      rate: -1,
      isAsc: false
    };
    this.onChange = this.onChange.bind(this);
  }

// 页面加载完毕
@checkShopStatus('purchase')
  async componentDidMount() {
    const { category } = this.state;
    const { purchaseStore } = this.props;
    // 品牌
    const brandList = await purchaseStore.fetchProBrandList({});
    // 类目
    const cateList = await purchaseStore.fetchProPgTagList({});
    category[0].children = brandList.Data; // [{ Id: 1, BrandName: '爱奇艺' }]; //
    category[1].children = cateList.Data; // [{ Id: 2, TagName: '面包' }]; //
    this.initData();
  }

// 切换优惠--佣金--类型
changeCouponCategory = async (type, params, e) => {
  const { category, reCategory } = this.state;
  if (e.target.tagName.toLocaleLowerCase() !== 'span') return;
  const index = e.target.getAttribute('index') - 0;
  category[type].index = index;
  // reCategory[params] = {
  if (index === -1) { // 选择全部的时候
    delete reCategory[type];
  } else { //
    reCategory[type] = {
      title: category[type].title,
      type: category[type].type,
      index: category[type].index,
      name: e.target.innerHTML,
      child: index === -1 ? '' : category[type].children[index]
    };
  }
  this.setState({ reCategory, current: 1 }, () => {
    // 初始化任何一栏API
    this.initData({
    });
  });
}


// 查看详情
goDetail = (json) => {
  const { history } = this.props;
  localStorage.setItem(sessPurchaseNewYiyeCouponDtlKey, JSON.stringify({
    MchId: json.MchId,
    CouponGrpId: json.CouponTradeCfg.CouponGrpId
  }));
  history.push(`/Yiye/Equity/Coupon/YiyeCoupondetail`);
}

// 切换排序
setMenuRank = (num) => {
  /* eslint-disable */
  this.setState({
    rankNum: num,
    IsAsc: false,
    current: 1,
    royalty: -1,
    rate: -1
  }, () => {
    this.initData();
  });
  /* eslint-enable */
}

// 切换排序
sortType = (num) => {
  let { royalty, rate } = this.state;
  let status = false;
  if (num === 1) { // 提成
    royalty = royalty === 1 ? 2 : 1;
    status = royalty === 1;
    rate = -1;
  } else { // 核销率
    rate = rate === 1 ? 2 : 1;
    status = rate === 1;
    royalty = -1;
  }
  this.setState({
    rankNum: num,
    isAsc: status,
    current: 1,
    royalty,
    rate
  }, () => {
    this.initData();
  });
}

// 变更每页请求页数数量事件回调的函数
onPageSizeChange = (pageSize) => {
  this.setState({
    pageSize
  }, () => {
    this.initData();
  });
}

// 变更当前请求的页数的回调
onChange = (data) => {
  this.setState({ current: data }, () => {
    this.initData();
  });
}

//
initData = async (params = {}) => {
  const { purchaseStore } = this.props;
  const {
    pageSize, current, rankNum, isAsc, reCategory
  } = this.state;
  const obj = {
    ProBrandId: reCategory['0'] ? reCategory['0'].child.Id : '',
    ProPgTagId: reCategory['1'] ? reCategory['1'].child.Id : ''
  };
  purchaseStore.fetchUnionProGrpList({
    PageIndex: current,
    PageSize: pageSize,
    OrderType: rankNum,
    IsAsc: isAsc,
    ...params,
    ...obj
  });
}

//
removeTag = async (item) => {
  const { reCategory, category } = this.state;
  const { type } = reCategory[item];
  category[type].index = -1;
  delete reCategory[item];
  this.setState({ reCategory, category }, () => {
    this.initData({
    });
  });
}

initTimeTpl = (item) => {
  if (item.CouponTradeCfg && item.CouponTradeCfg.RechargeBeginDate && item.CouponTradeCfg.RechargeBeginDate.indexOf('0001-01-01') === -1) {
    return (
      <span className={`${classNamePre}-pro-timenumber-time`}>
          兑换有效期：
        {moment(item.CouponTradeCfg.RechargeBeginDate).format('YYYY-MM-DD HH:mm:ss')}
        {' '}
        -
        {moment(item.CouponTradeCfg.RechargeEndDate).format('YYYY-MM-DD HH:mm:ss')}
      </span>
    );
  }
  return null;
}

render() {
  const { purchaseStore } = this.props;
  const { yiyeCouponList: { TotalRowsCount, PagedList } } = purchaseStore;
  const data = PagedList;
  const {
    category, reCategory, royalty, rate, rankNum, pageSizeList, current
  } = this.state;
  return (
    <div className={`${classNamePre}`}>
      {/* 优惠券类型 */}
      <div className={`${classNamePre}-coupon-type`}>
        {/* 已选 */}
        {
          Object.keys(reCategory).length
            ? (
              <div className={`${classNamePre}-coupon-type-box`}>
                <div className={`${classNamePre}-lable`}>已选</div>
                <div className={`${classNamePre}-lable-item`}>
                  <div className={`${classNamePre}-lable-box`}>
                    {
                      Object.keys(reCategory).map((item, index) => (
                        <div
                          key={item.Id}
                          className={`${classNamePre}-lable-box-tag ${classNamePre}-lable-box-tag-change`}
                        >
                          <span>{reCategory[item].name}</span>
                          <Icon
                            type="close"
                            index={index}
                            params={item}
                            className={`${classNamePre}-lable-box-tag-icon`}
                            ezrd
                            onClick={event => this.removeTag(reCategory[item].type, item, event)}
                          />
                        </div>
                      ))
                    }
                  </div>
                </div>
              </div>
            )
            : null
        }
        {/* 佣金类型 */}
        {
          category.map(item => (
            <div
              key={item.type}
              className={`${classNamePre}-coupon-type-box`}
            >
              <div className={`${classNamePre}-lable`}>{item.title}</div>
              <div
                className={`${classNamePre}-lable-item yiye-outline`}
                role="button"
                tabIndex="0"
                onClick={event => this.changeCouponCategory(item.type, item.params, event)}
              >
                <div className={`${classNamePre}-lable-all`}>
                  <span
                    index="-1"
                    params={item.params}
                    className={item.index === -1 ? `${classNamePre}-active` : ''}
                  >
                    {item.all}
                  </span>
                </div>
                <ul className={`${classNamePre}-lable-box`}>
                  {
                      item.children.map((itemchildren, index) => (
                        <div
                          key={itemchildren.Id}
                          className={`${classNamePre}-lable-box-tag`}
                        >
                          <span
                            index={index}
                            params={item.params}
                            className={`${index === item.index ? `${classNamePre}-active` : ''}`}
                          >
                            {
                                itemchildren.BrandName ? itemchildren.BrandName : itemchildren.TagName
                              }
                          </span>
                        </div>
                      ))
                    }
                </ul>
              </div>
            </div>
          ))
        }
      </div>
      {/* 列表排序区域 */}
      <div className={`${classNamePre}-contr`}>
        <ul>
          <li
            className={rankNum === 0 ? `${classNamePre}-contr-active` : ''}
            onClick={() => this.setMenuRank(0)}
          >
            <span>默认</span>
          </li>
          <li
            className={rankNum === 1 ? `${classNamePre}-contr-active` : ''}
            onClick={() => this.sortType(1)}
          >
            <span>销量</span>

            <div className={`${classNamePre}-contr-box`}>
              <Icon
                type="sort_down"
                ezrd
                className={cx(`${classNamePre}-contr-icon`, { [`${classNamePre}-contr-box-active`]: royalty === 2 })}
              />
              <Icon
                type="sort_up"
                ezrd
                className={cx(`${classNamePre}-contr-icon`, { [`${classNamePre}-contr-box-active`]: royalty === 1 })}
              />
            </div>
          </li>
          <li
            className={rankNum === 2 ? `${classNamePre}-contr-active` : ''}
            onClick={() => this.sortType(2)}
          >
            <span>价格</span>
            <div className={`${classNamePre}-contr-box`}>
              <Icon
                type="sort_down"
                ezrd
                className={cx(`${classNamePre}-contr-icon`, { [`${classNamePre}-contr-box-active`]: rate === 2 })}
              />
              <Icon
                type="sort_up"
                ezrd
                className={cx(`${classNamePre}-contr-icon`, { [`${classNamePre}-contr-box-active`]: rate === 1 })}
              />
            </div>
          </li>
        </ul>
      </div>
      {/* 列表展示区域 */}
      <div className={`${classNamePre}-pro`}>
        <ul>
          {
            data.map(item => (
              <li
                key={item.Id}
                className={`${classNamePre}-pro-item yiye-outline`}
                onClick={event => this.goDetail(item, event)}
              >
                <div
                  className={`${classNamePre}-pro-img`}
                >
                  <img
                    alt={item.MchName}
                    src={item.MchLogo}
                  />
                </div>
                <div className={`${classNamePre}-pro-info`}>
                  <div className={`${classNamePre}-pro-disnew`}>
                    <span className={`${classNamePre}-pro-disnew-name`}>
                      [
                      {item.MchName}
                      ]
                    </span>
                    <span>{item.CouponName}</span>
                  </div>
                  <div className={`${classNamePre}-pro-oldprice`}>
                    <span>{item.SubTitle}</span>
                  </div>
                  {
                    item.CouponTradeCfg.MarketPrice
                      ? (
                        <div className={`${classNamePre}-pro-oldprice`}>
                          <span>
                            市场价
                            {item.CouponTradeCfg.MarketPrice.toFixed(2)}
                            元
                          </span>
                        </div>
                      )
                      : null
                  }
                  <div className={`${classNamePre}-pro-type`}>
                    <span>
                      产品类型：
                      {
                        // yiyeCouponProType[item.UnionCouponOrigin]
                        item.UnionCouponOriginTypeName
                      }
                    </span>
                    {
                      // <span>
                      //   适用：
                      //   {item.OutSysName }
                      // </span>
                    }

                  </div>
                  <div className={`${classNamePre}-pro-timenumber`}>
                    {
                      this.initTimeTpl(item)
                    }
                    <span>
                      月销量:
                      {item.MonthSendTotal}
                      张
                    </span>
                  </div>
                </div>
                <div className={`${classNamePre}-pro-price`}>
                  <div>售价</div>
                  <div>
                    { item.CouponTradeCfg.SellPrice.toFixed(2) }
                    <span className={`${classNamePre}-pro-price-currency`}>Z币</span>
                  </div>
                </div>
                <div>
                  <Button
                    type="primary"
                    role="button"
                    tabIndex="0"
                    className="yiye-outline"
                    onClick={event => this.goDetail(item, event)}
                  >
                  查看
                  </Button>
                </div>
              </li>
            ))
          }
        </ul>
        {/* 分页区域 */}
        <Pagination
          current={current}
          totalItem={TotalRowsCount}
          onChange={this.onChange}
          pageSize={pageSizeList}
          className={`${classNamePre}-pagination`}
          onPageSizeChange={this.onPageSizeChange}
        />
      </div>

    </div>
  );
}
}

export default YiyeCouponList;
