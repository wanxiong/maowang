import * as React from 'react';
import {
  Pop, Icon, Table, Pagination
} from 'ezrd';
import { observer, inject } from 'mobx-react';
import moment from 'moment';
import OrderCouponSearch from '../../components/base/orderCouponSearch';
import { couponDefaultPage, orderYiyeCuoponType, sessPurchaseNewYiyeCouponDtlKey } from '../../components/base/constant';
import { checkShopStatus } from '../../utils/commonApi';

const classNamePre = 'yiye-purchase-order';

@inject('purchaseStore')
@observer
class YiyePurchaseOrder extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      ...couponDefaultPage
    };
    this.onChange = this.onChange.bind(this);
    this.onPageSizeChange = this.onPageSizeChange.bind(this);
  }

  @checkShopStatus('purchase')
  componentDidMount() {
    this.initData({});
  }

  // initData
  initData = (params = {}) => {
    const { purchaseStore } = this.props;
    const { pageSize, current } = this.state;
    purchaseStore.fetchPurchaseOrderList({
      PageIndex: current,
      PageSize: pageSize,
      PurchaseNo: '', // 采购单号
      ProBrandName: '', // 品牌
      Status: '', // 状态：入库中30 采购失败21  已入库3
      CouponName: '', // 券名称
      StartTime: '', // 开始时间
      EndTime: '', // 结束时间
      UnionCouponType: '1',
      ...params
    });
  }

  // 点击查询的事件
  onHandleSearch = (data, flag) => {
    if (flag !== 0) {
      this.setState({ current: 1 }, () => {
        this.initData({
          PurchaseNo: data.couponId,
          ProBrandName: data.brand,
          Status: data.currentSelect,
          CouponName: data.couponName,
          StartTime: data.time[0] ? data.time[0] : '',
          EndTime: data.time[1] ? data.time[1] : ''
        });
      });
      return;
    }
    this.initData({
      PurchaseNo: data.couponId,
      ProBrandName: data.brand,
      Status: data.currentSelect,
      CouponName: data.couponName,
      StartTime: data.time[0] ? data.time[0] : '',
      EndTime: data.time[1] ? data.time[1] : ''
    });
  }

  // 每页大小的回调
  onPageSizeChange = (pageSize) => {
    this.setState({
      pageSize,
      current: 1
    }, () => {
      this.searchDom.onSearch(0);
    });
  };

  // 分页的回调
  onChange = (data) => {
    const { current } = this.state;
    this.setState({
      current: data || current
    }, () => {
      this.searchDom.onSearch(0);
    });
  }

  // 查看详情也
  goDetail = (data) => {
    const { history } = this.props;
    localStorage.setItem(sessPurchaseNewYiyeCouponDtlKey, JSON.stringify({
      MchId: data.MchId,
      CouponGrpId: data.CouponGrpId,
      BuyCount: data.BuyCount
    }));
    history.push(`/Yiye/Equity/Coupon/YiyeCoupondetail`);
  }

  // 操作区域的渲染
  initStatus = (item) => {
    if (item.Status === 21) {
      return (
        <span>
          采购失败
          <Pop
            trigger="hover"
            position="top-right"
            content={item.BackReason}
          >
            <Icon
              type="info-circle-o"
              className={`${classNamePre}-pro-popicon`}
            />
          </Pop>
        </span>
      );
    }
    return (<span>{item.StatusDes}</span>);
  }

  render() {
    const { purchaseStore: { purchaseOrderList } } = this.props;
    const { TotalRowsCount, PagedList } = purchaseOrderList;
    const { current, pageSizeList } = this.state;
    const columns = [{
      title: '采购时间',
      textAlign: 'left',
      bodyRender: data => <div>{moment(data.BuyTime).format('YYYY-MM-DD HH:mm')}</div>
    }, {
      title: '采购单号',
      name: 'PurchaseNo'
    }, {
      title: '券名称',
      bodyRender: data => (
        <div
          className={`${classNamePre}-pro-yiye-special yiye-outline`}
          onClick={() => this.goDetail(data)}
          role="button"
          tabIndex="0"
        >
          <div style={{
            width: '64px', height: '64px', 'margin-right': '10px', display: 'flex', 'flex-direction': 'column', 'justify-content': 'center'
          }}
          >
            <img
              src={data.ProBrandLog}
              alt={data.ProBrandName}
              style={{ 'max-width': '100%', 'max-height': '100%' }}
            />
          </div>
          <div>
            <div className="coupon-name">{data.CouponName}</div>
            <div>{data.SubTitle}</div>
            <div>
              产品类型：
              {data.UnionCouponOriginTypeName}
            </div>
            <div>
              券ID：
              {data.CouponGrpId}
            </div>
          </div>
        </div>
      ),
      width: '280px'
    }, {
      title: '品牌',
      name: 'ProBrandName'
    }, {
      title: '采购量',
      name: 'BuyCount'
    }, {
      title: '单价(Z币)',
      name: 'SellPrice'
    }, {
      title: '采购总价(Z币)',
      name: 'UnionMoney'
    }, {
      title: '状态',
      bodyRender: data => this.initStatus(data)
    }];
    return (
      <div className={`${classNamePre}`}>
        {/* 查询头部 */}
        <OrderCouponSearch
          onSearch={this.onHandleSearch}
          onExport={this.onHandleExport}
          exportText="导出采购单"
          type="purchaseStore"
          typeName="采购单"
          selectData={orderYiyeCuoponType}
          // ref={(ref) => { this.searchDom = ref; }}
          getRef={(ref) => { this.searchDom = ref; }}
        />
        <div className={`${classNamePre}-pro`}>
          <Table
            columns={columns}
            datasets={PagedList}
            rowKey="id"
          />
          <Pagination
            current={current}
            totalItem={TotalRowsCount}
            pageSize={pageSizeList}
            onChange={this.onChange}
            onPageSizeChange={this.onPageSizeChange}
          />
        </div>
      </div>
    );
  }
}

export default YiyePurchaseOrder;
