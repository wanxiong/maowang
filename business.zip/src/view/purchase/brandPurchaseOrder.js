import * as React from 'react';
import {
  Pop, Icon, Pagination, Dialog, Button, Notify
} from 'ezrd';
import { observer, inject } from 'mobx-react';
import moment from 'moment';
import OrderCouponSearch from '../../components/base/orderCouponSearch';
import { couponDefaultPage } from '../../components/base/constant';
import { checkShopStatus } from '../../utils/commonApi';
// 新建

const { openDialog, closeDialog } = Dialog;

const classNamePre = 'yiye-purchase-order';

@inject('purchaseStore')
@observer
export default class BrandPurchaseOrder extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      ...couponDefaultPage
    };
    this.onChange = this.onChange.bind(this);
    this.onPageSizeChange = this.onPageSizeChange.bind(this);
  }

  @checkShopStatus('purchase')
  componentDidMount() {
    this.initData({});
  }

// initData
initData = (params = {}) => {
  const { purchaseStore } = this.props;
  const { pageSize, current } = this.state;
  purchaseStore.fetchPurchaseOrderList({
    PageIndex: current,
    PageSize: pageSize,
    PurchaseNo: '', // 采购单号
    ProviderName: '', // 品牌
    Status: '', // 状态：待审核0 审核未通过1 审核通过 制券中2  已入库3
    CouponName: '', // 券名称
    StartTime: '', // 开始时间
    EndTime: '', // 结束时间
    ...params
  });
}

// 点击查询的事件
onHandleSearch = (data, flag) => {
  if (flag !== 0) {
    this.setState({ current: 1 }, () => {
      this.initData({
        PurchaseNo: data.couponId,
        ProviderName: data.brand,
        Status: data.currentSelect,
        CouponName: data.couponName,
        StartTime: data.time[0] ? data.time[0] : '',
        EndTime: data.time[1] ? data.time[1] : ''
      });
    });
    return;
  }
  this.initData({
    PurchaseNo: data.couponId,
    ProviderName: data.brand,
    Status: data.currentSelect,
    CouponName: data.couponName,
    StartTime: data.time[0] ? data.time[0] : '',
    EndTime: data.time[1] ? data.time[1] : ''
  });
}

// 导出事件
// onHandleExport = (data) => {
//   console.log(data);
// }

// 每页大小的回调
onPageSizeChange = (pageSize) => {
  this.setState({
    pageSize
  }, () => {
    this.searchDom.onSearch(0);
  });
};

// 分页的回调
onChange = (data) => {
  const { current } = this.state;
  this.setState({
    current: data || current
  }, () => {
    this.searchDom.onSearch(0);
  });
}

// 删除订单
onDelete = (Id) => {
  const id = 1;
  openDialog({
    dialogId: id,
    title: (
      <div>
        <Icon
          className={`${classNamePre}-tip-icon`}
          type="error-circle-o"
        />
      操作提示
      </div>
    ),
    children: <div>是否删除待审核单号！</div>,
    footer: (
      <div>
        <Button
          type="primary"
          onClick={() => closeDialog(id)}
        >
      取消
        </Button>
        <Button
          type="primary"
          onClick={() => this.initDelete(Id, id)}
        >
      确认
        </Button>
      </div>
    ),
    onClose() {
      // console.log('outer dialog closed');
    }
  });
}

//
initDelete = async (Id, id) => {
  const { purchaseStore } = this.props;
  const statu = await purchaseStore.fetchPurchaseOrderDelete({ id: Id });
  if (statu.Data) {
    Notify.success('订单删除成功');
    this.searchDom.onSearch();
  } else {
    // Notify.error(statu.ErrorMsg);
  }
  closeDialog(id);
}

// 操作区域的渲染
initStatus = (item) => {
  if (item.Status === 0) {
    return (<span>待审核</span>);
  } if (item.Status === 3) {
    return (<span>已入库</span>);
  } if (item.Status === 1) {
    return (
      <span>
        审核未通过
        <Pop
          trigger="hover"
          content={item.BackReason}
        >
          <Icon
            type="info-circle-o"
            className={`${classNamePre}-pro-popicon`}
          />
        </Pop>
      </span>
    );
  } if (item.Status === 2) {
    return (<span>制券中</span>);
  }
  return null;
}

render() {
  const { purchaseStore: { purchaseOrderList } } = this.props;
  const { TotalRowsCount, PagedList } = purchaseOrderList;
  const { current, pageSizeList } = this.state;
  return (
    <div className={`${classNamePre}`}>
      {/* 查询头部 */}
      <OrderCouponSearch
        onSearch={this.onHandleSearch}
        onExport={this.onHandleExport}
        exportText="导出采购单"
        type="purchaseStore"
        typeName="流量交易单"
        // ref={(ref) => { this.searchDom = ref; }}
        getRef={(ref) => { this.searchDom = ref; }}
      />
      <div className={`${classNamePre}-pro`}>
        <div className={`${classNamePre}-pro-head`}>
          <span>采购时间</span>
          <span>券类型</span>
          <span className={`${classNamePre}-pro-head-special`}>券名称</span>
          <span>供应品牌</span>
          <span>采购量(万)</span>
          <span>核销单价/订单提成</span>
          <span>状态</span>
          <span>操作</span>
        </div>
        {
          PagedList.map(item => (
            <div
              key={item.Id}
              className={`${classNamePre}-pro-item`}
            >
              <div>
                采购单号:
                {item.PurchaseNo}
              </div>
              <ul>
                <li>{moment(item.BuyTime).format('YYYY-MM-DD HH:mm:ss')}</li>
                <li>{item.CouponType}</li>
                <li className={`${classNamePre}-pro-head-special`}>
                  <div>
                    <img
                      alt="logo"
                      src={item.MchLog}
                      width="64px"
                      height="64px"
                    />
                  </div>
                  <div>
                    <div>{item.CouponName}</div>
                    <div>{item.SubTitle}</div>
                    <div>
                      券ID：
                      {item.CouponGrpId}
                    </div>
                  </div>
                </li>
                <li>{item.ProviderName}</li>
                <li>{item.BuyCount / 10000}</li>
                <li>
                  {
                    item.RewardWray === 0 // 按核销单张券奖励金额
                      ? item.RewardMoney.toFixed(2)
                      : `${item.RewardMoney * 100}%`// 按核销的订单实付金额比例提成
                    }
                  {/* <span>10%<Pop trigger="hover" content="采购单发生了改价"><Icon type="info-circle-o" className={`${classNamePre}-pro-popicon`}/></Pop></span> */}
                </li>
                <li>
                  {
                  this.initStatus(item)
                }
                </li>
                <li>
                  {item.Status === 0 ? (
                    <span
                      role="button"
                      tabIndex="0"
                      className="yiye-outline btn-default-color"
                      onClick={event => this.onDelete(item.Id, event)}
                    >
                    删除
                    </span>
                  ) : <span>--</span>}
                </li>
              </ul>
            </div>
          ))
        }
        {/* 分页区域 */}
        <Pagination
          current={current}
          totalItem={TotalRowsCount}
          onChange={this.onChange}
          pageSize={pageSizeList}
          onPageSizeChange={this.onPageSizeChange}
        />
      </div>
    </div>
  );
}
}
