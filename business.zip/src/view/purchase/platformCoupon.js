import * as React from 'react';
import {
  Pagination, Dialog, Button, Icon, Notify
} from 'ezrd';
import { observer, inject } from 'mobx-react';
import { toJS } from 'mobx';
import moment from 'moment';
import PlatformCouponSearch from '../../components/base/platformCouponSearch';
import { couponDefaultPage, sessPurchaseCouponDtlKey } from '../../components/base/constant';
import { checkShopStatus } from '../../utils/commonApi';
import { isEmptyTime } from '../../utils/common';

const { openDialog, closeDialog } = Dialog;

const classNamePre = 'yiye-purchase-platform-coupon';

@inject('purchaseStore')
@inject('provideStore')
@observer
export default class PlatformCoupon extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      ...couponDefaultPage
    };
    this.onHandleSearch = this.onHandleSearch.bind(this);
  }

  //
@checkShopStatus('purchase')
  componentDidMount() {
    this.initData({});
  }

// 点击查询的事件
onHandleSearch = (data, flag) => {
  if (flag !== 0) {
    this.setState({ current: 1 }, () => {
      this.initData({
        CouponGrpId: data.couponId,
        CouponName: data.couponName,
        CouponType: data.currentSelect,
        BrandName: data.brand
      });
    });
    return;
  }
  this.initData({
    CouponGrpId: data.couponId,
    CouponName: data.couponName,
    CouponType: data.currentSelect,
    BrandName: data.brand
  });
}

// 每页大小的回调
onPageSizeChange = (pageSize) => {
  this.setState({
    pageSize
  }, () => {
    this.searchDom.onSearch(0);
  });
};

// 分页的回调
onChange = (data) => {
  const { current } = this.state;
  this.setState({
    current: data || current
  }, () => {
    this.searchDom.onSearch(0);
  });
}

// 禁用
isDisable = (CouponPurchaseStatus, item) => {
  // 删除订单
  const id = 1;
  const text = CouponPurchaseStatus === '0' ? '平台券开启将影响现有应用此券的活动，是否开启平台券' : '平台券禁用将影响现有应用此券的活动，是否禁用平台券';
  openDialog({
    dialogId: id,
    title: (
      <div>
        <Icon
          className={`${classNamePre}-tip-icon`}
          type="error-circle-o"
        />
      操作提示
      </div>
    ),
    children: <div>{text}</div>,
    footer: (
      <div>
        <Button
          type="primary"
          outline
          onClick={() => closeDialog(id)}
        >
        取消
        </Button>
        <Button
          type="primary"
          onClick={() => this.initDisable(CouponPurchaseStatus, id, item)}
        >
        确认
        </Button>
      </div>
    ),
    onClose() {
      // console.log('outer dialog closed');
    }
  });
}

// 禁用/开启
initDisable = async (CouponPurchaseStatus, id, item) => {
  const { provideStore } = this.props;
  const params = toJS(item);
  params.CouponPurchaseStatus = CouponPurchaseStatus;
  params.IsDisable = true;
  const statu = await provideStore.fetchProvidePlatformCouponStatus(params);
  if (!statu.IsError) {
    Notify.success('操作成功');
    this.searchDom.onSearch(0);
  }
  closeDialog(id);
}

// 查看详情
goDetail = (json) => {
  const { history } = this.props;
  localStorage.setItem(sessPurchaseCouponDtlKey, JSON.stringify(toJS(json)));
  history.push('/Yiye/Purchase/PlatformCouponDetail');
}

//
initData = (params = {}) => {
  const { purchaseStore } = this.props;
  const { pageSize, current } = this.state;
  purchaseStore.fetchPurchasePlatformCouponList({
    PageSize: pageSize,
    PageIndex: current,
    ...params
  });
}

// 券状态渲染
initPurchaseStatus = (item) => {
  /*  0 已生效 1 已禁用 2 已过期 3 已失效  */
  if (item.CouponPurchaseStatus === 0) {
    return (<span>已生效</span>);
  } if (item.CouponPurchaseStatus === 1) {
    return (<span>已禁用</span>);
  } if (item.CouponPurchaseStatus === 2) {
    return (<span>已过期</span>);
  } if (item.CouponPurchaseStatus === 3) {
    return (<span>已失效</span>);
  }
  return null;
}

// 操作区域的渲染
initPurchaseHandle = (item) => {
  if (item.CouponPurchaseStatus === 0) {
    return (
      <React.Fragment>
        <span
          role="button"
          tabIndex="0"
          className="yiye-outline btn-default-color"
          onClick={event => this.goDetail(item, event)}
        >
        查看
        </span>
        <span
          role="button"
          tabIndex="0"
          className="yiye-outline btn-default-color"
          onClick={event => this.isDisable('1', item, event)}
        >
        禁用
        </span>
      </React.Fragment>
    );
  } if (item.CouponPurchaseStatus === 1) {
    return (
      <React.Fragment>
        <span
          role="button"
          tabIndex="0"
          className="yiye-outline btn-default-color"
          onClick={event => this.goDetail(item, event)}
        >
        查看
        </span>
        <span
          role="button"
          tabIndex="0"
          className="yiye-outline btn-default-color"
          onClick={event => this.isDisable('0', item, event)}
        >
        开启
        </span>
      </React.Fragment>
    );
  }
  return (
    <React.Fragment>
      <span
        role="button"
        tabIndex="0"
        className="yiye-outline btn-default-color"
        onClick={event => this.goDetail(item, event)}
      >
        查看
      </span>
    </React.Fragment>
  );
}

render() {
  const { purchaseStore: { purchasePlatformCouponList } } = this.props;
  const { TotalRowsCount, PagedList } = purchasePlatformCouponList;
  const { current, pageSizeList } = this.state;
  const data = PagedList;
  return (
    <div className={`${classNamePre}`}>
      {/* 平台券检索区域 */}
      <div>
        <PlatformCouponSearch
          onSearch={this.onHandleSearch}
          ref={(ref) => { this.searchDom = ref; }}
        />
      </div>
      <div className={`${classNamePre}-pro`}>
        <div className={`${classNamePre}-pro-head`}>
          <span>券ID</span>
          <span>券类型</span>
          <span>品牌</span>
          <span>券名称</span>
          <span>剩余库存(百)</span>
          <span>状态</span>
          <span>操作</span>
        </div>
        {
          data.map(item => (
            <div
              key={item.Id}
              className={`${classNamePre}-pro-item`}
            >
              <div>
                入库时间：
                <span>{moment(item.StorageTime).format('YYYY-MM-DD HH:mm:ss')}</span>
                ，
                券发放截止时间：
                <span>{moment(item.CouponValidDate).format('YYYY-MM-DD HH:mm:ss')}</span>
                ，
                券使用有效期：
                <span>
                  {
                    isEmptyTime(item.CouponTradeCfg.BeginDate, item.CouponTradeCfg.EndDate)
                      ? (`自领取日 ${item.CouponTradeCfg.ValidVay} 天有效，`)
                      : `${moment(item.CouponTradeCfg.BeginDate).format('YYYY-MM-DD HH:mm:ss')} - ${moment(item.CouponTradeCfg.EndDate).format('YYYY-MM-DD HH:mm:ss')}`
                  }
                </span>
                采购量：
                <span>
                  {item.PurchaseQty / 10000}
                  万
                </span>
              </div>
              <ul>
                <li>{item.Id}</li>
                <li>{item.CouponTypeName}</li>
                <li>{item.MchName}</li>
                <li>{item.CouponName}</li>
                <li>{item.StockQty / 100}</li>
                <li>
                  {
                    this.initPurchaseStatus(item)
                  }
                </li>
                <li>
                  {
                    this.initPurchaseHandle(item)
                  }
                </li>
              </ul>
            </div>
          ))
        }
        {/* 分页区域 */}
        <Pagination
          current={current}
          totalItem={TotalRowsCount}
          onChange={this.onChange}
          pageSize={pageSizeList}
          onPageSizeChange={this.onPageSizeChange}
        />
      </div>
    </div>
  );
}
}
