import * as React from 'react';
import {
  Dialog, Notify, Button, NumberInput, Tabs, Icon, Pop, Breadcrumb
} from 'ezrd';
import { observer, inject } from 'mobx-react';
import { sessPurchaseCouponDtlKey } from '../../components/base/constant';
import ConstCouponDetail from '../../components/base/constCouponDetail';
import { multiplication } from '../../utils/common';

const { openDialog, closeDialog } = Dialog;
const { TabPanel } = Tabs;
const classNamePre = 'yiye-coupon-det';

// 注入
@inject('purchaseStore')
@observer
export default class BrandCouponDetail extends React.Component {
  constructor(prop) {
    super(prop);
    let obj = {};
    try {
      obj = JSON.parse(localStorage.getItem(sessPurchaseCouponDtlKey));
    } catch (error) {
      //
    }
    this.state = {
      activeId: '1',
      purchaseNum: '', // 采购数量
      params: obj,
      breadList: [],
      detail: {}
    };
  }

componentDidMount = () => {
  const { params } = this.state;
  // 设置折线图的宽度
  let bUrl = [];
  bUrl = [
    { name: '流量市场', href: "#/Yiye/Purchase/Coupon/BrandCouponList" },
    { name: '券详情', strong: true }
  ];
  this.setState({
    breadList: bUrl
  });
  this.initDetail(params);
}

goDetail = (id) => {
  const { history } = this.props;
  closeDialog(id);
  history.push('/Yiye/Purchase/Purchaseorder/BrandOrder');
}

onTabChange = (id) => {
  this.setState({
    activeId: id
  });
}

// 初始化详情
initDetail = async (params) => {
  const { purchaseStore } = this.props;
  const status = await purchaseStore.fetchPurchaseCouponListDetail({
    CouponGrpId: params.CouponTradeCfg.CouponGrpId,
    MchId: params.MchId
  });
  if (status.ErrorCode === 0 && !status.IsError) {
    this.setState({ detail: status.Data });
  } else {
    Notify.error(status.ErrorMsg);
  }
}

// 采购数量的输入框
onChangeNum = (e) => {
  const v = e.target.value;
  this.setState({ purchaseNum: v });
}

// 申请采购
purchase = async () => {
  const { purchaseStore } = this.props;
  const { purchaseNum, params } = this.state;
  if (!purchaseNum) {
    Notify.error('请输入采购数量');
    return;
  }
  //
  if (purchaseNum * 10000 > params.CouponTradeCfg.EndNo) {
    Notify.error('采购数量不能大于起批量最大值');
    return;
  }
  if (purchaseNum * 10000 < params.CouponTradeCfg.StartNo) {
    Notify.error('采购数量不能小于起批量最小值');
    return;
  }
  //
  const statu = await purchaseStore.fetchPurchaseApply({
    MchId: params.CouponTradeCfg.MchId,
    CouponCfgId: params.CouponTradeCfg.Id,
    BuyCount: multiplication(purchaseNum, 10000),
    CouponGrpId: params.CouponTradeCfg.CouponGrpId
  });
  if (statu.IsError) {
    // Notify.error(statu.ErrorMsg);
  } else {
    openDialog({
      dialogId: 1,
      title: '申请提交成功，待审核',
      footer: (
        <React.Fragment>
          <Button
            type="primary"
            onClick={event => this.goDetail(1, event)}
          >
          查看申请单
          </Button>
        </React.Fragment>
      )
    });
  }
}

render() {
  const {
    params, detail, purchaseNum, activeId, breadList
  } = this.state;
  const { purchaseStore } = this.props;
  return (
    <div className={`${classNamePre}-wrapper`}>
      <div className={`${classNamePre}-bread yiye-global-bread`}>
        <Breadcrumb breads={breadList} />
      </div>
      <div className={`${classNamePre}-goods`}>
        <div className={`${classNamePre}-goods-img`}>
          <img
            src={params.MchLogo}
            alt="logo"
          />
        </div>
        <div className={`${classNamePre}-goods-info`}>
          <div className={`${classNamePre}-goods-activity`}>
            <span>{params.CouponTypeName}</span>
            <span>
              [
              {params.MchName}
              ]
              {params.CouponName}
            </span>
            <span>{params.SubTitle}</span>
          </div>
          <div className={`${classNamePre}-goods-order`}>
            <div className={`${classNamePre}-goods-description`}>
              <span>
                订单提成
                {
                  params.CouponTradeCfg.RewardWray === 0
                    ? (
                      <Pop
                        trigger="hover"
                        content="核销一张优惠券的价格"
                      >
                        <Icon
                          type="info"
                          ezrd
                        />
                      </Pop>
                    )
                    : (
                      <Pop
                        trigger="hover"
                        content="核销优惠券对应的订单实付金额比例"
                      >
                        <Icon
                          type="info"
                          ezrd
                        />
                      </Pop>
                    )
                }
              </span>
              <span className={`${classNamePre}-goods-description-royalty`}>
                {
                params.CouponTradeCfg.RewardWray === 0
                  ? (
                    params.RewardMoney.toFixed(2)
                  )
                  : (
                    `${params.RewardMoney * 100}%`
                  )
              }
              </span>
            </div>
            {params.CouponTradeCfg.NewVipReward > 0
              ? (
                <div className={`${classNamePre}-goods-description`}>
                  <div>
                    <span>
                      拉新奖励
                      <Pop
                        trigger="hover"
                        content="注册一个新用户奖励的金额"
                      >
                        <Icon
                          type="info"
                          ezrd
                        />
                      </Pop>
                    </span>
                    <span className={`${classNamePre}-goods-description-royalty`}>
                      {params.CouponTradeCfg.NewVipReward.toFixed(2)}
                    </span>
                  </div>
                </div>

              ) : <div />}
            <div className={`${classNamePre}-goods-description`}>
              <span>起批量</span>
              <span className={`${classNamePre}-goods-description-num`}>
                {params.CouponTradeCfg.StartNo / 10000}
                {' '}
                -
                {' '}
                {params.CouponTradeCfg.EndNo / 10000}
                万张
              </span>
            </div>
          </div>
          <div className={`${classNamePre}-goods-purchase`}>
            <span>采购数量</span>
            <NumberInput
              min={0.01}
              width={95}
              value={purchaseNum}
              onChange={this.onChangeNum}
              decimal={2}
              placeholder="请输入数量"
            />
            万张
          </div>
          <div className={`${classNamePre}-goods-btn`}>
            <Button
              type="primary"
              onClick={this.purchase}
              size="large"
            >
            申请采购
            </Button>
          </div>
        </div>
      </div>

      <div className={`${classNamePre}-info`}>
        <Tabs
          activeId={activeId}
          onChange={this.onTabChange}
        >
          <TabPanel
            tab="优惠券详情"
            id="1"
          >
            <ConstCouponDetail
              couponDetail={params}
              MchId={params.MchId}
              detail={detail}
              purchaseStore={purchaseStore}
            />
          </TabPanel>
          <TabPanel
            tab="品牌介绍"
            id="2"
          >
            {/* eslint-disable */}
            <div
              className={`${classNamePre}-info-about`}
              dangerouslySetInnerHTML={{ __html: params.MchAbout }}
            />
            {/* eslint-enable */}
          </TabPanel>
        </Tabs>
      </div>
    </div>
  );
}
}
