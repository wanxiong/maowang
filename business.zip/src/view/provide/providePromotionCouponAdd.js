import * as React from 'react';
import {
  Pop, Icon, Form, Radio, Button, Notify
} from 'ezrd';
import { observer, inject } from 'mobx-react';
import { sessProvidePlatformcouponStatusKey, sessProvidePlatformCouponDtlType, sessProvidePlatformcouponDtlKey } from '../../components/base/constant';
import {
  ConstFormPromotionCouponList, ConstFormDay, ConstFormBetween, ConstFormValidDate
} from '../../components/base/constForm';
import { multiplication } from '../../utils/common';
import { checkShopStatus } from '../../utils/commonApi';
import { ConstFormUpload } from '../../components/base/constFormImage';
// 新建

const {
  Field, FormInputField, FormSelectField, createForm, FormRadioGroupField, FormNumberInputField
} = Form;

const classNamePre = 'yiye-provide-couponadd';

@inject('provideStore')
@inject('supplierStore')
// 注入
@observer
class FieldForm extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      sysList: [], // 适用门店
      detail: '',
      pageStatus: '',
      loading: false,
      pageDisabled: false,
      dateDisabled: false
    };
    this.submit = this.submit.bind(this);
  }

  @checkShopStatus('provide')
  componentWillMount() {
    const pageStatus = localStorage.getItem(sessProvidePlatformcouponStatusKey);
    let detail = '';
    let pageDisabled = false;
    let dateDisabled = false;
    // 只能查看的话，禁止编辑
    if (pageStatus === sessProvidePlatformCouponDtlType[0]) {
      pageDisabled = true;
      dateDisabled = true;
    }
    try {
      detail = JSON.parse(localStorage.getItem(sessProvidePlatformcouponDtlKey));
    } catch (error) {
      //
    }
    this.setState({
      detail, pageStatus, pageDisabled, dateDisabled
    });
  }

  componentDidMount() {
    this.initSys();
  }

// 基本输入框内容变更
onChangeInput = (type, e) => {
  this.setState({
    [type]: e.target.value
  });
}

submit = async (status) => {
  const { provideStore } = this.props;
  const { fetchProvideCouponAddSave } = provideStore;
  const { pageStatus, detail } = this.state;
  const { ezrdForm } = this.props;
  const values = ezrdForm.getFormValues();
  // if (values.TplId.CouponType !== 'DJ' && (values.OutSysId === -1 || values.OutSysId === -2)) {
  //   Notify.error("仅代金券支持选择适应系统为：全部通用、EZR线上商城！");
  //   return;
  // }
  // 拦截一波券模板和适用类型的校验
  const { PurchaseBet } = values;
  const { CusValidVay } = values;
  const { TplId } = values;
  // 其他字段处理
  // 起批量
  if (PurchaseBet && PurchaseBet.length) {
    values.StartNo = multiplication(PurchaseBet[0], 10000);
    values.EndNo = multiplication(PurchaseBet[1], 10000);
  }
  // 使用有效期
  if (CusValidVay && CusValidVay.type === '1') {
    const [one] = CusValidVay.data;
    values.ValidVay = one;
  } else if (CusValidVay && CusValidVay.type === '2') {
    const [, two] = CusValidVay.data;
    const [twoFirst, twoScend] = two;
    values.BeginDate = twoFirst;
    values.EndDate = twoScend;
  }
  this.setState({ loading: true });
  // 先上传图片
  // const imgObj = values.BrandLog;
  let url = '';
  if (values.WxQrCode.data && values.WxQrCode.data[0].file) {
    url = await this.uploadImg({ file: values.WxQrCode.data[0].file });
    if (!url) return;
  } else {
    url = values.WxQrCode.src;
  }
  values.WxQrCode = url;


  // 促销券的数据整理
  values.TplName = TplId.couponTpl;
  values.CouponType = TplId.CouponType;
  values.CouponValue = TplId.CouponValue;
  values.CouponPriceLimit = TplId.CouponPriceLimit || '';
  values.PromotionCode = TplId.PromotionCode;
  values.PromotionValidType = TplId.PromotionValidType;
  values.ApplyType = TplId.ApplyType;
  values.ApplyShops = TplId.ApplyShops;
  values.CouponRemark = TplId.CouponRemark;
  values.IsAllowUserMore = TplId.IsAllowUserMore;


  values.TplId = TplId.TplId;

  //
  delete values.CusValidVay;
  delete values.PurchaseBet;
  // 初始化对象
  values.CouponTradeCfg = {
    ValidDate: values.ValidDate,
    ValidVay: values.ValidVay,
    BeginDate: values.BeginDate,
    EndDate: values.EndDate,
    StartNo: values.StartNo,
    EndNo: values.EndNo,
    RewardWray: values.RewardWray,
    RewardMoney: values.RewardWray === '1' ? values.RewardMoney / 100 : values.RewardMoney,
    NewVipReward: values.getNewUser || ''
  };
  values.CouponStatus = status;
  // 删除
  delete values.ValidDate;
  delete values.ValidVay;
  delete values.BeginDate;
  delete values.EndDate;
  delete values.StartNo;
  delete values.EndNo;
  delete values.RewardWray;
  delete values.RewardMoney;
  if (!values.OuterCode) delete values.OuterCode;
  if (!values.OuterId) delete values.OuterId;
  // 新建还是编辑
  if (pageStatus === sessProvidePlatformCouponDtlType[1]) {
    values.Id = detail.Id;
    values.CouponTradeCfg.Id = detail.CouponTradeCfg.Id;
  }
  // 发送请求
  const sta = await fetchProvideCouponAddSave(values);

  if (sta.ErrorCode === 0 && !sta.IsError) {
    Notify.success('新增成功');
    window.history.back();
  } else {
    // Notify.error(sta.ErrorMsg);
  }
};

onSave = (v) => {
  const { ezrdForm } = this.props;
  ezrdForm.setFormDirty(true);
  if (ezrdForm.isValid()) {
    this.submit(v);
  }
}

// 获取适用门店配置
initSys = async () => {
  const { provideStore } = this.props;
  const { Data } = await provideStore.fetchProvideOrderSysStatus();
  // 过滤全部通用和EZR线上商城
  const list = Data.filter((item) => {
    if (item.Id === -1 || item.Id === -2) {
      return false;
    }
    return true;
  });
  this.setState({ sysList: list });
}

// 自定义券模板的回调
cuoponTplCallBack = (couponType, data) => {
  const { ezrdForm } = this.props;
  if (data) {
    ezrdForm.setFieldsValue({ CouponName: data.CouponName });
    ezrdForm.setFieldsValue({ CouponValue: data.CouponValue });
    ezrdForm.setFieldsValue({ CouponPriceLimit: data.CouponPriceLimit });
    if (data.BeginDate && data.EndDate) {
      const date = {
        type: '2',
        data: ['', [data.BeginDate, data.EndDate]]
      };
      ezrdForm.setFieldsValue({ CusValidVay: date });
      this.setState({ dateDisabled: true });
    } else {
      this.setState({ dateDisabled: false });
    }
  }
}

// 上传图片接口
uploadImg = async (params) => {
  const { supplierStore } = this.props;
  const status = await supplierStore.fetchSupplierUploadImg(params);
  if (!status.IsError && status.Data) {
    return status.Data.pathfull;
  }
  this.setState({ loading: false });
  return null;
}

// 操作区域的渲染
initHandleBtn = (pageStatus) => {
  const { ezrdForm } = this.props;
  const { loading } = this.state;
  if (pageStatus === sessProvidePlatformCouponDtlType[0]) {
    return null;
  } if (pageStatus === sessProvidePlatformCouponDtlType[2]) {
    return (
      <div className={`${classNamePre}-group-btn`}>
        <Button
          type="primary"
          outline
          size="middle"
          onClick={event => this.onSave('0', event)}
        >
        暂存
        </Button>
      </div>
    );
  }
  return (
    <div className={`${classNamePre}-group-btn`}>
      <Button
        type="primary"
        outline
        size="middle"
        loading={loading}
        onClick={event => this.onSave('0', event)}
      >
        暂存
      </Button>
      {
        (ezrdForm.getFormValues() && ezrdForm.getFormValues().IsCanUserSpePrd)
          ? null
          : (
            <Button
              type="primary"
              size="middle"
              loading={loading}
              onClick={event => this.onSave('1', event)}
            >
              立即上架
            </Button>
          )
      }
    </div>
  );
}

render() {
  const { ezrdForm } = this.props;
  const {
    sysList, pageStatus, detail, pageDisabled, dateDisabled
  } = this.state;
  return (
    <div className={`${classNamePre}`}>
      <div>
        <Form horizontal>
          {/* 基础配置 */}
          <div className={`${classNamePre}-base`}>
            <div className={`${classNamePre}-base-title`}>
              基础配置
              <span />
            </div>
            <Field
              name="TplId"
              type="text"
              label="促销编号"
              customCallBack={this.cuoponTplCallBack}
              component={ConstFormPromotionCouponList}
              value={
                detail ? {
                  couponTpl: '',
                  TplId: '',
                  CouponValue: detail.CouponValue,
                  PromotionCode: detail.PromotionCode,
                  PromotionValidType: detail.PromotionValidType,
                  ApplyType: detail.ApplyType,
                  ApplyShops: detail.ApplyShops,
                  CouponType: 'CX',
                  CouponPriceLimit: detail.CouponPriceLimit,
                  CouponName: detail.CouponName,
                  BeginDate: detail.CouponTradeCfg.BeginDate || '',
                  EndDate: detail.CouponTradeCfg.EndDate || '',
                  IsAllowUserMore: detail.IsAllowUserMore,
                  CouponRemark: detail.CouponRemark
                } : ''
              }
              disabled={pageDisabled}
              required
              validations={{ required: true }}
              validationErrors={{ required: '请选择促销券' }}
            />
            <FormInputField
              name="CouponName"
              type="text"
              label="券名称"
              width={320}
              value={
                detail
                  ? detail.CouponName
                  : ''
              }
              disabled
              required
              placeholder="例如：满300减30，填写后展示给消费者"
            />
            <FormInputField
              name="CouponPriceLimit"
              type="text"
              label="使用门槛"
              width={320}
              value={
                detail
                  ? detail.CouponPriceLimit
                  : ''
              }
              disabled
              placeholder=""
            />
            <FormInputField
              name="CouponValue"
              type="text"
              label="券面值"
              width={320}
              value={
                detail
                  ? detail.CouponValue
                  : ''
              }
              disabled
              placeholder=""
            />
            <FormInputField
              name="SubTitle"
              type="text"
              label="副标题"
              width={320}
              showCount
              value={detail ? detail.SubTitle : ''}
              disabled={pageDisabled && detail ? detail.SubTitle : false}
              maxLength={18}
              placeholder="可写券使用限制，填写后展示给消费者"
            />
            <FormSelectField
              name="OutSysId"
              type="text"
              required
              label="适用系统"
              optionText="Name"
              optionValue="Id"
              data={sysList}
              value={detail ? detail.OutSysId : ''}
              disabled={pageDisabled}
              validations={{ required: true }}
              validationErrors={{ required: '请选择适用系统类型' }}
            />
            <Field
              name="WxQrCode"
              label={(
                <span>
                公众号带参二维码&nbsp;
                  <Pop
                    trigger="hover"
                    position="right-center"
                    content="二维码参数建议提供：1、标题 2、描述、3、icon 4、跳转地址（小程序和H5）"
                    centerArrow
                  >
                    <Icon
                      type="info"
                      ezrd
                    />
                  </Pop>
                </span>
              )}
              component={ConstFormUpload}
              tips="建议尺寸：800 x 800 像素"
              value={detail && detail.WxQrCode ? { src: detail.WxQrCode } : {}}
              disabled={!!(detail && detail.WxQrCode)}
            />
            <FormInputField
              name="Guide"
              type="textarea"
              width={320}
              label="使用说明"
              required
              value={detail ? detail.Guide : ''}
              disabled={pageDisabled}
              maxLength={512}
              showCount
              placeholder="用于向买家展示，如该优惠券不得与其他活动同时使用；节假日不得使用等，回车即可划分段落"
              validations={{ required: true }}
              validationErrors={{ required: '请填写使用说明' }}
            />
          </div>
          {/* 券交易配置 */}
          <div className={`${classNamePre}-configure`}>
            <div className={`${classNamePre}-configure-title`}>
              券交易配置
              <span />
            </div>
            <Field
              name="ValidDate"
              type="text"
              label={(
                <span>
                  采购有效期&nbsp;
                  <Pop
                    trigger="hover"
                    content="券采购后，采购方只允许在设置的时间段内发放优惠券"
                    centerArrow
                  >
                    <Icon
                      type="info"
                      ezrd
                    />
                  </Pop>
                </span>
                )}
              component={ConstFormDay}
              value={detail ? detail.CouponTradeCfg.ValidDate : ''}
              disabled={pageDisabled}
              startTxt="自采购日起"
              endTxt="天可发放"
              required
              validations={
                {
                  required(values, value) {
                    return !!(`${value}`);
                  },
                  min(values, value) {
                    if (value < 1) {
                      return false;
                    }
                    return true;
                  }
                }
              }
              validationErrors={{ required: '采购有效期不能为空', min: '采购有效期必须为大于0的整数' }}
            />
            <Field
              name="CusValidVay"
              type="text"
              label={(
                <span>
                  使用有效期&nbsp;
                  <Pop
                    trigger="hover"
                    content="消费者使用优惠券的有效期"
                    centerArrow
                  >
                    <Icon
                      type="info"
                      ezrd
                    />
                  </Pop>
                </span>
                )}
              component={ConstFormValidDate}
              value={
                detail
                  ? {
                    type: detail.CouponTradeCfg.ValidVay ? '1' : '2',
                    data: detail.CouponTradeCfg.ValidVay
                      ? [detail.CouponTradeCfg.ValidVay || '', ['', '']]
                      : ['', [detail.CouponTradeCfg.BeginDate || '', detail.CouponTradeCfg.EndDate || '']]
                  }
                  : {
                    type: '',
                    data: ['', ['', '']]
                  }
              }
              disabled={dateDisabled}
              startTxt="自领取日起"
              endTxt="天有效"
              min={1}
              required
              validations={{
                required(values, value) {
                  return !!value.type;
                },
                valueOne(values, value) {
                  if (value.type && value.type === '1' && !(`${value.data[0]}`)) {
                    return false;
                  }
                  return true;
                },
                valueTwo(values, value) {
                  if (value.type && value.type === '2' && (!value.data[1][0] || !value.data[1][1])) {
                    return false;
                  }
                  return true;
                }
              }}
              validationErrors={{ required: '使用有效期不能为空', valueOne: '自领取日不能为空', valueTwo: '请输入开始时间和结束时间' }}
            />
            <FormNumberInputField
              name="getNewUser"
              label="拉新奖励"
              type="text"
              value={detail ? detail.CouponTradeCfg.NewVipReward : ''}
              rearDesc={
                <span style={{ color: '#666' }}>人/Z币</span>
              }
              decimal={2}
              disabled={pageDisabled}
            />
            <Field
              name="PurchaseBet"
              type="text"
              label="起批量"
              component={ConstFormBetween}
              value={detail ? [detail.CouponTradeCfg.StartNo / 10000, detail.CouponTradeCfg.EndNo / 10000] : ''}
              disabled={pageDisabled}
              toFixLen={2}
              min1={0.01}
              centerTxt="至"
              endTxt="万张"
              tip="可采购的数量区间"
              required
              validations={
                {
                  required(values, value) {
                    return !!value[0] && !!value[1];
                  },
                  start(values, value) {
                    if (value[0] && value[1]) {
                      if (value[1] < value[0]) {
                        return false;
                      }
                      return true;
                    }
                    return true;
                  }
                }
              }
              validationErrors={{ required: '起批量不能为空', start: '起批量区间范围格式错误' }}
            />
            <FormRadioGroupField
              name="RewardWray"
              label="奖励方式"
              required
              value={detail ? `${detail.CouponTradeCfg.RewardWray}` : ''}
              disabled={pageDisabled}
              validations={{ required: true }}
              validationErrors={{ required: '请选择奖励方式' }}
            >
              <Radio value="0">按核销单张券奖励金额</Radio>
              <Radio value="1">按核销的订单实付金额比例提成</Radio>
            </FormRadioGroupField>
            {
              // RewardWray
              (ezrdForm.getFormValues() && ezrdForm.getFormValues().RewardWray && (ezrdForm.getFormValues().RewardWray === '1'))
                ? (
                  <Field
                    name="RewardMoney"
                    label="订单提成"
                    component={ConstFormDay}
                    value={detail ? detail.CouponTradeCfg.RewardMoney * 100 : ''}
                    disabled={pageDisabled}
                    startTxt=""
                    endTxt="%"
                    max={100}
                    desc="平台建议订单提成比列5%~20%，仅供参考"
                    required
                    validations={{ required: true }}
                    validationErrors={{ required: '订单提成不能为空' }}
                  />
                )
                : (
                  <Field
                    name="RewardMoney"
                    label="奖励金额"
                    component={ConstFormDay}
                    value={detail ? detail.CouponTradeCfg.RewardMoney : ''}
                    disabled={pageDisabled}
                    startTxt=""
                    toFixLen={2}
                    endTxt="元"
                    required
                    validations={{ required: true }}
                    validationErrors={{ required: '奖励金额不能为空' }}
                  />
                )
            }
          </div>
          {
            this.initHandleBtn(pageStatus)
          }
        </Form>
      </div>
    </div>
  );
}
}

const ProvidePormotionCouponAdd = createForm()(FieldForm);

export default ProvidePormotionCouponAdd;
