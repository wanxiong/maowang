import * as React from 'react';
import {
  Icon, Button, Table, Notify, Dialog
} from 'ezrd';
import { observer, inject } from 'mobx-react';
import moment from 'moment';
import { toJS } from 'mobx';
import PlatformCouponSearch from '../../components/base/platformCouponSearch';
import {
  couponDefaultPage,
  sessProvidePlatformcouponDtlKey,
  sessProvidePlatformcouponStatusKey,
  sessProvidePlatformCouponDtlType,
  sessToImportCenter,
  sessProvidePlatformcouponTypeKey
} from '../../components/base/constant';
import { PurchasePlatformCouponDialog } from '../../components/base/constDialog';
import { checkShopStatus } from '../../utils/commonApi';
import { goPage } from '../../utils/common';


const classNamePre = 'yiye-provide-coupon';

@inject('provideStore')
@observer
export default class ProvidePlatformCoupon extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      show: false,
      status: '', //  店铺状态
      remark: '', //  店铺被禁用的原因
      importId: '', // 导入商品ID
      ...couponDefaultPage
    };
    this.onHandleSearch = this.onHandleSearch.bind(this);
    this.onChange = this.onChange.bind(this);
  }

@checkShopStatus('provide')
  async componentDidMount() {
    this.initData();
    this.initShopStatus();
  }

// 点击查询的事件
onHandleSearch = (data, flag) => {
  if (flag !== 0) {
    this.setState({ current: 1 }, () => {
      this.initData({
        CouponGrpId: data.couponId,
        CouponName: data.couponName,
        CouponType: data.currentSelect
      });
    });
    return;
  }
  this.initData({
    CouponGrpId: data.couponId,
    CouponName: data.couponName,
    CouponType: data.currentSelect
  });
}

// 新增平台券
addCoupon = () => {
  const { history } = this.props;
  localStorage.removeItem(sessProvidePlatformcouponStatusKey);
  localStorage.removeItem(sessProvidePlatformcouponDtlKey);
  localStorage.removeItem(sessProvidePlatformcouponTypeKey);
  history.push('/Yiye/Provide/PlatformcouponAdd');
}

// 分页的回调
onChange = (data) => {
  const { pageSize, current } = this.state;
  this.setState({
    pageSize: data.pageSize || pageSize,
    current: data.current || current
  }, () => {
    this.searchDom.onSearch(0);
  });
}

initData = (params = {}) => {
  const { provideStore } = this.props;
  const { pageSize, current } = this.state;
  provideStore.fetchProvidePlatformCouponList({
    PageSize: pageSize,
    PageIndex: current,
    ...params
  });
}

// 上架下架的接口
onShelf = async (item, index) => {
  const { provideStore } = this.props;
  const params = toJS(item);
  // 需要判断是否单品券并且没有导入商品的时候，需要拦截显示提示框
  if (params.IsCanUserSpePrd && !params.IsImported && index === '1') {
    Dialog.openDialog({
      dialogId: 1,
      title: '温馨提示',
      children: <div>单品券还未添加指定商品，请添加后再上架。</div>,
      footer: <Button onClick={() => Dialog.closeDialog(1)}>确定</Button>,
      onClose() {
        // console.log('outer dialog closed');
      }
    });
    return;
  }
  params.couponStatus = index;
  params.IsDisable = false;
  const status = await provideStore.fetchProvidePlatformCouponStatus(params);
  if (status.ErrorCode === 0 && !status.IsError) {
    Notify.success(index === '1' ? '上架成功' : '下架成功');
  } else {
    // Notify.error(status.ErrorMsg);
  }
  this.searchDom.onSearch(0);
}

// 导入商品
importGoods = (id) => {
  this.setState({ show: true, importId: id });
}

//
onImportConfirm = (index, valueType) => {
  const { importId } = this.state;
  const { history } = this.props;
  this.setState({ show: false });
  if (index === '0') {
    localStorage.setItem(sessToImportCenter, JSON.stringify({
      couponGrpId: importId,
      ProType: 0,
      couponProIsExclude: valueType === '0'
    }));
  } else {
    localStorage.setItem(sessToImportCenter, JSON.stringify({
      couponGrpId: importId,
      ProType: 1,
      couponProIsExclude: valueType === '0'
    }));
  }
  history.push('/Yiye/ImportGoods');
}

//
onImportClose = () => {
  this.setState({ show: false });
}

// 获取店铺状态接口
initShopStatus = async () => {
  const { provideStore } = this.props;
  const { Data } = await provideStore.fetchProvideOrderShopStatus({});
  if (Data.Status === 1 || Data.Status === -2) {
    //  待审核-审核未通过
    goPage('/Yiye/Provide/Page/Examine');
  } else if (Data.Status === 2) {
    //  营业中
  } else if (Data.Status === 0) {
    //  商户初始化
    goPage('/Yiye/Provide/Page/Apply');
  } else if (Data.Status === -1) {
    this.setState({
      status: -1
    });
    //  品牌歇业
  } else if (Data.Status === -3) {
    //  平台禁用
    this.setState({
      status: -3,
      remark: Data.Remark
    });
  }
}

// 查看详情接口
goDetail = (json) => {
  const { history } = this.props;
  localStorage.setItem(sessProvidePlatformcouponDtlKey, JSON.stringify(toJS(json)));
  localStorage.setItem(sessProvidePlatformcouponStatusKey, sessProvidePlatformCouponDtlType[0]);
  localStorage.setItem(sessProvidePlatformcouponTypeKey, json.CouponType);
  history.push('/Yiye/Provide/PlatformcouponAdd');
}

//
lookImport = (data) => {
  const { history } = this.props;
  this.setState({ show: false });
  localStorage.setItem(sessToImportCenter, JSON.stringify({
    couponGrpId: data.Id,
    ProType: data.CouponProType,
    couponProIsExclude: data.couponProIsExclude
  }));
  history.push('/Yiye/ImportGoods');
}

// 编辑
edit = (json) => {
  const { history } = this.props;
  localStorage.setItem(sessProvidePlatformcouponDtlKey, JSON.stringify(toJS(json)));
  localStorage.setItem(sessProvidePlatformcouponStatusKey, sessProvidePlatformCouponDtlType[1]);
  localStorage.setItem(sessProvidePlatformcouponTypeKey, json.CouponType);
  history.push('/Yiye/Provide/PlatformcouponAdd');
}

// 复制
copy = (json) => {
  const { history } = this.props;
  localStorage.setItem(sessProvidePlatformcouponDtlKey, JSON.stringify(toJS(json)));
  localStorage.setItem(sessProvidePlatformcouponStatusKey, sessProvidePlatformCouponDtlType[2]);
  localStorage.setItem(sessProvidePlatformcouponTypeKey, json.CouponType);
  history.push('/Yiye/Provide/PlatformcouponAdd');
}

// 导入导出渲染
initImportOrExport = (data) => {
  if (data.IsCanUserSpePrd) {
    if (data.IsImported) {
      return (
        <span
          type="primary"
          role="button"
          tabIndex="0"
          className="yiye-outline btn-default-color"
          onClick={event => this.lookImport(data, event)}
        >
        查看导入
        </span>
      );
    }
    return (
      <span
        type="primary"
        role="button"
        tabIndex="0"
        className="yiye-outline btn-default-color"
        onClick={event => this.importGoods(data.Id, event)}
      >
      导入商品
      </span>
    );
  }
  return null;
}

// 初始化店铺状态
initShopStatusTpl = (status, remark) => {
  if (status === -3) {
    return (
      <React.Fragment>
        <span>店铺已被平台禁用</span>
        <div>{remark}</div>
      </React.Fragment>
    );
  } if (status === -1) {
    return (
      <React.Fragment>
        <span>店铺已歇业</span>
        <div>你已下架店铺，所有上架中的平台券不在交易市场展示，无法被采购，但不影响已经采购的订单。</div>
      </React.Fragment>
    );
  }
  return null;
}

render() {
  const { provideStore: { providePlatformCouponList } } = this.props;
  const { TotalRowsCount, PagedList } = providePlatformCouponList;
  const {
    status, remark, show, current, pageSizeList
  } = this.state;
  const dataList = PagedList;
  const columns = [
    {
      title: '券ID',
      width: '100px',
      bodyRender: data => <div>{data.Id}</div>
    },
    {
      title: '创建时间',
      bodyRender: data => (
        moment(data.CreateDate).format('YYYY-MM-DD HH:mm:ss')
      )
    },
    {
      title: '券类型',
      width: '100px',
      name: 'CouponTypeName'
    },
    {
      title: '券名称',
      bodyRender: data => (
        <div>
          {data.CouponName}
          {
              data.IsCanUserSpePrd
                ? (<span className="yiye-provide-coupon-pro-coupon-name">单品券</span>)
                : null
            }
        </div>
      )
    },
    {
      title: '适用系统',
      name: 'OutSysName',
      width: '120px'
    },
    {
      title: '状态',
      width: '120px',
      bodyRender: (data) => {
        if (data.CouponStatus === 0) {
          return (
            <div><span>设计中</span></div>
          );
        } if (data.CouponStatus === 1) {
          return (
            <div><span>已上架</span></div>
          );
        }
        return (
          <div><span>已下架</span></div>
        );
      }
    },
    {
      title: '操作',
      bodyRender: (data) => {
        if (data.CouponStatus === 0) {
          return (
            <div className="yiye-provide-coupon-group-btn">
              <span
                type="primary"
                role="button"
                tabIndex="0"
                className="yiye-outline btn-default-color"
                onClick={event => this.edit(data, event)}
              >
              编辑
              </span>
              <span
                type="primary"
                role="button"
                tabIndex="0"
                className="yiye-outline btn-default-color"
                onClick={event => this.onShelf(data, '1', event)}
              >
              上架
              </span>
              <span
                type="primary"
                role="button"
                tabIndex="0"
                className="yiye-outline btn-default-color"
                onClick={event => this.copy(data, event)}
              >
              复制
              </span>
              {
                this.initImportOrExport(data)
              }
            </div>
          );
        } if (data.CouponStatus === 1) {
          return (
            <div className="yiye-provide-coupon-group-btn">
              <span
                type="primary"
                role="button"
                tabIndex="0"
                className="yiye-outline btn-default-color"
                onClick={event => this.goDetail(data, event)}
              >
              查看
              </span>
              <span
                type="primary"
                role="button"
                tabIndex="0"
                className="yiye-outline btn-default-color"
                onClick={event => this.onShelf(data, '2', event)}
              >
              下架
              </span>
              <span
                type="primary"
                role="button"
                tabIndex="0"
                className="yiye-outline btn-default-color"
                onClick={event => this.copy(data, event)}
              >
              复制
              </span>
              {
                this.initImportOrExport(data)
              }
            </div>
          );
        }
        return (
          <div className="yiye-provide-coupon-group-btn">
            <span
              type="primary"
              role="button"
              tabIndex="0"
              className="yiye-outline btn-default-color"
              onClick={event => this.goDetail(data, event)}
            >
              查看
            </span>
            <span
              type="primary"
              role="button"
              tabIndex="0"
              className="yiye-outline btn-default-color"
              onClick={event => this.onShelf(data, '1', event)}
            >
              上架
            </span>
            <span
              type="primary"
              role="button"
              tabIndex="0"
              className="yiye-outline btn-default-color"
              onClick={event => this.copy(data, event)}
            >
              复制
            </span>
            {
              this.initImportOrExport(data)
            }
          </div>
        );
      }
    }
  ];
  return (
    <div className={`${classNamePre}`}>
      {/* 店铺是否歇业 */}
      {
        (status === -1 || status === -3)
          ? (
            <div className={`${classNamePre}-shop`}>
              <div className={`${classNamePre}-shop-status`}>
                <Icon
                  type="error-circle-o"
                  className={`${classNamePre}-shop-status-icon`}
                />
                <div>
                  {
                    this.initShopStatusTpl(status, remark)
                  }
                </div>
              </div>
            </div>
          )
          : null
      }
      {/* 平台券检索区域 */}
      <div>
        <PlatformCouponSearch
          onSearch={this.onHandleSearch}
          brandShow={false}
          ref={(ref) => { this.searchDom = ref; }}
        />
      </div>
      {/* 新建平台券 */}
      <div className={`${classNamePre}-add-btn`}>
        <div>
          <Button
            type="primary"
            size="middle"
            onClick={this.addCoupon}
          >
          新建平台券
          </Button>
        </div>
        <span>推荐适应系统为“全部通用”、“EZR商城”，只有上架的券才会在市场展示</span>
      </div>
      {/* table展示区域 */}
      <div className={`${classNamePre}-pro`}>
        <Table
          columns={columns}
          datasets={dataList}
          rowKey="id"
          pageInfo={{
            totalItem: TotalRowsCount,
            current,
            pageSize: pageSizeList
          }}
          onChange={this.onChange}
        />
      </div>
      {/* 弹框 */}
      <PurchasePlatformCouponDialog
        show={show}
        onClose={this.onImportClose}
        onConfirm={this.onImportConfirm}
      />
    </div>
  );
}
}
