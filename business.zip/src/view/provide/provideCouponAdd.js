import * as React from 'react';
import {
  Tabs, Breadcrumb
} from 'ezrd';
import { observer, inject } from 'mobx-react';

import { checkShopStatus } from '../../utils/commonApi';
import ProvidePlatformCouponAdd from './providePlatformCouponAdd';
import ProvidePromotionCouponAdd from './providePromotionCouponAdd';
import { sessProvidePlatformcouponTypeKey, sessProvidePlatformcouponDtlKey } from '../../components/base/constant';
// 新建

const classNamePre = 'yiye-provide-couponadd';
@inject('provideStore')
// 注入
@observer
class ProvideCouponAdd extends React.Component {
  constructor(prop) {
    super(prop);
    const couponType = localStorage.getItem(sessProvidePlatformcouponTypeKey);
    let detail = '';
    try {
      detail = JSON.parse(localStorage.getItem(sessProvidePlatformcouponDtlKey));
    } catch (error) {
    //
    }
    this.state = {
      activeId: couponType === 'CX' ? '2' : '1',
      breadList: [
        { name: '平台券', href: "#/Yiye/Provide/Platformcoupon" },
        { name: couponType === 'CX' ? '促销券详情' : '平台券详情', strong: true }
      ],
      tabs: [{
        title: '平台券',
        key: '1',
        disabled: !detail
          ? false
          : couponType === 'CX'

      }, {
        title: '促销券',
        key: '2',
        disabled: !detail
          ? false
          : couponType !== 'CX'
      }]
    };
  }

@checkShopStatus('provide')
  componentWillMount() {
  }

onTabChange = (id) => {
  this.setState({
    activeId: id
  });
}

tpl = () => {
  const { activeId } = this.state;
  if (activeId === '1') {
    return (
      <ProvidePlatformCouponAdd />
    );
  }
  return (
    <ProvidePromotionCouponAdd />
  );
}

render() {
  const {
    activeId, tabs, breadList
  } = this.state;
  return (
    <div>
      <div>
        <div className={`${classNamePre}-bread yiye-global-bread`}>
          <Breadcrumb breads={breadList} />
        </div>
        {/** tab 切换区域 */}
        <div>
          <Tabs
            className={`${classNamePre}-tabs`}
            activeId={activeId}
            onChange={this.onTabChange}
            tabs={tabs}
            borderRadius
          />
          {
            this.tpl()
          }
        </div>
      </div>
    </div>
  );
}
}

export default ProvideCouponAdd;
