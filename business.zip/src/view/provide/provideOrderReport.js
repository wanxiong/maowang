import * as React from 'react';
import {
  Pagination,
  Dialog,
  Button,
  Input
} from 'ezrd';
import { observer, inject } from 'mobx-react';
import moment from 'moment';
import { couponDefaultPage } from '../../components/base/constant';
import { checkShopStatus } from '../../utils/commonApi';
import OrderReportCount from '../../components/base/orderReportCount';
import OrderReportSearch from '../../components/base/orderReportSearch';
import { goPage, division } from '../../utils/common';

const classNamePre = 'yiye-provide-order-report';
// 注入
@inject('provideStore')
@observer
export default class ProvideOrderReport extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      visible: false, // 弹窗显示
      loading: false, // 弹窗按钮loading
      TaskName: '', // 弹窗输入框名称
      json: {}, // 新拉新明细数据
      isDownflag: false, // 核销明细和拉新明细
      ...couponDefaultPage
    };
  }

  @checkShopStatus('provide')
  async componentDidMount() {
    this.initData({});
  }

// initData
initData = (params = {}) => {
  const { provideStore } = this.props;
  const { pageSize, current } = this.state;
  provideStore.fetchProvideOrderReportList({
    PageIndex: current,
    PageSize: pageSize,
    ...params
  });
}

// 点击查询的事件
onHandleSearch = (data, flag) => {
  if (flag !== 0) {
    this.setState({ current: 1 }, () => {
      this.initData({
        CouponGrpId: data.couponId,
        CouponGrpName: data.couponName,
        BeginDate: data.rangeValue[0] ? data.rangeValue[0] : '',
        EndDate: data.rangeValue[1] ? data.rangeValue[1] : ''
      });
    });
    return;
  }
  this.initData({
    CouponGrpId: data.couponId,
    CouponGrpName: data.couponName,
    BeginDate: data.rangeValue[0] ? data.rangeValue[0] : '',
    EndDate: data.rangeValue[1] ? data.rangeValue[1] : ''
  });
}

// 导出事件
onHandleExport = () => {
  // const { provideStore } = this.props;
  // let status = await provideStore.fetchProvideOrderList({});
  // if (!status.isError) {
  //   Notify.success('导出文件成功');
  //   window.location.href = status.Data.downLoadLink;
  // }
}

// 每页大小的回调
onPageSizeChange = (pageSize) => {
  this.setState({
    pageSize
  }, () => {
    this.searchDom.onSearch(0);
  });
};

// 分页的回调
onChange = (data) => {
  const { current } = this.state;
  this.setState({
    current: data || current
  }, () => {
    this.searchDom.onSearch(0);
  });
}

// onChange = (data) => {
//   const { pageSize, current } = this.state;
//   this.setState({
//     pageSize: data.pageSize || pageSize,
//     current: data.current || current
//   }, () => {
//     this.searchDom.onSearch(0);
//   });
// }

// 查看明细
// goDetail = () => {
//   goPage('/Yiye/Provide/ProvideOrderReportDetail');
// }

goDownload = (OrderId) => {
  this.setState({
    visible: true, OrderId, TaskName: `${moment().format('YYYY-MM-DD')}核销明细`, isDownflag: true
  });
}

goNewDownload = (item) => {
  this.setState({
    visible: true, json: item, TaskName: `${moment().format('YYYY-MM-DD')}拉新明细`, isDownflag: false
  });
}

// 关闭弹窗
closeDialog = () => {
  this.setState({
    visible: false
  });
}

// 弹窗确认
confirm = async () => {
  const { provideStore } = this.props;
  const {
    TaskName, OrderId, isDownflag
  } = this.state;
  this.setState({ loading: true });
  if (isDownflag) {
    const res = await provideStore.fetchDownloadProConsumeDtl({ TaskName, Querys: { OrderId } });
    this.setState({ visible: false, loading: false, TaskName: `${moment().format('YYYY-MM-DD')}明细` });
    if (!res.IsError) {
      goPage('/Yiye/Download');
    }
  } else {
    this.confirmNew();
  }
}

confirmNew = async () => {
  const { provideStore, history } = this.props;
  const { TaskName, json } = this.state;
  this.setState({ loading: true });
  const res = await provideStore.fetchDownloadProConsumeNewDtl({
    TaskName,
    type: 9,
    Querys: {
      OrderId: json.PurchaseOrderId,
      BegDate: json.CouponBeginDate,
      EndDate: json.CouponEndDate
    }
  });
  this.setState({ visible: false, loading: false, TaskName: `${moment().format('YYYY-MM-DD')}明细` });
  if (!res.IsError) {
    history.push('/Yiye/Download');
  }
}

// 输入框输入
onChangeInput = (type, e) => {
  this.setState({
    [type]: e.target.value
  });
}

// title列表组件需要函数
titleFun = (key, number, fixed = 0, pass = false) => {
  const { provideStore } = this.props;
  const { provideOrderReportList: { Data } } = provideStore;
  if (!Data[key] && Data[key] !== 0) {
    return '';
  }
  if (pass) {
    return Data[key];
  }
  if (number) {
    if (!fixed) {
      return division(Data[key], number);
    }
    return division(Data[key], number).toFixed(fixed);
  }
  return Data[key].toFixed(fixed);
}

render() {
  const {
    current, pageSizeList, visible, loading, TaskName
  } = this.state;
  const { provideStore } = this.props;
  const { provideOrderReportList: { TotalRowsCount, PagedList } } = provideStore;
  return (
    <div className={`${classNamePre}`}>
      {/* 全部数据总和 */}
      <OrderReportCount
        titleList={['供货量(万)', '发放量(万)', '核销量(百)', '核销率', '拉新(人)', '活动收益(万)', '采购方佣金(元)', '平台手续费(元)']}
        keyList={[
          this.titleFun('TotalProvideQty', 10000),
          this.titleFun('TotalUseQty', 10000),
          this.titleFun('TotalConsumeQty', 100),
          this.titleFun('TotalConsumeRate', 0, 0, true),
          this.titleFun('TotalNewVipQty', 0, 0, true),
          this.titleFun('TotalActAmount', 10000),
          this.titleFun('TotalPurchaseAmount', 0, 2),
          this.titleFun('TotalProvidePlatformAmount', 0, 2)
        ]}
      />
      <OrderReportSearch
        onSearch={this.onHandleSearch}
        onExport={this.onHandleExport}
        exportText="导出供货报表"
        type="provideStore"
        typeName="流量付费报表"
        brandShow={false}
        defaultTime={[`${new Date().getFullYear()}-01-01`, `${new Date().getFullYear()}-12-31`]}
        // ref={(ref) => { this.searchDom = ref; }}
        getRef={(ref) => { this.searchDom = ref; }}
      />
      {/* */}
      <div className={`${classNamePre}-pro`}>
        <div className={`${classNamePre}-pro-head`}>
          <span>采购品牌</span>
          <span>采购量(万)</span>
          <span>发放量(万)</span>
          <span>领取数(人)</span>
          <span>领取数(张)</span>
          <span>核销量(百)</span>
          <span>核销率</span>
          <span>拉新(人)</span>
          <span>冻结Z币</span>
          <span>采购方佣金</span>
          <span>平台手续费</span>
          <span>操作</span>
        </div>
        {
          PagedList.map(item => (
            <div
              className={`${classNamePre}-pro-item`}
              key={item.Id}
            >
              <div className={`${classNamePre}-pro-item-title`}>
                <div>
                    采购时间：
                  {moment(item.BuyTime).format('YYYY-MM-DD HH:mm')}
                  ，采购单号：
                  {item.PurchaseNo}
                  {' '}
                  ，【
                  {item.CouponType}
                  】
                  {item.CouponName}
                  （ID：
                  {item.PlatformCouponGrpId}
                  ），活动收益：
                  {division(item.ActAmount, 10000)}
                  万
                </div>
              </div>
              <ul>
                <li>{item.PurchaseMchName}</li>
                <li>{division(item.PurchaseQty, 10000)}</li>
                <li>{division(item.UsedQty, 10000)}</li>
                <li>{item.ReceiveCouponPQty}</li>
                <li>{item.ReceiveCouponQty}</li>
                <li>{division(item.ConsumeQty, 100)}</li>
                <li>{item.ConsumeRate}</li>
                <li>{item.NewVipQty}</li>
                <li>{item.FreezeCosts.toFixed(2)}</li>
                <li>{item.PurchaseAmount.toFixed(2)}</li>
                <li>{item.ProvidePlatformAmount.toFixed(2)}</li>
                <li>
                  {
                    // <span
                    //   role="button"
                    //   tabIndex="0"
                    //   className="yiye-outline btn-default-color yiye-cursor"
                    //   onClick={() => this.goDetail(item)}
                    // >
                    // 明细
                    // </span>
                  }
                  <span
                    role="button"
                    tabIndex="0"
                    className="yiye-outline btn-default-color yiye-cursor"
                    onClick={() => this.goDownload(item.PurchaseOrderId)}
                  >
                  核销明细
                  </span>
                  <span
                    role="button"
                    tabIndex="0"
                    className="yiye-outline btn-default-color yiye-cursor"
                    onClick={() => this.goNewDownload(item)}
                  >
                  拉新明细
                  </span>
                </li>
              </ul>
            </div>
          ))
        }
        {/* 分页区域 */}
        <Pagination
          current={current}
          totalItem={TotalRowsCount}
          onChange={this.onChange}
          pageSize={pageSizeList}
          onPageSizeChange={this.onPageSizeChange}
        />
        {/* 导出明细名称弹窗 */}
        <Dialog
          title="导出数据的文件名称"
          visible={visible}
          onClose={() => this.closeDialog()}
          style={{ width: '600px' }}
          maskClosable={false}
          footer={(
            <div>
              <Button
                outline
                loading={loading}
                onClick={() => this.closeDialog()}
              >
                  取消
              </Button>
              <Button
                loading={loading}
                onClick={() => this.confirm()}
              >
                  确定
              </Button>
            </div>
            )}
        >
          <Input
            signleBorder
            placeholder="请输入导出数据的文件名称"
            showClear
            maxLength={30}
            width="100%"
            value={TaskName}
            onChange={event => this.onChangeInput('TaskName', event)}
          />
        </Dialog>
      </div>
    </div>
  );
}
}
