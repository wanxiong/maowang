import * as React from 'react';
import {
  Button
} from 'ezrd';
import { withRouter } from 'react-router-dom';
// 新建

const classNamePre = 'yiye-provide-page-apply';

@withRouter
export default class ProvidePageApply extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      // checked: false
    };
  }

  // onChange = (e) => {
  //   this.setState({ checked: e.target.checked });
  // }

// 立即入住的点击事件
onJoin = () => {
  const { history } = this.props;
  // if(!this.state.checked) {
  //   Notify.error('请选择已阅读并同意')
  //   return
  // }
  // this.props.history.push('/account/accountinfo')
  history.push('/Yiye/Account/Accountinfo');
}

render() {
  return (
    <div className={`${classNamePre}`}>
      <div>
        <div className={`${classNamePre}-title`}>优惠券交易市场</div>
        <div className={`${classNamePre}-txt`}>为你达更多消费者，让生意有更多可能！</div>
        <div className={`${classNamePre}-txt`}>驿业平台致力于为优质品牌商提供优惠券流量互换解决方案，品牌商通过与众多优质渠道商建立合作关系，打通多场景流量渠道，触达数亿目标消费者，快速实现优惠券流通和销售增长。</div>
        <div className={`${classNamePre}-title-2`}>如果您想</div>
        <div className={`${classNamePre}-pro`}>
          <div>
            <img
              alt="增加商品销量,提高业绩增长"
              src="https://static.ezrpro.com/assets/icon/petslogo/icon-1.png"
            />
          </div>
          <div>
            <img
              alt="建立分销渠道,丰富销售机会"
              src="https://static.ezrpro.com/assets/icon/petslogo/icon-2.png"
            />
          </div>
          <div>
            <img
              alt="提高运营效率,降低获客成本"
              src="https://static.ezrpro.com/assets/icon/petslogo/icon-3.png"
            />
          </div>
        </div>
        <div className={`${classNamePre}-last`}>
          <div className={`${classNamePre}-last-title`}>
            期待您的加入，共同让零售变得更简单
          </div>
          {/*
            <div className={`${classNamePre}-last-agreement`}>
              <Checkbox className={`${classNamePre}-last-agreement-input`} checked={this.state.checked} onChange={this.onChange}></Checkbox>
              我已阅读并同意<span>《使用协议》</span><span>《隐私政策》</span>
            </div>
            */}
          <div>
            <Button
              type="primary"
              size="large"
              onClick={this.onJoin}
            >
            立即入驻
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
}
