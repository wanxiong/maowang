import * as React from 'react';
import {
  Pop, Icon, Form, Radio, Button, Switch, Notify
} from 'ezrd';
import { observer, inject } from 'mobx-react';
import { sessProvidePlatformcouponStatusKey, sessProvidePlatformCouponDtlType, sessProvidePlatformcouponDtlKey } from '../../components/base/constant';
import {
  ConstFormCouponList, ConstFormDay, ConstFormBetween, ConstFormValidDate, ConstFormDayCheckBox, ConstFormSelect
} from '../../components/base/constForm';
import { multiplication, isEmptyTime } from '../../utils/common';
import { checkShopStatus } from '../../utils/commonApi';
import { ConstFormUpload } from '../../components/base/constFormImage';
// 新建

const {
  Field, FormInputField, FormSelectField, createForm, FormCheckboxField, FormRadioGroupField, FormNumberInputField
} = Form;

const classNamePre = 'yiye-provide-couponadd';
@inject('provideStore')
@inject('supplierStore')
// 注入
@observer
class FieldForm extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      sysList: [], // 适用门店
      detail: '',
      pageStatus: '',
      openSwitch: false, // 是否打开高级配置
      switchDisab: false,
      pageDisabled: false,
      loading: false,
      isCustomCouponFlag: false // 是否礼品或者邀请券，如果是需要隐藏底部订单金额比例提成
    };
    this.submit = this.submit.bind(this);
  }

  @checkShopStatus('provide')
  componentWillMount() {
    const pageStatus = localStorage.getItem(sessProvidePlatformcouponStatusKey);
    let detail = '';
    let switchDisab = false;
    let openSwitch = false;
    let pageDisabled = false;
    let isCustomCouponFlag = false;
    // 只能查看的话，禁止编辑
    if (pageStatus === sessProvidePlatformCouponDtlType[0]) {
      pageDisabled = true;
      switchDisab = true;
    }
    try {
      detail = JSON.parse(localStorage.getItem(sessProvidePlatformcouponDtlKey));
      if (!detail.ConsumeShops && detail.IsHasConsumeShops) { // 全部核销门店
        detail.ConsumeShops = {
          ShopType: detail.ConsumeApplyType === 'BD' ? 'SH' : detail.ConsumeApplyType,
          ShopListId: []
        };
      }
    } catch (error) {
      //
    }
    // 额外判断高级配置是否处于编辑状态--- 查看状态
    if (detail) {
      if (detail.CouponType === 'LP' || detail.CouponType === 'YQ') { // 特殊券处理
        isCustomCouponFlag = true;
      }
      if (detail.OuterCode
        || detail.OuterId
        || detail.IsAllowUserMore
        || detail.IsAllowBuyMore
        || detail.AllowMaxBuyNum
        || detail.IsAllowPositive
        || detail.DiscountLimit
        || detail.IsHasConsumeShops) {
        openSwitch = true;
      }
    }
    this.setState({
      detail, pageStatus, switchDisab, openSwitch, pageDisabled, isCustomCouponFlag
    });
  }

  componentDidMount() {
    this.initSys();
  }

// 基本输入框内容变更
onChangeInput = (type, e) => {
  this.setState({
    [type]: e.target.value
  });
}

submit = async (status) => {
  const { provideStore } = this.props;
  const { fetchProvideCouponAddSave } = provideStore;
  const { pageStatus, detail, openSwitch } = this.state;
  const { ezrdForm } = this.props;
  const values = ezrdForm.getFormValues();
  if (values.TplId.CouponType !== 'DJ' && (values.OutSysId === -1 || values.OutSysId === -2)) {
    Notify.error("仅代金券支持选择适应系统为：全部通用、EZR线上商城！");
    return;
  }
  this.setState({ loading: true });
  // 先上传图片
  // const imgObj = values.BrandLog;
  let url = '';
  if (values.WxQrCode.data && values.WxQrCode.data[0].file) {
    url = await this.uploadImg({ file: values.WxQrCode.data[0].file });
    if (!url) return;
  } else {
    url = values.WxQrCode.src;
  }
  values.WxQrCode = url;
  // 拦截一波券模板和适用类型的校验
  const { PurchaseBet } = values;
  const { CusValidVay } = values;
  const { TplId } = values;
  if (openSwitch) { // 匹配了高级配置
    const { IsHasConsumeShops } = values;
    const { DiscountLimit } = values;
    const { AllowMaxBuyNum } = values;
    if (IsHasConsumeShops.custom) { // 是否来自编辑和复制
      values.ConsumeShops = {
        ShopListId: IsHasConsumeShops.data,
        ShopType: IsHasConsumeShops.type
      };
      values.IsHasConsumeShops = true;
    } else if (IsHasConsumeShops && IsHasConsumeShops.type) {
      // 核销门店  // 正常的新建
      values.IsHasConsumeShops = true;
      const arr = [];
      if (IsHasConsumeShops.data && IsHasConsumeShops.data.type === 'SH') {
        for (let i = 0; i < IsHasConsumeShops.data.shopArr.length; i++) {
          arr.push(IsHasConsumeShops.data.shopArr[i].value);
        }
      } else if (IsHasConsumeShops.data && IsHasConsumeShops.data.type !== 'SH') {
        for (let i = 0; i < IsHasConsumeShops.data.groupArr.length; i++) {
          arr.push(IsHasConsumeShops.data.groupArr[i].value);
        }
      }
      values.ConsumeShops = {
        ShopListId: arr,
        ShopType: IsHasConsumeShops.data ? IsHasConsumeShops.data.type : 'SH'
      };
    } else {
      values.IsHasConsumeShops = false;
      values.ConsumeShops = {
        ShopListId: [],
        ShopType: 'SH'
      };
    }
    // 折扣限制处理
    if (DiscountLimit.type) {
      values.DiscountLimit = DiscountLimit.data;
    } else {
      delete values.DiscountLimit;
    }
    // 购买件数处理
    if (AllowMaxBuyNum.type) {
      values.IsAllowBuyMore = AllowMaxBuyNum.type;
      values.AllowMaxBuyNum = AllowMaxBuyNum.data;
    } else {
      values.IsAllowBuyMore = false;
      delete values.AllowMaxBuyNum;
    }
  }
  // 其他字段处理
  // 起批量
  if (PurchaseBet && PurchaseBet.length) {
    values.StartNo = multiplication(PurchaseBet[0], 10000);
    values.EndNo = multiplication(PurchaseBet[1], 10000);
  }
  // 使用有效期
  if (CusValidVay && CusValidVay.type === '1') {
    const [one] = CusValidVay.data;
    values.ValidVay = one;
  } else if (CusValidVay && CusValidVay.type === '2') {
    const [, two] = CusValidVay.data;
    const [twoFirst, twoScend] = two;
    values.BeginDate = twoFirst;
    values.EndDate = twoScend;
  }
  //
  values.TplName = TplId.couponTpl;
  values.CouponType = TplId.CouponType;
  values.CouponValue = TplId.CouponValue;
  values.CouponPriceLimit = TplId.CouponPriceLimit || '';
  values.TplId = TplId.TplId;

  //
  delete values.CusValidVay;
  delete values.PurchaseBet;
  // 初始化对象
  values.CouponTradeCfg = {
    ValidDate: values.ValidDate,
    ValidVay: values.ValidVay,
    BeginDate: values.BeginDate,
    EndDate: values.EndDate,
    StartNo: values.StartNo,
    EndNo: values.EndNo,
    RewardWray: values.RewardWray,
    RewardMoney: values.RewardWray === '1' ? values.RewardMoney / 100 : values.RewardMoney,
    NewVipReward: values.getNewUser || ''
  };
  values.CouponStatus = status;
  // 删除
  delete values.ValidDate;
  delete values.ValidVay;
  delete values.BeginDate;
  delete values.EndDate;
  delete values.StartNo;
  delete values.EndNo;
  delete values.RewardWray;
  delete values.RewardMoney;
  if (!values.OuterCode) delete values.OuterCode;
  if (!values.OuterId) delete values.OuterId;
  // 新建还是编辑
  if (pageStatus === sessProvidePlatformCouponDtlType[1]) {
    values.Id = detail.Id;
    values.CouponTradeCfg.Id = detail.CouponTradeCfg.Id;
  }
  // 发送请求
  const sta = await fetchProvideCouponAddSave(values);

  if (sta.ErrorCode === 0 && !sta.IsError) {
    Notify.success('新增成功');
    window.history.back();
  } else {
    // Notify.error(sta.ErrorMsg);
  }
  this.setState({ loading: false });
};

onSave = (v) => {
  const { ezrdForm } = this.props;
  ezrdForm.setFormDirty(true);
  if (ezrdForm.isValid()) {
    this.submit(v);
  }
}

// 高级配置
onChangeSwitch = (checked) => {
  this.setState({ openSwitch: checked });
}

// 获取适用门店配置
initSys = async () => {
  const { provideStore } = this.props;
  const { Data } = await provideStore.fetchProvideOrderSysStatus();
  this.setState({ sysList: Data });
}

// 自定义券模板的回调
cuoponTplCallBack = (couponType) => {
  const { ezrdForm } = this.props;
  if (couponType === 'LP' || couponType === 'YQ') {
    this.setState({ isCustomCouponFlag: true });
    if (ezrdForm.getFormValues() && ezrdForm.getFormValues().RewardWray === '1') {
      ezrdForm.setFieldsValue({ RewardWray: '0' });
    }
  } else {
    this.setState({ isCustomCouponFlag: false });
  }
}

// 上传图片接口
uploadImg = async (params) => {
  const { supplierStore } = this.props;
  const status = await supplierStore.fetchSupplierUploadImg(params);
  if (!status.IsError && status.Data) {
    return status.Data.pathfull;
  }
  this.setState({ loading: false });
  return null;
}

// 操作区域的渲染
initHandleBtn = (pageStatus) => {
  const { ezrdForm } = this.props;
  const { loading } = this.state;
  if (pageStatus === sessProvidePlatformCouponDtlType[0]) {
    return null;
  } if (pageStatus === sessProvidePlatformCouponDtlType[2]) {
    return (
      <div className={`${classNamePre}-group-btn`}>
        <Button
          type="primary"
          outline
          size="middle"
          onClick={event => this.onSave('0', event)}
        >
        暂存
        </Button>
      </div>
    );
  }
  return (
    <div className={`${classNamePre}-group-btn`}>
      <Button
        type="primary"
        outline
        size="middle"
        loading={loading}
        onClick={event => this.onSave('0', event)}
      >
        暂存
      </Button>
      {
        (ezrdForm.getFormValues() && ezrdForm.getFormValues().IsCanUserSpePrd)
          ? null
          : (
            <Button
              type="primary"
              size="middle"
              loading={loading}
              onClick={event => this.onSave('1', event)}
            >
              立即上架
            </Button>
          )
      }
    </div>
  );
}

render() {
  const { ezrdForm } = this.props;
  const {
    sysList, pageStatus, detail, switchDisab, pageDisabled, openSwitch, isCustomCouponFlag
  } = this.state;
  return (
    <div className={`${classNamePre}`}>
      <div>
        <Form horizontal>
          {/* 基础配置 */}
          <div className={`${classNamePre}-base`}>
            <div className={`${classNamePre}-base-title`}>
              基础配置
              <span />
            </div>
            <Field
              name="TplId"
              type="text"
              label="券模板"
              customCallBack={this.cuoponTplCallBack}
              component={ConstFormCouponList}
              value={
                detail ? {
                  couponTpl: detail.TplName,
                  TplId: detail.TplId,
                  CouponType: detail.CouponType,
                  CouponValue: detail.CouponValue,
                  CouponPriceLimit: detail.CouponPriceLimit
                } : ''
              }
              disabled={pageDisabled}
              required
              validations={{ required: true }}
              validationErrors={{ required: '请选择优惠券' }}
            />
            <FormInputField
              name="CouponName"
              type="text"
              label="券名称"
              width={320}
              maxLength={26}
              showCount
              value={detail ? detail.CouponName : ''}
              disabled={pageDisabled}
              required
              placeholder="例如：满300减30，填写后展示给消费者"
              validations={{ required: true }}
              validationErrors={{ required: '请填写券名称' }}
            />
            <FormInputField
              name="SubTitle"
              type="text"
              label="副标题"
              width={320}
              showCount
              value={detail ? detail.SubTitle : ''}
              disabled={pageDisabled && detail ? detail.SubTitle : false}
              maxLength={18}
              placeholder="可写券使用限制，填写后展示给消费者"
            />
            <FormSelectField
              name="OutSysId"
              type="text"
              required
              label="适用系统"
              optionText="Name"
              optionValue="Id"
              data={sysList}
              value={detail ? detail.OutSysId : ''}
              disabled={pageDisabled}
              validations={{ required: true }}
              validationErrors={{ required: '请选择适用系统类型' }}
            />
            <Field
              name="WxQrCode"
              label={(
                <span>
                公众号带参二维码&nbsp;
                  <Pop
                    trigger="hover"
                    position="right-center"
                    content="二维码参数建议提供：1、标题 2、描述、3、icon 4、跳转地址（小程序和H5）"
                    centerArrow
                  >
                    <Icon
                      type="info"
                      ezrd
                    />
                  </Pop>
                </span>
              )}
              component={ConstFormUpload}
              tips="建议尺寸：800 x 800 像素"
              openBase64={false}
              value={detail && detail.WxQrCode ? { src: detail.WxQrCode } : {}}
              disabled={!!(detail && detail.WxQrCode)}
            />
            <FormInputField
              name="Guide"
              type="textarea"
              width={320}
              label="使用说明"
              required
              value={detail ? detail.Guide : ''}
              disabled={pageDisabled}
              maxLength={512}
              showCount
              placeholder="用于向买家展示，如该优惠券不得与其他活动同时使用；节假日不得使用等，回车即可划分段落"
              validations={{ required: true }}
              validationErrors={{ required: '请填写使用说明' }}
            />
            <FormCheckboxField
              name="IsCanUserSpePrd"
              label={(
                <span>
                  单品券&nbsp;
                  <Pop
                    trigger="hover"
                    position="right-center"
                    content="不勾选则默认所有商品可用；该功能生效说明：EZR线上商城：已支持单品券；若线下POS、全部通用需要对接API接口核销券；"
                    centerArrow
                  >
                    <Icon
                      type="info"
                      ezrd
                    />
                  </Pop>
                </span>
                )}
              value={detail ? detail.IsCanUserSpePrd : ''}
              disabled={pageDisabled && detail ? detail.IsCanUserSpePrd : false}
            >
            仅限指定商品可使用该优惠券
            </FormCheckboxField>
          </div>
          {/* 高级配置 */}
          <div className={`${classNamePre}-advanced-configure`}>
            <div className={`${classNamePre}-advanced-configure-title`}>
              高级配置
              <span className={`${classNamePre}-advanced-configure-title-icon`} />
              <span className={`${classNamePre}-advanced-configure-title-tip`}>仅限已对接了券接口使用，EZR线上商城暂不支持以下配置</span>
              <Switch
                className={`${classNamePre}-advanced-configure-title-switch`}
                checked={openSwitch}
                onChange={this.onChangeSwitch}
                disabled={switchDisab}
              />
            </div>
            {
              openSwitch
                ? (
                  <React.Fragment>
                    <FormInputField
                      name="OuterCode"
                      type="text"
                      width={320}
                      label={(
                        <span>
                          外部编码&nbsp;
                          <Pop
                            trigger="hover"
                            position="right-center"
                            content="可用于多系统中券的非唯一识别，例如：第三方券规则比EZR复杂，则可以通过在核销券时通过券编码判断本地券的使用规则。"
                            centerArrow
                          >
                            <Icon
                              type="info"
                              ezrd
                            />
                          </Pop>
                        </span>
                      )}
                      helpDesc="第三方券系统编码，非唯一识别，可重复"
                      value={detail ? detail.OuterCode : ''}
                      disabled={pageDisabled && detail ? detail.OuterCode : ''}
                    />
                    <FormInputField
                      name="OuterId"
                      type="text"
                      width={320}
                      label={(
                        <span>
                          外部编号&nbsp;
                          <Pop
                            trigger="hover"
                            position="right-center"
                            content="可用于多系统中券的唯一识别，例如：第三方券规则比EZR复杂，则可以通过在核销券时通过券编号判断本地券的使用规则。"
                            centerArrow
                          >
                            <Icon
                              type="info"
                              ezrd
                            />
                          </Pop>
                        </span>
                      )}
                      helpDesc="第三方券系统编码，唯一识别，不可重复"
                      value={detail ? detail.OuterId : ''}
                      disabled={pageDisabled && detail ? detail.OuterId : ''}
                    />
                    <FormCheckboxField
                      name="IsAllowUserMore"
                      label="多券使用"
                      value={detail ? detail.IsAllowUserMore : ''}
                      disabled={pageDisabled && detail ? detail.IsAllowUserMore : false}
                    >
                      允许一个订单使用多张券
                    </FormCheckboxField>
                    <Field
                      name="AllowMaxBuyNum"
                      type="text"
                      label="购买件数"
                      component={ConstFormDayCheckBox}
                      value={
                        detail
                          ? {
                            type: detail.IsAllowBuyMore,
                            data: detail.AllowMaxBuyNum
                          }
                          : {
                            type: false,
                            data: ''
                          }
                      }
                      disabled={pageDisabled && detail ? detail.AllowMaxBuyNum : ''}
                      startTxt="允许一个订单最多购买"
                      endTxt="件商品"
                      validations={{
                        valueOne(values, value) {
                          if (value.type && !value.data) {
                            return false;
                          }
                          return true;
                        },
                        valueTwo(values, value) {
                          if (!value.type && value.data) {
                            return false;
                          }
                          return true;
                        }
                      }}
                      validationErrors={{ valueOne: '请输入购买件数', valueTwo: '请购选购买件数' }}
                    />
                    <FormCheckboxField
                      name="IsAllowPositive"
                      label="正价限制"
                      value={detail ? detail.IsAllowPositive : ''}
                      disabled={pageDisabled && detail ? detail.IsAllowPositive : ''}
                    >
                      仅允许正价商品使用
                    </FormCheckboxField>
                    <Field
                      name="DiscountLimit"
                      type="text"
                      label={(
                        <span>
                          折扣限制&nbsp;
                          <Pop
                            trigger="hover"
                            content="折扣率1-99"
                            centerArrow
                          >
                            <Icon
                              type="info"
                              ezrd
                            />
                          </Pop>
                        </span>
                      )}
                      component={ConstFormDayCheckBox}
                      value={
                        (detail && detail.DiscountLimit)
                          ? {
                            type: !!detail.DiscountLimit,
                            data: detail.DiscountLimit
                          }
                          : {
                            type: false,
                            data: ''
                          }
                      }
                      disabled={pageDisabled && detail ? detail.DiscountLimit : ''}
                      startTxt="仅允许订单折扣大于等于"
                      endTxt="%  使用"
                      max="99"
                      min="1"
                      validations={{
                        valueOne(values, value) {
                          if (value.type && !value.data) {
                            return false;
                          }
                          return true;
                        },
                        valueTwo(values, value) {
                          if (!value.type && value.data) {
                            return false;
                          }
                          return true;
                        }
                      }}
                      validationErrors={{ valueOne: '请输入订单折扣比列', valueTwo: '请购选折扣限制' }}
                    />
                    <Field
                      name="IsHasConsumeShops"
                      type="text"
                      label={(
                        <span>
                          核销门店&nbsp;
                          <Pop
                            trigger="hover"
                            position="right-center"
                            content="若对接“1310券库推送”接口，券库创建后任何组织变更将无法自动推送至客户系统；若对接“1311实时查询券库”接口，则支持实时查询券库组织信息。"
                            centerArrow
                          >
                            <Icon
                              type="info"
                              ezrd
                            />
                          </Pop>
                        </span>
                        )}
                      component={ConstFormSelect}
                      showItems={['SH', 'GP', 'PQ']}
                      selectValue="isActive"
                      isSelectDisabled
                      selectInfo={
                        (detail && detail.IsHasConsumeShops)
                          ? {
                            type: detail.ConsumeShops.ShopType,
                            list: detail.ConsumeShops.ShopListId
                          }
                          : {

                          }
                      }
                      value={
                        (detail && detail.IsHasConsumeShops)
                          ? {
                            type: detail.ConsumeShops.ShopType,
                            custom: true,
                            data: detail.ConsumeShops.ShopListId
                          }
                          : {
                            type: false,
                            data: ''
                          }
                      }
                      disabled={pageDisabled && detail ? detail.IsHasConsumeShops : ''}
                      max="1000"
                    />
                  </React.Fragment>
                )
                : null
            }
          </div>
          {/* 券交易配置 */}
          <div className={`${classNamePre}-configure`}>
            <div className={`${classNamePre}-configure-title`}>
              券交易配置
              <span />
            </div>
            <Field
              name="ValidDate"
              type="text"
              label={(
                <span>
                  采购有效期&nbsp;
                  <Pop
                    trigger="hover"
                    content="券采购后，采购方只允许在设置的时间段内发放优惠券"
                    centerArrow
                  >
                    <Icon
                      type="info"
                      ezrd
                    />
                  </Pop>
                </span>
                )}
              component={ConstFormDay}
              value={detail ? detail.CouponTradeCfg.ValidDate : ''}
              disabled={pageDisabled}
              startTxt="自采购日起"
              endTxt="天可发放"
              required
              validations={
                {
                  required(values, value) {
                    return !!(`${value}`);
                  },
                  min(values, value) {
                    if (value < 1) {
                      return false;
                    }
                    return true;
                  }
                }
              }
              validationErrors={{ required: '采购有效期不能为空', min: '采购有效期必须为大于0的整数' }}
            />
            <Field
              name="CusValidVay"
              type="text"
              label={(
                <span>
                  使用有效期&nbsp;
                  <Pop
                    trigger="hover"
                    content="消费者使用优惠券的有效期"
                    centerArrow
                  >
                    <Icon
                      type="info"
                      ezrd
                    />
                  </Pop>
                </span>
                )}
              component={ConstFormValidDate}
              min={0}
              value={
                detail
                  ? {
                    type: isEmptyTime(detail.CouponTradeCfg.BeginDate, detail.CouponTradeCfg.EndDate) ? '1' : '2',
                    data: isEmptyTime(detail.CouponTradeCfg.BeginDate, detail.CouponTradeCfg.EndDate)
                      ? [`${detail.CouponTradeCfg.ValidVay}` || '', ['', '']]
                      : ['', [detail.CouponTradeCfg.BeginDate || '', detail.CouponTradeCfg.EndDate || '']]
                  }
                  : {
                    type: '',
                    data: ['', ['', '']]
                  }
              }
              disabled={pageDisabled}
              startTxt="自领取日起"
              endTxt="天有效"
              required
              validations={{
                required(values, value) {
                  return !!value.type;
                },
                valueOne(values, value) {
                  if (value.type && value.type === '1' && !(`${value.data[0]}`)) {
                    return false;
                  }
                  return true;
                },
                valueTwo(values, value) {
                  if (value.type && value.type === '2' && (!value.data[1][0] || !value.data[1][1])) {
                    return false;
                  }
                  return true;
                }
              }}
              validationErrors={{ required: '使用有效期不能为空', valueOne: '自领取日不能为空', valueTwo: '请输入开始时间和结束时间' }}
            />
            <FormNumberInputField
              name="getNewUser"
              label="拉新奖励"
              type="text"
              value={detail ? detail.CouponTradeCfg.NewVipReward : ''}
              rearDesc={
                <span style={{ color: '#666' }}>Z币/人</span>
              }
              decimal={2}
              min={0}
              disabled={pageDisabled}
            />
            <Field
              name="PurchaseBet"
              type="text"
              label="起批量"
              component={ConstFormBetween}
              value={detail ? [detail.CouponTradeCfg.StartNo / 10000, detail.CouponTradeCfg.EndNo / 10000] : ''}
              disabled={pageDisabled}
              toFixLen={2}
              min1={0.01}
              centerTxt="至"
              endTxt="万张"
              tip="可采购的数量区间"
              required
              validations={
                {
                  required(values, value) {
                    return !!value[0] && !!value[1];
                  },
                  start(values, value) {
                    if (value[0] && value[1]) {
                      if (value[1] < value[0]) {
                        return false;
                      }
                      return true;
                    }
                    return true;
                  }
                }
              }
              validationErrors={{ required: '起批量不能为空', start: '起批量区间范围格式错误' }}
            />
            <FormRadioGroupField
              name="RewardWray"
              label="奖励方式"
              required
              value={detail ? `${detail.CouponTradeCfg.RewardWray}` : ''}
              disabled={pageDisabled}
              validations={{ required: true }}
              validationErrors={{ required: '请选择奖励方式' }}
            >
              <Radio value="0">按核销单张券奖励金额</Radio>
              {
                isCustomCouponFlag
                  ? null
                  : <Radio value="1">按核销的订单实付金额比例提成</Radio>
              }
            </FormRadioGroupField>
            {
              // RewardWray
              (ezrdForm.getFormValues() && ezrdForm.getFormValues().RewardWray && (ezrdForm.getFormValues().RewardWray === '1'))
                ? (
                  <Field
                    name="RewardMoney"
                    label="订单提成"
                    component={ConstFormDay}
                    value={detail ? detail.CouponTradeCfg.RewardMoney * 100 : ''}
                    disabled={pageDisabled}
                    startTxt=""
                    endTxt="%"
                    max={100}
                    desc="平台建议订单提成比列5%~20%，仅供参考"
                    required
                    validations={{ required: true }}
                    validationErrors={{ required: '订单提成不能为空' }}
                  />
                )
                : (
                  <Field
                    name="RewardMoney"
                    label="奖励金额"
                    component={ConstFormDay}
                    value={detail ? detail.CouponTradeCfg.RewardMoney : ''}
                    disabled={pageDisabled}
                    startTxt=""
                    toFixLen={2}
                    endTxt="元"
                    required
                    validations={{ required: true }}
                    validationErrors={{ required: '奖励金额不能为空' }}
                  />
                )
            }
          </div>
          {
            this.initHandleBtn(pageStatus)
          }
        </Form>
      </div>
    </div>
  );
}
}

const ProvidePlatformCouponAdd = createForm()(FieldForm);

export default ProvidePlatformCouponAdd;
