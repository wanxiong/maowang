import * as React from 'react';
import { Button } from 'ezrd';
import { withRouter } from 'react-router-dom';
// 新建
const classNamePre = 'yiye-provide-page-examine';
// 注入
@withRouter
export default class ProvidePageExamine extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
    };
  }

  redirectInfo = () => {
    const { history } = this.props;
    history.push('/Yiye/Account/Accountinfo');
  }

  render() {
    return (
      <div className={`${classNamePre}`}>
        <div>
          <img
            src="https://static.ezrpro.com/assets/icon/petslogo/logo_icon_2.png"
            alt="请先完善账户信息"
          />
          <div className={`${classNamePre}-title`}>请先完善账户信息，审核通过后即可使用</div>
          <Button
            className={`${classNamePre}-btn`}
            size="large"
            type="primary"
            onClick={this.redirectInfo}
          >
          立即完善
          </Button>
        </div>
      </div>
    );
  }
}
