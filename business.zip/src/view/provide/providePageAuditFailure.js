import * as React from 'react';
import { Button } from 'ezrd';
import { textAreaBr } from '../../utils/common';
import { sessPageAuditFailure } from '../../components/base/constant';
// 新建
const classNamePre = 'yiye-provide-page-failure';
// 注入
export default class ProvidePageAuditFailure extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
    };
  }

  redirectInfo = () => {
    const { history } = this.props;
    history.push('/Yiye/Account/Accountinfo');
  }

  render() {
    const remark = localStorage.getItem(sessPageAuditFailure) || '';
    return (
      <div className={`${classNamePre}`}>
        <div>
          <img
            src="https://static.ezrpro.com/assets/icon/petslogo/logo_icon_6.png"
            alt="请先完善账户信息"
          />
        </div>
        <div>
          <div className={`${classNamePre}-title`}>审核未通过</div>
          <div className={`${classNamePre}-sub-title`}>审核修改意见如下：</div>
          {/* eslint-disable */}
          <div
            className={`${classNamePre}-text`}
            dangerouslySetInnerHTML={{ __html: textAreaBr(remark) }}
          />
          {/* eslint-enable */}
          <Button
            className={`${classNamePre}-btn`}
            size="middle"
            type="primary"
            onClick={this.redirectInfo}
          >
          修改资料
          </Button>
        </div>
      </div>
    );
  }
}
