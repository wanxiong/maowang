import * as React from 'react';
import {
  Notify, Pagination, Pop, Icon, Dialog, Button, Input, NumberInput
} from 'ezrd';
import { observer, inject } from 'mobx-react';
import moment from 'moment';
import OrderCouponSearch from '../../components/base/orderCouponSearch';
import { couponDefaultPage } from '../../components/base/constant';
import CountDownItem from '../../components/base/CountDownItem';
import ProvideOrderExamineDtl from '../../components/provideOrderExamineDtl';
import { checkShopStatus } from '../../utils/commonApi';

const classNamePre = 'yiye-provide-order';
// 注入
@inject('provideStore')
@inject('purchaseStore')
@observer
export default class ProvideOrder extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      Json: {},
      detail: {},
      PriceValue: '',
      RemarksValue: '',
      dialogVisible: false,
      ...couponDefaultPage
    };
  }

  @checkShopStatus('provide')
  async componentDidMount() {
    // await shopStatus()
    this.initData({});
  }

// initData
initData = (params = {}) => {
  const { provideStore } = this.props;
  const { pageSize, current } = this.state;
  provideStore.fetchProvideOrderList({
    PageIndex: current,
    PageSize: pageSize,
    PurchaseNo: '', // 采购单号
    PurchaseName: '', // 品牌
    Status: '', // 状态：待审核0 审核未通过1 审核通过 制券中2  已入库3
    CouponName: '', // 券名称
    StartTime: '', // 开始时间
    EndTime: '', // 结束时间
    ...params
  });
}

// 点击查询的事件
onHandleSearch = (data, flag) => {
  if (flag !== 0) {
    this.setState({ current: 1 }, () => {
      this.initData({
        PurchaseNo: data.couponId,
        PurchaseName: data.brand,
        Status: data.currentSelect,
        CouponName: data.couponName,
        StartTime: data.time[0] ? data.time[0] : '',
        EndTime: data.time[1] ? data.time[1] : ''
      });
    });
    return;
  }
  this.initData({
    PurchaseNo: data.couponId,
    PurchaseName: data.brand,
    Status: data.currentSelect,
    CouponName: data.couponName,
    StartTime: data.time[0] ? data.time[0] : '',
    EndTime: data.time[1] ? data.time[1] : ''
  });
}

// 导出事件
onHandleExport = () => {
}

// 每页大小的回调
onPageSizeChange = (pageSize) => {
  this.setState({
    pageSize
  }, () => {
    this.searchDom.onSearch(0);
  });
};

// 分页的回调
onChange = (data) => {
  const { current } = this.state;
  this.setState({
    current: data || current
  }, () => {
    // console.log(this.searchDom);
    this.searchDom.onSearch(0);
  });
}

// 改价事件
onPrice = () => {
  Notify.success('暂不支持线上沟通');
}

// 审核接口
startExamine = async (item) => {
  const { provideStore } = this.props;
  const status = await provideStore.fetchProvideOrderExamineDetail({
    SupplyBrandId: item.MchId,
    Id: item.Id,
    PurchaseBrandId: item.PurchaseMchId
  });
  if (status.IsError) {
    // Notify.error(status.ErrorMsg);
  } else {
    // Data.ShopCount.forEach( (item, i) => {
    //   if ( i == 0) {
    //     item.CityName = '上海'
    //   }
    //   if ( i == 1) {
    //     item.CityName = '北京'
    //   }
    //   if ( i == 2) {
    //     item.CityName = '深圳'
    //   }
    //   if ( i == 3) {
    //     item.CityName = '芜湖'
    //   }
    //   if ( i == 4) {
    //     item.CityName = '哈哈'
    //   }
    // })
    const data = [];
    const { Data } = status;
    for (let i = 0; i < Data.ShopCount.length; i++) {
      data.push({
        month: Data.ShopCount[i].CityName,
        city: '我的',
        temperature: Data.ShopCount[i].ShopCount
      });
      data.push({
        month: Data.ShopCount[i].CityName,
        city: '其他的',
        temperature: Data.ShopCount[i].SupShopCount
      });
    }
    Data.ShopCount = data;
    this.setState({ Json: item, detail: Data }, () => {
      this.setState({ visible: true });
    });
  }
}

// 关闭审核界面
onClose = () => {
  this.setState({
    visible: false
  });
}

// 确认审核界面
onSave = async (data) => {
  this.setState({ visible: false });
  const { provideStore } = this.props;
  const status = await provideStore.fetchProvideOrderExamineSave({
    Status: data.Status,
    BackReason: data.BackReason,
    Id: data.Id
  });
  if (!status.IsError) {
    Notify.success('审核成功');
    this.initData();
  } else {
    // Notify.error(status.ErrorMsg);
  }
}

//
onChangePrice = (e) => {
  this.setState({ PriceValue: e.target.value });
}

//
onChangeRemarks = (e) => {
  this.setState({ RemarksValue: e.target.value });
}

//
priceConfirm = async () => {
  const { PriceValue, RemarksValue, Json } = this.state;
  const { provideStore } = this.props;
  if (!PriceValue && PriceValue !== 0) {
    Notify.error('订单提成不能为空');
    return;
  }
  const status = await provideStore.fetchProvideOrderChangeReward({
    Id: Json.Id,
    RewardMoney: Json.RewardWray === 1 ? PriceValue / 100 : PriceValue,
    RewardChangeDes: RemarksValue
  });
  if (status.ErrorCode === 0) {
    Notify.success('改价成功');
    this.setState({
      PriceValue: '',
      RemarksValue: '',
      dialogVisible: false
    }, () => {
      this.searchDom.onSearch(0);
    });
  } else {
    Notify.error(status.ErrorMsg);
  }
}

//
priceReset = (item) => {
  this.setState({ Json: item }, () => {
    this.setState({ dialogVisible: true });
  });
}

//
dialogClose = () => {
  this.setState({ dialogVisible: false, RemarksValue: '', PriceValue: '' });
}

// 状态显示模板
initStatusTpl = (item) => {
  if (item.Status === 0) {
    return (<span>待审核</span>);
  } if (item.Status === 3) {
    return (<span>已入库</span>);
  } if (item.Status === 1) {
    return (
      <span>
        审核未通过
        <Pop
          trigger="hover"
          content={item.BackReason}
        >
          <Icon
            type="info-circle-o"
            className={`${classNamePre}-pro-item-popicon`}
          />
        </Pop>
      </span>
    );
  } if (item.Status === 2) {
    return (<span>制券中</span>);
  }
  return null;
}

render() {
  const {
    visible, Json, detail, RemarksValue, PriceValue, dialogVisible, current, pageSizeList
  } = this.state;
  const { provideStore } = this.props;
  const { provideOrderList: { TotalRowsCount, PagedList } } = provideStore;
  return (
    <div className={`${classNamePre}`}>
      <OrderCouponSearch
        onSearch={this.onHandleSearch}
        onExport={this.onHandleExport}
        exportText="导出供货单"
        type="provideStore"
        typeName="流量交易单"
        // ref={(ref) => { this.searchDom = ref; }}
        getRef={(ref) => { this.searchDom = ref; }}
      />
      {/* */}
      <div className={`${classNamePre}-pro`}>
        <div className={`${classNamePre}-pro-head`}>
          <span>采购时间</span>
          <span>券类型</span>
          <span className={`${classNamePre}-pro-head-special`}>券名称</span>
          <span>采购品牌</span>
          <span>采购量(万)</span>
          <span>核销单价/订单提成</span>
          <span>状态</span>
          <span>操作</span>
        </div>
        {
          PagedList.map(item => (
            <div
              className={`${classNamePre}-pro-item`}
              key={item.Id}
            >
              <div className={`${classNamePre}-pro-item-title`}>
                <div>
                  {item.PurchaseTypeDes}
                  单号:
                  <span>{item.PurchaseNo}</span>
                </div>
                <div>
                  {
                    item.Status === 3
                      ? (
                        <CountDownItem
                          classNamePre={`${classNamePre}`}
                          key={item.Id}
                          json={item}
                          endTime={moment(item.FreezeDate).format('x')}
                          nowDate={moment(item.ServerTime).format('x')}
                          FreezeCosts={item.FreezeCosts}
                        />
                      )
                      : null
                  }
                </div>
              </div>
              <ul>
                <li>{moment(item.BuyTime).format('YYYY-MM-DD HH:mm:ss')}</li>
                <li>{item.CouponType}</li>
                <li className={`${classNamePre}-pro-head-special`}>
                  <div>
                    <img
                      alt="图标"
                      src={item.MchLog}
                      width="64px"
                      height="64px"
                    />
                  </div>
                  <div>
                    <div>{item.CouponName}</div>
                    <div>{item.SubTitle}</div>
                    <div>
                      券ID：
                      {item.CouponGrpId}
                    </div>
                  </div>
                </li>
                <li>{item.PurchaseName}</li>
                <li>{item.BuyCount / 10000}</li>
                <li>
                  {
                      item.RewardWray === 0 // 按核销单张券奖励金额
                        ? (
                          <span>{item.RewardMoney.toFixed(2)}</span>
                        )
                        : ( // 按核销的订单实付金额比例提成
                          <span>{`${item.RewardMoney * 100}%`}</span>
                        )
                    }
                  {
                      item.RewardChangeDes ? (
                        <Pop
                          trigger="hover"
                          content={item.RewardChangeDes}
                        >
                          <Icon
                            type="info-circle-o"
                            className={`${classNamePre}-pro-item-popicon`}
                          />
                        </Pop>
                      ) : null
                    }
                </li>
                <li>
                  {
                    this.initStatusTpl(item)
                  }
                </li>
                <li className={`${classNamePre}-pro-item-last`}>
                  {
                        item.Status === 0
                          ? (
                            <React.Fragment>
                              <span
                                role="button"
                                tabIndex="0"
                                className="yiye-outline btn-default-color"
                                onClick={() => this.startExamine(item)}
                              >
                              审核
                              </span>
                              <span
                                role="button"
                                tabIndex="0"
                                className="yiye-outline btn-default-color"
                                onClick={() => this.priceReset(item)}
                              >
                              改价
                              </span>
                            </React.Fragment>
                          )
                          : <span>--</span>
                      }
                </li>
              </ul>
            </div>
          ))
        }
        {/* 分页区域 */}
        <Pagination
          current={current}
          totalItem={TotalRowsCount}
          onChange={this.onChange}
          pageSize={pageSizeList}
          onPageSizeChange={this.onPageSizeChange}
        />
      </div>
      { /** 审核详情 */}
      <ProvideOrderExamineDtl
        visible={visible}
        provideStore={provideStore}
        close={this.onClose}
        save={this.onSave}
        Json={Json}
        detail={detail}
      />
      {
        /* 改价接口 */
      }
      <Dialog
        title="改价"
        visible={dialogVisible}
        onClose={() => this.dialogClose()}
        style={{ width: '600px' }}
        footer={(
          <div>
            <Button onClick={() => this.priceConfirm(false)}>确定</Button>
          </div>
      )}
      >
        <div className={`${classNamePre}-price-dialog`}>
          <div>
            <span>
              <span>* </span>
              {
                Json.RewardWray === 0 // 按核销单张券奖励金额
                  ? (
                    '单张券金额：'
                  )
                  : ( // 按核销的订单实付金额比例提成
                    '订单提成：'
                  )
              }
            </span>
            {
              Json.RewardWray === 0 // 按核销单张券奖励金额
                ? (
                  <NumberInput
                    type="text"
                    decimal={2}
                    min={0}
                    className={`${classNamePre}-price-dialog-reward`}
                    value={PriceValue}
                    onChange={this.onChangePrice}
                    width={320}
                  />
                )
                : (
                  <NumberInput
                    type="text"
                    decimal={0}
                    min={0}
                    max={100}
                    className={`${classNamePre}-price-dialog-reward`}
                    value={PriceValue}
                    onChange={this.onChangePrice}
                    width={320}
                  />
                )
            }

            <font>
              {
              Json.RewardWray === 0 // 按核销单张券奖励金额
                ? (
                  ''
                )
                : ( // 按核销的订单实付金额比例提成
                  '%'
                )
            }
            </font>
          </div>
          <div>
            <span>备注：</span>
            <Input
              type="textarea"
              value={RemarksValue}
              width={320}
              maxLength={100}
              onChange={this.onChangeRemarks}
              showCount
            />
          </div>
        </div>
      </Dialog>
    </div>
  );
}
}
