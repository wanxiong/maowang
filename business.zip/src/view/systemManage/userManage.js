import * as React from 'react';
import {
  Button, Table, Notify
} from 'ezrd';
import { observer, inject } from 'mobx-react';
import md5 from 'js-md5';
import {
  couponDefaultPage, sysUserStatus
} from '../../components/base/constant';
import UserManageSearch from '../../components/systemManage/userManageSearch';
import { getMchId } from '../../utils/common';
import DefaultTipDialog from '../../components/transaction/defaultTipDialog';
import UserManageReset from '../../components/systemManage/userManageReset';
import UserManageAddDialog from '../../components/systemManage/userManageAddDialog';
// 新建

const classNamePre = 'yiye-system-user-manage';

@inject('systemManageStore')
@observer
export default class RoleManage extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      addDialog: false,
      freezeLoading: false,
      freezeText: '冻结',
      showDelDialog: false,
      resetDialog: false,
      // delData: '',
      resetData: '',
      addData: '',
      addLoading: false,
      resetPsdLoading: false,
      roleList: [],
      ...couponDefaultPage
    };
  }

  async componentDidMount() {
    this.initData();
  }

initData = async () => {
  this.initList();
  this.getAllRoleList();
}

// 获取所有角色列表
getAllRoleList = async () => {
  const { systemManageStore } = this.props;
  const status = await systemManageStore.fetchSysRoleListAll({
    MchId: getMchId(),
    PageSize: 100000,
    Page: 1,
    Code: '',
    Name: ''
  });
  if (status && !status.IsError) {
    this.setState({
      roleList: status.Data.Data || []
    });
  }
}

// 列表接口
initList = async (params = {}) => {
  const { systemManageStore } = this.props;
  const { pageSize, current } = this.state;
  await systemManageStore.fetchSysUserList({
    MchId: 0,
    MobileNo: '',
    RealNameKeyWord: '',
    PageSize: pageSize,
    Page: current,
    Status: -1,
    ...params
  });
}

// 分页的回调
onChange = (data) => {
  let { current } = this.state;
  const { pageSize } = this.state;
  if (data.pageSize) {
    if (data.pageSize === pageSize) {
      return;
    }
    current = 1;
  }
  this.setState({
    pageSize: data.pageSize || pageSize,
    current: data.current || current
  }, () => {
    this.searchDom.onSearch(0);
  });
}

// 搜索按钮的回调
onSearch = (data, flag) => {
  const params = {
    MobileNo: data.phone,
    RealNameKeyWord: data.roleName,
    Status: data.selected || -1,
    MchId: data.brandId || 0
  };
  if (flag !== 0) {
    this.setState({ current: 1 }, () => {
      this.initList(params);
    });
    return;
  }
  this.initList(params);
}

addUser = (flag, data) => {
  this.setState({
    addDialog: flag,
    addData: data
  });
}

openDelDialog = () => {
  this.setState({
    showDelDialog: true
  });
}

closeDialog = (type) => {
  this.setState({
    [type]: false
  });
}

// 冻结用户
freezeUserDialog = (flag, data, text) => {
  this.setState({
    showDelDialog: flag,
    delData: data,
    freezeText: text
  });
}

//
freezeConfirm = async (flag) => {
  const { systemManageStore } = this.props;
  const { delData } = this.state;
  if (!flag) {
    this.setState({
      showDelDialog: false
    });
    return;
  }
  this.setState({
    freezeLoading: true
  });
  let status = '';
  if (delData.Status === 2) {
    status = 3;
  } else if (delData.Status === 3) {
    status = 2;
  }
  const data = await systemManageStore.fetchSysUserUpdateStatus({
    Id: delData.Id,
    Status: status
  });
  if (data && !data.IsError) {
    this.setState({
      showDelDialog: false,
      freezeLoading: false
    });
    this.searchDom.onSearch(0);
    return;
  }
  this.setState({
    showDelDialog: false
  });
}

// 重置密码弹框
resetPasswordDialog = (falg, data) => {
  this.setState({
    resetDialog: falg,
    resetData: data
  });
}

// 重置密码回调
modifyPsdConfirm = async (data) => {
  const { systemManageStore } = this.props;
  const { resetData } = this.state;
  this.setState({
    resetPsdLoading: true
  });
  const status = await systemManageStore.fetchSysUserModifyPassword({
    NewPassword: md5(data.confirmPassword),
    Id: resetData.Id
  });
  if (status && !status.IsError) {
    Notify.success('重置密码成功');
    this.setState({
      resetPsdLoading: false,
      resetDialog: false
    });
    this.searchDom.onSearch(0);
    return;
  }
  this.setState({
    resetPsdLoading: false
  });
}

// 新增
addConfirm = async (data, type) => {
  const { systemManageStore } = this.props;
  const { addData } = this.state;
  this.setState({
    addLoading: true
  });
  if (type === 'add') {
    const status = await systemManageStore.fetchSysUserAdd({
      RealName: data.name,
      MobileNo: data.phone,
      EMail: data.email,
      Password: md5(data.password),
      Remark: data.remark,
      MchId: data.MchId,
      Status: data.status,
      RoleId: data.role
    });
    if (status && !status.IsError) {
      Notify.success('新增用户成功');
      this.setState({
        addDialog: false,
        addLoading: false
      });
      this.searchDom.onSearch(0);
      return;
    }
  } else {
    const status = await systemManageStore.fetchSysUserUpdate({
      RealName: data.name,
      MobileNo: data.phone,
      EMail: data.email,
      Remark: data.remark,
      MchId: getMchId(),
      Status: data.status,
      RoleId: data.role,
      Id: addData.Id
    });
    if (status && !status.IsError) {
      Notify.success('编辑用户成功');
      this.setState({
        addDialog: false,
        addLoading: false
      });
      this.searchDom.onSearch(0);
      return;
    }
  }
  this.setState({
    addLoading: false
  });
}

render() {
  const {
    current, pageSizeList, addDialog, freezeLoading, showDelDialog, addData, resetDialog, resetData, addLoading, roleList, freezeText, resetPsdLoading
  } = this.state;
  const { systemManageStore } = this.props;
  const { sysUserList: { Data, Count } } = systemManageStore;
  const columns = [
    {
      title: '姓名',
      bodyRender: data => (
        <div>{data.RealName}</div>
      )
    },
    {
      title: '品牌',
      bodyRender: data => (
        <div>{data.MerchantName}</div>
      )
    },
    {
      title: '手机号',
      bodyRender: data => <div>{data.MobileNo}</div>
    },
    {
      title: '邮箱',
      bodyRender: data => <div>{data.EMail}</div>
    },
    {
      title: '角色',
      bodyRender: data => (
        <div className={`${classNamePre}-recharge`}>
          {data.RoleName}
        </div>
      )
    },
    // {
    //   title: '所属组织',
    //   bodyRender: data => (
    //     <div className={`${classNamePre}-recharge`}>
    //       {data.GroupName}
    //     </div>
    //   )
    // },
    {
      title: '用户状态',
      bodyRender: (data) => {
        if (data.Status === 2) {
          return '正常';
        } if (data.Status === 3) {
          return '冻结';
        }
        return '--';
      }
    },
    {
      title: '操作',
      bodyRender: data => (
        <div>
          <span
            type="primary"
            role="button"
            tabIndex="0"
            className={`yiye-outline btn-default-color ${classNamePre}-handle-span`}
              // onClick={() => this.addUser(true, data)}
            onClick={() => this.addUser(true, data)}
          >
              编辑
          </span>
          {
               data.Status === 2 && (
               <span
                 type="primary"
                 role="button"
                 tabIndex="0"
                 className={`yiye-outline btn-default-color ${classNamePre}-handle-span`}
                 onClick={() => this.freezeUserDialog(true, data, '冻结')}
               >
                  冻结
               </span>
               )
          }
          {
              data.Status === 3 && (
                <span
                  type="primary"
                  role="button"
                  tabIndex="0"
                  className={`yiye-outline btn-default-color ${classNamePre}-handle-span`}
                  onClick={() => this.freezeUserDialog(true, data, '启用')}
                >
                  启用
                </span>
              )
            }
          <span
            type="primary"
            role="button"
            tabIndex="0"
            className={`yiye-outline btn-default-color ${classNamePre}-handle-span`}
            onClick={() => this.resetPasswordDialog(true, data)}
          >
              重置密码
          </span>
        </div>
      )
    }
  ];
  return (
    <div className={`${classNamePre}`}>
      {/* 搜索区域 */}
      <div>
        <UserManageSearch
          selectData={sysUserStatus}
          ref={(ref) => { this.searchDom = ref; }}
          onSearch={this.onSearch}
        />
      </div>
      <div className={`${classNamePre}-contain`}>
        <div>
          <Button
            type="primary"
            size="middle"
            onClick={() => this.addUser(true, '')}
          >
          新增用户
          </Button>
        </div>
        {/* table展示区域 */}
        <div className={`${classNamePre}-contain-table`}>
          <Table
            columns={columns}
            datasets={Data}
            rowKey="Id"
            pageInfo={{
              totalItem: Count,
              current,
              pageSize: pageSizeList
            }}
            onChange={this.onChange}
          />
        </div>
      </div>
      {/** 用户添加的弹框 */}
      <UserManageAddDialog
        show={addDialog}
        data={addData}
        loading={addLoading}
        roleList={roleList}
        onClose={() => this.closeDialog('addDialog')}
        onConfirm={this.addConfirm}
      />
      {/** 冻结提示 */}
      <DefaultTipDialog
        showEnableVisible={showDelDialog}
        content={`用户${freezeText}后，账号将${freezeText === '冻结' ? '不能' : '能'}正常登录平台，确认${freezeText}该用户吗`}
        title={`${freezeText}确认`}
        maskClosable={false}
        loading={freezeLoading}
        confirmEnable={this.freezeConfirm}
      />
      {/** 重置密码 */}
      <UserManageReset
        show={resetDialog}
        data={resetData}
        confirm={this.modifyPsdConfirm}
        loading={resetPsdLoading}
        onClose={() => this.resetPasswordDialog(false, '')}
      />
    </div>
  );
}
}
