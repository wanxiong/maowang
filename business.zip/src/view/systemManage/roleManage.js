import * as React from 'react';
import {
  Button, Table, Notify
} from 'ezrd';
import { observer, inject } from 'mobx-react';
import {
  couponDefaultPage
} from '../../components/base/constant';
import RoleManageSearch from '../../components/systemManage/roleManageSearch';
import { getMchId } from '../../utils/common';
import RoleManageAdd from '../../components/systemManage/roleManageAdd';
import DefaultTipDialog from '../../components/transaction/defaultTipDialog';
// 新建

const classNamePre = 'yiye-system-role-manage';

@inject('accountStore')
@inject('systemManageStore')
@observer
export default class RoleManage extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      addDialog: false,
      delLoading: false,
      showDelDialog: false,
      addLoading: false,
      openAll: true,
      dialogStatus: '',
      delData: {},
      edit: '',
      treeData: [{
        Id: '0',
        Name: '驿业菜单',
        expand: true,
        SubRoutes: []
      }],
      disabledCheckedKeys: [],
      ...couponDefaultPage
    };
  }

  async componentDidMount() {
    this.initData({});
    this.initAllMenu();
  }

initData = async (params = {}) => {
  const { systemManageStore } = this.props;
  const { pageSize, current } = this.state;
  await systemManageStore.fetchSysRoleList({
    MchId: getMchId(),
    PageSize: pageSize,
    Page: current,
    Code: '',
    Name: '',
    ...params
  });
}

// 分页的回调
onChange = (data) => {
  let { current } = this.state;
  const { pageSize } = this.state;
  if (data.pageSize) {
    if (data.pageSize === pageSize) {
      return;
    }
    current = 1;
  }
  this.setState({
    pageSize: data.pageSize || pageSize,
    current: data.current || current
  }, () => {
    this.searchDom.onSearch(0);
  });
}

// 搜索按钮的回调
onSearch = (data, flag) => {
  if (flag !== 0) {
    this.setState({ current: 1 }, () => {
      this.initData({
        Code: data.roleNum,
        Name: data.roleName
      });
    });
    return;
  }
  this.initData(data);
}

addRole = () => {
  this.setState({
    addDialog: true,
    dialogStatus: 'add'
  });
}

openDelDialog = (type, data) => {
  this.setState({
    showDelDialog: true,
    delData: data
  });
}

closeDialog = (type, flag) => {
  this.setState({
    [type]: flag
  });
}

openHandleDialog = (type, data, status) => {
  this.setState({
    [type]: true,
    edit: data,
    dialogStatus: status
  });
}

delConfirm = async (falg) => {
  const { systemManageStore } = this.props;
  if (!falg) {
    this.setState({
      delLoading: false,
      showDelDialog: false
    });
    return;
  }
  const { delData } = this.state;
  this.setState({
    delLoading: true
  });
  const status = await systemManageStore.fetchSysRoleDel({
    Id: delData.Id
  });
  if (status && !status.IsError) {
    if (status.Data) {
      Notify.success('删除角色成功');
    } else {
      Notify.error('该角色下有关联用户，请先解除用户关联关系');
    }
    this.setState({
      delLoading: false,
      showDelDialog: false
    });
    this.searchDom.onSearch(0);
    return;
  }
  this.setState({
    delLoading: false,
    showDelDialog: false
  });
}

// 角色添加或编辑的回调
addConfirm = (data, fn, status) => {
  this.setState({
    addLoading: true
  });
  if (status === 'edit') {
    this.edit(data, fn);
  } else {
    this.addInsert(data, fn);
  }
}

// 新增角色
addInsert = async (data, fn) => {
  const { systemManageStore } = this.props;
  const params = {
    Code: data.roleNumber,
    Name: data.roleName,
    MenuIds: data.list,
    Remark: data.remark
  };
  const status = await systemManageStore.fetchSysRoleAdd(params);
  if (status && !status.IsError) {
    Notify.success('添加角色成功');
    this.setState({
      addDialog: false
    });
    fn();
    this.searchDom.onSearch(0);
  }
  this.setState({
    addLoading: false
  });
}

// 编辑接口
edit = async (data, fn = () => {}) => {
  const { systemManageStore } = this.props;
  const { edit } = this.state;
  const params = {
    Id: edit.Id,
    Code: data.roleNumber,
    Name: data.roleName,
    MenuIds: data.list,
    Remark: data.remark
  };
  const status = await systemManageStore.fetchSysRoleEdit(params);
  if (status && !status.IsError) {
    Notify.success('编辑角色成功');
    this.setState({
      addDialog: false
    });
    fn();
    this.searchDom.onSearch(0);
  }
  this.setState({
    addLoading: false
  });
}

// 获取角色所有接口权限
initAllMenu = async () => {
  const { accountStore } = this.props;
  const data = await accountStore.fetchAccountAllMenuList({});
  if (data && !data.IsError) {
    /* eslint-disable */
    const arr = ['0'];
    const pushId = (list) => {
      list.forEach((item) => {
        arr.push(item.Id);
        item.id = item.Id;
        item.title = item.Name;
        item.children = item.SubRoutes || [];
        if (item.SubRoutes && item.SubRoutes.length) {
          pushId(item.SubRoutes || []);
        }
      });
    };
    /* eslint-enable */
    pushId(data.Data.Data);
    this.setState({
      disabledCheckedKeys: arr,
      treeData: [{
        Id: '0',
        Name: '驿业菜单',
        id: '0',
        name: '驿业菜单',
        children: data.Data.Data
      }]
    });
  }
}

render() {
  const {
    current, pageSizeList, addDialog, delLoading, showDelDialog, openAll, dialogStatus, addLoading, treeData, edit, disabledCheckedKeys
  } = this.state;
  const { systemManageStore } = this.props;
  const { sysRoleList } = systemManageStore;
  const { Data, Count } = sysRoleList;
  const columns = [
    {
      title: '角色编号',
      bodyRender: data => <div>{data.Code}</div>
    },
    {
      title: '角色名称',
      bodyRender: data => (
        <div>{data.Name}</div>
      )
    },
    {
      title: '备注',
      bodyRender: data => (
        <div className={`${classNamePre}-recharge`}>
          {data.Remark}
        </div>
      )
    },
    {
      title: '操作',
      bodyRender: data => (
        <div>
          <span
            type="primary"
            role="button"
            tabIndex="0"
            className={`yiye-outline btn-default-color ${classNamePre}-handle-span`}
            onClick={() => this.openHandleDialog('addDialog', data, 'look')}
          >
            查看
          </span>
          <span
            type="primary"
            role="button"
            tabIndex="0"
            className={`yiye-outline btn-default-color ${classNamePre}-handle-span`}
            onClick={() => this.openHandleDialog('addDialog', data, 'edit')}
          >
            编辑
          </span>
          <span
            type="primary"
            role="button"
            tabIndex="0"
            className={`yiye-outline btn-default-color ${classNamePre}-handle-span`}
            onClick={() => this.openDelDialog('showDelDialog', data)}
          >
            删除
          </span>
        </div>
      )
    }
  ];
  return (
    <div className={`${classNamePre}`}>
      {/* 搜索区域 */}
      <div>
        <RoleManageSearch
          ref={(ref) => { this.searchDom = ref; }}
          onSearch={this.onSearch}
        />
      </div>
      <div className={`${classNamePre}-contain`}>
        <div>
          <Button
            type="primary"
            size="middle"
            onClick={this.addRole}
          >
          添加角色
          </Button>
        </div>
        {/* table展示区域 */}
        <div className={`${classNamePre}-contain-table`}>
          <Table
            columns={columns}
            datasets={Data}
            rowKey="Id"
            pageInfo={{
              totalItem: Count,
              current,
              pageSize: pageSizeList
            }}
            onChange={this.onChange}
          />
        </div>
      </div>
      {/** 角色添加的弹框 */}
      <RoleManageAdd
        show={addDialog}
        confirm={this.addConfirm}
        openAll={openAll}
        status={dialogStatus}
        loading={addLoading}
        treeData={treeData}
        disabledCheckedKeys={disabledCheckedKeys}
        data={edit}
        onClose={() => { this.closeDialog('addDialog', false); }}
      />
      {/** 删除提示 */}
      <DefaultTipDialog
        showEnableVisible={showDelDialog}
        content="确定删除角色吗？"
        title="温馨提示"
        maskClosable={false}
        loading={delLoading}
        confirmEnable={this.delConfirm}
      />
    </div>
  );
}
}
