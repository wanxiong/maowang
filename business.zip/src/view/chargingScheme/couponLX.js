/* eslint-disable */
import * as React from 'react';
import { Table, Button } from 'ezrd';
import moment from 'moment';
import { couponDefaultPage } from '../../components/base/constant';
import CouponWriteOffSearch from '../../components/chargingScheme/couponWriteOffSearch'
import { inject, observer } from 'mobx-react';
import ChargingSchemeDefaultAdd from '../../components/chargingScheme/chargingSchemeDefaultAdd';
import DefaultTipDialog from '../../components/transaction/defaultTipDialog';

const classNamePre = 'yiye-couponWriteOff';


@inject('CouponCodeStore')
@observer
class CouponLX extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      ...couponDefaultPage,
      addShowDialog: false,
      addLoading: false,
      showOpenFlag: false,
      openLoading: false,
      title: '',
      content: '',
      editJson: ''
    };
  }

  // 分页的回调
  onChange = (data) => {
    let { current } = this.state;
    const { pageSize } = this.state;
    if (data.pageSize) {
      if (data.pageSize === pageSize) {
        return;
      }
      current = 1;
    }
    this.setState({
      pageSize: data.pageSize || pageSize,
      current: data.current || current
    }, () => {
      this.searchDom.onSearch(0);
    });
  }

  // 搜索按钮的回调
  onSearch = (data, flag) => {
    const params = {
      MchId: data.brandId,
      ActName: data.selectValue
    };
    if (flag !== 0) {
      this.setState({ current: 1 }, () => {
        this.initData(params);
      });
      return;
    }
    this.initData(params);
  }

  initData = () => {

  }
  
  // 新增
  addScheme = (data) => {
    this.setState({
      addShowDialog: true,
      editJson: data
    })
  }

  onClose = () => {
    this.setState({
      addShowDialog: false
    })
  }

  // 新增的回调
  onConfirm = (data, fn) => {
    console.log(data)
    fn()
  }

  /**开启或者关闭收费方案
   * flag true=开始按钮点击    false=关闭按钮点击
   * */ 
  openScheme = (data, flag) => {
    if (flag) { // 开启
      this.setState({
        title: '确定开启 XX品牌的券核销收费方案吗？',
        content: '方案开启后，将采用此品牌券拉新收费方案',
        showEnableVisible: true
      })
    } else { // 关闭
      this.setState({
        title: '确定关闭 XX品牌的券拉新收费方案吗？',
        content: '方案关闭后，品牌券拉新收费方案将采用平台默认收费方案当前平台默认方案： 广告主支付平台 10 Z币/人',
        showEnableVisible: true
      })
    }
  }
  // 开启或者关闭的回调
  openConfirm = (falg) => {
    if (!falg) { // 取消
      this.setState({
        showEnableVisible: false
      })
    } else {

    }
  }

  render() {
    const columns = [
      {
        title: '更新时间',
        width: '200px',
        bodyRender: data => <div>{moment(data.createTime).format('YYYY-MM-DD HH:mm:ss')}</div>
      },
      {
        title: '品牌名称',
        name: 'StockQty'
      },
      {
        title: (
          <React.Fragment>
            <div>拉新服务费（Z币）</div>
            <div>广告主</div>
          </React.Fragment>
        ),
        name: 'StockQty'
      },
      {
        title: '方案有效期',
        width: '200px',
        bodyRender: data => <div>{moment(data.createTime).format('YYYY-MM-DD HH:mm:ss')}</div>
      },
      {
        title: '状态',
        name: 'StockQty'
      },
      {
        title: '操作',
        bodyRender: () => {
          return (
            <div className={`${classNamePre}-contain-control`}>
              <span
                className={`${classNamePre}-contain-control yiye-outline yiye-cursor`}
                tabIndex='0'
                onClick={() => this.addScheme({
                  serviceCharge: 1,
                  rate: 2,
                  timeRange: ["2020-01-20", "2020-01-20"],
                  brandId: 10291,
                })}
              >
              编辑
              </span>
              <span className={`${classNamePre}-contain-control yiye-outline yiye-cursor`} tabIndex='0' onClick={() => this.openScheme({}, false)}>关闭</span>
              <span className={`${classNamePre}-contain-control yiye-outline yiye-cursor`} tabIndex='0' onClick={() => this.openScheme({}, true)}>开启</span>
            </div>
          )
        }
      }
    ];
    // const { CouponCodeStore: { couponCodeList } } = this.props;
    // const { TotalRowsCount, PagedList } = couponCodeList;
    const {
      current, pageSizeList, addShowDialog, addLoading, title, content, showEnableVisible, openLoading, editJson
    } = this.state;
    let PagedList = [{StockQty: 'wws'},{StockQty: 'wwwsdws'},{StockQty: 'wsdwdws'},{StockQty: 'wsdsdws'},{StockQty: '1wws'},{StockQty: 'ww2wsdws'},{StockQty: 'ww6wsdws'},{StockQty: 'wsdw7dws'},{StockQty: 'ws8dsdws'}];
    let TotalRowsCount = 11

    return (
      <div className={classNamePre}>
        {/** 顶部说明 */}
        <div className='yiye-global-top-title'>
          <div>品牌在流量交易过程中如没有配置券拉新服务费，执行平台默认券拉新方案，平台默认券核销收费方案： 广告主支付平台 10 Z币/人 。</div>
        </div>
        {/** 检索区域 */}
        <div>
          <CouponWriteOffSearch
            ref={(ref) => { this.searchDom = ref; }}
            onSearch={this.onSearch}
          />
        </div>
        {/** table区域 */}
        <div className={`${classNamePre}-contain`}>
          <div className={`${classNamePre}-contain-add`}>
            <Button onClick={() => this.addScheme('')}>新增券拉新收费方案</Button>
          </div>
          {
            <Table
              columns={columns}
              datasets={PagedList}
              rowKey="Id"
              pageInfo={{
                totalItem: TotalRowsCount,
                current: current,
                pageSize: pageSizeList
              }}
              onChange={this.onChange}
            />
          }
        </div>
        {/** 新增弹框 */}
        <ChargingSchemeDefaultAdd
          show={addShowDialog}
          title={'新增券拉新收费方案'}
          close={this.onClose}
          confirm={this.onConfirm}
          loading={addLoading}
          serviceLable='券拉新服务费'
          serviceAfterText='Z币/人'
          showRate={true}
          serviceTips='广告主支付给平台，平台默认10元/人'
          data={editJson}
        />
        {/** 关闭弹框 */}
        <DefaultTipDialog
          showEnableVisible={showEnableVisible}
          loading={openLoading}
          title={title}
          content={content}
          confirmEnable ={this.openConfirm}
          maskClosable={false}
        />
      </div>
    )
  }
}
export default CouponLX
