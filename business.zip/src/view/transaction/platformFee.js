import * as React from 'react';
import {
  Table, Button, Notify
} from 'ezrd';
import moment from 'moment';
import { observer, inject } from 'mobx-react';
import { toJS } from 'mobx';
import PlatformFeeSearch from '../../components/transaction/platformFeeSearch';
import PlatformFeeAdd from '../../components/transaction/platformFeeAdd';
import DefaultTipDialog from '../../components/transaction/defaultTipDialog';
import {
  defaultTrancationPlatformFeeStatusType, couponDefaultPage, defaultCategorySettingType, defaultTrancationSettingFee
} from '../../components/base/constant';
import { multiplication, getMchId } from '../../utils/common';
// 新建

const classNamePre = 'merchant-transaction-platform-fee';

@inject('transactionStore')
@observer
class WriteOffRate extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      showEnableVisible: false,
      showDialog: false,
      showEnableVisibleText: '',
      enableJson: {},
      editJson: '',
      defaultFeeJson: {},
      text: '', // 新增和修改的文言
      ...couponDefaultPage
    };
    this.onHandleSearch = this.onHandleSearch.bind(this);
  }

  componentWillMount() {
    this.initData();
    this.initDefautlFee();
  }

  // 点击查询的事件
  onHandleSearch = (data, flag) => {
    if (flag !== 0) {
      this.setState({ current: 1 }, () => {
        this.initData({
          Date: data.CreateOn,
          MchId: data.brandId,
          Status: data.Status || 9
        });
      });
      return;
    }
    this.initData({
      Date: data.CreateOn,
      MchId: data.brandId,
      Status: data.Status || 9
    });
  }

  // 初始化数据
  initData = (params = {}) => {
    const { transactionStore } = this.props;
    const { pageSize, current } = this.state;
    transactionStore.fetchMerchantPlatformFeeList({
      PageSize: pageSize,
      SettingType: defaultCategorySettingType.coupon,
      Page: current,
      Status: 9,
      ...params
    });
  }

  // 初始化平台费用接口
  initDefautlFee = async () => {
    const { transactionStore } = this.props;
    const status = await transactionStore.fetchMerchantDefaultSettingFee({
      MchId: getMchId(),
      SettingType: defaultCategorySettingType.coupon,
      AttrType: defaultTrancationSettingFee.fee
    });
    if (status && !status.IsError) {
      this.setState({
        defaultFeeJson: status.Data
      });
    }
  }

  // 分页的回调
  onChange = (data) => {
    let { current } = this.state;
    const { pageSize } = this.state;
    if (data.pageSize) {
      if (data.pageSize === pageSize) {
        return;
      }
      current = 1;
    }
    this.setState({
      pageSize: data.pageSize || pageSize,
      current: data.current || current
    }, () => {
      this.searchDom.onSearch(0);
    });
  }

  // 新增编辑编辑接口
  confirmAddOrEdit = async (data, callback) => {
    const { transactionStore } = this.props;
    const { editJson } = this.state;
    const status = await transactionStore.fetchMerchantPlatformFeeEdit({
      SettingType: defaultCategorySettingType.coupon,
      Id: editJson.Id || 0,
      PreferentialFee: data.fee,
      PreferentialRate: data.feeRate,
      PreferentialStartDate: data.rangeValue[0],
      PreferentialEndDate: data.rangeValue[1],
      ReferrerFee: data.newFee,
      MchId: data.brandId
    });
    if (!status.IsError) {
      const txt = !editJson.Id ? '新增成功' : '修改成功';
      Notify.success(txt);
      this.searchDom.onSearch(0);
    }
    this.closeDialog();
    callback();
  }

  // 启用禁用接口
  initEnable = async () => {
    const { transactionStore } = this.props;
    const { enableJson } = this.state;
    const status = await transactionStore.fetchMerchantPlatformFeeEnable({
      SettingType: defaultCategorySettingType.coupon,
      Status: enableJson.Status === 0 ? 1 : 0,
      Id: enableJson.Id,
      MchId: enableJson.MchId
    });
    if (!status.isError) {
      Notify.success(enableJson.Status === 1 ? '禁用成功' : '启用成功');
      this.searchDom.onSearch(0);
    }
    this.closeDialog();
  }

  // 打开禁用开启弹出框
  initEnableDialog = (data, flag) => {
    const txt = flag ? '确定禁用此条手续费优惠？' : '确定启用此条手续费优惠？';
    this.setState({
      showEnableVisible: true,
      showEnableVisibleText: txt,
      enableJson: data
    });
  }

  // 打开禁用的回调
  confirmEnable = async (flag) => {
    if (flag) {
      await this.initEnable();
    }
    this.setState({
      showEnableVisible: false,
      showEnableVisibleText: ''
    });
  }

  // 打开弹出框
  showDialog = (flag, data) => {
    this.setState({
      showDialog: true,
      text: flag ? '新增优惠' : '修改优惠',
      editJson: toJS(data)
    });
  }

  // 关闭弹出框
  closeDialog = () => {
    this.setState({
      showDialog: false,
      editJson: ''
    });
  }

  render() {
    const { transactionStore } = this.props;
    const { merchantPlatformFeeList: { Data, Count } } = transactionStore;
    const {
      current, pageSizeList, showDialog, text, showEnableVisible, showEnableVisibleText, editJson, defaultFeeJson
    } = this.state;
    const columns = [
      {
        title: '创建时间',
        bodyRender: data => <div>{moment(data.CreateDate).format('YYYY-MM-DD HH:mm:ss')}</div>
      },
      {
        title: '品牌名称',
        bodyRender: data => (
          <div>{data.MerchantName}</div>
        )
      },
      {
        title: '生效时间',
        bodyRender: data => (
          <div>{moment(data.PreferentialStartDate).format('YYYY-MM-DD HH:mm:ss')}</div>
        )
      },
      {
        title: '结束时间',
        bodyRender: data => (
          <div>{moment(data.PreferentialEndDate).format('YYYY-MM-DD HH:mm:ss')}</div>
        )
      },
      {
        title: (
          <div>
            优惠服务费(元)
            <br />
            供货方
          </div>
        ),
        bodyRender: data => <div>{data.PreferentialFee.toFixed(2)}</div>
      },
      {
        title: (
          <div>
            平台服务费(元)
            <br />
            供货方
          </div>
        ),
        bodyRender: () => (
          <div>{defaultFeeJson.DefaultFee && defaultFeeJson.DefaultFee.toFixed(2)}</div>
        )
      },
      {
        title: (
          <div>
            优惠服务费率
            <br />
            采购方
          </div>
        ),
        bodyRender: data => (
          <div>
            {multiplication(data.PreferentialRate || 0, 100)}
            %
          </div>
        )
      },
      {
        title: (
          <div>
            平台服务费率
            <br />
            采购方
          </div>
        ),
        bodyRender: () => (
          <div>
            {defaultFeeJson.DefaultRate && multiplication(defaultFeeJson.DefaultRate, 100)}
            %
          </div>
        )
      },
      {
        width: '135px',
        title: (
          <div>
            拉新服务费(元/人)
            <br />
            供券方
          </div>
        ),
        bodyRender: data => (
          <div>{data.ReferrerFee.toFixed(2)}</div>
        )
      },
      {
        title: '状态',
        width: '80px',
        bodyRender: (data) => {
          // 0禁用中 ---- 1启用中
          if (data.Status === 1) {
            return (<div>启用中</div>);
          }
          return (<div>已禁用</div>);
        }
      },
      {
        title: '操作',
        bodyRender: (data) => {
          if (data.Status === 1) {
            return (
              <div className={`${classNamePre}-pro-menu`}>
                <span
                  role="button"
                  tabIndex="0"
                  className="yiye-outline btn-default-color yiye-cursor"
                  onClick={() => this.showDialog(false, data)}
                >
                编辑
                </span>
                <span
                  role="button"
                  tabIndex="0"
                  className="yiye-outline btn-default-color yiye-cursor"
                  onClick={() => this.initEnableDialog(data, 1)}
                >
                  禁用
                </span>
              </div>
            );
          }
          return (
            <div className={`${classNamePre}-pro-menu`}>
              <span
                role="button"
                tabIndex="0"
                className="yiye-outline btn-default-color yiye-cursor"
                onClick={() => this.showDialog(false, data)}
              >
                  编辑
              </span>
              <span
                role="button"
                tabIndex="0"
                className="yiye-outline btn-default-color yiye-cursor"
                onClick={() => this.initEnableDialog(data, 0)}
              >
                  启用
              </span>
            </div>
          );
        }
      }
    ];
    return (
      <div className={classNamePre}>
        <PlatformFeeSearch
          data={defaultTrancationPlatformFeeStatusType}
          onSearch={this.onHandleSearch}
          ref={(ref) => { this.searchDom = ref; }}
        />
        {/* table展示区域 */}
        <div className={`${classNamePre}-pro`}>
          <div className={`${classNamePre}-pro-add`}>
            <Button
              type="primary"
              size="middle"
              onClick={() => this.showDialog(true, '')}
            >
            新增优惠
            </Button>
            <span>
              平台默认供货方每张券核销平台手续费
              {defaultFeeJson.DefaultFee && defaultFeeJson.DefaultFee.toFixed(2)}
              元，采购方手续费
              {defaultFeeJson.DefaultRate && multiplication(defaultFeeJson.DefaultRate, 100)}
              %
            </span>
          </div>
          <Table
            columns={columns}
            datasets={Data}
            rowKey="id"
            pageInfo={{
              totalItem: Count,
              current,
              pageSize: pageSizeList
            }}
            onChange={this.onChange}
          />
        </div>
        {/** 新增或者修改的弹出框 */}
        <PlatformFeeAdd
          show={showDialog}
          data={editJson}
          text={text}
          decimalRate={2}
          confirmAddOrEdit={this.confirmAddOrEdit}
          close={this.closeDialog}
        />

        {/* 禁用启用的弹出框 */}
        <DefaultTipDialog
          showEnableVisible={showEnableVisible}
          confirmEnable={this.confirmEnable}
          content={showEnableVisibleText}
        />
      </div>
    );
  }
}


export default WriteOffRate;
