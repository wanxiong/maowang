import * as React from 'react';
import {
  Table, Button, Notify
} from 'ezrd';
import moment from 'moment';
import { observer, inject } from 'mobx-react';
import { toJS } from 'mobx';
import PlatformFeeSearch from '../../components/transaction/platformFeeSearch';
import FreezeRatioAdd from '../../components/transaction/freezeRatioAdd';
import DefaultTipDialog from '../../components/transaction/defaultTipDialog';
import {
  defaultTrancationPlatformFeeStatusType, couponDefaultPage, defaultCategorySettingType, defaultTrancationSettingFee
} from '../../components/base/constant';
import { multiplication, getMchId } from '../../utils/common';
// 新建

const classNamePre = 'merchant-transaction-platform-fee';

@inject('transactionStore')
@observer
class FreezeRatio extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      showEnableVisible: false,
      showDialog: false,
      showEnableVisibleText: '',
      enableJson: {},
      editJson: '',
      defaultFeeJson: {},
      showEnableVisibleTitle: '',
      text: '', // 新增和修改的文言
      ...couponDefaultPage
    };
    this.onHandleSearch = this.onHandleSearch.bind(this);
  }

  componentWillMount() {
    this.initData();
    this.initDefautlFee();
  }

  // 点击查询的事件
  onHandleSearch = (data, flag) => {
    if (flag !== 0) {
      this.setState({ current: 1 }, () => {
        this.initData({
          Date: data.CreateOn,
          MchId: data.brandId,
          Status: data.Status || 9
        });
      });
      return;
    }
    this.initData({
      Date: data.CreateOn,
      MchId: data.brandId,
      Status: data.Status || 9
    });
  }

  // 初始化数据
  initData = (params = {}) => {
    const { transactionStore } = this.props;
    const { pageSize, current } = this.state;
    transactionStore.fetchMerchantFreezeRatioList({
      PageSize: pageSize,
      SettingType: defaultCategorySettingType.coupon,
      Page: current,
      Status: 9,
      ...params
    });
  }

  // 初始化平台费用接口
  initDefautlFee = async () => {
    const { transactionStore } = this.props;
    const status = await transactionStore.fetchMerchantDefaultSettingFee({
      MchId: getMchId(),
      SettingType: defaultCategorySettingType.coupon,
      AttrType: defaultTrancationSettingFee.freezeRatio
    });
    if (status && !status.IsError) {
      this.setState({
        defaultFeeJson: status.Data
      });
    }
  }

  // 分页的回调
  onChange = (data) => {
    let { current } = this.state;
    const { pageSize } = this.state;
    if (data.pageSize) {
      if (data.pageSize === pageSize) {
        return;
      }
      current = 1;
    }
    this.setState({
      pageSize: data.pageSize || pageSize,
      current: data.current || current
    }, () => {
      this.searchDom.onSearch(0);
    });
  }

  // 新增编辑编辑接口
  confirmAddOrEdit = async (data, callback) => {
    const { transactionStore } = this.props;
    const { editJson } = this.state;
    const status = await transactionStore.fetchMerchantFreezeRatioEdit({
      Id: editJson.Id || 0,
      DiscountRate: data.feeRate,
      StartDate: data.rangeValue[0],
      EndDate: data.rangeValue[1],
      SettingType: defaultCategorySettingType.coupon,
      MchId: data.brandId
    });
    if (!status.IsError) {
      const txt = !editJson.Id ? '新增成功' : '修改成功';
      Notify.success(txt);
      this.searchDom.onSearch(0);
    }
    this.closeDialog();
    callback();
  }

  // 启用禁用接口
  initEnable = async () => {
    const { transactionStore } = this.props;
    const { enableJson } = this.state;
    const status = await transactionStore.fetchMerchantFreezeRatioEnable({
      SettingType: defaultCategorySettingType.coupon,
      Status: enableJson.Status === 0 ? 1 : 0,
      Id: enableJson.Id,
      MchId: enableJson.MchId
    });
    if (!status.IsError) {
      Notify.success(enableJson.Status === 0 ? '启用成功' : '禁用成功');
      this.searchDom.onSearch(0);
    }
    this.closeDialog();
  }

  // 打开禁用开启弹出框
  initEnableDialog = (data, flag) => {
    const title = flag ? `确定禁用优惠冻结比例吗？` : `确定启用优惠冻结比例吗？`;
    const num = `${multiplication(data.DiscountRate || 0, 100)}%`;
    const txt = flag ? `目前优惠冻结比例为${num}，禁用后品牌采购时，将采用平台冻结比例进行Z币冻结` : `目前优惠冻结比例为${num}，启用后品牌采购时，将采用优惠冻结比例进行Z币冻结`;
    this.setState({
      showEnableVisible: true,
      showEnableVisibleText: txt,
      showEnableVisibleTitle: title,
      enableJson: data
    });
  }

  // 打开禁用的回调
  confirmEnable = async (flag) => {
    if (flag) {
      await this.initEnable();
    }
    this.setState({
      showEnableVisible: false,
      showEnableVisibleText: '',
      showEnableVisibleTitle: ''
    });
  }

  // 打开弹出框
  showDialog = (flag, data) => {
    this.setState({
      showDialog: true,
      text: flag ? '新增冻结比列' : '修改冻结比列',
      editJson: toJS(data)
    });
  }

  // 关闭弹出框
  closeDialog = () => {
    this.setState({
      showDialog: false,
      editJson: ''
    });
  }

  render() {
    const { transactionStore } = this.props;
    const { merchantFreezeRatioList: { Data, Count } } = transactionStore;
    const {
      current, pageSizeList, showDialog, text, showEnableVisible, showEnableVisibleText, editJson, defaultFeeJson, showEnableVisibleTitle
    } = this.state;
    const columns = [
      {
        title: '新增时间',
        bodyRender: data => <div>{moment(data.CreateOn).format('YYYY-MM-DD HH:mm:ss')}</div>
      },
      {
        title: '品牌名称',
        bodyRender: data => (
          <div>{data.MerchantName}</div>
        )
      },
      {
        title: '生效时间',
        bodyRender: data => (
          <div>{moment(data.StartDate).format('YYYY-MM-DD HH:mm:ss')}</div>
        )
      },
      {
        title: '结束时间',
        bodyRender: data => (
          <div>{moment(data.EndDate).format('YYYY-MM-DD HH:mm:ss')}</div>
        )
      },
      {
        title: '优惠比例',
        bodyRender: data => (
          <div>
            {multiplication(data.DiscountRate || 0, 100)}
            %
          </div>
        )
      },
      {
        title: '平台比例',
        bodyRender: () => (
          <div>
            {defaultFeeJson.DefaultFreezeRate && multiplication(defaultFeeJson.DefaultFreezeRate, 100)}
%
          </div>
        )
      },
      {
        title: '状态',
        bodyRender: (data) => {
          // 0禁用中 ---- 1启用中
          if (data.Status === 1) {
            return (<div>启用中</div>);
          }
          return (<div>已禁用</div>);
        }
      },
      {
        title: '操作',
        bodyRender: (data) => {
          if (data.Status === 1) {
            return (
              <div className={`${classNamePre}-pro-menu`}>
                <span
                  role="button"
                  tabIndex="0"
                  className="yiye-outline btn-default-color yiye-cursor"
                  onClick={() => this.showDialog(false, data)}
                >
                编辑
                </span>
                <span
                  role="button"
                  tabIndex="0"
                  className="yiye-outline btn-default-color yiye-cursor"
                  onClick={() => this.initEnableDialog(data, 1)}
                >
                  禁用
                </span>
              </div>
            );
          }
          return (
            <div className={`${classNamePre}-pro-menu`}>
              <span
                role="button"
                tabIndex="0"
                className="yiye-outline btn-default-color yiye-cursor"
                onClick={() => this.showDialog(false, data)}
              >
                  编辑
              </span>
              <span
                role="button"
                tabIndex="0"
                className="yiye-outline btn-default-color yiye-cursor"
                onClick={() => this.initEnableDialog(data, 0)}
              >
                  启用
              </span>
            </div>
          );
        }
      }
    ];
    return (
      <div className={classNamePre}>
        <PlatformFeeSearch
          data={defaultTrancationPlatformFeeStatusType}
          onSearch={this.onHandleSearch}
          ref={(ref) => { this.searchDom = ref; }}
        />
        {/* table展示区域 */}
        <div className={`${classNamePre}-pro`}>
          <div className={`${classNamePre}-pro-add`}>
            <Button
              type="primary"
              size="middle"
              onClick={() => this.showDialog(true, '')}
            >
            新增冻结比列
            </Button>
            <span>
              平台默认冻结比例
              {defaultFeeJson.DefaultFreezeRate && multiplication(defaultFeeJson.DefaultFreezeRate, 100)}
              %
            </span>
          </div>
          <Table
            columns={columns}
            datasets={Data}
            rowKey="id"
            pageInfo={{
              totalItem: Count,
              current,
              pageSize: pageSizeList
            }}
            onChange={this.onChange}
          />
        </div>
        {/** 新增或者修改的弹出框 */}
        <FreezeRatioAdd
          show={showDialog}
          data={editJson}
          text={text}
          decimalRate={2}
          confirmAddOrEdit={this.confirmAddOrEdit}
          close={this.closeDialog}
        />

        {/* 禁用启用的弹出框 */}
        <DefaultTipDialog
          showEnableVisible={showEnableVisible}
          confirmEnable={this.confirmEnable}
          title={showEnableVisibleTitle}
          content={showEnableVisibleText}
        />
      </div>
    );
  }
}


export default FreezeRatio;
