import * as React from 'react';
import {
  Pagination, Dialog, NumberInput, Button, Notify
} from 'ezrd';
import { observer, inject } from 'mobx-react';
import WriteOffRateSearch from '../../components/transaction/writeOffRateSearch';
import WriteOffDialog from '../../components/transaction/writeOffDialog';
import { couponDefaultPage, defaultCategorySettingType, defaultTrancationSettingFee } from '../../components/base/constant';
import { multiplication, getMchId, division } from '../../utils/common';
// 新建

const classNamePre = 'merchant-transaction-write-off';

@inject('transactionStore')
@observer
class WriteOffRate extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      visible: false,
      editValue: '',
      loading: false,
      addLoading: false,
      showAddWriteOff: false,
      json: {},
      defaultFeeJson: {},
      ...couponDefaultPage
    };
    this.onHandleSearch = this.onHandleSearch.bind(this);
  }

  componentWillMount() {
    this.initData();
    this.initDefautlFee();
  }

  // 点击查询的事件
  onHandleSearch = (data, flag) => {
    if (flag !== 0) {
      this.setState({ current: 1 }, () => {
        this.initData({
          StartDate: data.StartDate,
          EndDate: data.EndDate,
          MchId: data.brandId
        });
      });
      return;
    }
    this.initData({
      StartDate: data.StartDate,
      EndDate: data.EndDate,
      MchId: data.brandId
    });
  }

  // 初始化数据
  initData = (params = {}) => {
    const { transactionStore } = this.props;
    const { pageSize, current } = this.state;
    transactionStore.fetchMerchantWriteRateList({
      PageSize: pageSize,
      SettingType: defaultCategorySettingType.coupon,
      Page: current,
      Status: 9,
      ...params
    });
  }

  // 每页大小的回调
  onPageSizeChange = (size) => {
    const { pageSize } = this.state;
    if (size === pageSize) {
      return;
    }
    this.setState({
      pageSize: size,
      current: 1
    }, () => {
      this.searchDom.onSearch(0);
    });
  };

  // 分页的回调
  onChange = (data) => {
    const { current } = this.state;
    this.setState({
      current: data || current
    }, () => {
      this.searchDom.onSearch(0);
    });
  }

  // 核销编辑接口
  initEdit = async (value) => {
    const { transactionStore } = this.props;
    const { json } = this.state;
    this.setState({ loading: true });
    const status = await transactionStore.fetchMerchantWriteRateEdit({
      InitCancelRate: division(value, 100),
      Id: json.Id,
      SettingType: defaultCategorySettingType.coupon,
      MchId: json.MchId
    });
    if (!status.isError) {
      Notify.success('修改成功');
      this.searchDom.onSearch(0);
    }
    this.closeDialog();
  }

  // 初始化平台费用接口
  initDefautlFee = async () => {
    const { transactionStore } = this.props;
    const status = await transactionStore.fetchMerchantDefaultSettingFee({
      MchId: getMchId(),
      SettingType: defaultCategorySettingType.coupon,
      AttrType: defaultTrancationSettingFee.writeOf
    });
    if (status && !status.IsError) {
      this.setState({
        defaultFeeJson: status.Data
      });
    }
  }

  // 打开弹出框
  openDialog = (item) => {
    this.setState({
      visible: true,
      json: item
    });
  }

  onChangeEdit = (e) => {
    this.setState({
      editValue: e.target.value
    });
  }

  // 新增初始化核销率
  addWriteOff = async (params, fn) => {
    const { transactionStore } = this.props;
    const status = await transactionStore.fetchMerchantWriteRateAdd({
      SettingType: defaultCategorySettingType.coupon,
      ...params
    });
    if (status && !status.IsError) {
      Notify.success('新增初始化核销率成功');
      this.searchDom.onSearch(1);
      this.showAddDialog(false);
      fn();
    }
    this.setState({ addLoading: false });
  }

  // 关闭弹出框
  closeDialog = () => {
    this.setState({
      editValue: '',
      visible: false,
      loading: false,
      json: {}
    });
  }

  // 确认修改
  confirmEdit = () => {
    const { editValue } = this.state;
    if (!editValue && editValue !== 0) {
      Notify.error('请输入核销率');
      return;
    }
    this.initEdit(editValue);
  }

  // 新增初始核销率的回调
  addConfirm = (data, fn) => {
    this.setState({ addLoading: true });
    const params = {
      // MchId: getMchId(),
      MchId: data.brandId,
      InitCancelRate: data.feeRate,
      ClientPrice: data.price
    };
    this.addWriteOff(params, fn);
  }

  showAddDialog = (flag) => {
    this.setState({
      showAddWriteOff: flag
    });
  }

  addClose = () => {
    this.showAddDialog(false);
  }

  render() {
    const { transactionStore, history } = this.props;
    const { merchantWriteRateList: { Data, Count } } = transactionStore;
    const {
      current, pageSizeList, visible, editValue, loading, defaultFeeJson, showAddWriteOff, addLoading
    } = this.state;
    return (
      <div className={classNamePre}>
        <WriteOffRateSearch
          data={[]}
          show={false}
          typeName="核销率"
          history={history}
          showTime
          downloadStore={transactionStore}
          downloadType="writeOff"
          onSearch={this.onHandleSearch}
          ref={(ref) => { this.searchDom = ref; }}
        />
        <div className={`${classNamePre}-pro`}>
          <div className={`${classNamePre}-tips`}>
            <Button
              type="primary"
              size="middle"
              onClick={() => this.showAddDialog(true)}
            >
              新增初始核销率
            </Button>
            <span>
              平台初始化核销率
              {' '}
              {defaultFeeJson.InitCancelRate && multiplication(defaultFeeJson.InitCancelRate, 100)}
              %，客单价
              {defaultFeeJson.ClientPrice && defaultFeeJson.ClientPrice.toFixed(2)}
              元
            </span>
          </div>
          <div className={`${classNamePre}-pro-head`}>
            <span>入驻时间</span>
            <span>品牌名称</span>
            <span>店铺核销率</span>
            <span>初始核销率</span>
            <span>客单价</span>
          </div>
          {
            Data.map(item => (
              <div
                key={item.Id}
                className={`${classNamePre}-pro-item`}
              >
                <div>
                  {' '}
                  品牌ID：
                  {item.MchId}
                  ，公司名称：
                  {item.OrganizationName}
                </div>
                <ul>
                  <li>{item.Date}</li>
                  <li>{item.MerchantName}</li>
                  <li>
                    {multiplication(item.CancelRate, 100).toFixed(2)}
                    %
                  </li>
                  <li>
                    {multiplication(item.InitCancelRate, 100).toFixed(2)}
                    %
                    <text
                      className={`${classNamePre}-pro-edit`}
                      onClick={() => this.openDialog(item)}
                      role="button"
                      tabIndex="0"
                    >
                        更改
                    </text>
                  </li>
                  <li>{item.ClientPrice.toFixed(2)}</li>
                </ul>
              </div>
            ))
          }
          {/* 分页区域 */}
          <Pagination
            current={current}
            totalItem={Count}
            onChange={this.onChange}
            pageSize={pageSizeList}
            onPageSizeChange={this.onPageSizeChange}
          />
        </div>
        {/** 修改弹出框 */}
        <Dialog
          title="修改初始核销率"
          visible={visible}
          onClose={() => this.closeDialog()}
          style={{ width: '600px' }}
          maskClosable={false}
          footer={(
            <div>
              <Button
                outline
                loading={loading}
                onClick={() => this.closeDialog()}
              >
              取消
              </Button>
              <Button
                loading={loading}
                onClick={() => this.confirmEdit()}
              >
              确定
              </Button>
            </div>
            )}
        >
          <NumberInput
            signleBorder
            placeholder="请输入修改的核销率（%）"
            showClear
            min={0}
            max={100}
            width="100%"
            decimal={2}
            value={editValue}
            onChange={this.onChangeEdit}
          />
        </Dialog>
        {/* 新增初始核销率的弹框 */}
        <WriteOffDialog
          show={showAddWriteOff}
          confirm={this.addConfirm}
          close={this.addClose}
          text="新增初始核销率"
          decimalRate={2}
          decimalPrice={2}
          loading={addLoading}
        />
      </div>
    );
  }
}


export default WriteOffRate;
