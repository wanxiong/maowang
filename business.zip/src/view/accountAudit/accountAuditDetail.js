import * as React from 'react';
import { observer, inject } from 'mobx-react';
import AccountInfoLook from './accountInfoLook';
// 新建

const classNamePre = 'merchant-account-audit';

@inject('accountAuditStore')
@observer
class AccountAuditDetail extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
    };
  }

  render() {
    const { match } = this.props;
    const { params: { id } } = match;
    return (
      <div className={classNamePre}>
        <AccountInfoLook
          type="look"
          MchId={id}
        />
      </div>
    );
  }
}


export default AccountAuditDetail;
