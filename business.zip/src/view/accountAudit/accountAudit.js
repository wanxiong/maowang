import * as React from 'react';
import {
  Pagination, Button
} from 'ezrd';
import { observer, inject } from 'mobx-react';
import AccountAuditSearch from '../../components/accountAudit/accountAuditSearch';
import AccountAuditItem from '../../components/accountAudit/accountAuditItem';
import { couponDefaultPage } from '../../components/base/constant';
import { getMchId } from '../../utils/common';
import AccountAuditInitBrandDialog from '../../components/accountAudit/accountAuditInitBrandDialog';

const classNamePre = 'merchant-account-audit';

@inject('accountAuditStore')
@observer
class AccountAudit extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      showInitDialog: false,
      ...couponDefaultPage
    };
  }

  async componentDidMount() {
    this.initData();
  }

  // 点击查询的事件
  onHandleSearch = (data, flag) => {
    if (flag !== 0) {
      this.setState({ current: 1 }, () => {
        this.initData({
          StartDate: data.StartDate,
          EndDate: data.EndDate,
          QueryMchId: data.brandId,
          Status: data.status,
          AccountType: data.type
        });
      });
      return;
    }
    this.initData({
      StartDate: data.StartDate,
      EndDate: data.EndDate,
      QueryMchId: data.brandId,
      Status: data.status,
      AccountType: data.type
    });
  }

  // 每页大小的回调
  onPageSizeChange = (size) => {
    const { pageSize } = this.state;
    if (size === pageSize) {
      return;
    }
    this.setState({
      pageSize: size,
      current: 1
    }, () => {
      this.searchDom.onSearch(0);
    });
  };

  // 分页的回调
  onChange = (data) => {
    const { current } = this.state;
    this.setState({
      current: data || current
    }, () => {
      this.searchDom.onSearch(0);
    });
  }

  initData = async (params) => {
    const { accountAuditStore } = this.props;
    const { current, pageSize } = this.state;
    await accountAuditStore.fetchMerchantApplyList({
      MchId: getMchId(),
      PageSize: pageSize,
      Page: current,
      Status: 9,
      AccountType: 9,
      ...params
    });
  }

  // 需要同步API列表的回调
  changeData = (fn) => {
    this.searchDom.onSearch(0);
    fn();
  }

  initDialog = () => {
    this.setState({
      showInitDialog: true
    });
  }

  onClose = () => {
    this.setState({
      showInitDialog: false
    });
  }

  onConfirm = () => {
    this.onClose();
    this.searchDom.onSearch(0);
  }

  render() {
    const { current, pageSizeList, showInitDialog } = this.state;
    const { history, accountAuditStore } = this.props;
    const { merchantApplyList: { Count, Data } } = accountAuditStore;
    return (
      <div className={classNamePre}>
        {/* 描述 */}
        <div>
          <div
            className="yiye-global-top-title"
          >
            <div>完成账号审核后，可再对开通的功能设置其他参数</div>
          </div>
        </div>
        {/** 头部搜索区域 */}
        <AccountAuditSearch
          typeName="账户审核"
          onSearch={this.onHandleSearch}
          ref={(ref) => { this.searchDom = ref; }}
        />
        {/** 列表区域 */}
        <div className={`${classNamePre}-pro`}>
          <div className={`${classNamePre}-tips`}>
            <div>
              <Button onClick={this.initDialog}>初始化品牌客户</Button>
            </div>
            <div>普通账户需要缴纳保证金，担保账户无需保证金</div>
          </div>
          <div className={`${classNamePre}-pro-head`}>
            <span>入驻时间</span>
            <span>Z币</span>
            <span>保证金</span>
            <span>余额</span>
            <span>状态</span>
            <span>操作</span>
          </div>
          {/* 列表渲染区域 */}
          <div>
            {
              Data.map((item, index) => (
                <AccountAuditItem
                  key={item.Id}
                  classNamePre={`${classNamePre}-pro-product-item`}
                  history={history}
                  data={item}
                  index={index}
                  store={accountAuditStore}
                  changeData={this.changeData}
                />
              ))
            }

          </div>
          {/* 分页区域 */}
          <Pagination
            current={current}
            totalItem={Count}
            onChange={this.onChange}
            pageSize={pageSizeList}
            onPageSizeChange={this.onPageSizeChange}
          />
        </div>
        {/** 初始化弹框 */}
        <AccountAuditInitBrandDialog
          show={showInitDialog}
          onClose={this.onClose}
          confirm={this.onConfirm}
        />
      </div>
    );
  }
}


export default AccountAudit;
