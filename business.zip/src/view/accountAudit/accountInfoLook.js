import * as React from 'react';
import { withRouter } from 'react-router-dom';
import {
  Form, Button
} from 'ezrd';
import { observer, inject } from 'mobx-react';
import { ConstFormBetween, ConstFormSelectIndustry, ConstFormCascaderCategory } from '../../components/base/constForm';
import { ConstFormImage, ConstFormUpload } from '../../components/base/constFormImage';
import { Editor } from '../../components/base/constEdit';

const {
  Field, FormInputField, createForm, FormCheckboxField
} = Form;

const classNamePre = 'yiye-account-info';

// 注入
@withRouter
@inject('accountStore')
@observer
class AccountInfoForm extends React.Component {
  static defaultProps = {
    type: '', // look status 代表查看或者审核
    loading: false, // 点击审核按钮得操作
    MchId: ''
  }

  constructor(prop) {
    super(prop);
    this.state = {
      industry: [],
      editData: {},
      category: [],
      BusinessLicenseUrl: ''
    };
  }

  async componentDidMount() {
    const { accountStore, MchId } = this.props;
    const { Data } = await accountStore.fetchMerchantStatus({
      MchId
    });
    this.setState({
      editData: Data
    });
    this.initIndustry();
    this.initCategory();
    this.initBusinessLicense();
  }

  // 所属行业初始化接口
  initIndustry = async () => {
    const { accountStore } = this.props;
    const { Data } = await accountStore.fetchAccountInfoIndustryList({});
    const data = Data.filter(item => item.ParentId === 0);
    this.setState({ industry: data });
  }

  initCategory = async () => {
    const { accountStore } = this.props;
    const { Data } = await accountStore.fetchAccountInfoSelectAll({});
    const parent = [];
    const children = [];
    Data.forEach((item) => {
      if (item.ParentId === 0) { // 一级别
        parent.push(item);
      } else {
        children.push(item);
      }
    });
    const newArr = parent.map((item) => {
      const obj = {
        id: item.Id,
        title: item.Name,
        ParentId: item.ParentId,
        children: []
      };
      for (let i = 0; i < children.length; i++) {
        if (children[i].ParentId === item.Id) {
          obj.children.push({
            id: children[i].Id,
            title: children[i].Name,
            ParentId: children[i].ParentId
          });
        }
      }
      return obj;
    });
    this.setState({ category: newArr || [] });
  }

  // 获取营业执照图片接口
  initBusinessLicense = async () => {
    const { accountStore, MchId } = this.props;
    const data = await accountStore.fetchGetBusinessLicense({
      MchId
    });
    if (!data.IsError) {
      if (data.Data && data.Data.BusinessLicenseImage) {
        this.setState({ BusinessLicenseUrl: data.Data.BusinessLicenseImage });
      }
    }
  }

  back = () => {
    const { history } = this.props;
    history.goBack(-1);
  }

  // 通过拒绝审核
  confirm = (flag) => {
    const { confirm } = this.props;
    confirm(flag);
  }

  //
  initBtnTpl = () => {
    const { type, loading } = this.props;
    if (type === 'look') {
      return (
        <div className={`${classNamePre}-group-btn`}>
          <Button
            type="primary"
            size="middle"
            outline
            onClick={this.back}
          >
          返回
          </Button>
        </div>
      );
    }
    if (type === 'status') {
      return (
        <div className={`${classNamePre}-group-btn`}>
          <Button
            type="primary"
            size="middle"
            loading={loading}
            style={{ 'margin-right': '20px' }}
            onClick={() => this.confirm(true)}
          >
            通过审核
          </Button>
          <Button
            type="primary"
            size="middle"
            outline
            loading={loading}
            onClick={() => this.confirm(false)}
          >
            拒绝审核
          </Button>
        </div>
      );
    }
    return null;
  }

  render() {
    const { accountStore } = this.props;
    const {
      industry, editData, category, BusinessLicenseUrl
    } = this.state;
    return (
      <div className={`${classNamePre}`}>
        <div className={`${classNamePre}-pro`}>
          <Form horizontal>
            {/* 基础配置 */}
            <div className={`${classNamePre}-base`}>
              <div className={`${classNamePre}-base-title`}>
                基础配置
                <span />
              </div>
              <FormInputField
                name="MerchantName"
                type="text"
                label="品牌"
                required
                showCount
                width={320}
                maxLength={30}
                value={editData.MerchantName ? editData.MerchantName : ''}
                disabled
                placeholder="品牌简介"
              />
              <FormInputField
                name="OrganizationName"
                type="text"
                label="公司名称"
                maxLength={30}
                showCount
                width={320}
                required
                disabled
                value={editData.OrganizationName ? editData.OrganizationName : ''}
                placeholder="公司名称与营业执照一致"
              />
              <Field
                name="IndustryId"
                type="text"
                label="所属行业"
                component={ConstFormSelectIndustry}
                parent={industry}
                disabled
                helpDesc="请根据你的营业执照和实际售卖商品来选择行业，审核通过后不可修改"
                value={editData.IndustryId ? editData.IndustryId : ''}
              />
              <Field
                name="CommodityTypeIds"
                type="text"
                label="经营类目"
                component={ConstFormCascaderCategory}
                accountStore={accountStore}
                data={category}
                disabled
                value={
                  editData.CommodityTypeJson ? JSON.parse(editData.CommodityTypeJson) : []
                }
                className={`${classNamePre}-category`}

              />
              <Field
                name="Logo"
                type="text"
                label="品牌LOGO"
                disabled
                component={ConstFormImage}
                value={editData.Logo ? { url: editData.Logo, filePath: editData.ShortLogo } : ''}
              />
              <Field
                name="BusinessLicense"
                type="text"
                label="营业执照"
                disabled
                component={ConstFormUpload}
                value={
                  BusinessLicenseUrl
                    ? { src: BusinessLicenseUrl }
                    : {}
                }
              />

              <Field
                name="About"
                type="text"
                label="品牌简介"
                component={Editor}
                readOnly
                className={`${classNamePre}-edit-con`}
                value={editData.About ? { text: editData.About, init: true } : { text: '', init: false }}
              />
              <Field
                name="AgeRange"
                type="text"
                label="品牌人群年龄"
                component={ConstFormBetween}
                value={
                  editData.AgeRange
                    ? [editData.AgeRange.split('-')[0], editData.AgeRange.split('-')[1]]
                    : ''
                }
                centerTxt="至"
                max2={100}
                min={1}
                min2={1}
                endTxt="岁"
                disabled
                tip=""
              />
              <FormCheckboxField
                name="ShopStatus"
                label="店铺状态:"
                helpDesc="下架后，店铺及商品将歇业，无法再被浏览"
                value={!editData.ShopStatus}
                disabled
              >
                下架店铺
              </FormCheckboxField>
            </div>
            {/* 运营人员信息 */}
            <div className={`${classNamePre}-person`}>
              <div className={`${classNamePre}-base-title`}>
                运营人员信息
                <span />
              </div>
              <FormInputField
                name="ContactName"
                type="text"
                label="负责人"
                required
                placeholder="姓名"
                width={320}
                showCount
                disabled
                maxLength={10}
                value={editData.ContactName ? editData.ContactName : ''}
              />
              <FormInputField
                name="ContactMobile"
                type="text"
                label="手机号"
                required
                width={320}
                placeholder="手机号"
                maxLength={11}
                showCount
                disabled
                value={editData.ContactMobile ? editData.ContactMobile : ''}
              />
              <FormInputField
                name="ContactEmail"
                type="text"
                label="邮箱"
                required
                width={320}
                maxLength={32}
                showCount
                disabled
                placeholder="邮箱"
                value={editData.ContactEmail ? editData.ContactEmail : ''}
              />
            </div>
            {
                this.initBtnTpl()
              }
          </Form>
        </div>
      </div>
    );
  }
}

const AccountInfoLook = createForm()(AccountInfoForm);

export default AccountInfoLook;
