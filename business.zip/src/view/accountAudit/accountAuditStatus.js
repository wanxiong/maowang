import * as React from 'react';
import { observer, inject } from 'mobx-react';
import {
  Dialog, Button, Notify, Input
} from 'ezrd';
import AccountInfoLook from './accountInfoLook';
import { trim } from '../../utils/common';
// 新建

const classNamePre = 'merchant-account-audit';

@inject('accountAuditStore')
@observer
class AccountAuditStatus extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      loading: false,
      visible: false,
      value: ''
    };
  }

  componentDidMount() {
  }

  //
  confirm = async (flag) => {
    if (flag) {
      this.initCheck(flag);
    } else {
      this.triggerDialog(true);
    }
  }

  // false 拒绝   true 通过
  initCheck = async (flag) => {
    const { accountAuditStore, match } = this.props;
    const { value } = this.state;
    this.setState({ loading: true });
    const status = await accountAuditStore.fetchMerchantApplyCheck({
      IsPass: flag ? 1 : 0,
      Remark: value,
      MchId: match.params.id
    });
    if (status && !status.IsError) {
      Notify.success('审核成功');
      window.history.back();
    }
    this.setState({ loading: false });
  }

  triggerDialog = (visible) => {
    if (!visible) {
      this.setState({
        value: '',
        visible
      });
      return;
    }
    this.setState({ visible });
  }

  handleChange = (e) => {
    this.setState({ value: e.target.value });
  }

  checkApply = () => {
    const { value } = this.state;
    if (!trim(value)) {
      Notify.error('请输入拒绝审核理由');
      return;
    }
    this.initCheck(false);
  }

  render() {
    const { loading, visible, value } = this.state;
    const { match } = this.props;
    const { params: { id } } = match;
    return (
      <div className={classNamePre}>
        <AccountInfoLook
          type="status"
          confirm={this.confirm}
          loading={loading}
          MchId={id}
        />
        {/** 弹出框 */}
        <Dialog
          title="审核意见"
          visible={visible}
          onClose={() => this.triggerDialog(false)}
          style={{ width: '450px' }}
          footer={(
            <div>
              <Button
                outline
                loading={loading}
                onClick={() => this.triggerDialog(false)}
              >
              取消
              </Button>
              <Button
                loading={loading}
                onClick={() => this.checkApply(false)}
              >
              确定
              </Button>
            </div>
          )}
        >
          <Input
            type="textarea"
            value={value}
            width="100%"
            onChange={this.handleChange}
            maxLength={100}
            placeholder="请输入拒绝审核理由"
            showCount
          />
        </Dialog>
      </div>
    );
  }
}


export default AccountAuditStatus;
