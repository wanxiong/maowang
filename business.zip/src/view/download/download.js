import * as React from 'react';
import {
  Table, Notify
} from 'ezrd';
import { observer, inject } from 'mobx-react';
import moment from 'moment';
import { couponDefaultPage } from '../../components/base/constant';
import DownloadSearch from '../../components/download/downloadSearch';
import { downLoadUrl, getMchId } from '../../utils/common';
import DefaultTipDialog from '../../components/transaction/defaultTipDialog';

// 新建
import '../../styles/download.less';

const classNamePre = 'yiye-download';

@inject('downloadStore')
@observer
class DownLoad extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      typeList: [], // 下载类型数据源
      delLoading: false,
      showDelDialog: false,
      delData: '',
      ...couponDefaultPage
    };
    this.onHandleSearch = this.onHandleSearch.bind(this);
  }

  async componentDidMount() {
    this.initDownloadTyle();
    this.initData();
  }

// 点击查询的事件
onHandleSearch = (data, flag) => {
  if (flag !== 0) {
    this.setState({ current: 1 }, () => {
      this.initData({
        Type: data.currentSelect || 0,
        TaskName: data.fileName,
        BegDate: data.rangeValue[0],
        EndDate: data.rangeValue[1]
      });
    });
    return;
  }
  this.initData({
    Type: data.currentSelect || 0,
    TaskName: data.fileName,
    BegDate: data.rangeValue[0],
    EndDate: data.rangeValue[1]
  });
}

// 分页的回调
onChange = (data) => {
  let { current } = this.state;
  const { pageSize } = this.state;
  if (data.pageSize) {
    if (data.pageSize === pageSize) {
      return;
    }
    current = 1;
  }
  this.setState({
    pageSize: data.pageSize || pageSize,
    current: data.current || current
  }, () => {
    this.searchDom.onSearch(0);
  });
}

// 初始化数据
initData = (params = {}) => {
  const { downloadStore } = this.props;
  const { pageSize, current } = this.state;
  downloadStore.fetchDownLoadList({
    PageSize: pageSize,
    PageIndex: current,
    MchId: getMchId(),
    ...params
  });
}

// 下载
down = async (data) => {
  const { downloadStore } = this.props;
  if (data.Type < 100) {
    const status = await downloadStore.fetchDownLoadCrm({
      id: data.Id
    });
    if (!status.IsError) {
      downLoadUrl(status.Data, data.VirtualName);
    }
    return;
  }
  const status = await downloadStore.fetchDownLoad({
    TaskId: data.Id,
    MchId: getMchId()
  });
  if (!status.IsError) {
    downLoadUrl(status.Data, data.VirtualName);
  }
}

// 重新计算
reset = async (data) => {
  const { downloadStore } = this.props;
  if (data.Type < 100) {
    const status = await downloadStore.fetchDownLoadResetCrm({
      id: data.Id
    });
    if (!status.IsError) {
      Notify.success('重新计算成功');
      this.searchDom.onSearch(0);
    }
    return;
  }
  const status = await downloadStore.fetchDownLoadReset({
    TaskId: data.Id,
    TaskyType: data.Type,
    MchId: getMchId()
  });
  if (!status.IsError) {
    Notify.success('重新计算成功');
    this.searchDom.onSearch(0);
  }
}

// 获取文件下载类型
initDownloadTyle = async () => {
  const { downloadStore } = this.props;
  const status = await downloadStore.fetchDownLoadTypeList({ MchId: getMchId() });
  if (!status.IsError) {
    this.setState({
      typeList: status.Data
    });
  }
}

// 删除
del = async (data) => {
  this.setState({
    delData: data,
    showDelDialog: true
  });
}


// 真正的删除
delConfirm = async (flag) => {
  if (!flag) {
    this.setState({
      showDelDialog: false,
      delData: ''
    });
    return;
  }
  this.setState({
    delLoading: true
  });
  const { downloadStore } = this.props;
  const { delData } = this.state;
  if (delData.Type < 100) {
    const status = await downloadStore.fetchDownLoadDeleteCrm({
      id: delData.Id
    });
    if (!status.IsError) {
      Notify.success('删除成功');
      this.searchDom.onSearch(0);
      this.setState({
        showDelDialog: false,
        delLoading: false
      });
    }
    return;
  }
  const status = await downloadStore.fetchDownLoadDelete({
    id: delData.Id,
    MchId: getMchId()
  });
  if (!status.IsError) {
    Notify.success('删除成功');
    this.searchDom.onSearch(0);
    this.setState({
      showDelDialog: false,
      delLoading: false
    });
  }
}

render() {
  const { downloadStore: { downLoadList } } = this.props;
  const { TotalRowsCount, PagedList } = downLoadList;
  const {
    current, pageSizeList, typeList, delLoading, showDelDialog
  } = this.state;
  const columns = [
    {
      title: '序列号',
      bodyRender: data => <div>{data.Id}</div>
    },
    {
      title: '下载日期',
      bodyRender: data => <div>{moment(data.LastComputingTime).format('YYYY-MM-DD HH:mm:ss')}</div>
    },
    {
      title: '文件名称',
      bodyRender: data => <div>{data.VirtualName}</div>
    },
    {
      title: '数据量',
      bodyRender: data => <div>{data.Number}</div>
    },
    {
      title: '任务状态',
      bodyRender: (data) => {
        // 0提交中  1处理中 2已完成  3异常 9已删除 4数据为空
        if (data.Status === 0) {
          return (<div>提交中</div>);
        } if (data.Status === 1) {
          return (<div>处理中</div>);
        } if (data.Status === 2) {
          return (<div>成功</div>);
        } if (data.Status === 3) {
          return (<div>失败</div>);
        } if (data.Status === 4) {
          return (<div>数据为空</div>);
        } if (data.Status === 9) {
          return (<div>已删除</div>);
        }
        return (<div>--</div>);
      }
    },
    {
      title: '操作人',
      bodyRender: data => <div>{data.CreateUser || '--'}</div>
    },
    {
      title: '操作',
      bodyRender: (data) => {
        // 0提交中  1处理中 2已完成  3异常 9已删除
        if (data.Status === 1 || data.Status === 0) {
          return (
            <span
              type="primary"
              role="button"
              tabIndex="0"
              className={`yiye-outline btn-default-color ${classNamePre}-span`}
              onClick={event => this.del(data, event)}
            >
              删除
            </span>
          );
        } if (data.Status === 2) {
          return (
            <div className={`${classNamePre}-menu`}>
              <span
                type="primary"
                role="button"
                tabIndex="0"
                className={`yiye-outline btn-default-color ${classNamePre}-span`}
                onClick={event => this.down(data, event)}
              >
                下载
              </span>
              <span
                type="primary"
                role="button"
                tabIndex="0"
                className={`yiye-outline btn-default-color ${classNamePre}-span`}
                onClick={event => this.reset(data, event)}
              >
                重新计算
              </span>
              <span
                type="primary"
                role="button"
                tabIndex="0"
                className={`yiye-outline btn-default-color ${classNamePre}-span`}
                onClick={event => this.del(data, event)}
              >
                删除
              </span>
            </div>
          );
        } if (data.Status === 3) {
          return (
            <div className={`${classNamePre}-menu`}>
              <span
                type="primary"
                role="button"
                tabIndex="0"
                className={`yiye-outline btn-default-color ${classNamePre}-span`}
                onClick={event => this.del(data, event)}
              >
                删除
              </span>
            </div>
          );
        } if (data.Status === 9 || data.Status === 4) {
          return (
            <span>--</span>
          );
        }
        return null;
      }
    }
  ];
  return (
    <div className={`${classNamePre}`}>
      {/* 文件时间提示 */}
      <div className="yiye-global-top-title">
        <div>
            本页面展示近半年的下载记录，具体下载的文件保留1个月可操作
        </div>
      </div>
      {/* 检索区域 */}
      <DownloadSearch
        onSearch={this.onHandleSearch}
        data={typeList}
        ref={(ref) => { this.searchDom = ref; }}
      />
      {/* table展示区域 */}
      <div className={`${classNamePre}-pro`}>
        <Table
          columns={columns}
          datasets={PagedList}
          rowKey="id"
          pageInfo={{
            totalItem: TotalRowsCount,
            current,
            pageSize: pageSizeList
          }}
          onChange={this.onChange}
        />
      </div>
      {/** 删除弹框 */}
      <DefaultTipDialog
        showEnableVisible={showDelDialog}
        content="您要删除本条数据，是否继续操作？"
        loading={delLoading}
        confirmEnable={this.delConfirm}
        title="操作提示"
        maskClosable={false}
      />
    </div>
  );
}
}

export default DownLoad;
