import * as React from 'react';
import {
  Input, Button, Notify
} from 'ezrd';
import { observer, inject } from 'mobx-react';
import md5 from 'js-md5';
import { checkEmail, getUrlkey, setCookie } from '../../utils/common';
import { LoginToken, LoginTYPE } from '../../components/base/constant';
// 新建

@inject('loginStore')
@observer
class LoginForm extends React.Component {
  static defaultProps = {
    classNamePre: ''
  }

  constructor(prop) {
    super(prop);
    this.state = {
      loading: false,
      email: '',
      password: '',
      errors: {
        email: {
          status: false,
          message: ''
        },
        password: {
          status: false,
          message: ''
        }
      }
    };
  }

  componentWillMount() {
    const { history } = this.props;
    const params = getUrlkey(history.location.search);
    if (params.Token) { // 来自跳转 自动登陆即可
      localStorage.setItem(LoginToken, JSON.stringify(params));
      this.initLoginInfo(true);
    }
  }

  // 提交操作
  onSave = async () => {
    const { loginStore } = this.props;
    const { email, password } = this.state;
    if (this.validate()) {
      this.setState({ loading: true });
      const status = await loginStore.fetchLogin({
        UserName: email,
        Password: md5(password)
      });
      if (status && !status.IsError) {
        localStorage.setItem(LoginToken, JSON.stringify(status.Data));
        this.initLoginInfo();
      } else {
        this.setState({ loading: false });
      }
    }
  }

  initLoginInfo = async () => {
    const { loginStore, history } = this.props;
    const status = await loginStore.fetchMerchantSelf({});
    if (status && !status.IsError) {
      Notify.success('登录成功');
      setCookie('MerchantId', status.Data.Id);
      localStorage.setItem(LoginTYPE, JSON.stringify(status.Data));
      // if (status.Data.MerchantType === 0) { // 超级VIP/平台账号
      //   history.push('/Yiye/Account/Audit');
      // } else { // 商户账号
      //   history.push('/Yiye/Account/AccountInfo/AssetManageList');
      // }
      history.push('/');
    }
    this.setState({ loading: false });
  }

  // 忘记密码
  forgetPassword = () => {
    const { forgetPassWord } = this.props;
    forgetPassWord('forgetPassword');
  }

  // 通用输入框的事件
  defaultChange = (e) => {
    this.setState({
      [e.target.name]: e.target.value
    });
  }

  // 验证输入
  validate = () => {
    const { password, email, errors } = this.state;
    if (!email) {
      errors.email.status = true;
      errors.email.message = '请输入邮箱账号';
      this.setState({ errors });
    } else {
      errors.email.status = false;
    }
    if (!checkEmail(email)) {
      errors.email.status = true;
      errors.email.message = '请输入正确格式的邮箱账号';
      this.setState({ errors });
    } else {
      errors.email.status = false;
    }

    if (!password) {
      errors.password.status = true;
      errors.password.message = '请输入登录密码';
      this.setState({ errors });
    } else {
      errors.password.status = false;
    }

    if (!errors.password.status && !errors.email.status) {
      return true;
    }
    return false;
  }

  render() {
    const {
      loading, errors, email, password
    } = this.state;
    const { classNamePre } = this.props;
    return (
      <div className={classNamePre}>
        <div className={`${classNamePre}-title`}>登录</div>
        <div className={`${classNamePre}-default`}>
          <div className={errors.email.status ? `${classNamePre}-default-error` : ''}>
            <lable>邮箱账号</lable>
            <Input
              className={`${classNamePre}-default-nostyle`}
              name="email"
              onChange={this.defaultChange}
              value={email}
              width="220px"
              placeholder="请输入邮箱账号"
            />
          </div>
          {
            errors.email.status
              ? (<div className={`${classNamePre}-default-error-text`}>{errors.email.message}</div>)
              : null
          }
        </div>
        <div className={`${classNamePre}-default`}>
          <div className={errors.password.status ? `${classNamePre}-default-error` : ''}>
            <lable>登录密码</lable>
            <Input
              className={`${classNamePre}-default-nostyle`}
              name="password"
              onChange={this.defaultChange}
              password={password}
              type="password"
              placeholder="请输入登陆密码"
              onPressEnter={this.onSave}
            />
          </div>
          {
            errors.password.status
              ? (<div className={`${classNamePre}-default-error-text ${classNamePre}-default-error-text-relative`}>{errors.password.message}</div>)
              : null
          }
        </div>
        <div className={`${classNamePre}-forget-password`}>
          <span
            onClick={this.forgetPassword}
            role="button"
            tabIndex="0"
            className="yiye-outline btn-default-color"
          >
          忘记密码
          </span>
        </div>
        {/** 提交 */}
        <div className={`${classNamePre}-btn`}>
          <Button
            type="primary"
            size="middle"
            loading={loading}
            className="br4"
            onClick={this.onSave}
          >
          登录
          </Button>
        </div>
      </div>
    );
  }
}

export default LoginForm;
