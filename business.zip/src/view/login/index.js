import * as React from 'react';
import { observer, inject } from 'mobx-react';
// import BGParticle from '../../utils/BgParticle';
import ForgetPassword from './forgetPassword';
import LoginForm from './login';
import Auth from '../../utils/auth';
// 新建

const classNamePre = 'merchant-login';

@inject('loginStore')
@observer
class Login extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      status: 'login' // 当前是登陆还是忘记密码
    };
  }

  componentWillMount() {
    const { history } = this.props;
    if (Auth()) {
      history.push('/Yiye/Account/AccountInfo/AssetManageList');
    }
  }

  componentDidMount() {
    // this.particle = new BGParticle('backgroundBox');
    // this.particle.init();
  }

  // 登陆-忘记密码切换
  switchStatus = (v) => {
    this.setState({
      status: v
    });
  }

  render() {
    const { status } = this.state;
    const { history } = this.props;
    return (
      <div className={classNamePre}>
        <div>
          <div id="backgroundBox" />
          <div className={`${classNamePre}-backgroundBox`}>
            <div className={`${classNamePre}-backgroundBox-contatin`}>
              {/** 图片遮挡区域 */}
              <div className={`${classNamePre}-backgroundBox-contatin-welcome`}>
                <img
                  src="https://static.ezrpro.com/assets/icon/yiye/login_welcome_1.png"
                  alt="welcome ezr"
                  width="383"
                  height="566"
                />
              </div>
              <div>
                {
                  status === 'login'
                    ? (
                      <LoginForm
                        classNamePre={`${classNamePre}-backgroundBox-contatin-login-form`}
                        history={history}
                        forgetPassWord={this.switchStatus}
                      />
                    )
                    : (
                      <ForgetPassword
                        classNamePre={`${classNamePre}-backgroundBox-contatin-forget-password-form`}
                        forgetPassWord={this.switchStatus}
                        history={history}
                      />
                    )
                }
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}


export default Login;
