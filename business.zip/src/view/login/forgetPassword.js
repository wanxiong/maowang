import * as React from 'react';
import {
  Input, Button, NumberInput, Notify
} from 'ezrd';
import { observer, inject } from 'mobx-react';
import md5 from 'js-md5';
import { checkPassword, checkMobile } from '../../utils/common';

let time = 60;

@inject('loginStore')
@observer
class ForgetPassword extends React.Component {
  static defaultProps = {
    classNamePre: ''
  }

  constructor(prop) {
    super(prop);
    this.state = {
      loading: false,
      phone: '',
      password: '',
      confirmPassword: '',
      verifyCode: '',
      verifyLoading: false,
      verifyLoadingText: '获取验证码',
      errors: {
        phone: {
          status: false,
          message: ''
        },
        verifyCode: {
          status: false,
          message: ''
        },
        password: {
          status: false,
          message: ''
        },
        confirmPassword: {
          status: false,
          message: ''
        }
      }
    };
  }

  componentDidMount() {
  }

  // 提交操作
  onSave = async () => {
    const { loginStore } = this.props;
    const { password, verifyCode, phone } = this.state;
    if (!this.validate()) return;
    this.setState({ loading: true });
    const status = await loginStore.fetchResetPassword({
      MobileNo: phone,
      NewPassword: md5(password),
      VerifyCode: verifyCode
    });
    if (!status.IsError) {
      Notify.success('密码修改成功');
      // localStorage.clear();
      this.goLogin();
    }
    this.setState({ loading: false });
  }

  // 通用输入框的事件
  defaultChange = (e) => {
    this.setState({
      [e.target.name]: e.target.value
    });
  }

  // 倒计时
  codeDown = () => {
    if (time <= 1) {
      time = 60;
      this.setState({
        verifyLoading: false,
        verifyLoadingText: '重新获取验证码'
      });
      return;
    }
    time--;
    this.setState({
      verifyLoading: true,
      verifyLoadingText: `${time}s`
    });

    setTimeout(() => {
      this.codeDown();
    }, 1000);
  }

  // 获取验证码
  sendCode = () => {
    const { verifyLoading, phone, errors } = this.state;
    if (verifyLoading) return;
    if (!phone) {
      errors.phone.status = true;
      errors.phone.message = '请输入手机号';
      this.setState({ errors });
      return;
    }
    errors.phone.status = false;


    if (!checkMobile(phone)) {
      errors.phone.status = true;
      errors.phone.message = '请输入正确格式的手机号';
      this.setState({ errors });
      return;
    }
    errors.phone.status = false;

    this.setState({
      verifyLoading: true
    }, () => {
      this.initVerifyCode();
    });
  }

  // 验证码接口
  initVerifyCode = async () => {
    const { loginStore } = this.props;
    const { phone } = this.state;
    const status = await loginStore.fetchGetVerifyCode({
      MobileNo: phone
    });
    if (status && !status.IsError) {
      Notify.success('验证码发送成功');
      this.codeDown();
    } else {
      this.setState({
        verifyLoading: false
      });
    }
  }

  // 去登陆
  goLogin = () => {
    const { forgetPassWord } = this.props;
    forgetPassWord('login');
  }

  // 验证输入
  validate = () => {
    const {
      password, phone, errors, verifyCode, confirmPassword
    } = this.state;
    if (!phone) {
      errors.phone.status = true;
      errors.phone.message = '请输入手机号';
      this.setState({ errors });
    } else {
      errors.phone.status = false;
    }

    if (!checkMobile(phone)) {
      errors.phone.status = true;
      errors.phone.message = '请输入正确格式的手机号';
      this.setState({ errors });
    } else {
      errors.phone.status = false;
    }
    if (!verifyCode) {
      errors.verifyCode.status = true;
      errors.verifyCode.message = '请输入验证码';
      this.setState({ errors });
    } else {
      errors.verifyCode.status = false;
    }

    if ((`${verifyCode}`).length < 6) {
      errors.verifyCode.status = true;
      errors.verifyCode.message = '请输入有效格式的验证码';
      this.setState({ errors });
    } else {
      errors.verifyCode.status = false;
    }

    if (!password) {
      errors.password.status = true;
      errors.password.message = '请输入登录密码';
      this.setState({ errors });
    } else {
      errors.password.status = false;
    }

    if (!checkPassword(password)) {
      errors.password.status = true;
      errors.password.message = '请输入字母和数字组合成的8-20位数登录密码';
      this.setState({ errors });
    } else {
      errors.password.status = false;
    }

    if (!confirmPassword) {
      errors.confirmPassword.status = true;
      errors.confirmPassword.message = '请输入确认密码';
      this.setState({ errors });
    } else {
      errors.confirmPassword.status = false;
    }

    if (confirmPassword !== password) {
      errors.confirmPassword.status = true;
      errors.confirmPassword.message = '两次输入的密码不一致';
      this.setState({ errors });
    }
    if (confirmPassword === password && confirmPassword) {
      errors.confirmPassword.status = false;
    }

    if (!errors.phone.status && !errors.verifyCode.status && !errors.password.status && !errors.confirmPassword.status) {
      return true;
    }
    return false;
  }

  render() {
    const {
      loading, errors, phone, password, confirmPassword, verifyCode, verifyLoadingText, verifyLoading
    } = this.state;
    const { classNamePre } = this.props;
    return (
      <div className={classNamePre}>
        <div className={`${classNamePre}-title`}>
          <div>找回密码</div>
          <div><span>重新设置您的登录密码</span></div>
        </div>
        <div className={`${classNamePre}-default ${classNamePre}-default-init-margin`}>
          <div className={errors.phone.status ? `${classNamePre}-default-error` : ''}>
            <lable>手机号</lable>
            <NumberInput
              className={`${classNamePre}-default-nostyle`}
              name="phone"
              maxLength="11"
              onChange={this.defaultChange}
              value={phone}
              placeholder="绑定的手机号"
            />
          </div>
          {
            errors.phone.status
              ? (<div className={`${classNamePre}-default-error-text`}>{errors.phone.message}</div>)
              : null
          }
        </div>
        <div className={`${classNamePre}-default`}>
          <div className={errors.verifyCode.status ? `${classNamePre}-default-error ${classNamePre}-default-verify-box` : ''}>
            <lable>验证码</lable>
            <NumberInput
              className={`${classNamePre}-default-nostyle`}
              maxLength="6"
              width={120}
              name="verifyCode"
              onChange={this.defaultChange}
              password={verifyCode}
              placeholder="请输入验证码"
            />
            <span
              className={verifyLoading ? `${classNamePre}-verify ${classNamePre}-verify-dis yiye-outline` : `${classNamePre}-verify yiye-outline`}
              onClick={this.sendCode}
              role="button"
              tabIndex="0"
            >
              {verifyLoadingText}
            </span>
          </div>
          {
            errors.verifyCode.status
              ? (<div className={`${classNamePre}-default-error-text`}>{errors.verifyCode.message}</div>)
              : null
          }
        </div>
        <div className={`${classNamePre}-default`}>
          <div className={errors.password.status ? `${classNamePre}-default-error` : ''}>
            <lable>新密码</lable>
            <Input
              className={`${classNamePre}-default-nostyle`}
              name="password"
              onChange={this.defaultChange}
              width={200}
              password={password}
              type="password"
              placeholder="8-20位，支持数字和字母"
            />
          </div>
          {
            errors.password.status
              ? (<div className={`${classNamePre}-default-error-text`}>{errors.password.message}</div>)
              : null
          }
        </div>
        <div className={`${classNamePre}-default`}>
          <div className={errors.confirmPassword.status ? `${classNamePre}-default-error` : ''}>
            <lable>密码确认</lable>
            <Input
              className={`${classNamePre}-default-nostyle`}
              name="confirmPassword"
              onChange={this.defaultChange}
              password={confirmPassword}
              type="password"
              placeholder="重复一次设置的密码"
            />
          </div>
          {
            errors.confirmPassword.status
              ? (<div className={`${classNamePre}-default-error-text`}>{errors.confirmPassword.message}</div>)
              : null
          }
        </div>
        {/** 提交 */}
        <div className={`${classNamePre}-btn`}>
          <Button
            type="primary"
            size="middle"
            loading={loading}
            onClick={this.onSave}
          >
          确定
          </Button>
        </div>
        {/** 记得密码 登陆 */}
        <div className={`${classNamePre}-go-login`}>
          <span>记得密码，</span>
          <span
            role="button"
            tabIndex="0"
            className="yiye-outline btn-default-color br4"
            onClick={this.goLogin}
          >
            立即登录
          </span>
        </div>
      </div>
    );
  }
}

export default ForgetPassword;
