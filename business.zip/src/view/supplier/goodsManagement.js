import * as React from 'react';
import {
  Button, Table, Notify
} from 'ezrd';
import moment from 'moment';
import { observer, inject } from 'mobx-react';
import { toJS } from 'mobx';
import GoodsManagementSearch from '../../components/supplier/goodsManagementSearch';
import {
  couponDefaultPage, goodsManagementSearchStatus, sessSupplierCouponDtlKey, sessSupplierCouponDtlType
} from '../../components/base/constant';
import DefaultTipDialog from '../../components/transaction/defaultTipDialog';
// 新建
const classNamePre = 'yiye-supplier-goods-management';

@inject('accountStore')
@inject('supplierStore')
@inject('provideStore')
@observer
export default class GoodsManagement extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      showDialog: false,
      dialogText: '',
      status: '', // 上架1/下架2
      shelfData: '', // 上架下架的列表数据
      shelfLoading: false,
      ...couponDefaultPage
    };
  }

  async componentDidMount() {
    this.initData({
      Status: ''
    });
  }

initData = async (params = {}) => {
  const { supplierStore } = this.props;
  const { pageSize, current } = this.state;
  await supplierStore.fetchSupplierGoodsList({
    SupplyName: '',
    ProBrandName: '',
    BeginDate: '',
    EndDate: '',
    BrandKey: '',
    CouponStatus: '',
    UnionCouponOrigin: '',
    PageSize: pageSize,
    PageIndex: current,
    ...params
  });
}

// 分页的回调
onChange = (data) => {
  let { current } = this.state;
  const { pageSize } = this.state;
  if (data.pageSize) {
    if (data.pageSize === pageSize) {
      return;
    }
    current = 1;
  }
  this.setState({
    pageSize: data.pageSize || pageSize,
    current: data.current || current
  }, () => {
    this.searchDom.onSearch(0);
  });
}

// 搜索按钮的回调
onSearch = (data, flag) => {
  const params = {
    SupplyName: data.supplierName,
    ProBrandName: data.brand,
    BeginDate: data.StartDate,
    EndDate: data.EndDate,
    BrandKey: data.goodsId,
    CouponStatus: data.typeValue,
    UnionCouponOrigin: data.proTypeValue
  };
  if (flag !== 0) {
    this.setState({ current: 1 }, () => {
      this.initData(params);
    });
    return;
  }
  this.initData(params);
}

// 编辑
goDetail = (data) => {
  const { history } = this.props;
  localStorage.setItem(sessSupplierCouponDtlKey, JSON.stringify(toJS(data)));
  localStorage.setItem(sessSupplierCouponDtlType, 'look');
  history.push('/Yiye/Supplier/GoodsManagementAdd');
}

goEdit = (data) => {
  const { history } = this.props;
  localStorage.setItem(sessSupplierCouponDtlKey, JSON.stringify(toJS(data)));
  localStorage.setItem(sessSupplierCouponDtlType, 'edit');
  history.push('/Yiye/Supplier/GoodsManagementAdd');
}

// 新增
goAdd = () => {
  const { history } = this.props;
  localStorage.removeItem(sessSupplierCouponDtlKey);
  localStorage.removeItem(sessSupplierCouponDtlType);
  history.push('/Yiye/Supplier/GoodsManagementAdd');
}

// 上架下架接口
swtichStatus = async (index, data) => {
  const { provideStore } = this.props;
  const params = toJS(data);
  this.setState({ shelfLoading: true });
  params.couponStatus = index;
  params.IsDisable = false;
  const status = await provideStore.fetchProvidePlatformCouponStatus(params);
  if (!status.IsError) {
    Notify.success(index === 1 ? '上架成功' : '下架成功');
    this.searchDom.onSearch(0);
  }
  this.setState({ showDialog: false, shelfLoading: false });
}

// 打开弹出框
openDialog = (visible, status, shelfData) => {
  this.setState({
    showDialog: visible,
    dialogText: status === 1 ? '您确定要上架此商品吗？商品上架后，商品将能正常交易' : '您确定要下架此商品吗？商品下架后，将无法正常交易',
    status,
    shelfData
  });
}

dialogConfirm = (flag, data) => {
  const { status } = this.state;
  if (flag) {
    this.swtichStatus(status, data);
  } else {
    this.setState({ showDialog: false });
  }
}

// ''
render() {
  const {
    current, pageSizeList, showDialog, dialogText, shelfData, shelfLoading
  } = this.state;
  const { supplierStore } = this.props;
  const { supplierGoodsList } = supplierStore;
  const { PagedList, TotalRowsCount } = supplierGoodsList;
  const columns = [
    {
      title: '商品',
      textAlign: 'left',
      width: '280px',
      bodyRender: data => (
        <div className={`${classNamePre}-contain-table-first`}>
          <div style={{ width: '64px', height: '64px', 'margin-right': '10px' }}>
            <img
              src={data.ProductPic}
              alt={data.ProBrandName}
            />
          </div>
          <div>
            <div>{data.CouponName}</div>
            <div>{data.ProductCode}</div>
          </div>
        </div>
      )
    },
    {
      title: '商品类型',
      name: 'UnionCouponOriginTypeName'
    },
    {
      title: '供应商',
      name: 'MchName'
    },
    {
      title: '驿业品牌',
      name: 'ProBrandName'
    },
    {
      title: '创建时间',
      bodyRender: data => <div>{moment(data.CreateDate).format('YYYY-MM-DD HH:mm:ss')}</div>
    },
    {
      title: '状态',
      bodyRender: (data) => {
        if (data.CouponStatus === 2) {
          return (<div>已下架</div>);
        } if (data.CouponStatus === 1) {
          return (<div>已上架</div>);
        }
        return '--';
      }
    },
    {
      title: '操作',
      bodyRender: (data) => {
        if (data.CouponStatus === 1) { // 上架中
          return (
            <div className={`${classNamePre}-contain-table-contr`}>
              <span
                role="button"
                tabIndex="0"
                className="yiye-outline btn-default-color yiye-cursor"
                onClick={() => this.openDialog(true, 2, data)}
              >
              下架
              </span>
              <span
                role="button"
                tabIndex="0"
                className="yiye-outline btn-default-color yiye-cursor"
                onClick={() => this.goEdit(data)}
              >
              编辑
              </span>
              <span
                role="button"
                tabIndex="0"
                className="yiye-outline btn-default-color yiye-cursor"
                onClick={() => this.goDetail(data)}
              >
              查看
              </span>
            </div>
          );
        } if (data.CouponStatus === 2) { // 下架种
          return (
            <div className={`${classNamePre}-contain-table-contr`}>
              <span
                role="button"
                tabIndex="0"
                className="yiye-outline btn-default-color yiye-cursor"
                onClick={() => this.openDialog(true, 1, data)}
              >
              上架
              </span>
              <span
                role="button"
                tabIndex="0"
                className="yiye-outline btn-default-color yiye-cursor"
                onClick={() => this.goEdit(data)}
              >
              编辑
              </span>
              <span
                role="button"
                tabIndex="0"
                className="yiye-outline btn-default-color yiye-cursor"
                onClick={() => this.goDetail(data)}
              >
              查看
              </span>
            </div>
          );
        }
        return '--';
      }
    }
  ];
  return (
    <div className={`${classNamePre}`}>
      {/* 搜索区域 */}
      <div style={{ 'margin-top': '20px' }}>
        <GoodsManagementSearch
          data={goodsManagementSearchStatus}
          ref={(ref) => { this.searchDom = ref; }}
          onSearch={this.onSearch}
        />
      </div>
      <div className={`${classNamePre}-contain`}>
        <div>
          <Button
            type="primary"
            size="middle"
            onClick={() => this.goAdd()}
          >
          新增商品
          </Button>
        </div>
        {/* table展示区域 */}
        <div className={`${classNamePre}-contain-table`}>
          <Table
            columns={columns}
            datasets={PagedList}
            rowKey="Id"
            pageInfo={{
              totalItem: TotalRowsCount,
              current,
              pageSize: pageSizeList
            }}
            onChange={this.onChange}
          />
        </div>
      </div>
      {/** 下架和上架弹出框 */}
      <DefaultTipDialog
        showEnableVisible={showDialog}
        content={dialogText}
        customFlag={shelfData}
        maskClosable={false}
        loading={shelfLoading}
        confirmEnable={this.dialogConfirm}
      />
    </div>
  );
}
}
