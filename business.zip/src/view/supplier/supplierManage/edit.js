import React, { Component } from 'react';
import qs from 'qs';
import { observer, inject } from 'mobx-react';
import {
  Button,
  Icon,
  Form,
  Title,
  Radio,
  Breadcrumb,
  Notify,
  Dialog
} from 'ezrd';
import { getUserInfo } from '../../../services/supplierManagement';

const { createForm, FormInputField, FormRadioGroupField } = Form;
const classNamePre = 'yiye-bottom-edit';
const {
  openDialog, closeDialog
} = Dialog;
const DIALOG_ID = 'supplier-edit';
@inject('supplierManagement')
@observer
class SupplierEdit extends Component {
  state = {
    loading: false,
    merchantId: 0
  }

  breadList = [
    { name: '供应商管理', href: "#/Yiye/Supplier/Management" },
    { name: '新增供应商', strong: true }
  ]

  async componentDidMount() {
    const {
      history: {
        location: {
          search
        }
      }
    } = this.props;
    if (search) {
      const { merchantId } = qs.parse(search.replace('?', ''));
      if (merchantId) {
        this.breadList[1].name = '编辑供应商';
      }
      this.setState({
        merchantId
      });
      const { Data } = await getUserInfo({
        MchId: merchantId
      });
      const {
        ezrdForm: {
          setFieldsValue
        }
      } = this.props;
      setFieldsValue(Data);
    }
  }

  onValid = async () => {
    // console.log(values);
    const {
      ezrdForm

    } = this.props;
    ezrdForm.setFormDirty(true);
    if (ezrdForm.isValid()) {
      const values = ezrdForm.getFormValues();
      const {
        MerchantName
      } = values;
      const {
        merchantId
      } = this.state;
      if (merchantId) {
        this.sureSave(values);
      } else {
        openDialog({
          dialogId: DIALOG_ID,
          title: (
            <div>
              <Icon
                className={`${classNamePre}-tip-icon`}
                type="error-circle-o"
              />
                温馨提示
            </div>
          ),
          children: <div>{`您是否确认增加供应商${MerchantName}`}</div>,
          footer: (
            <div>
              <Button
                type="primary"
                outline
                onClick={() => closeDialog(DIALOG_ID)}
              >
              取消
              </Button>
              <Button
                type="primary"
                onClick={() => this.sureSave(values)}
              >
              确认
              </Button>
            </div>
          ),
          onClose() {
            // console.log('outer dialog closed');
          }
        });
      }
    }
  }

  sureSave = async (values) => {
    const { MerchantName } = values;
    closeDialog(DIALOG_ID);
    this.setState({
      loading: true
    }, async () => {
      const {
        merchantId
      } = this.state;
      const {
        supplierManagement: {
          addSupplier,
          saveSupplier
        },
        history
      } = this.props;
      // 附加的页面中不存在，但是不加会报错的字段
      const otherParams = {
        MerchantType: 3,
        BrandName: MerchantName,
        BrandCode: MerchantName,
        CopName: MerchantName
      };
      let Data = false;
      let ErrorMsg = '';
      if (merchantId) {
        ({ Data, ErrorMsg } = await saveSupplier({
          ...values, Id: merchantId, MchId: merchantId, ...otherParams
        }));
      } else {
        ({ Data, ErrorMsg } = await addSupplier({
          ...values,
          ...otherParams
        }));
      }
      if (Data) {
        Notify.success('操作成功');
        setTimeout(() => {
          history.go(-1);
          this.setState({
            loading: false
          });
        }, 1000);
      } else {
        Notify.error(ErrorMsg);
        this.setState({
          loading: false
        });
      }
    });
  }

  render() {
    const {
      loading,
      merchantId
    } = this.state;

    return (
      <div>
        <div className="yiye-global-bread">
          <Breadcrumb breads={this.breadList} />
        </div>
        <Form horizontal>
          <Title
            titleDesc="基本信息"
          >
            <FormInputField
              label="供应商名称"
              name="MerchantName"
              required
              showCount
              showClear={!merchantId}
              maxLength={30}
              validations={{
                required: true
              }}
              disabled={merchantId}
              validationErrors={{
                required: '请填写供应商名称'
              }}
            />
          </Title>

          <Title
            titleDesc="联系人信息"
          >
            <FormInputField
              label="姓名"
              name="ContactName"
              showCount
              showClear
              maxLength={10}
            />
            <FormInputField
              label="电子邮箱"
              name="ContactEmail"
              showCount
              validateOnChange={false}
              validateOnBlur
              validations={{
                matchRegex: /^\w+@[a-z0-9]+\.[a-z]+$/i
              }}
              validationErrors={{
                matchRegex: '请填写正确的电子邮箱'
              }}
              showClear
              maxLength={32}
            />
            <FormInputField
              label="手机号"
              name="ContactMobile"
              showCount
              showClear
              maxLength={11}
              validateOnChange={false}
              validateOnBlur
              validations={{
                matchRegex: /^1[3456789]\d{9}$/
              }}
              validationErrors={{
                matchRegex: '请填写正确的手机号'
              }}
            />
          </Title>

          <Title
            titleDesc="开发设置"
          >
            <FormRadioGroupField
              name="ConnectType"
              label="系统对接"
              required
              validations={{
                required: true
              }}
              validationErrors={{
                required: '请选择系统对接'
              }}
            >
              <Radio
                value={0}
              >
                接口对接
              </Radio>
              <Radio
                value={1}
              >
                手动导入
              </Radio>
            </FormRadioGroupField>
          </Title>
        </Form>

        <div className={`${classNamePre}-group-btn`}>
          <Button
            type="primary"
            size="middle"
            loading={loading}
            onClick={this.onValid}
          >
            {merchantId ? '保存' : '新增'}
          </Button>
        </div>
      </div>
    );
  }
}

const SupplierEditForm = createForm()(SupplierEdit);
export default SupplierEditForm;
