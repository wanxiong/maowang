import * as React from 'react';
import {
  Table, Dialog, Pagination, Button, Icon, Notify
} from 'ezrd';
import { observer, inject } from 'mobx-react';
import SupplierManagement from '../../../components/supplier/supplierManagementForm';
import { couponDefaultPage } from '../../../components/base/constant';
import { toggleMerchant } from '../../../services/supplierManagement';

const classNamePre = 'yiye-purchase-order';
const editPath = '/Yiye/Supplier/Edit';
const STATUS_ENUM = {
  2: '启用',
  '-3': '禁用',
  '-9': '全部'
};

const { openDialog, closeDialog } = Dialog;

const ID = 'supplier-dialog';
@inject('supplierManagement')
@observer
class YiyePurchaseOrder extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      ...couponDefaultPage
    };
    this.MchId = '';
    this.status = 0;
    this.onChange = this.onChange.bind(this);
    this.onPageSizeChange = this.onPageSizeChange.bind(this);
  }

  // @checkShopStatus('purchase')
  componentDidMount() {
    this.initData({});
  }

  // initData
  initData = (params = {}) => {
    const { supplierManagement } = this.props;
    const { pageSize, current } = this.state;
    supplierManagement.QueryByPage({
      Page: current,
      PageSize: pageSize,
      Status: -9,
      MerchantName: '',
      ...params
    });
  }

  // 点击查询的事件
  onHandleSearch = (data, flag) => {
    if (flag) {
      this.setState({
        current: 1
      }, () => {
        this.initData(data);
      });
    } else {
      this.initData(data);
    }
  }

  // 每页大小的回调
  onPageSizeChange = (pageSize) => {
    this.setState({
      pageSize,
      current: 1
    }, () => {
      this.searchDom.onSearch(0);
    });
  };

  // 分页的回调
  onChange = (data) => {
    const { current } = this.state;
    this.setState({
      current: data || current
    }, () => {
      this.searchDom.onSearch(0);
    });
  }

  addSupplier = () => {
    const {
      props: {
        history
      }
    } = this;
    history.push(editPath);
  }

  toggleUse = (MchId, status) => () => {
    this.MchId = MchId;
    this.status = status;
    const use = (
      <React.Fragment>
        <h3>您确定要启用此供应商吗？</h3>
        <p>供应商启用后，供应商所属商品可恢复正常交易</p>
      </React.Fragment>
    );
    const stop = (
      <React.Fragment>
        <h3>您确定要禁用此供应商吗？</h3>
        <p>供应商禁用后，供应商所属商品将无法进行正常交易</p>
      </React.Fragment>
    );
    const text = status === 2 ? stop : use;
    openDialog({
      dialogId: ID,
      title: (
        <div>
          <Icon
            className={`${classNamePre}-tip-icon`}
            type="error-circle-o"
          />
            温馨提示
        </div>
      ),
      children: <div>{text}</div>,
      footer: (
        <div>
          <Button
            type="primary"
            outline
            onClick={() => closeDialog(ID)}
          >
          取消
          </Button>
          <Button
            type="primary"
            onClick={this.useOrStop}
          >
          确认
          </Button>
        </div>
      ),
      onClose() {
        // console.log('outer dialog closed');
      }
    });
  }


  edit = MchId => () => {
    const {
      history
    } = this.props;
    history.push(`${editPath}?merchantId=${MchId}`);
  }

  useOrStop = async () => {
    const { Data, ErrorMsg } = await toggleMerchant({
      IsEnable: this.status === 2 ? 0 : 1,
      MchId: this.MchId
    });
    if (Data) {
      Notify.success('操作成功');
    } else {
      Notify.error(ErrorMsg);
    }
    closeDialog(ID);
    this.searchDom.onSearch(false);
  }


  render() {
    const { history, supplierManagement: { queryPageList, TotalRowsCount } } = this.props;
    const { current, pageSizeList } = this.state;
    const columns = [{
      title: '供应商名称',
      textAlign: 'left',
      name: 'MerchantName'
    }, {
      title: '状态',
      name: 'PurchaseNo',
      bodyRender: data => STATUS_ENUM[`${data.Status}`]
    }, {
      title: '新增时间',
      name: 'CreateOn',
      width: '280px'
    }, {
      title: '操作',
      name: 'ProviderName',
      bodyRender: data => (
        <div>
          {data.Status === -3 && (
            <Button
              size="small"
              onClick={this.toggleUse(data.Id, data.Status)}
              isText
            >
              启用

            </Button>
          )}
          {data.Status === 2 && (
            <Button
              size="small"
              onClick={this.toggleUse(data.Id, data.Status)}
              isText
            >
              禁用

            </Button>
          )}

          <Button
            size="small"
            onClick={this.edit(data.Id)}
            isText
          >
            编辑
          </Button>
        </div>
      )
    }];
    return (
      <div className={`${classNamePre}`}>
        {/* 查询头部 */}
        <SupplierManagement
          onSearch={this.onHandleSearch}
          history={history}
          // ref={(ref) => { this.searchDom = ref; }}
          getRef={(ref) => { this.searchDom = ref; }}
        />
        <div className={`${classNamePre}-pro`}>
          <Button
            type="primary"
            style={{ marginBottom: '20px' }}
            onClick={this.addSupplier}
          >
            新增供应商
          </Button>
          <Table
            columns={columns}
            datasets={queryPageList}
            rowKey="id"
          />
          <Pagination
            current={current}
            totalItem={TotalRowsCount}
            pageSize={pageSizeList}
            onChange={this.onChange}
            onPageSizeChange={this.onPageSizeChange}
          />
        </div>
      </div>
    );
  }
}

export default YiyePurchaseOrder;
