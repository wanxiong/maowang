import React, { Component } from 'react';
import {
  Table, Icon, DateRangePicker, Button
} from 'ezrd';
import { observer, inject } from 'mobx-react';
import cx from 'classnames';
import moment from 'moment';
import ProductBrandSelect from '../../../components/base/productBrandSelect';
import { couponDefaultPage } from "../../../components/base/constant";
import SaleReportTotalDataHeader from '../../../components/supplier/saleReportTotalDataHeader';
import { division } from '../../../utils/common';

const classNamePre = 'sale-report';
const columns = [{
  title: '供应商',
  name: 'ProviderName',
  textAlign: 'center'
}, {
  title: '驿业品牌',
  name: 'ProBrandName'
}, {
  title: '利润(Z币)',
  name: 'Profit'
}, {
  title: '销量(张)',
  name: 'BuyCount'
}, {
  title: '应收(Z币)',
  name: 'UnionMoney'
}, {
  title: '应付(Z币)',
  name: 'SupplyMoney'
}];
@inject('supplierSaleReportBrand')
@observer class Brand extends Component {
  static defaultProps = {
    showTime: true, // 是否显示时间筛选
    format: 'YYYY-MM-DD HH:mm:ss'
  }

  constructor(props) {
    super(props);
    this.state = {
      ...couponDefaultPage,
      // currentRankingSortType: 'Profit', // 默认为利润降序
      saleStatus: 0, // 0 默认非选中状态 1升序 2降序
      profitStatus: 0,
      time: [moment().subtract(3, 'months').format(props.format), moment().format(props.format)],
      startTime: '',
      endTime: '',
      id: '0',
      rankNum: 0 // 1利润 2销量
    };
  }

  componentDidMount() {
    const { time } = this.state;
    this.setState({
      startTime: time[0],
      endTime: time[1]
    }, () => this.requestData());
  }

  onChange = (id) => {
    this.setState({ id });
  }

  onPageChange = (conf) => {
    // console.log('conf ------', conf);
    if (conf.pageSize) {
      this.setState({
        current: 1,
        pageSize: conf.pageSize
      }, () => this.requestData());
    }
    if (conf.current) {
      this.setState({
        current: conf.current
      }, () => this.requestData());
    }
  }

  onTimeChange = (value) => {
    // console.log('value ========', value);
    const { startTime, endTime } = this.state;
    this.setState({
      time: value,
      startTime: value[0].length ? value[0] : startTime,
      endTime: value[1].length ? value[1] : endTime
    });
  }

  sortType = (type) => {
    const { profitStatus, saleStatus } = this.state;
    if (type === 1) {
      if (profitStatus === 1) {
        this.setState({
          profitStatus: 2,
          saleStatus: 0,
          rankNum: type,
          orderType: 2
        }, () => this.requestData());
      } else {
        this.setState({
          profitStatus: 1,
          saleStatus: 0,
          rankNum: type,
          orderType: 1
        }, () => this.requestData());
      }
    } else if (type === 2) {
      if (saleStatus === 1) {
        this.setState({
          saleStatus: 2,
          profitStatus: 0,
          rankNum: type,
          orderType: 4
        }, () => this.requestData());
      } else {
        this.setState({
          saleStatus: 1,
          profitStatus: 0,
          rankNum: type,
          orderType: 3
        }, () => this.requestData());
      }
    }
  }

  requestData = () => {
    const { supplierSaleReportBrand } = this.props;
    const {
      pageSize, current, orderType, startTime, endTime, id
    } = this.state;
    const obj = {
      PageIndex: current,
      PageSize: pageSize,
      OrderType: orderType,
      StartTime: startTime,
      EndTime: endTime,
      ProBrandId: id
    };
    supplierSaleReportBrand.SaleReportBrandList(obj);
  }

  renderHeaderView = () => {
    const {
      time
    } = this.state;
    const {
      format, showTime
    } = this.props;
    return (
      <div className={`${classNamePre}-header`}>
        <ProductBrandSelect
          onChange={this.onChange}
          width="240px"
          textLable="驿业品牌："
        />
        <div className={`${classNamePre}-header-selectDiv`}>
          <span>采购时间：</span>
          <DateRangePicker
            width={190}
            value={time}
            format={format}
            showTime={showTime}
            onChange={this.onTimeChange}
          />
        </div>
        <Button
          type="primary"
          className={`${classNamePre}-btn`}
          onClick={this.onSearch}
        >
        查询
        </Button>
      </div>
    );
  }

  onSearch = () => {
    this.requestData();
  }


  renderTotalDataView = () => (
    <SaleReportTotalDataHeader
      titleList={['利润(Z币)', '销量(张)', '应收(Z币)', '应付(Z币)']}
      keyList={[
        this.titleFun('TotalProfit', 0, 2),
        this.titleFun('TotalBuyCount'),
        this.titleFun('TotalUnionMoney', 0, 2),
        this.titleFun('TotalSupplyMoney', 0, 2)
      ]}
    />
  )

  // title列表组件需要函数
  titleFun = (key, number, fixed = 0, pass = false) => {
    const { supplierSaleReportBrand } = this.props;
    const { totalData } = supplierSaleReportBrand;
    if (!totalData[key] && totalData[key] !== 0) {
      return '';
    }
    if (pass) {
      return totalData[key];
    }
    if (number) {
      if (!fixed) {
        return division(totalData[key], number);
      }
      return division(totalData[key], number).toFixed(fixed);
    }
    return totalData[key].toFixed(fixed);
  }

  renderSoretView = () => {
    const { profitStatus, saleStatus, rankNum } = this.state;
    return (
      <div className={`${classNamePre}-contr`}>
        <ul>
          <li
            className={rankNum === 1 ? `${classNamePre}-contr-active` : ''}
            onClick={() => this.sortType(1)}
          >
            <span>利润(Z币)</span>
            <div className={`${classNamePre}-contr-box`}>
              <Icon
                type="sort_down"
                ezrd
                className={cx(`${classNamePre}-contr-icon`, { [`${classNamePre}-contr-box-active`]: profitStatus === 2 })}
              />
              <Icon
                type="sort_up"
                ezrd
                className={cx(`${classNamePre}-contr-icon`, { [`${classNamePre}-contr-box-active`]: profitStatus === 1 })}
              />
            </div>
          </li>
          <li
            className={rankNum === 2 ? `${classNamePre}-contr-active` : ''}
            onClick={() => this.sortType(2)}
          >
            <span>销量(张)</span>
            <div className={`${classNamePre}-contr-box`}>
              <Icon
                type="sort_down"
                ezrd
                className={cx(`${classNamePre}-contr-icon`, { [`${classNamePre}-contr-box-active`]: saleStatus === 2 })}
              />
              <Icon
                type="sort_up"
                ezrd
                className={cx(`${classNamePre}-contr-icon`, { [`${classNamePre}-contr-box-active`]: saleStatus === 1 })}
              />
            </div>
          </li>
        </ul>
      </div>
    );
  }

  renderListView = () => {
    const { current, pageSizeList } = this.state;
    const { supplierSaleReportBrand } = this.props;
    const { totalRowsCount, queryPageList } = supplierSaleReportBrand;
    return (
      <div className={`${classNamePre}-list`}>
        <Table
          columns={columns}
          datasets={queryPageList}
          rowKey="Id"
          // eslint-disable-next-line react/jsx-no-bind
          onChange={this.onPageChange}
          pageInfo={{
            totalItem: totalRowsCount,
            current,
            pageSize: pageSizeList
          }}
        />
      </div>
    );
  }


  render() {
    return (
      <div className={classNamePre}>
        {this.renderHeaderView()}
        {this.renderTotalDataView()}
        {this.renderSoretView()}
        {this.renderListView()}
      </div>
    );
  }
}

export default Brand;
