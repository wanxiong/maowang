import React, { Component } from 'react';
import {
  Table, Icon, DateRangePicker, Button, Input
} from 'ezrd';
import { observer, inject } from 'mobx-react';
import cx from 'classnames';
import moment from 'moment';
// import ConstBrandSelect from '../../../components/base/constBrandSelect';
import { couponDefaultPage } from "../../../components/base/constant";
import SaleReportTotalDataHeader from '../../../components/supplier/saleReportTotalDataHeader';
import { division } from '../../../utils/common';

const classNamePre = 'sale-report';
const columns = [{
  title: '商品名称',
  name: 'CouponName'
}, {
  title: '驿业品牌',
  name: 'ProBrandName'
}, {
  title: '供应商',
  name: 'MchName',
  textAlign: 'center'
}, {
  title: '利润(Z币)',
  bodyRender: data => <div>{(data.ReceivableZb - data.RealityZb).toFixed(2)}</div>
}, {
  title: '销量(张)',
  name: 'PurchaseQty'
}, {
  title: '发放数(张)',
  name: 'CouponSend'
}, {
  title: '应收(Z币)',
  name: 'ReceivableZb'
}, {
  title: '成本价(Z币)',
  name: 'CostPrice'
}, {
  title: '应付(Z币)',
  name: 'RealityZb'
}];
@inject('supplierSaleReportProduction')
@observer class Production extends Component {
  static defaultProps = {
    showTime: true,
    format: 'YYYY-MM-DD HH:mm:ss'
  }

  constructor(props) {
    super(props);
    this.state = {
      ...couponDefaultPage,
      saleStatus: 0, // 0 默认非选中状态 1升序 2降序
      profitStatus: 0,
      sendPeopleCount: 0,
      sendCouponCount: 0,
      value: '',
      time: [moment().subtract(3, 'months').format(props.format), moment().format(props.format)],
      startTime: '',
      endTime: '',
      // id: '0',
      rankNum: 0, // 1利润 2销量
      isASC: false
    };
  }

  componentDidMount() {
    const { time } = this.state;
    this.setState({
      startTime: time[0],
      endTime: time[1]
    }, () => this.requestData());
  }

  onPageChange = (conf) => {
    // console.log('conf ------', conf);
    if (conf.pageSize) {
      this.setState({
        pageSize: conf.pageSize,
        current: 1
      }, () => this.requestData());
    }
    if (conf.current) {
      this.setState({
        current: conf.current
      }, () => this.requestData());
    }
  }

  onTimeChange = (value) => {
    const { startTime, endTime } = this.state;
    this.setState({
      time: value,
      startTime: value[0].length ? value[0] : startTime,
      endTime: value[1].length ? value[1] : endTime
    });
  }

  sortType = (type) => {
    const {
      profitStatus, saleStatus, sendPeopleCount, sendCouponCount
    } = this.state;
    if (type === 1) {
      this.setState({
        profitStatus: (profitStatus === 2 || profitStatus === 0) ? 1 : 2,
        saleStatus: 0,
        sendPeopleCount: 0,
        sendCouponCount: 0,
        rankNum: type,
        orderType: type,
        isASC: profitStatus === 2 || profitStatus === 0
      }, () => this.requestData());
    } else if (type === 2) {
      this.setState({
        profitStatus: 0,
        saleStatus: (saleStatus === 2 || saleStatus === 0) ? 1 : 2,
        sendPeopleCount: 0,
        sendCouponCount: 0,
        rankNum: type,
        orderType: type,
        isASC: saleStatus === 2 || saleStatus === 0
      }, () => this.requestData());
    } else if (type === 3) {
      this.setState({
        profitStatus: 0,
        saleStatus: 0,
        sendPeopleCount: (sendPeopleCount === 2 || sendPeopleCount === 0) ? 1 : 2,
        sendCouponCount: 0,
        rankNum: type,
        orderType: type,
        isASC: (sendPeopleCount === 2 || sendPeopleCount === 0)
      }, () => this.requestData());
    } else if (type === 4) {
      this.setState({
        profitStatus: 0,
        saleStatus: 0,
        sendPeopleCount: 0,
        sendCouponCount: (sendCouponCount === 2 || sendCouponCount === 0) ? 1 : 2,
        rankNum: type,
        orderType: type,
        isASC: (sendCouponCount === 2 || sendCouponCount === 0)
      }, () => this.requestData());
    }
  }

  requestData = () => {
    // console.log('this.state ==== ', this.state);
    const { supplierSaleReportProduction } = this.props;
    const {
      pageSize, current, orderType, startTime, endTime, isASC, value
    } = this.state;
    const obj = {
      PageIndex: current,
      PageSize: pageSize,
      OrderType: orderType,
      StartTime: startTime,
      EndTime: endTime,
      IsAsc: isASC,
      CouponGrpName: value
    };
    supplierSaleReportProduction.SaleReportProductionList(obj);
  }

  renderHeaderView = () => {
    const {
      value, time
    } = this.state;
    const {
      format, showTime
    } = this.props;
    return (
      <div className={`${classNamePre}-header`}>
        <div className={`${classNamePre}-header-input`}>
          <span>
            权益商品：
          </span>
          <Input
            name="value"
            onChange={e => this.setState({ value: e.target.value })}
            value={value}
            maxLength={25}
            showClear
            placeholder="请输入"
          />
        </div>
        <div className={`${classNamePre}-header-selectDiv`}>
          <span>采购时间：</span>
          <DateRangePicker
            width={190}
            value={time}
            format={format}
            showTime={showTime}
            onChange={this.onTimeChange}
          />
        </div>
        <Button
          type="primary"
          className={`${classNamePre}-btn`}
          onClick={this.onSearch}
        >
        查询
        </Button>
      </div>
    );
  }

  onSearch = () => {
    this.requestData();
  }


  renderTotalDataView = () => (
    <SaleReportTotalDataHeader
      titleList={['利润(Z币)', '销量(张)', '发放数(张)', '应收(Z币)', '应付(Z币)']}
      keyList={[
        this.titleFun('ZbProfileTotal', 0, 2),
        this.titleFun('PurchaseTotal'),
        // this.titleFun('CouponSendPTotal'),
        this.titleFun('CouponSendTotal'),
        this.titleFun('ReceivableZbTotal', 0, 2),
        this.titleFun('RealityZbTotal', 0, 2)
      ]}
    />
  )

  // title列表组件需要函数
  titleFun = (key, number, fixed = 0, pass = false) => {
    const { supplierSaleReportProduction } = this.props;
    const { totalData } = supplierSaleReportProduction;
    if (!totalData[key] && totalData[key] !== 0) {
      return '';
    }
    if (pass) {
      return totalData[key];
    }
    if (number) {
      if (!fixed) {
        return division(totalData[key], number);
      }
      return division(totalData[key], number).toFixed(fixed);
    }
    return totalData[key].toFixed(fixed);
  }

  renderSoretView = () => {
    const {
      profitStatus, saleStatus, sendCouponCount, rankNum
    } = this.state;
    return (
      <div className={`${classNamePre}-contr`}>
        <ul>
          <li
            className={rankNum === 1 ? `${classNamePre}-contr-active` : ''}
            onClick={() => this.sortType(1)}
          >
            <span>利润(Z币)</span>
            <div className={`${classNamePre}-contr-box`}>
              <Icon
                type="sort_down"
                ezrd
                className={cx(`${classNamePre}-contr-icon`, { [`${classNamePre}-contr-box-active`]: profitStatus === 2 })}
              />
              <Icon
                type="sort_up"
                ezrd
                className={cx(`${classNamePre}-contr-icon`, { [`${classNamePre}-contr-box-active`]: profitStatus === 1 })}
              />
            </div>
          </li>
          <li
            className={rankNum === 2 ? `${classNamePre}-contr-active` : ''}
            onClick={() => this.sortType(2)}
          >
            <span>销量(张)</span>
            <div className={`${classNamePre}-contr-box`}>
              <Icon
                type="sort_down"
                ezrd
                className={cx(`${classNamePre}-contr-icon`, { [`${classNamePre}-contr-box-active`]: saleStatus === 2 })}
              />
              <Icon
                type="sort_up"
                ezrd
                className={cx(`${classNamePre}-contr-icon`, { [`${classNamePre}-contr-box-active`]: saleStatus === 1 })}
              />
            </div>
          </li>
          {/* <li
            className={rankNum === 3 ? `${classNamePre}-contr-active` : ''}
            onClick={() => this.sortType(3)}
          >
            <span>发放数(人)</span>
            <div className={`${classNamePre}-contr-box`}>
              <Icon
                type="sort_down"
                ezrd
                className={cx(`${classNamePre}-contr-icon`, { [`${classNamePre}-contr-box-active`]: sendPeopleCount === 2 })}
              />
              <Icon
                type="sort_up"
                ezrd
                className={cx(`${classNamePre}-contr-icon`, { [`${classNamePre}-contr-box-active`]: sendPeopleCount === 1 })}
              />
            </div>
          </li> */}
          <li
            className={rankNum === 4 ? `${classNamePre}-contr-active` : ''}
            onClick={() => this.sortType(4)}
          >
            <span>发放数(张)</span>
            <div className={`${classNamePre}-contr-box`}>
              <Icon
                type="sort_down"
                ezrd
                className={cx(`${classNamePre}-contr-icon`, { [`${classNamePre}-contr-box-active`]: sendCouponCount === 2 })}
              />
              <Icon
                type="sort_up"
                ezrd
                className={cx(`${classNamePre}-contr-icon`, { [`${classNamePre}-contr-box-active`]: sendCouponCount === 1 })}
              />
            </div>
          </li>
        </ul>
      </div>
    );
  }

  renderListView = () => {
    const { current, pageSizeList } = this.state;
    const { supplierSaleReportProduction } = this.props;
    const { totalRowsCount, queryPageList } = supplierSaleReportProduction;
    return (
      <div className={`${classNamePre}-list`}>
        <Table
          columns={columns}
          datasets={queryPageList}
          rowKey="Id"
          // eslint-disable-next-line react/jsx-no-bind
          onChange={this.onPageChange}
          pageInfo={{
            totalItem: totalRowsCount,
            current,
            pageSize: pageSizeList
          }}
        />
      </div>
    );
  }


  render() {
    return (
      <div className={classNamePre}>
        {this.renderHeaderView()}
        {this.renderTotalDataView()}
        {this.renderSoretView()}
        {this.renderListView()}
      </div>
    );
  }
}

export default Production;
