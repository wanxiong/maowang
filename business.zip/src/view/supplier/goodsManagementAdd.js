import * as React from 'react';
import {
  Title, Form, Pop, Icon, Button, Radio, Notify, Breadcrumb
} from 'ezrd';
import { observer, inject } from 'mobx-react';
// import { Editor } from '../../components/base/constEdit';
import { ConstFormUpload } from '../../components/base/constFormImage';
import { ConstFormSearchSelect, ConstFormProType } from '../../components/supplier/goodsManagementForm';
import { ConstFormDay } from '../../components/base/constForm';
import { sessSupplierCouponDtlKey, sessSupplierCouponDtlType } from '../../components/base/constant';
// 新建

const {
  Field, FormInputField, createForm, FormDateRangePickerField, FormRadioGroupField
} = Form;
const classNamePre = 'yiye-supplier-goods-managementadd';

@inject('supplierStore')
@inject('purchaseStore')
@inject('provideStore')
@observer
class GoodsManagementAddForm extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      brandList: [],
      tagList: [],
      supplierList: [],
      loading: false,
      breadList: [
        { name: '权益商品管理', href: "#/Yiye/Supplier/GoodsManagement" },
        { name: '新增权益商品', strong: true }
      ],
      detail: '',
      type: ''
    };
  }

  componentDidMount() {
    let detail = '';
    let type = '';
    try {
      detail = JSON.parse(localStorage.getItem(sessSupplierCouponDtlKey));
      type = localStorage.getItem(sessSupplierCouponDtlType);
      // detail.ProTagList.map
      this.setState({
        detail,
        type
      });
    } catch (error) {
      //
    }
    // 初始化所有驿业品牌列表
    this.initBrandList();

    // 初始获取标签列表接口
    this.initTagList();

    // 获取所有供应商接口
    this.initSupplierList();
  }

  // 获取品牌列表接口
  initBrandList = async () => {
    const { purchaseStore } = this.props;
    // 品牌
    const blist = await purchaseStore.fetchProBrandList({});
    this.setState({
      brandList: blist.Data || []
    });
  }

  // 获取标签列表接口
  initTagList = async () => {
    const { purchaseStore } = this.props;
    // 品牌
    const tlist = await purchaseStore.fetchProPgTagList({});
    if (!tlist.IsError) {
      this.setState({
        tagList: tlist.Data || []
      });
    }
  }

  // 获取所有供应商列表
  initSupplierList = async () => {
    const { supplierStore } = this.props;
    const sList = await supplierStore.fetchQueryAllSupplier({});
    if (!sList.IsError) {
      this.setState({
        supplierList: sList.Data || []
      });
    }
  }

  // 权益标签选择
  changeTag = (event) => {
    const { tagList } = this.state;
    if (event.target.tagName.toLocaleLowerCase() !== 'span' && event.target.tagName.toLocaleLowerCase() !== 'button') return;
    let dom = event.target;
    if (event.target.tagName.toLocaleLowerCase() === 'span') {
      dom = event.target.parentNode;
    }
    const index = dom.getAttribute('index');
    const hasActive = dom.getAttribute('hasClass') - 0;
    tagList[index].active = !hasActive;
    this.setState({
      tagList
    });
  }

  // 上传图片接口
  uploadImg = async (params) => {
    const { supplierStore } = this.props;
    const status = await supplierStore.fetchSupplierUploadImg(params);
    if (!status.IsError && status.Data) {
      return status.Data.pathfull;
    }
    return null;
  }

  onSave = async () => {
    const { ezrdForm } = this.props;
    ezrdForm.setFormDirty(true);
    if (ezrdForm.isValid()) {
      this.setState({ loading: true });
      const { detail } = this.state;
      const params = detail ? { id: detail.Id } : {};
      this.submit(params);
    }
  }

  submit = async (params) => {
    const { ezrdForm, provideStore } = this.props;
    const { tagList } = this.state;

    const values = ezrdForm.getFormValues();
    // 先上传图片
    const imgObj = values.ProductPic;
    if (imgObj && imgObj.src.indexOf('http') !== -1) {
      values.ProductPic = imgObj.src;
    } else {
      const imgUrl = await this.uploadImg({ file: imgObj.data[0].file });
      // 图片成功且存在URL
      if (imgUrl) {
        values.ProductPic = imgUrl;
      } else {
        this.setState({ loading: false });
        return;
      }
    }

    // 品牌简介重置
    // values.Guide = values.Guide.text;
    // 基本参数
    values.CouponTradeCfg = {
      MarketPrice: values.MarketPrice || '',
      CostPrice: values.CostPrice,
      SellPrice: values.SellPrice
    };
    // 兑换有效期重置
    if (values.exchangeDate && values.exchangeDate[0] && values.exchangeDate[1]) {
      const [start, end] = values.exchangeDate;
      values.CouponTradeCfg.RechargeBeginDate = `${start}`;
      values.CouponTradeCfg.RechargeEndDate = `${end}`;
    }
    // 商品类型重置
    const unionCouponOrigin = values.UnionCouponOrigin;
    values.UnionCouponOrigin = unionCouponOrigin.type;
    if (Number(values.UnionCouponOrigin) === 3) {
      values.UnionCouponRechargeUrl = unionCouponOrigin.link;
    } else {
      values.UnionCouponRechargeUrl = '';
    }
    //
    delete values.CostPrice;
    delete values.SellPrice;
    delete values.MarketPrice;
    delete values.exchangeDate;

    // 驿业
    values.UnionCouponType = 1;
    // 权益标签
    const tList = [];
    tagList.forEach((item) => {
      if (item.active) {
        tList.push({
          Id: item.Id,
          TagName: item.TagName
        });
      }
    });
    values.ProTagList = tList;
    //
    // 发送请求
    const status = await provideStore.fetchProvideCouponAddSave({ ...values, ...params });
    if (!status.IsError) {
      const text = params.id ? '编辑' : '新增';
      Notify.success(`${text}商品成功`);
      window.history.back();
    }
    this.setState({ loading: false });
  }

  // 标签模板
  initTagTpl = () => {
    const { detail, tagList } = this.state;
    if (detail) {
      const json = {};
      tagList.forEach((item) => {
        json[item.Id] = item;
      });
      detail.ProTagList.forEach((item) => {
        if (json[item.Id]) { // 选中标签 打上选中标记
          json[item.Id].active = true;
        }
      });
      // 重构数组
      const newTagList = Object.values(json).reverse();
      // 编辑
      return (
        <div
          className={`${classNamePre}-tag-con yiye-outline`}
        >
          {
            newTagList.map((item, index) => (
              <Button
                key={item.Id}
                index={index}
                disabled
                outline={item.active ? 0 : true}
              >
                {item.TagName}
              </Button>
            ))
        }
        </div>
      );
    }
    // 新增
    return (
      <div
        className={`${classNamePre}-tag-con yiye-outline`}
        role="button"
        tabIndex="0"
        onClick={event => this.changeTag(event)}
      >
        {
          tagList.map((item, index) => (
            <Button
              key={item.Id}
              index={index}
              type="primary"
              size="middle"
              outline={item.active ? 0 : true}
              hasClass={item.active ? 1 : 0}
              className={item.active ? 'active' : ''}
            >
              {item.TagName}
            </Button>
          ))
        }
      </div>
    );
  }

  // 时间为空转换
  transEmptyDate = (date) => {
    if (date.indexOf('0001-01-01') !== -1) {
      return '';
    }
    return date;
  }

  render() {
    const {
      brandList, supplierList, loading, breadList, detail, type
    } = this.state;
    return (
      <div className={`${classNamePre}`}>
        <div className="yiye-global-bread">
          <Breadcrumb breads={breadList} />
        </div>
        <div className="yiye-global-top-title">
          <div>商品上架后不可再修改</div>
        </div>
        <Form horizontal>
          {/* 基础配置 */}
          <Title
            titleDesc="基础配置"
            className={`${classNamePre}-base`}
          >
            <div>
              <FormInputField
                name="CouponName"
                type="text"
                label="商品名称"
                width={320}
                maxLength={20}
                showCount
                value={detail ? detail.CouponName : ''}
                disabled={type === 'look'}
                required
                placeholder="请输入商品名称"
                validations={{ required: true }}
                helpDesc="例如：爱奇艺VIP体验卡，填写后展示于兑换市场给EZR客户"
                validationErrors={{ required: '请填写商品名称' }}
              />
              <FormInputField
                name="subTitle"
                type="text"
                label="副标题"
                width={320}
                maxLength={20}
                showCount
                value={detail ? detail.SubTitle : ''}
                disabled={type === 'look'}
                placeholder="请输入副标题"
                helpDesc="可写商品使用限制，填写后展示于兑换市场给EZR客户"
              />
              <Field
                name="ProductPic"
                type="text"
                label="商品图片"
                tips="建议尺寸：750 x 750 像素"
                component={ConstFormUpload}
                openBase64={false}
                value={
                  detail
                    ? {
                      src: detail.ProductPic
                    }
                    : {}
                }
                disabled={type === 'look'}
                validations={{
                  required(values, value) {
                    if (value.src) {
                      return true;
                    }
                    return false;
                  }
                }}
                required
                validationErrors={{ required: '商品图片不能为空' }}
              />
              <Field
                name="SupplyId"
                type="text"
                label="供应商"
                optionText="MerchantName"
                component={ConstFormSearchSelect}
                data={supplierList}
                value={
                  detail ? detail.SupplyId : ''
                }
                disabled={!!detail}
                required
                validations={{
                  required(values, value) {
                    if (value) {
                      return true;
                    }
                    return false;
                  }
                }}
                validationErrors={{ required: '请选择供应商' }}
              />
              <FormInputField
                name="ProductCode"
                type="text"
                label="商品编码"
                width={320}
                showCount
                required
                value={
                  detail ? detail.ProductCode : ''
                }
                disabled={!!detail}
                placeholder="请输入商品编码"
                validations={{ required: true }}
                validationErrors={{ required: '请填写商品编码' }}
                helpDesc="第三方券系统商品编码，非唯一识别，可重复"
              />
              <Field
                name="ProBrandId"
                type="text"
                label="驿业品牌"
                optionText="BrandName"
                component={ConstFormSearchSelect}
                data={brandList}
                value={
                  detail ? detail.ProBrandId : ''
                }
                disabled={!!detail}
                required
                validations={{
                  required(values, value) {
                    if (value) {
                      return true;
                    }
                    return false;
                  }
                }}
                validationErrors={{ required: '请选择驿业品牌' }}
              />
              <Field
                name="UnionCouponOrigin"
                type="text"
                label="商品类型"
                component={ConstFormProType}
                data={detail ? (type === 'look') : false}
                value={
                  detail ? { type: `${detail.UnionCouponOrigin}`, link: detail.UnionCouponRechargeUrl } : { link: '' }
                }
                disabled={!!detail}
                required
                validations={{
                  required(values, value) {
                    if (value.type) {
                      return true;
                    }
                    return false;
                  },
                  checkurl(values, value) {
                    if (Number(value.type) === 3 && !value.link) {
                      return false;
                    }
                    return true;
                  }
                }}
                validationErrors={{ required: '请选择商品类型', checkurl: 'URL不能为空' }}
              />
              {
                // <Field
                //   name="Guide"
                //   type="text"
                //   label="使用说明"
                //   component={Editor}
                //   className={`${classNamePre}-edit-con`}
                //   value={detail ? { text: detail.Guide, init: true } : { text: '', init: false }}
                //   disabled={!!detail}
                //   required
                //   validations={{
                //     required(values, value) {
                //       if (value.isEmpty) {
                //         return false;
                //       }
                //       return true;
                //     }
                //   }}
                //   validationErrors={{ required: '使用说明不能为空' }}
                // />
              }
              <FormInputField
                name="Guide"
                type="textarea"
                width={320}
                label="使用说明"
                required
                value={detail ? detail.Guide : ''}
                disabled={detail}
                maxLength={512}
                showCount
                validations={{ required: true }}
                validationErrors={{ required: '请填写使用说明' }}
              />
            </div>
          </Title>
          {/** 交易配置 */}
          <Title
            titleDesc="交易配置"
            className={`${classNamePre}-transaction`}
          >
            <div>
              <Field
                name="MarketPrice"
                label="市场价"
                component={ConstFormDay}
                value={
                  (detail && detail.CouponTradeCfg && detail.CouponTradeCfg.MarketPrice) ? detail.CouponTradeCfg.MarketPrice : ''
                }
                disabled={type === 'look'}
                startTxt=""
                toFixLen={2}
                endTxt="元"
                width={120}
              />
              <Field
                name="SellPrice"
                label="售价"
                component={ConstFormDay}
                value={
                  detail ? detail.CouponTradeCfg.SellPrice : ''
                }
                disabled={!!detail}
                startTxt=""
                toFixLen={2}
                width={120}
                endTxt="Z币(元)"
                required
                validations={{ required: true }}
                validationErrors={{ required: '售价不能为空' }}
              />
              <Field
                name="CostPrice"
                label="成本价"
                component={ConstFormDay}
                value={
                  detail ? detail.CouponTradeCfg.CostPrice : ''
                }
                disabled={!!detail}
                startTxt=""
                toFixLen={2}
                endTxt="Z币(元)"
                width={120}
                required
                validations={
                  {
                    required: true,
                    costEffective(values, value) {
                      if (value && values.SellPrice && value > values.SellPrice) {
                        return false;
                      }
                      return true;
                    }
                  }}
                validationErrors={{ required: '成本价不能为空', costEffective: '成本价必须小于等于售价' }}
              />
              <FormDateRangePickerField
                name="exchangeDate"
                label={(
                  <span>
                  兑换有效期&nbsp;
                    <Pop
                      trigger="hover"
                      position="right-center"
                      content="券的兑换有效期，如：券只在某个固定时间段可兑换"
                      centerArrow
                    >
                      <Icon
                        type="info"
                        ezrd
                      />
                    </Pop>
                  </span>
                )}
                type="split"
                value={
                  (detail && detail.CouponTradeCfg && detail.CouponTradeCfg.RechargeBeginDate && detail.CouponTradeCfg.RechargeEndDate)
                    ? [this.transEmptyDate(detail.CouponTradeCfg.RechargeBeginDate), this.transEmptyDate(detail.CouponTradeCfg.RechargeEndDate)]
                    : []
                }
                dateFormat="YYYY-MM-DD HH:mm:ss"
                preDesc=""
                width={190}
                rearDesc=""
                showTime
                disabled={type === 'look'}
                required
                validations={{
                  required(values, value) {
                    if (!value[0] && !value[1]) {
                      return false;
                    }
                    return true;
                  },
                  checkStart(values, value) {
                    if (!value[0] && !value[1]) {
                      return true;
                    }
                    return !!value[0];
                  },
                  checkEnd(values, value) {
                    if (!value[0] && !value[1]) {
                      return true;
                    }
                    return !!value[1];
                  }
                }}
                validationErrors={{
                  required: '兑换有效不能为空',
                  checkStart: '请选择开始日期',
                  checkEnd: '请选择结束日期'
                }}
              />
              {
                // <Field
                //   name="CusValidVay"
                //   type="text"
                //   label='商品上架时间'
                //   component={ConstFormDateAndRadio}
                //   value={{
                //         type: '',
                //         data: ['', '']
                //       }
                //   }
                //   firstTxt="立即上架"
                //   secondTxt='指定上架时间'
                //   required
                //   validations={{
                //     required(values, value) {
                //       console.log(!!value.type)
                //       return !!value.type;
                //     },
                //     valueTwo(values, value) {
                //       if (value.type && value.type === '2' && (!value.data[1][0] || !value.data[1][1])) {
                //         return false;
                //       }
                //       return true;
                //     }
                //   }}
                //   validationErrors={{ required: '商品上架时间不能为空', valueTwo: '请输入开始时间和结束时间' }}
                // />
              }
              <FormRadioGroupField
                name="CouponStatus"
                label="商品上架时间"
                required
                value={
                  detail ? `${detail.CouponStatus}` : ''
                }
                disabled={!!detail}
                validations={{
                  required(values, value) {
                    return value !== '';
                  }
                }}
                validationErrors={{
                  required: '请选择商品上架时间'
                }}
              >
                <Radio value="1">立即上架</Radio>
              </FormRadioGroupField>
            </div>
          </Title>

          {/** 交易配置 */}
          <Title
            titleDesc="商品权益标签"
            className={`${classNamePre}-tag`}
          >
            {
            this.initTagTpl()
          }
          </Title>
          { /** 保存按钮 */}
          {
            type === 'look'
              ? null
              : (
                <div className={`${classNamePre}-group-btn`}>
                  <Button
                    type="primary"
                    size="middle"
                    loading={loading}
                    onClick={() => this.onSave()}
                  >
                  保存
                  </Button>
                </div>
              )
          }
        </Form>
      </div>
    );
  }
}


const GoodsManagementAdd = createForm()(GoodsManagementAddForm);

export default GoodsManagementAdd;
