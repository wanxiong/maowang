import React, { Component } from 'react';
import { observer, inject } from 'mobx-react';
import {
  Drawer,
  Form,
  Button
} from 'ezrd';
import { ConstFormUpload } from '../../../../components/base/constFormImage';


const {
  Field,
  createForm,
  FormInputField
} = Form;
@inject('supplierStore')
@observer
class DrawWrapper extends Component {
  state = {
    loading: false
  }

  submit = async () => {
    const { ezrdForm, save } = this.props;
    // const { tagList } = this.state;
    ezrdForm.setFormDirty(true);
    if (ezrdForm.isValid()) {
      this.setState({
        loading: true
      }, async () => {
        const values = ezrdForm.getFormValues();
        const {
          BrandName,
          BrandLog,
          Remark
        } = values;
        // 先上传图片
        // const imgObj = values.BrandLog;
        let imgUrl = '';
        if (BrandLog.data && BrandLog.data[0].file) {
          imgUrl = await this.uploadImg({ file: BrandLog.data[0].file });
        } else {
          imgUrl = BrandLog.src;
        }
        save({ BrandLog: imgUrl, Remark, BrandName }, this.resetForm);
        this.setState({ loading: false });
      });
    }
  }

  close = () => {
    const {
      closeDrawer
    } = this.props;
    // this.resetForm();
    closeDrawer();
  }

  resetForm = () => {
    const {
      ezrdForm
    } = this.props;
    ezrdForm.resetFieldsValue();
  }

  // 上传图片接口
  uploadImg = async (params) => {
    const { supplierStore } = this.props;
    const status = await supplierStore.fetchSupplierUploadImg(params);
    if (!status.IsError && status.Data) {
      return status.Data.pathfull;
    }
    return null;
  }

  render() {
    const {
      drawVisible,
      detail,
      id,
      count
    } = this.props;
    const {
      loading
    } = this.state;
    // console.log(detail, 'drawer');
    return (
      <Drawer
        visible={drawVisible}
        width="800px"
        title={id ? `编辑品牌` : `新增品牌`}
        className="brand-manage-drawer"
        titleColor="#000"
        topPadding="0px"
        headerStyle={{
          background: '#fff',
          height: '56px',
          lineHeight: '56px',
          textAlign: 'left',
          padding: '0 20px'
        }}
        showFooter={false}
        footer={(
          <React.Fragment>
            <Button
              type="default"
              onClick={this.close}
            >
              取消
            </Button>
            <Button
              loading={loading}
              onClick={this.submit}
              type="primary"
            >
              确定
            </Button>
          </React.Fragment>
        )}
        style={{ marginTop: '0' }}
        handleClose={this.close}
      >
        <div
          key={count}
          style={{ paddingTop: '20px', background: '#fff', height: '100%' }}
        >
          <Form horizontal>
            <FormInputField
              label="品牌名称"
              name="BrandName"
              required
              showCount
              showClear
              maxLength={30}
              validations={{
                required: true
              }}
              value={detail.BrandName}
              validationErrors={{
                required: '请填写品牌名称'
              }}
              validateOnBlur
            />

            <Field
              name="BrandLog"
              type="text"
              label="品牌LOGO"
              component={ConstFormUpload}
              openBase64={false}
              required
              value={
                detail.BrandLog
                  ? {
                    src: detail.BrandLog
                  }
                  : {}
              }
              validations={{
                required(values, value) {
                  // console.log(values, value);
                  if (value.src) {
                    return true;
                  }
                  return false;
                }
              }}
              validationErrors={{ required: '品牌LOGO不能为空' }}
            />

            {/* <Field
              name="Remark"
              type="text"
              label="品牌简介"
              component={Editor}
              style={{ maxWidth: '100%' }}
              value={detail.Remark ? { text: detail.Remark, init: true } : { text: '', init: true }}
            /> */}
            <FormInputField
              name="Remark"
              type="textarea"
              label="品牌简介"
              width={320}
              value={detail.Remark}
              maxLength={512}
              showCount
            />
          </Form>
        </div>

      </Drawer>
    );
  }
}

const DrawWrapperForm = createForm()(DrawWrapper);

export default DrawWrapperForm;
