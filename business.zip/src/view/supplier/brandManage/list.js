import * as React from 'react';
import {
  Table, Pagination, Button, Notify
} from 'ezrd';
import { observer, inject } from 'mobx-react';
import DrawerForm from './components/drawer';
import BrandManagement from '../../../components/supplier/brandManagementForm';
import { AddBrand, SaveBrand } from '../../../services/brandManagement';

const classNamePre = 'yiye-purchase-order';
let count = 1;
@inject('brandManagement')
@observer
class YiyePurchaseOrder extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      drawVisible: false,
      details: {}
    };
    this.id = 0;
    this.onChange = this.onChange.bind(this);
    this.onPageSizeChange = this.onPageSizeChange.bind(this);
  }

  // @checkShopStatus('purchase')
  componentDidMount() {
    this.initData({});
  }

  // initData
  initData = (params = {}) => {
    const { brandManagement } = this.props;
    const { pageSize, current } = this.state;
    brandManagement.QueryByPage({
      Page: current,
      PageSize: pageSize,
      BrandName: '',
      ...params
    });
  }

  // 点击查询的事件
  onHandleSearch = (data, flag) => {
    if (flag) {
      this.setState({
        current: 1
      }, () => {
        this.initData(data);
      });
    } else {
      this.initData(data);
    }
  }

  // 每页大小的回调
  onPageSizeChange = (pageSize) => {
    this.setState({
      pageSize,
      current: 1
    }, () => {
      this.searchDom.onSearch(0);
    });
  };

  // 分页的回调
  onChange = (data) => {
    const { current } = this.state;
    this.setState({
      current: data || current
    }, () => {
      this.searchDom.onSearch(0);
    });
  }

  addBrand = () => {
    count++;
    this.setState({
      drawVisible: true
    });
    this.id = 0;
  }

  closeDrawer = () => {
    this.setState({
      drawVisible: false,
      details: {}
    });
  }

  save = async (values, cb) => {
    let Data;
    let ErrorMsg;
    if (this.id) {
      ({ Data, ErrorMsg } = await SaveBrand({ ...values, Id: this.id }));
    } else {
      ({ Data, ErrorMsg } = await AddBrand(values));
    }
    // eslint-disable-next-line no-unused-expressions
    cb && cb();
    if (Data) {
      Notify.success('操作成功');
      this.setState({
        drawVisible: false,
        details: {}
      });
      this.searchDom.onSearch(0);
    } else {
      Notify.error(ErrorMsg);
    }
  }

  close = () => {
    this.setState({
      drawVisible: false
    });
  }

  edit = ({
    Id, BrandName, BrandLog, Remark
  }) => () => {
    this.id = Id;
    this.setState({
      details: {
        BrandName,
        BrandLog,
        Remark
      },
      drawVisible: true
    });
  }

  render() {
    const { history, brandManagement: { queryPageList, TotalRowsCount } } = this.props;
    const {
      current, pageSizeList, drawVisible, details
    } = this.state;
    // console.log(details, 'list');
    const columns = [{
      title: '驿业品牌',
      textAlign: 'left',
      name: 'MerchantName',
      bodyRender: data => (
        <div style={{
          display: 'flex', alignItems: 'center'
        }}
        >
          <div style={{
            width: '64px', height: '64px', display: 'flex', alignItems: 'center', justifyContent: 'center', marginRight: '20px'
          }}
          >
            <img
              style={{
                border: '1px solid #eee', borderRadius: '2px', maxWidth: '100%', maxHeight: '100%'
              }}
              src={data.BrandLog}
              alt=""
            />
          </div>

          <p>{data.BrandName}</p>
        </div>
      )
    }, {
      title: '操作',
      name: 'ProviderName',
      bodyRender: data => (
        <div>
          <Button
            size="small"
            onClick={this.edit(data)}
            isText
          >
            编辑
          </Button>
        </div>
      )
    }];
    return (
      <div className={`${classNamePre}`}>
        {/* 查询头部 */}
        <BrandManagement
          onSearch={this.onHandleSearch}
          history={history}
          getRef={(ref) => { this.searchDom = ref; }}
        />
        <div className={`${classNamePre}-pro`}>
          <Button
            type="primary"
            style={{ marginBottom: '20px' }}
            onClick={this.addBrand}
          >
            新增驿业品牌
          </Button>
          <Table
            columns={columns}
            datasets={queryPageList}
            rowKey="id"
          />
          <Pagination
            current={current}
            totalItem={TotalRowsCount}
            pageSize={pageSizeList}
            onChange={this.onChange}
            onPageSizeChange={this.onPageSizeChange}
          />
        </div>

        <DrawerForm
          drawVisible={drawVisible}
          close={this.close}
          save={this.save}
          detail={details}
          closeDrawer={this.closeDrawer}
          id={this.id}
          count={count}
        />
      </div>
    );
  }
}

export default YiyePurchaseOrder;
