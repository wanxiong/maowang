import * as React from 'react';
import {
  Table, Pop, Icon
} from 'ezrd';
import moment from 'moment';
import { observer, inject } from 'mobx-react';
// import { toJS } from 'mobx';
import SaleOrderSearch from '../../components/supplier/saleOrderSearch';
import { couponDefaultPage, sessSupplierCouponCodeKey } from '../../components/base/constant';
// 新建
const classNamePre = 'yiye-supplier-sale-order';

@inject('supplierStore')
@inject('provideStore')
@observer
export default class SaleOrder extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      ...couponDefaultPage
    };
  }

  async componentDidMount() {
    this.initData({
      Status: ''
    });
  }

initData = async (params = {}) => {
  const { supplierStore } = this.props;
  const { pageSize, current } = this.state;
  await supplierStore.fetchSupplierSaleOrderList({
    PurchaseNo: '',
    ProviderName: '',
    CouponName: '',
    PurchaseName: '',
    StartTime: '',
    EndTime: '',
    Status: '',
    PageSize: pageSize,
    PageIndex: current,
    ...params
  });
}

// 分页的回调
onChange = (data) => {
  let { current } = this.state;
  const { pageSize } = this.state;
  if (data.pageSize) {
    if (data.pageSize === pageSize) {
      return;
    }
    current = 1;
  }
  this.setState({
    pageSize: data.pageSize || pageSize,
    current: data.current || current
  }, () => {
    this.searchDom.onSearch(0);
  });
}

// 搜索按钮的回调
onSearch = (data, flag) => {
  const params = {
    PurchaseNo: data.saleNumber,
    ProviderName: data.proName,
    CouponName: data.couponName,
    PurchaseName: data.brand,
    StartTime: data.StartDate,
    EndTime: data.EndDate,
    Status: data.typeValue
  };
  if (flag !== 0) {
    this.setState({ current: 1 }, () => {
      this.initData(params);
    });
    return;
  }
  this.initData(params);
}

// 操作区域的渲染
initStatus = (item) => {
  if (item.Status === 21) {
    return (
      <span>
        入库异常
        <Pop
          trigger="hover"
          position="top-right"
          content={item.BackReason}
        >
          <Icon
            type="info-circle-o"
            style={{ 'margin-left': '3px' }}
            className={`${classNamePre}-pro-popicon`}
          />
        </Pop>
      </span>
    );
  }
  return (<span>{item.StatusDes}</span>);
}

importCoupon = (data) => {
  const { history } = this.props;
  localStorage.setItem(sessSupplierCouponCodeKey, JSON.stringify({
    CouponGrpId: data.CouponGrpId,
    PurchaseOrderId: data.Id
  }));
  history.push('/Yiye/Import/CouponCode');
}

// ''
render() {
  const {
    current, pageSizeList
  } = this.state;
  const { supplierStore } = this.props;
  const { supplierSaleOrderList } = supplierStore;
  const { PagedList, TotalRowsCount } = supplierSaleOrderList;
  const columns = [
    {
      title: '采购方',
      textAlign: 'left',
      name: 'PurchaseName'
    },
    {
      title: '销售时间',
      textAlign: 'left',
      bodyRender: data => <div>{moment(data.BuyTime).format('YYYY-MM-DD HH:mm:ss')}</div>
    },
    {
      title: '券信息',
      textAlign: 'left',
      width: '280px',
      bodyRender: data => (
        <div className={`${classNamePre}-contain-table-first`}>
          <div style={{ width: '64px', height: '64px', 'margin-right': '10px' }}>
            <img
              src={data.ProductPic}
              alt={data.ProBrandName}
            />
          </div>
          <div>
            <div>{data.CouponName}</div>
            <div>{data.SubTitle}</div>
            <div>{data.UnionCouponOriginTypeName}</div>
            <div>
              券ID:
              {data.CouponGrpId}
            </div>
          </div>
        </div>
      )
    },
    {
      title: '销售单号',
      width: '220px',
      name: 'PurchaseNo'
    },
    {
      title: '供应商',
      name: 'ProviderName'
    },
    {
      title: '销量(张)',
      name: 'BuyCount'
    },
    {
      title: '售价(Z币)',
      name: 'SellPrice'
    },
    {
      title: '订单总价(Z币)',
      name: 'UnionMoney'
    },

    {
      title: '状态',
      bodyRender: data => this.initStatus(data)
    },
    {
      title: '操作',
      bodyRender: (data) => {
        if (data.IsImportCoupon) {
          return (
            <div className={`${classNamePre}-contain-table-contr`}>
              <span
                role="button"
                tabIndex="0"
                className="yiye-outline btn-default-color yiye-cursor"
                onClick={() => this.importCoupon(data)}
              >
                导入券码
              </span>
            </div>
          );
        }
        return ('--');
      }
    }
  ];
  return (
    <div className={`${classNamePre}`}>
      {/* 搜索区域 */}
      <div>
        <SaleOrderSearch
          ref={(ref) => { this.searchDom = ref; }}
          onSearch={this.onSearch}
        />
      </div>
      <div className={`${classNamePre}-contain`}>
        {/* table展示区域 */}
        <div className={`${classNamePre}-contain-table`}>
          <Table
            columns={columns}
            datasets={PagedList}
            rowKey="Id"
            pageInfo={{
              totalItem: TotalRowsCount,
              current,
              pageSize: pageSizeList
            }}
            onChange={this.onChange}
          />
        </div>
      </div>
    </div>
  );
}
}
