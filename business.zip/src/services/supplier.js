import http from '../utils/http';
import config from '../config';

const { baseUrl } = config;

/** 供应商-商品管理-列表接口
* @params {String CouponStatus}             券状态
* @params {String UnionCouponOrigin}        产品类型/1:券码   2:url 3:券码+url  4:直充
* @params {String BrandKey}                 商品名称或者商品编码
* @params {String EndDate}                  创建时间结束
* @params {String BeginDate}                创建时间开始
* @params {String ProBrandName}             商品品牌名称
* @params {String SupplyName}               供应商名称
* @params {String PageIndex}                当前页数
* @params {String PageSize}                 当前页的数量
* */
export const GetSupplierGoodsList = params => http.post(`${baseUrl}Coupon/Union/UnionCoupon/GetUnionProList`, params);

/** 供应商-商品管理-新增商品-上传商品图片
* 文件流
* */
export const GetSupplierUploadImg = params => http.postUpload(`${baseUrl}Coupon/Union/UnionCoupon/PostImage`, params);

/** 供应商-商品管理-获取所有供应商
*
* */
export const GetQueryAllSupplier = params => http.post(`${baseUrl}account/api/Merchant/QueryAllSupplier`, params);

/** 供应商-销售订单-列表
* @params {String PurchaseNo}               销售单号
* @params {String ProviderName}             供应商名称
* @params {String CouponName}               券名称
* @params {String PurchaseName}             驿业品牌
* @params {String StartTime}                销售开始时间
* @params {String EndTime}                  销售结束时间
* @params {String Status}                   状态
* @params {String PageIndex}                当前页数
* @params {String PageSize}                 当前页的数量
* */
export const GetSupplierSaleOrderList = params => http.post(`${baseUrl}Coupon/Union/Purchase/GetSaleOrderList`, params);
