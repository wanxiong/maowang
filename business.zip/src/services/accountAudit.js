import http from '../utils/http';
import config from '../config';

const { baseUrl } = config;

/** 审核品牌商入住申请
* @params {String IsPass}                   通过-0/拒绝-1
* @params {String Remark}                   拒绝原因
* @params {String MchId}                    审核商户Id
* */
export const GetMerchantApplyCheck = params => http.post(`${baseUrl}account/api/Merchant/CheckBrandApply`, params);

/** 商户审核列表
* @params {String StartDate}                 入驻开始时间
* @params {String EndDate}                   入驻结束时间
* @params {String Status}                    [状态]-3:平台禁用;-2:审核未通过;-1:品牌歇业;0:商户初始化;1:待审核;2:营业中; 9:查询全部
* @params {String AccountType}               [类型]0:普通账户;1:担保账户 9:查询全部
* @params {String QueryMchId}                品牌Id
* @params {String Page}                      分页当前页
* @params {String PageSize}                  分页每页大小
* @params {String MchId}                     商户ID
* */
export const GetMerchantApplyList = params => http.post(`${baseUrl}account/api/Merchant/QueryCheckList`, params);

/** 商户审核--启用/禁用
* @params {String IsEnable}                  是否启用 0-禁用 1-启用
* @params {String Remark}                    备注
* @params {String MchId}                     商户ID
* */
export const GetMerchantEnable = params => http.post(`${baseUrl}account/api/Merchant/EnableMerchant`, params);

/** 商户审核--担保账户/普通账户 切换
* @params {String AccountType}               是否启用 0-禁用 1-启用
* @params {String MchId}                     商户ID
* */
export const GetMerchantChangeAccountType = params => http.post(`${baseUrl}account/api/Merchant/ChangeAccountType`, params);

/** 账户审核-初始化品牌客户-查看对应的品牌信息
* @params {String BrandId}                  品牌id
* @params {String CloudId}                  所在云地址,1-uc 2-微软 3-腾讯云
* */
export const GetCrmBrandInfo = params => http.post(`${baseUrl}Coupon/Union/Init/GetCrmBrandInfo`, params);


/** 账户审核-平台初始化商户数据带初始化券平台
* @params {String Id}                       品牌id
* @params {String CloudId}                  所在云地址Id
* @params {String MerchantType}             商户类型;[0:EZR;1:品牌商户;2:外部商户;3:供应商(向平台供货)]
* @params {String BrandName}                CRM品牌名
* @params {String MerchantName}             CRM品牌名
* @params {String MchId}                    商户ID
* */
export const MerchantInsertOfInitWithCrm = params => http.post(`${baseUrl}account/api/Merchant/MerchantInsertOfInitWithCrm`, params);
