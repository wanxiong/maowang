import http from '../utils/http';
import config from '../config';

const { baseUrl } = config;

/** 系统管理-角色管理-列表接口
* @params {String Code}                     角色编码
* @params {String Name}                     角色名称
* @params {String MchId }                   品牌Id
* @params {Number Page}                     当前页
* @params {Number PageSize}                 显示几条
* */
export const GetSysRoleList = params => http.post(`${baseUrl}account/api/Permission/RoleQueryByPage`, params);

/** 系统管理-角色管理-新增接口
* @params {String Code}                     角色编码
* @params {String Name}                     角色名称
* @params {Number MenuIds}                  选中的树ID数组
* */
export const GetSysRoleAdd = params => http.post(`${baseUrl}account/api/Permission/RoleInsert`, params);

/** 系统管理-角色管理-删除接口
* @params {String Id}                       删除Id
* */
export const GetSysRoleDel = params => http.post(`${baseUrl}account/api/Permission/RoleDelete`, params);

/** 系统管理-角色管理-编辑接口
* @params {String Id}                       删除Id
* @params {String Code}                     角色编码
* @params {String Name}                     角色名称
* @params {Number MenuIds}                  选中的树ID数组
* */
export const GetSysRoleEdit = params => http.post(`${baseUrl}account/api/Permission/RoleEdit`, params);

/** 系统管理-角色管理-详情接口
* @params {String Id}                       删除Id
* @params {String Code}                     角色编码
* @params {String Name}                     角色名称
* */
export const GetSysRoleDetail = params => http.post(`${baseUrl}account/api/Permission/RoleQueryById`, params);

/** 系统管理-用户管理-新增
* @params {String RealName}                 用户姓名
* @params {String MobileNo}                 手机号
* @params {String EMail}                    邮箱号
* @params {Number RoleId}                   角色Id
* @params {Number OrganizationId}           组织Id
* @params {Number Password}                 密码
* @params {Number Remark}                   备注
* @params {String MchId }                   品牌Id
* */
export const GetSysUserAdd = params => http.post(`${baseUrl}account/api/Account/AddAccount`, params);

/** 系统管理-用户管理-列表
* @params {String CodeKeyWord}              用户编码
* @params {String RealNameKeyWord}          用户姓名
* @params {String Status}                   状态[-1-全部，0-初始，1-禁用，2-启用，冻结]
* @params {Number Page}                     当前页
* @params {Number PageSize}                 显示几条
* @params {String MchId }                   品牌Id
* */
export const GetSysUserList = params => http.post(`${baseUrl}account/api/Account/QueryAccountFullInfo`, params);


/** 系统管理-用户管理-冻结/启动/等状态接口
* @params {String Id}                       用户Id
* @params {String Status}                   状态[-1-全部，0-初始，1-禁用，2-启用，冻结]
* */
export const GetSysUserUpdateStatus = params => http.post(`${baseUrl}account/api/Account/ModifyStatus`, params);

/** 系统管理-用户管理-编辑接口
* @params {String Id}                       用户Id
* @params {String Code}                     用户编码
* @params {String AccountName}              用户名
* @params {String RealName}                 真实姓名
* @params {String MobileNo}                 手机号码
* @params {String EMail}                    邮箱
* @params {String RoleId}                   角色Id
* @params {String MchId}                    商户ID
* @params {String Status}                   状态[-1-全部，0-初始，1-禁用，2-启用，冻结]
* */
export const GetSysUserUpdate = params => http.post(`${baseUrl}account/api/Account/ModifyAccount`, params);

/** 系统管理-用户管理-修改他人密码
* @params {String Id}                       用户Id
* @params {String NewPassword}              密码
* */
export const GetSysUserModifyPassword = params => http.post(`${baseUrl}account/api/Account/ModifyPassword`, params);
