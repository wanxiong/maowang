import qs from 'qs';
import http from '../utils/http';
import config from '../config';

const { baseUrl } = config;

/** 下载中心-下载类型列表接口
* */
export const GetDownLoadTypeList = params => http.get(`${baseUrl}account/api/DataTask/GetDownloadType?${qs.stringify(params)}`);

/** 下载中心-列表接口
* @params { String Type }           下载类型
* @params { String TaskName }       文件名称
* @params { String BegDate }        开始时间
* @params { String EndDate }        结束时间
* @params {String PageIndex}        当前页数
* @params {String PageSize}         当前页数的条目
* */
export const GetDownLoadList = params => http.post(`${baseUrl}account/api/DataTask/GetList`, params);

/** 下载中心-下载接口
* @params { String id }             下载id
* return 下载URL的地址
* */
export const GetDownLoad = params => http.post(`${baseUrl}account/api/DataTask/Download`, params);

/** 下载中心-重新计算接口
* @params { String id }             下载id
* */
export const GetDownLoadReset = params => http.post(`${baseUrl}account/api/DataTask/ResetTask`, params);

/** 下载中心-删除
* @params { String id }             下载id
* */
export const GetDownLoadDelete = params => http.post(`${baseUrl}account/api/DataTask/Delete`, params);

/** 下载中心-下载接口-Crm
* @params { String id }             下载id
* return 下载URL的地址
* */
export const GetDownLoadCrm = params => http.get(`${baseUrl}Coupon/Union/DataTask/Download?${qs.stringify(params)}`);

/** 下载中心-重新计算接口-Crm
* @params { String id }             下载id
* */
export const GetDownLoadResetCrm = params => http.get(`${baseUrl}Coupon/Union/DataTask/ResetTask?${qs.stringify(params)}`);

/** 下载中心-删除-Crm
* @params { String id }             下载id
* */
export const GetDownLoadDeleteCrm = params => http.post(`${baseUrl}Coupon/Union/DataTask/Delete`, params);
