import qs from 'qs';
import http from '../utils/http';
import config from '../config';

const { baseUrl } = config;

/** 渠道注册 - 列表
* */
export const RequestChannelList = params => http.get(`${baseUrl}Coupon/Union/WapRegister/GetList?${qs.stringify(params)}`);

/** 渠道注册 - 新建
* */
export const CreateNewChannel = params => http.post(`${baseUrl}Coupon/Union/WapRegister/SaveData`, params);

/** 渠道注册 - 详情 http://localhost:9901/Union/WapRegister/GetDetailById?id=1
* */
export const RequestNewChannelDetail = params => http.get(`${baseUrl}Coupon/Union/WapRegister/GetDetailById?${qs.stringify(params)}`);

/** 渠道注册 - 编辑
* */
export const EditNewChannel = params => http.post(`${baseUrl}Coupon/Union/WapRegister/SaveData`, params);


/** 新建渠道 - 保存账号设置
* */
export const SaveChannelRegisterSetting = params => http.post(`${baseUrl}Coupon/Union/WapRegister/SaveRegisterFields`, params);

/** 新建渠道 - 获取账号设置
* */
export const GetChannelRegisterSetting = () => http.get(`${baseUrl}Coupon/Union/WapRegister/GetRegisterFields`);


// 获取礼包券
export const GetGiftbagsList = params => http.get(`${baseUrl}Coupon/CouponGrp/GetGiftbagDtls?${qs.stringify(params)}`);

// 获取短信数量
export const GetBrandMsgCfg = () => http.get(`${baseUrl}Coupon/Union/UnionCoupon/GetBrandMsgCfg`);

/** 活动明细导出
 *@params { String TaskName }    任务名称
 *@params { String Type     }    固定值 = 8
 *@params { Object Querys   }
 *          { String Id }        活动Id
 * */
export const GetChannelExportDetail = params => http.post(`${baseUrl}Coupon/Union/DataTask/DownChannelRegDetail`, params);
