import http from '../utils/http';
import config from '../config';

const { baseUrl } = config;

/** 核销率-列表查询
* @params {String Date}                     入住时间
* @params {String SettingType}              适用场景；[1:券;2:积分;3:商品;]
* @params {String Date}                     入驻日期（yyyy-MM-dd）
* @params {String Status}                   商户状态[ -3:平台禁用;-2:审核未通过;-1:品牌歇业;0:商户初始化;1:待审核;2:营业中;9:全部]
* @params {String Page}                     当前页数
* @params {String MchId }                   品牌Id
* @params {String PageSize}                 每页大小
* */
export const GetMerchantWriteRateList = params => http.post(`${baseUrl}account/api/Attr/RateQuery`, params);

/** 核销率-核销编辑接口
* @params {String Id}                       自增ID
* @params {String InitCancelRate}           核销率价格 0-1
* @params {String MchId }                   品牌Id
* */
export const GetMerchantWriteRateEdit = params => http.post(`${baseUrl}account/api/Attr/RateEditInitCancelRate`, params);

/** 平台手续费优惠-列表接口
* @params {String Status}                   状态 0:禁用；1:启用；-1:读取全部
* @params {String SettingType}              适用场景；[1:券;2:积分;3:商品;]
* @params {String Page}                     当前页数
* @params {String PageSize}                 每页大小
* @params {String MchId }                   品牌Id
* */
export const GetMerchantPlatformFeeList = params => http.post(`${baseUrl}account/api/Attr/FeeQuery`, params);

/** 平台手续费优惠-新增/编辑
* @params {String Id}                       自增ID
* @params {String SettingType}              适用场景；[1:券;2:积分;3:商品;]
* @params {String PreferentialRate}         优惠交易扣点
* @params {String PreferentialFee}          优惠佣金
* @params {String PreferentialStartDate}    优惠开始日期
* @params {String PreferentialEndDate}      优惠结束日期
* @params {String MchId }                   品牌Id
* */
export const GetMerchantPlatformFeeEdit = params => http.post(`${baseUrl}account/api/Attr/FeeSave`, params);

/** 平台手续费优惠--禁用/启用
* @params {String Id}                       自增ID
* @params {String Status}                   0:禁用；1:启用；
* @params {String MchId }                   品牌Id
* @params {String SettingType}              适用场景；[1:券;2:积分;3:商品;]
* */
export const GetMerchantPlatformFeeEnable = params => http.post(`${baseUrl}account/api/Attr/FeeEnable`, params);

/** 冻结比列--列表接口
* @params {String Id}                       自增ID
* @params {String SettingType}              适用场景；[1:券;2:积分;3:商品;]
* @params {String Status}                   0:禁用；1:启用；-1:读取全部
* @params {String MchId }                   品牌Id
* @params {String Page}                     当前页数
* @params {String PageSize}                 每页大小
* */
export const GetMerchantFreezeRatioList = params => http.post(`${baseUrl}account/api/Attr/FrozeRateQuery`, params);

/** 冻结比列--禁用/启用
* @params {String Id}                       自增ID
* @params {String Status}                   0:禁用；1:启用；
* @params {String MchId }                   品牌Id
* */
export const GetMerchantFreezeRatioEnable = params => http.post(`${baseUrl}account/api/Attr/FrozeRateEnable`, params);

/** 冻结比列-新增/编辑
* @params {String Id}                       自增ID
* @params {String DiscountRate}             优惠比例率
* @params {String StartDate}                优惠开始日期
* @params {String EndDate}                  优惠结束日期
* @params {String MchId }                   品牌Id
* */
export const GetMerchantFreezeRatioEdit = params => http.post(`${baseUrl}account/api/Attr/FrozeRateSave`, params);

/** 平台默认---手续费/核销率/冻结比例
* @params {String AttrType}                 1/默认手续费 2/默认冻结比例 3/默认核销率
* @params {String SettingType}              适用场景；[1:券;2:积分;3:商品;]
* @params {String MchId }                   品牌Id
* */
export const GetMerchantDefaultSettingFee = params => http.post(`${baseUrl}account/api/Attr/DefaultSettingQuery`, params);

/** 核销率--- 列表导出
* @params {String StartDate}                查询开始日期
* @params {String EndDate}                  查询结束日期
* @params {String Status}                   商户状态[ -3:平台禁用;-2:审核未通过;-1:品牌歇业;0:商户初始化;1:待审核;2:营业中;9:全部]
* @params {String SettingType}              适用场景；[1:券;2:积分;3:商品;]
* @params {String MchId }                   品牌Id
* @params {String taskName }                文件名称
* @params {String Page }                    不分页 --- 此参数暂时不要
* @params {String PageSize }                不分页 --- 此参数暂时不要

* */
export const GetMerchantDefaultExport = params => http.post(`${baseUrl}account/api/Attr/RateExport`, params);

/** 核销率--- 新增/编辑
* @params {String Id}                       自增ID
* @params {String InitCancelRate}           初始核销率
* @params {String CancelRate}               店铺核销率
* @params {String ClientPrice}              客单价
* @params {String SettingType}              适用场景；[1:券;2:积分;3:商品;]
* @params {String MchId }                   品牌Id
* */
export const GetMerchantWriteRateAdd = params => http.post(`${baseUrl}account/api/Attr/RateSave`, params);
