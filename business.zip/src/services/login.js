import http from '../utils/http';
import config from '../config';

const { baseUrl } = config;

/** 登陆接口
* @params {String UserName}                 用户名
* @params {String Passwoed}                 用户密码
* */
export const GetLogin = params => http.post(`${baseUrl}auth/api/Login/SigninInsideByPass`, params);

/** 忘记密码接口
* @params {String MobileNo}                 手机号
* @params {String VerifyCode}               验证码
* @params {String NewPassword}              新密码
* */
export const GetResetPassword = params => http.post(`${baseUrl}auth/api/Basic/ForgetPasswordModify`, params);

/** 忘记密码接口
* @params {String MobileNo}                 手机号
* */
export const GetVerifyCode = params => http.post(`${baseUrl}auth/api/Basic/GetVerifyCodeForForget`, params);


/** 退出接口操作
* @params {String MobileNo}                 手机号
* */
export const GetLogout = params => http.post(`${baseUrl}account/api/Account/RevoSelfToken`, params);

/** 获取当前账户类型---如商户还是平台----或者是CRM跳转登陆获取登陆信息
* */
export const GetMerchantSelf = () => http.get(`${baseUrl}account/api/Merchant/MerchantSelectBySelf`, {});
