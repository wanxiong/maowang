import qs from 'qs';
import http from '../utils/http';
import config from '../config';

const { baseUrl } = config;

/** 获取优惠券一览接口
* @params {String CouponType}             优惠券类型
* @params {String TplName}                券模板名称
* @params {String || Number PageIndex}    当前页数
* @params {String || Number PageSize}     每页大小
* */
export const GetBaseCouponList = params => http.get(`${baseUrl}Coupon/Union/UnionCoupon/GetCouponTplList?${qs.stringify(params)}`);


/** 获取商户所有品牌
* @params {String || Number Page}         当前页数
* @params {String || Number PageSize}     每页大小
* @params {String || Number MerchantTypes}过滤掉得品牌商
* */
export const GetMerchantBrandList = params => http.post(`${baseUrl}account/api/Merchant/QueryShortInfo`, params);

/** 获取驿业品牌列表
* @params {String || Number Page}         当前页数
* @params {String || Number PageSize}     每页大小
* */
export const GetProductBrandList = () => http.post(`${baseUrl}Coupon/Union/ProBrand/getallList`);

/** 获取促销券一览接口
* @params {String PromotionCode}          促销券编号
* @params {String PromotionName}          促销券名称
* @params {String || Number PageIndex}    当前页数
* @params {String || Number PageSize}     每页大小
* */
export const GetBasePromotionCouponList = params => http.get(`${baseUrl}Coupon/Union/UnionCoupon/GetPromotionCouponList?${qs.stringify(params)}`);
