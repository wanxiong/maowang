import qs from 'qs';
import http from '../utils/http';
import config from '../config';

const { baseUrl } = config;

/** 券码管理-列表接口
* @params {String Id}                     批次号
* @params {String StartDate}              开始时间
* @params {String EndDate}                结束时间
* @params {String Status}                 0-已提交/1-制券中/2-已生效/3-未生效/4-已失效
* @params {String ActName}                券码名称
* @params {String || Number PageIndex}    当前页数
* @params {String || Number PageSize}     每页大小
* */
export const GetCouponCodeList = params => http.post(`${baseUrl}Coupon/Union/CouponCode/GetList`, params);


/** 券码管理-详情接口
* @params {String Id}                     券码活动id
* */
export const GetCouponCodeDetil = params => http.get(`${baseUrl}Coupon/Union/CouponCode/GetById?${qs.stringify(params)}`);

/** 券码管理-导出接口
* @params {String TaskName}                任务名称
* @params {String Type}                    10/固定值
* @params {String ActId}                   券码id
* */
export const GetCouponCodeExport = params => http.post(`${baseUrl}Coupon/Union/DataTask/DownloadCouponCode`, params);

/** 券码管理-增加制券
* @params {String CouponGrpId}             券库id
* @params {String MakeQty}                 增加数量
* @params {String ActId}                   券码id
* */
export const GetCouponListAddStock = params => http.post(`${baseUrl}Coupon/Union/CouponCode/AddStock`, params);


/** 券码管理-新增券码
* @params {String CouponGrpId}             券库id
* @params {String CouponGrpName}           券库名称
* @params {String ActName}                 券码名称
* @params {String CouponValidType}         券的有效期类型，1领取之日起多少天有效 2自定义有效期
* @params {String CouponValidDays}         领取之日多少天内有效
* @params {String CouponBeginDate}         券的有效期-开始时间
* @params {String CouponType}              券类型，从选择器中获取
* @params {String CouponOrigin}            制券来源 0 品牌券 1 平台券 2 微信,从选择器中获取
* @params {String UnionCouponType}         0品牌驿业券 1第三方驿业券,默认值0,从选择器中获取
* @params {String CouponEndDate}           券的有效期-结束时间
* @params {String CouponRemark}            券使用说明
* @params {String ExchangeBeginDate}       兑换有效期-开始时间
* @params {String ExchangeEndDate}         兑换有效期-结束时间
* @params {String MakeType}                制券类型 0批量制券 1批次号发券
* @params {String MakeQty}                  制券数量
* */
export const GetCouponSaveData = params => http.post(`${baseUrl}Coupon/Union/CouponCode/SaveData`, params);

/** 券码管理-详情
* @params {String Id}                      券码活动id
* */
export const GetCouponListAddDetail = params => http.get(`${baseUrl}Coupon/Union/CouponCode/GetById?${qs.stringify(params)}`);

/** 券码管理-权益券库存显示
* @params {String CouponGrpId}             CouponGrpId
* */
export const GetCouponYyStock = params => http.get(`${baseUrl}Coupon/Union/CouponCode/GetYYCouponStock?${qs.stringify(params)}`);
