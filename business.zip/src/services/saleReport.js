import http from '../utils/http';
import config from '../config';

const { baseUrl } = config;
/** 平台供应商销售报表接口
* @params {String MchId}                    供应商ID
* @params {String StartTime}                采购开始时间
* @params {String EndTime}                  采购结束时间
* @params {String PageSize}                 每页数量
* @params {String PageIndex }               页数
* @params {String OrderType }               排序方式（1:利润正序，2：利润倒序，3：销量正序，4：销量倒序）
* */
export const GetSaleReportList = params => http.post(`${baseUrl}Coupon/Union/Purchase/GetSaleReportList`, params);


/** 驿业品牌销售报表
* @params {String MchId}                    供应商ID
* @params {String StartTime}                采购开始时间
* @params {String EndTime}                  采购结束时间
* @params {String PageSize}                 每页数量
* @params {String PageIndex }               页数
* @params {String OrderType }               排序方式（1:利润正序，2：利润倒序，3：销量正序，4：销量倒序）
* */
export const GetBrandSaleReportList = params => http.post(`${baseUrl}Coupon/Union/Purchase/GetBrandSaleReportList`, params);


/** 权益商品销售报表
* @params {String CouponGrpName}                    权益商品名称
* @params {String StartTime}                采购开始时间
* @params {String EndTime}                  采购结束时间
* @params {String PageSize}                 每页数量
* @params {String PageIndex }               页数
* @params {String IsAsc }                   是否升序
* @params {String OrderType }               排序方式（0默认 1 按利润 2 按销量 3 按发放数（人) 4 按发放数(张））
* */
export const GetCouponSaleReportList = params => http.post(`${baseUrl}Coupon/Union/Report/CouponSaleReportList`, params);
