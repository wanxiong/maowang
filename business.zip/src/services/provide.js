// import qs from 'qs';
import http from '../utils/http';
import config from '../config';

const { baseUrl } = config;

/** 我要供货-平台券-新建平台券-保存接口
*@params  {String TplName}          券库模板名称
*@params  {String CouponType}       券库模板券类型
*@params  {String TplId}            券库模板Id
*@params {String CouponName}        券名称
*@params {String SubTitle}          副标题
*@params {String OutSysId}          适用系统
*@params {String WxQrCode}          公众号带参二维码
*@params {String Guide}      使用说明
*@params {String IsCanUserSpePrd}   是否仅限指定商品可使用该优惠券
*@params {String IsCanGiveFriend}   是否可以转赠(1.可以 0.不可以)
*@params {String OuterCode}         外部编码
*@params {String OuterId}           外部编号
*@params {String IsAllowUserMore}   是否可以一个订单 使用多张券（1 可以 0 不可以)
*@params {String IsAllowBuyMore}    是否允许一个订单购买多个商品
*@params {String AllowMaxBuyNum}    允许一个订单最多购买  x件商品
*@params {String IsAllowPositive}   是否允许正价商品使用
*@params {String DiscountLimit}     折扣限制
*@params {String IsHasConsumeShops} 是否选择了券核销门店范围
*@params {String UnionCouponType}   0品牌驿业券 1第三方驿业券,   默认值0  （传1）
*@params {String CouponStatus}      状态 0暂存  1立即上架
*@params {String ProBrandId}        驿业-驿业品牌Id
*@params {String ProductCode}       驿业-商品编号
*@params {String SupplyId}          驿业-供应商品牌Id
*@params {Object ConsumeShops} 券核销 组织类型值 片区 店群 品牌 门店ID
*           @params {Array ShopListId}  券核销 组织类型值 片区 店群 品牌 门店ID
*           @params {String ShopType}   门店类型
*@params {Object CouponTradeCfg}
*           @params {String ValidDate}          有效期 -自采购日起x天可发放
*           @params {String ValidVay}           自领取X天有效
*           @params {String BeginDate}          有效期 -起
*           @params {String EndDate}            有效期截止
*           @params {String StartNo}            起始量（可采购数量区间）
*           @params {String EndNo}              截止量（可采购的数量区间)
*           @params {String RewardWray}         按核销单张券奖励金额 - 0 按核销的订单实付金额比例提成 -1
*           @params {String RewardMoney}        金额或比例
*           @params {String RechargeBeginDate}  驿业-兑换有效期开始时间
*           @params {String RechargeEndDate}    驿业-兑换有效期结束时间
* */
export const GetProvideCouponAddSave = params => http.post(`${baseUrl}Coupon/Union/UnionCoupon/Save`, params);

/** 我要供货-平台券
*@params {String CouponGrpId}       券库Id
*@params {String CouponName}        券库名称
*@params {String CouponType}        券库类型
*@params {String PageIndex}         当前页数
*@params {String PageSize}          当前页数的条目
*/
export const GetProvidePlatformCouponList = params => http.post(`${baseUrl}Coupon/Union/UnionCoupon/GetMyUnionGrpList`, params);

/** 我要供货-平台券-上架/下架(数据的list整个传递) || 我要采购-平台券-开启/禁用接口
*@params {String CouponStatus}       上架1/下架2/3开启/4禁用
*/
export const GetProvidePlatformCouponStatus = params => http.post(`${baseUrl}Coupon/Union/UnionCoupon/ChangeCouponStatus`, params);

/** 我要供货-供货单-列表接口
*@params {String PurchaseNo}         采购单号
*@params {String CouponGrpName}      券名称
*@params {String PurchaseName}       品牌名称
*@params {String Status}             状态：待审核0/审核未通过1/审核通过-制券中2/已入库3
*@params {String StartTime}          开始时间
*@params {String EndTime}            结束时间
*@params {String PageIndex}          当前页数
*@params {String PageSize}           当前页数的条目
*/
export const GetProvideOrderList = params => http.post(`${baseUrl}Coupon/Union/Purchase/GetProvideList`, params);

/** 我要供货-平台券-店铺状态
*/
export const GetProvideOrderShopStatus = () => http.get(`${baseUrl}Coupon/Union/UnionCoupon/GetMerchattStatus`);

/** 我要供货-平台券-新建平台券-适用门店
 *  @params {String MchId}            商户Id(供券方品牌)
*/
export const GetProvideOrderSysStatus = () => http.get(`${baseUrl}Coupon/Union/UnionCoupon/GetOutSysByBrandId`);

/** 我要供货-供货单-审核--详情接口
* @params { String SupplyBrandId }    供应商的品牌Id
* @params { String Id }               采购单的Id
* @params { String PurchaseBrandId }  采购方品牌Id
*/
export const GetProvideOrderExamineDetail = params => http.post(`${baseUrl}Coupon/Union/Purchase/AuditPurchaseDetail`, params);

/** 我要供货-供货单-审核--保存
* @params { String Status }         1：不通过/2：通过
* @params { String BackReason }     拒绝原因
* @params { String Id }             采购单的Id
*/
export const GetProvideOrderExamineSave = params => http.post(`${baseUrl}Coupon/Union/Purchase/AuditPurchase`, params);

/** 我要供货-供货单-改价
* @params { String RewardMoney }    订单提成/核销张数比例
* @params { String RewardChangeDes }备注
* @params { String Id }             采购单的Id
*/
export const GetProvideOrderChangeReward = params => http.post(`${baseUrl}Coupon/Union/Purchase/ChangeReward`, params);

/** 我要供货-供货报表-一览
* @params { String CouponGrpId }    券ID
* @params { String CouponGrpName }  券名称
* @params { String BeginDate }      采购开始时间
* @params { String EndDate }        采购截至时间
* @params {String PageIndex}        当前页数
* @params {String PageSize}         当前页数的条目
*/
export const GetProvideOrderReportList = params => http.post(`${baseUrl}Coupon/Union/Report/ProvideReportList`, params);

/** 我要供货-供货报表-详情列表接口
* @params { String Id }             Id
* @params { String Date }           核销时间
* @params {String PageIndex}        当前页数
* @params {String PageSize}         当前页数的条目
*/
export const GetProvideOrderReportDetailList = params => http.post(`${baseUrl}Coupon/Union/Report/ProvideConsumeDtl`, params);

/** 我要供货-供货报表-导出
* @params { String TaskName }       导出文件名字
* @params { Object Querys }
* @params { ----- CouponGrpId}      券ID
* @params { ----- CouponGrpName}    券名称
* @params { ----- BeginDate}        采购开始时间
* @params { ----- EndDate}          采购结束时间
*/
export const GetProvideOrderReportDownLoad = params => http.post(`${baseUrl}Coupon/Union/DataTask/DownloadProConsume`, params);

/** 我要供货-供货单-导出
* @params { String TaskName }       货单文件名字
* @params { Object Querys }
* @params { ----- PurchaseNo}       供货单号
* @params { ----- PurchaseName}     品牌
* @params { ----- CouponName}       券名称
* @params { ----- Status}           状态
* @params { ----- StartTime}        供货开始时间
* @params { ----- EndTime}          供货结束时间
*/
export const GetProvideOrderDownLoad = params => http.post(`${baseUrl}Coupon/Union/DataTask/DownloadProList`, params);

/**
 * 供货报表核销明细导出
 * @params { String TaskName}        名称
 * @params { Object Querys}
 * @params { ----- OrderId}          订单id PurchaseOrderId
 */
export const GetDownloadProConsumeDtl = params => http.post(`${baseUrl}Coupon/Union/DataTask/DownloadProConsumeDtl`, params);

/**
 * 供货报表拉新明细下载
 * @params { String TaskName}        名称
 * @params { String Type }           9 写死
 * @params { Object Querys}
 * @params { ----- OrderId}          purchaseorderid
 * @params { ----- BegDate}          开始时间
 * @params { ----- EndDate}          结束时间
 */
export const GetDownloadProConsumeNewDtl = params => http.post(`${baseUrl}Coupon/Union/DataTask/DownloadPurNewVip`, params);
