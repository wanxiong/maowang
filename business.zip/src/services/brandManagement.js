import http from '../utils/http';
import config from '../config';

const { baseUrl } = config;

/** 供应商-品牌管理-列表接口
* @params {String BrandName}                品牌名称
* @params {Number Page}                     当前页
* @params {Number PageSize}                 显示几条
* */
export const QueryByPage = params => http.post(`${baseUrl}account/api/ProdBrand/QueryByPage`, params);

/** 供应商-供应商管理-新增供应商接口
* @params {Number MerchantType}             商户类型;[0:EZR;1:品牌商户;2:外部商户;3:供应商(向平台供货)],此处固定 3
* @params {String MerchantName}             商户名称
* @params {String BrandName}                CRM品牌名 只是接口需要，不加会报错，此处取MerchantName
* @params {String BrandCode}                CRM品牌编号 只是接口需要，不加会报错，此处取MerchantName
* @params {String CopName}                  CRM集团名 只是接口需要，不加会报错，此处取MerchantName
* @params {String ContactName}              负责人姓名
* @params {Number ContactMobile}            负责人手机号
* @params {String ContactEmail}             负责人邮箱
* @params {Number ConnectType}              对接方式 0-接口,1-线下导入
* */
export const AddBrand = params => http.post(`${baseUrl}account/api/ProdBrand/CouponProBrandInsert`, params);

/** 供应商-供应商管理-编辑供应商接口
* @params {Number MerchantType}             商户类型;[0:EZR;1:品牌商户;2:外部商户;3:供应商(向平台供货)],此处固定 3
* @params {String MerchantName}             商户名称
* @params {String BrandName}                CRM品牌名 只是接口需要，不加会报错，此处取MerchantName
* @params {String BrandCode}                CRM品牌编号 只是接口需要，不加会报错，此处取MerchantName
* @params {String CopName}                  CRM集团名 只是接口需要，不加会报错，此处取MerchantName
* @params {String ContactName}              负责人姓名
* @params {Number ContactMobile}            负责人手机号
* @params {String ContactEmail}             负责人邮箱
* @params {Number ConnectType}              对接方式 0-接口,1-线下导入
* */
export const SaveBrand = params => http.post(`${baseUrl}account/api/ProdBrand/CouponProBrandUpdate`, params);
