import http from '../utils/http';
import config from '../config';
// import qs from 'qs'

const { baseUrl } = config;

/** 获取账户信息一保存接口
* @params {String Id}                           品牌Id
* @params {String MchId}                        品牌Id
* @params {String MerchantName}                 品牌名称
* @params {String OrganizationName}             公司名称
* @params {String || Number IndustryId}         所属行业
* @params {String || Number CommodityTypeIds}   经营类目
* @params {String || Number Logo}               品牌LOGO
* @params {String || Number BusinessLicense}    营业执照目前是没有的
* @params {String || Number BusinessLicensePath}每页大小
* @params {String || Number About}              品牌简介
* @params {String || Number AgeRange}           品牌人群年龄
* @params {String || Number ShopStatus}         店铺状态
* @params {String || Number ContactName}        负责人
* @params {String || Number ContactMobile}      手机号
* @params {String || Number ContactEmail}       邮箱
* @params {String || Number CommodityTypeJson}  经营类目备用字段，仅供前端回显用

* */
export const GetAccountInfoSave = params => http.post(`${baseUrl}account/api/Merchant/BrandSave`, params);


/** 获取账户信息一所属行业接口
*
* */
export const GetAccountInfoIndustryList = params => http.post(`${baseUrl}account/api/Attr/IndustrySelectAll`, params);

/** 获取账户信息一经营类目
*
* */
export const GetAccountInfoSelectAll = params => http.post(`${baseUrl}account/api/Attr/CommodityTypeSelectAll`, params);

/** 获取商户门店状态接口
*
* */
export const GetVerifyMerchant = params => http.post(`${baseUrl}account/api/Merchant/VerifyMerchant`, params);

/** 商户营业执照上传图片接口
* @params {String MchId}                         商户Id
* @params {String BusinessLicenseImage}          图片base64
* */
export const BusinessLicenseUpload = params => http.post(`${baseUrl}account/api/Merchant/BusinessLicenseSave`, params);

/** 商户营业执照获取接口
* @params {String MchId}                         商户Id
* */
export const GetBusinessLicense = params => http.post(`${baseUrl}account/api/Merchant/BusinessLicenseSelect`, params);

/** 我的商户状态信息查看
* @params {String MchId}                         商户Id
* */
export const GetMerchantStatus = params => http.post(`${baseUrl}account/api/Merchant/MerchantSelectByMchid`, params);

/** 商户余额充值明细申请列表
* @params {String CreateOn}                      创建时间
* @params {String Status}                        审核状态；[-3:入账失败;-2:审核未通过;-1:取消;0:审核中;1:审核通过;2:已入账;]
* @params {String Page}                          当前页
* @params {String PageSize}                      每页条数
* @params {String MchId}                         商户Id
* */
export const GetAssetRechargeList = params => http.post(`${baseUrl}finance/api/Balance/QueryTopUpApply`, params);

/** 商户余额充值明细审核
* @params {String Id}                            自增Id
* @params {String IsPass}                        审核状态；0：不通过，1：通过
* @params {String Remark}                        拒绝审核时的原因描述
* @params {String MchId}                         商户Id
* */
export const GetAssetRechargeCheck = params => http.post(`${baseUrl}finance/api/Balance/CheckTopUpApply`, params);

/** 资产管理-Z币-明细列表
* @params {String CreateOn}                      创建时间
* @params {String QueryType}                     查询状态；[0:全部;2:充值;3:核销券;1:平台赠送金额]
* @params {String Page}                          当前页
* @params {String PageSize}                      每页条数
* @params {String MchId}                         商户Id
* */
export const GetAssetZDetailList = params => http.post(`${baseUrl}finance/api/Zb/QueryZbDetail`, params);

/** 资产管理-保证金-明细列表
* @params {String CreateOn}                      创建时间
* @params {String TradeType}                     查询状态；[-3:全部;-2:充值;-1:扣款;]
* @params {String Page}                          当前页
* @params {String PageSize}                      每页条数
* @params {String MchId}                         商户Id
* */
export const GetAssetBondDetailList = params => http.post(`${baseUrl}finance/api/Deposit/QueryDeposit`, params);

/** 资产管理-充值-获取所有银行
* @params {String MchId}                         商户Id
* */
export const GetAssetBankSelectAll = params => http.post(`${baseUrl}account/api/Attr/BankSelectAll`, params);

/** 资产管理-充值-商户充值余额申请/新增
* @params {String CashCount}                     充值金额
* @params {String BankCode}                      转账银行Code
* @params {String ImageData}                     银行流水截图
* @params {String BankRecordNo}                  银行流水号
* @params {String MchId}                         商户Id
* */
export const GetAssetRechargeBankApply = params => http.post(`${baseUrl}finance/api/Balance/TopUpApply`, params);

/** 资产管理-充值-商户充值余额修改
* @params {String Id}                            自增Id/修改的Id
* @params {String CashCount}                     充值金额
* @params {String BankCode}                      转账银行Code
* @params {String ImageData}                     银行流水截图
* @params {String BankRecordNo}                  银行流水号
* @params {String BankRecordNo}                  银行流水号
* @params {String MchId}                         商户Id
* */
export const GetAssetRechargeBankUpdate = params => http.post(`${baseUrl}finance/api/Balance/UpdateTopUpApply`, params);

/** 资产管理-充值-商户充值银行流水截图修改
* @params {String MchId}                         自增Id/修改的Id
* @params {String ImageData}                     充值金额
* @params {String BankRecordNo}                  转账银行Code
* */
export const GetAssetRechargeBankImageUpdate = params => http.post(`${baseUrl}finance/api/Balance/UpdateRechargeImage`, params);

/** 资产管理-充值-商户充值余额详情查询
* @params {String MchId}                         商户ID
* @params {String Id}                            详情ID
* */
export const GetAssetRechargeBankDetail = params => http.post(`${baseUrl}finance/api/Balance/QueryTopUpApplyDetail`, params);

/** 资产管理-查询财务账号信息
* @params {String MchId}                         商户Id
* */
export const GetAssetAccount = params => http.post(`${baseUrl}finance/api/Account/QueryAccount`, params);

/** 资产管理-查询平台手续费信息
* @params {String MchId}                         商户Id
* @params {String SettingType}                   适用场景；[1:券;2:积分;3:商品;]
SettingType
* */
export const GetAssetAccountPlatformFee = params => http.post(`${baseUrl}account/api/Attr/FeeShow`, params);

/** 资产管理-商户充值Z币
* @params {String TradeType}                     交易类型
* @params {String TradeCount}                    交易数额
* @params {String MchId}                         商户ID
* */
export const GetAssetRechargeZ = params => http.post(`${baseUrl}finance/api/Zb/TopUp`, params);

/** 资产管理-商户缴纳保证金
* @params {String TradeType}                     交易类型
* @params {String TradeCount}                    交易数额
* @params {String MchId}                         商户ID
* */
export const GetAssetRechargeBond = params => http.post(`${baseUrl}finance/api/Deposit/PaymentDeposit`, params);

/** 账号管理-商户屏蔽设置
* @params {String SettingType}                   适用场景；[1:券;2:积分;3:商品;]
* @params {String IsOn}                          是否开启;[0:禁用；1:开启]
* @params {String MchId}                         商户ID
* */
export const GetAccountShieldSetting = params => http.post(`${baseUrl}account/api/Merchant/SetShield`, params);

/** 账号管理-商户屏蔽设置查询
* @params {String SettingType}                   适用场景；[1:券;2:积分;3:商品;]
* @params {String MchId}                         商户ID
* */
export const GetAccountShieldStatus = params => http.post(`${baseUrl}account/api/Merchant/QueryShield`, params);

/** 账号管理-商户屏蔽类目/品牌添加
* @params {String SettingType}                   适用场景；[1:券;2:积分;3:商品;]SelectedType
* @params {String SelectedType}                  添加屏蔽的类型 [1:运营类目;2:品牌]
* @params {String SelectedId}                    添加屏蔽运营类目Id || 品牌Id
* @params {String MchId}                         商户ID
* */
export const GetAccountShieldItem = params => http.post(`${baseUrl}account/api/Merchant/AddShieldItem`, params);

/** 账号管理-商户屏蔽类目/品牌-列表查询
* @params {String SettingType}                   适用场景；[1:券;2:积分;3:商品;]SelectedType
* @params {String SelectedType}                  添加屏蔽的类型 [1:运营类目;2:品牌]
* @params {String MchId}                         商户ID
* */
export const GetAccountShieldItemList = params => http.post(`${baseUrl}account/api/Merchant/QueryShieldItem`, params);

/** 账号管理-商户屏蔽类目-品牌/删除
* @params {String SettingType}                   适用场景；[1:券;2:积分;3:商品;]SelectedType
* @params {String SelectedType}                  删除屏蔽的类型 [1:运营类目;2:品牌]
* @params {String SelectedId}                    删除屏蔽运营类目Id || 品牌Id
* @params {String MchId}                         商户ID
* */
export const GetAccountShieldDelItem = params => http.post(`${baseUrl}account/api/Merchant/DelShieldItem`, params);

/** 账号管理-商户屏蔽品牌-列表查询
* @params {String IndustryId}                    行业子二级ID
* @params {String QueryMchId}                    被查询的品牌商户ID/品牌Id
* @params {String MchId}                         商户ID
* @params {String Page}                          当前页
* @params {String PageSize}                      每页条数
* */
export const GetAccountBrandList = params => http.post(`${baseUrl}account/api/Merchant/QueryByPage`, params);


/** 账号管理-余额充值明细-导出
* @params {String StartDate}                查询开始日期
* @params {String EndDate}                  查询结束日期
* @params {String Status}                   商户状态[ -3:平台禁用;-2:审核未通过;-1:品牌歇业;0:商户初始化;1:待审核;2:营业中;9:全部]
* @params {String SettingType}              适用场景；[1:券;2:积分;3:商品;]
* @params {String MchId }                   品牌Id
* @params {String FileName }                文件名称
* @params {String Page }                    不分页 --- 此参数暂时不要
* @params {String PageSize }                不分页 --- 此参数暂时不要
* */
export const GetAccountRechargeExport = params => http.post(`${baseUrl}finance/api/Balance/ExportTopUpApply`, params);

/** 账号管理-保证金-导出
* @params {String StartDate}                查询开始日期
* @params {String EndDate}                  查询结束日期
* @params {String SettingType}              适用场景；[1:券;2:积分;3:商品;]
* @params {String MchId }                   品牌Id
* @params {String FileName }                文件名称
* @params {String TradeType }               交易类型
* @params {String Page }                    不分页 --- 此参数暂时不要
* @params {String PageSize }                不分页 --- 此参数暂时不要
* */
export const GetAccountRechargeBondExport = params => http.post(`${baseUrl}finance/api/Deposit/ExportDeposit`, params);

/** 账号管理-ZB-导出
* @params {String StartDate}                查询开始日期
* @params {String EndDate}                  查询结束日期
* @params {String SettingType}              适用场景；[1:券;2:积分;3:商品;]
* @params {String MchId }                   品牌Id
* @params {String FileName }                文件名称
* @params {String TradeType }               交易类型
* @params {String Page }                    不分页 --- 此参数暂时不要
* @params {String PageSize }                不分页 --- 此参数暂时不要
* */
export const GetAccountRechargeZExport = params => http.post(`${baseUrl}finance/api/Zb/ExportZbDetail`, params);

/** 资产管理-Zb-赠送
* @params {String TradeType}                交易类型
* @params {String TradeCount}               赠送金额
* @params {String ETradeNo}                 交易流水号---单独接口获取
* @params {String MchId }                   当前登陆的平台Id
* @params {String TradeMchId }              赠送目标的商户Id
* */
export const GetAccountRechargeZGive = params => http.post(`${baseUrl}finance/api/Zb/Give`, params);

/** 资产管理-Zb-获取平台内部交易号
* @params {String TradeType}                交易类型
* @params {String MchId}                    商户Id
* */
export const GetAccountTradeNo = params => http.post(`${baseUrl}finance/api/Zb/QueryETradeNo`, params);


/** 获取当前用户菜单结构
* */
export const GetAccountSelfMenuList = params => http.post(`${baseUrl}account/api/Account/SelfPermissions`, params);

/** 获取所有菜单结构
* */
export const GetAccountAllMenuList = () => http.post(`${baseUrl}account/api/Permission/MenuQueryByPage`, { IsTree: 1 });

/** 账户管理 - 品牌收益审核列表
* @params {String PurchaseMchId}            采购方品牌编号
* @params {String PageIndex}                页码数
* @params {String PageSize}                 每页显示数
* @params {String BrandName}                CRM品牌名
* @params {String BeginDate}                采购时间开始
* @params {String EndDate}                  采购时间结束
* @params {String AuditStatus}              采购方收益审核状态 0 未审核 1 已审核
* */
export const CheckBrandIncomeList = params => http.post(`${baseUrl}Coupon/Union/Purchase/GetPurchaseAmountAuditList`, params);


/** 账户管理 - 品牌收益审核
* @params {String PurchaseOrderId}            采购单编号
* @params {String PurchaseMchId}              采购品牌编号
* @params {String PurchaseTotalAmount}        收益
* */
export const CheckBrandIncome = params => http.post(`${baseUrl}Coupon/Union/Purchase/AuditPurchaseAmount`, params);


/** 账户管理 - 品牌收益核准总计
* */
export const GetTotalBrandIncome = params => http.get(`${baseUrl}Coupon/Union/Purchase/GetPurchaseAmountAuditAmount`, params);
