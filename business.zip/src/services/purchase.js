import qs from 'qs';
import http from '../utils/http';
import config from '../config';

const { baseUrl } = config;

/** 我要采购-优惠券-列表接口
*@params {String CatgoryId}     平台券所属类目
*@params {String BrandId}       品牌编号
*@params {String CouponType}    券库类型
*@params {String CommissionType}佣金类型  按核销单张券奖励金额  0 按核销的订单实付金额比例提成  1
*@params {String OrderType}     0默认/1按提成/2按核销率
*@params {Boolean IsAsc}        升序还是降序
*@params {String PageIndex}     当前页数
*@params {String PageSize}      当前页数的条目
* */
export const GetPurchaseCouponList = params => http.post(`${baseUrl}Coupon/Union/UnionCoupon/GetUnionGrpList`, params);

/** 我要采购-优惠券-商品详情-申请采购接口
*@params {String MchId}         商户Id(供券方品牌)
*@params {String CouponCfgId}   平台券交易配置id
*@params {String BuyCount}      采购数量
* */
export const GetPurchaseApply = params => http.post(`${baseUrl}Coupon/Union/Purchase/PurchaseSubmit`, params);

/** 我要采购-采购单-列表接口
*@params {String PurchaseNo}    采购单号
*@params {String ProviderName}  品牌
*@params {String Status}        状态（待审核0/审核未通过1/审核通过/制券中2/已入库3）
*@params {String StartTime}     采购开始时间
*@params {String EndTime}       采购结束时间
*@params {String CouponName}    券名称
*@params {String UnionCouponType} 当为1时代表驿业采购单，为0或者为空时代表品牌采购单
*@params {String PageIndex}     当前页数
*@params {String PageSize}      当前页数的条目

* */
export const GetPurchaseOrderList = (params = {}) => http.post(`${baseUrl}Coupon/Union/Purchase/GetPurchaseList`, params);


/** 我要采购-采购单-删除接口
*@params {String Id}            采购单Id
* */
export const GetPurchaseOrderDelete = (params = {}) => http.get(`${baseUrl}Coupon/Union/Purchase/DeleteOrder?${qs.stringify(params)}`);

/** 我要采购-平台券-列表接口
*@params {String CouponGrpId}   券库Id
*@params {String CouponName}    券库名称
*@params {String CouponType}    券库类型
*@params {String BrandName}     品牌名称
*@params {String PageIndex}     当前页数
*@params {String PageSize}      当前页数的条目
* */
export const GetPurchasePlatformCouponList = (params = {}) => http.post(`${baseUrl}Coupon/Union/UnionCoupon/GetMyPurchaseUnionGrpList`, params);

/** 我要采购-优惠券-品牌列表
*
* */
export const GetPurchaseCouponListBrand = params => http.get(`${baseUrl}Coupon/Union/UnionCoupon/GetBrandList${qs.stringify(params)}`);

/** 我要采购-优惠券-类目列表
*
* */
export const GetPurchaseCouponCategory = params => http.get(`${baseUrl}Coupon/Union/UnionCoupon/GetBrandCategoryList${qs.stringify(params)}`);

/** 我要采购-优惠券-根据类目获取品牌列表
*@params {String CagetoryId}     类目ID
* */
export const GetPurchaseCouponBrandByCate = params => http.get(`${baseUrl}Coupon/Union/UnionCoupon/GetBrandsByCatId?${qs.stringify(params)}`);

/** 我要采购-优惠券-优惠券详情
*@params {String CouponGrpId}     券库Id
*@params {String MchId}           品牌ID
* */
export const GetPurchaseCouponListDetail = params => http.get(`${baseUrl}Coupon/Union/UnionCoupon/Get?${qs.stringify(params)}`);

/** 我要采购-券详情-门店分布
*@params {String SupplyBrandId}  供券方品牌编号
* */
export const GetPurchaseCouponDetailCity = params => http.post(`${baseUrl}Coupon/Union/UnionCoupon/GetCityShopCount`, params);

/** 我要采购-采购报表-一览
* @params { String CouponGrpId }    券ID
* @params { String CouponGrpName }  券名称
* @params { String ProvideMchName } 品牌名称
* @params { String BeginDate }      采购开始时间
* @params { String EndDate }        采购截至时间
* @params {String PageIndex}        当前页数
* @params {String PageSize}         当前页数的条目
*/
export const GetPurchaseOrderReportList = params => http.post(`${baseUrl}Coupon/Union/Report/PurchaseReportList`, params);

/** 我要采购-采购报表-导出
* @params { String TaskName }       采购文件名字
* @params { Object Querys }
* @params { ----- CouponGrpId}      券ID
* @params { ----- CouponGrpName}    券名称
* @params { ----- BeginDate}        采购开始时间
* @params { ----- EndDate}          采购结束时间
*/
export const GetPurchaseOrderReportDownLoad = params => http.post(`${baseUrl}Coupon/Union/DataTask/DownloadPurConsume`, params);

/** 我要采购-采购单-导出
* @params { String TaskName }       货单文件名字
* @params { Object Querys }
* @params { ----- PurchaseNo}       采购单号
* @params { ----- ProviderName}     品牌
* @params { ----- CouponName}       券名称
* @params { ----- Status}           状态
* @params { ----- StartTime}        供货开始时间
* @params { ----- EndTime}          供货结束时间
*/
export const GetPurchaseOrderDownLoad = params => http.post(`${baseUrl}Coupon/Union/DataTask/DownloadPurList`, params);

/**
 * 采购报表核销明细导出
 * @params { String TaskName}        名称
 * @params { Object Querys}
 * @params { ----- OrderId}          订单id PurchaseOrderId
 */
export const GetDownloadPurConsumeDtl = params => http.post(`${baseUrl}Coupon/Union/DataTask/DownloadPurConsumeDtl`, params);

/**
 * 我要采购-驿业券列表
* @params { String OrderType }      -- 0/默认  1/按销量  2/按价格
* @params { String IsAsc }          是否升序
* @params { String ProBrandId }     商品品牌ID/ 品牌Id
* @params { String ProPgTagId }     商品权益标签Id/ 类型Id
* @params {String PageIndex}        当前页数
* @params {String PageSize}         当前页数的条目
 */
export const GetUnionProGrpList = params => http.post(`${baseUrl}Coupon/Union/UnionCoupon/GetUnionProGrpList`, params);

/** 获取商品品牌列表
* */
export const GetProBrandList = () => http.get(`${baseUrl}Coupon/Union/UnionCoupon/GetProBrandList`, {});

/** 获得商品权益标签列表/我要采购-驿业券列表-类型
* */
export const GetProPgTagList = () => http.get(`${baseUrl}Coupon/Union/UnionCoupon/GetProPgTagList`, {});
