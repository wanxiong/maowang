import qs from 'qs';
import http from '../utils/http';
import config from '../config';

const { baseUrl } = config;

/** 导入中心-商品券导入日志0
* @params { String couponGrpId }           券库Id
* @params { String JobBegDate }            开始时间
* @params { String JobDate }               结束时间
* @params {String PageIndex    }           当前页数
* @params {String PageSize     }           当前页数的条目
* */
export const GetExportCenterGoodsLogList = params => http.get(`${baseUrl}Coupon/Union/UnionCoupon/GetUploadCouponProJobList?${qs.stringify(params)}`);

/** 导入中心-sku导入日志1
* @params { String couponGrpId }           券库Id
* @params { String JobBegDate }            开始时间
* @params { String JobDate }               结束时间
* @params { String PageIndex    }           当前页数
* @params { String PageSize     }           当前页数的条目
* */
export const GetExportCenterSkuLogList = params => http.get(`${baseUrl}Coupon/Union/UnionCoupon/GetUploadCouponSkuJobList?${qs.stringify(params)}`);

/** 导入中心-商品券导入-导入明细
* @params { String couponGrpId }           券库Id
* @params { String MchId       }           品牌编号 **** 目前不需要次字段
* @params { String ProType     }           0-商品  1-sku 2-分类
* @params { String PageIndex    }           当前页数
* @params { String PageSize     }           当前页数的条目
* */
export const GetExportCenterGoodsList = params => http.get(`${baseUrl}Coupon/Union/UnionCoupon/GetCouponGrpProListById?${qs.stringify(params)}`);

/** 导入中心-商品券导入-按SKU
* xxx?id=1&couponProIsExclude=true id券库Id couponProIsExclude true 包含导入商品 false 排除导入商品
* form表单文件上传
* */
export const GetExportCenterUploadSku = (urpParams, params) => http.postUpload(`${baseUrl}Coupon/Union/UnionCoupon/UploadCouponSku?${qs.stringify(urpParams)}`, params);

/** 导入中心-商品券导入-按商品||货号
* xxx?id=1&couponProIsExclude =true id券库Id couponProIsExclude true 包含导入商品 false 排除导入商品
* form表单文件上传
* */
export const GetExportCenterUploadNumber = (urpParams, params) => http.postUpload(`${baseUrl}Coupon/Union/UnionCoupon/UploadCouponPro?${qs.stringify(urpParams)}`, params);


/** 删除货号
* @params { String id }    Id
* */
export const DeleteProData = params => http.post(`${baseUrl}Coupon/Union/UnionCoupon/DeleteProData?${qs.stringify(params)}`, {});

/** 删除sku
* @params { String id }    Id
* */
export const DeleteSkuData = params => http.post(`${baseUrl}Coupon/Union/UnionCoupon/DeleteSkuData?${qs.stringify(params)}`, {});

/**
 * 上传
 */
export const uploadUrl = `${baseUrl}Coupon/Union/UnionCoupon/UploadCouponPro`;

export const uploadSkuUrl = `${baseUrl}Coupon/Union/UnionCoupon/UploadCouponSku`;

/**
 * 下载模版
 */
export const downExcelUrl = `${baseUrl}Coupon/Union/UnionCoupon/ProductTemplate`;

export const downExcelSkuUrl = `${baseUrl}Coupon/Union/UnionCoupon/ProductSKUTemplate`;

// 销售订单-导入券码 => 导出页面-模板下载
export const GetCouponCodeDownExcel = () => http.post(`${baseUrl}Coupon/Union/UnionCoupon/GetUnionCouponExcelTemp`, {}, { responseType: 'blob' });

// 销售订单-导入券码 => 导出页面-文件上传
export const downExcelCouponCodeUploadUrl = `${baseUrl}Coupon/Union/UnionCoupon/UploadUnionCoupon?`;

/** 销售订单-导入券码 => 导出页面-文件上传
* @params { CouponGrpId }        券库Id
* @params { PurchaseOrderId }    采购单号Id
* */
export const GetCouponCodeUpload = (params, fileObj) => http.postUpload(`${baseUrl}Coupon/Union/UnionCoupon/UploadUnionCoupon?${qs.stringify(params)}`, fileObj);

/** 销售订单-导入券码 => 导出页面-文件上传-列表
* @params { String CouponGrpId }           券库Id
* @params { String PurchaseOrderId }       券库Id
* @params { String JobBegDate }            开始时间
* @params { String JobDate }               结束时间
* */
export const GetCouponCodeUploadList = params => http.get(`${baseUrl}Coupon/Union/UnionCoupon/GetUploadUnionCouponJobList?${qs.stringify(params)}`, {});

// 文件下载-通用get
export const GetDownExcelDefaultGet = (url, params = {}) => http.get(`${url}`, params, { responseType: 'blob' });

// 文件下载-通用Post
export const GetDownExcelDefaultPost = (url, params = {}) => http.post(`${url}`, params, { responseType: 'blob' });

/** 文件上传-通用post
* @params { CouponGrpId }        券库Id
* @params { PurchaseOrderId }    采购单号Id
* */
export const GetUploadExcelDefaultPost = (url, params = {}, fileObj) => http.postUpload(`${url}?${qs.stringify(params)}`, fileObj);
