import * as React from 'react';
import {
  Input, Button
} from 'ezrd';

const classNamePre = 'yiye-asset-manage-search';

export default class BrandManagement extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      BrandName: '',
      Status: -9
    };
  }

  componentDidMount() {
    const { getRef } = this.props;
    getRef(this);
  }


  // 普通input框的事件回调
  onChangeInput = (type, e) => {
    this.setState({
      [type]: e.target.value
    });
  }

  // 点击查询按钮
  onSearch = (flag) => {
    const {
      BrandName, Status
    } = this.state;
    const { onSearch } = this.props;
    const params = {
      BrandName,
      Status
    };
    onSearch(params, flag);
  }

  render() {
    const {
      BrandName
    } = this.state;
    // const { selectData } = this.props;
    return (
      <div className={`${classNamePre}`}>
        <div className={`${classNamePre}-top`}>
          <div>
            <span>品牌名称：</span>
            <Input
              type="text"
              size="small"
              width={180}
              value={BrandName}
              onChange={event => this.onChangeInput('BrandName', event)}
            />
          </div>
        </div>
        <div className={`${classNamePre}-search-btn`}>
          <Button
            type="primary"
            onClick={() => this.onSearch(true)}
            className={`${classNamePre}-btn-1`}
          >
            查询
          </Button>
        </div>
      </div>
    );
  }
}
