import * as React from 'react';
import {
  Form, Select, Radio, Icon, Pop, Input
} from 'ezrd';

const { getControlGroup } = Form;
const RadioGroup = Radio.Group;

const classNamePre = 'yiye-supplier-goods-form';

class ConstFormSearchSelectTpl extends React.Component {
static defaultProps = {
  showTime: true,
  width: 320,
  optionText: 'MerchantName',
  optionValue: 'Id',
  textLable: '品牌：',
  textLableStyle: '',
  disabled: false,
  value: '',
  onChange: () => {}
}

// constructor(props) {
//   super(props);
// }

onChange = (e, selected) => {
  const { onChange } = this.props;
  onChange(selected.Id || '');
};

filter = (item, keyword) => {
  const { optionText } = this.props;
  const keyUp = keyword.toUpperCase();
  const itemUp = item[optionText].toUpperCase();
  return itemUp.indexOf(keyUp) > -1;
}

// 选中为空的回调
onEmptySelected = () => {
  // console.log(data)
}

render() {
  const {
    showTime, width, optionText, optionValue, disabled, data, value
  } = this.props;
  return (
    <div>
      <Select
        data={data}
        value={value}
        optionText={optionText}
        optionValue={optionValue}
        width={width}
        showTime={showTime}
        className={classNamePre}
        disabled={disabled}
        filter={this.filter}
        autoWidth
        onEmptySelected={this.onEmptySelected}
        onChange={this.onChange}
      />
    </div>
  );
}
}


class ConstFormProTypeTpl extends React.Component {
  static defaultProps = {
    disabled: false,
    value: '',
    data: false
  }

  constructor(props) {
    super(props);
    this.state = {
    };
  }

  onChange = (e) => {
    const { onChange, value } = this.props;
    onChange({
      ...value,
      type: e.target.value
    });
  }

  onChangeInput = (e) => {
    const { onChange, value } = this.props;
    onChange({
      ...value,
      link: e.target.value
    });
  }

  render() {
    const { value, disabled, data } = this.props;
    return (
      <div className={`${classNamePre}-add-brand`}>
        <RadioGroup
          onChange={this.onChange}
          disabled={disabled}
          value={value.type}
          className={`${classNamePre}-add-brand-list`}
        >
          <div>
            <Radio value="1">
              <div className={`${classNamePre}-add-brand-list-radio`}>
                <span>券码</span>
                <Pop
                  trigger="hover"
                  position="top-center"
                  content="此类型适用于第三方系统提供的券码，展示券码的条形码与二维码"
                >
                  <Icon
                    type="info"
                    ezrd
                  />
                </Pop>
              </div>
            </Radio>
            <img
              src="https://assets-img.ezrpro.com/yiye_goods_icon11.png"
              alt="券码"
              width="218"
              height="306"
            />
          </div>
          <div>
            <Radio value="2">
              <div className={`${classNamePre}-add-brand-list-radio`}>
                <span>兑换链接</span>
                <Pop
                  trigger="hover"
                  position="top-center"
                  content="此类型适用于第三方系统提供的券码兑换链接（URL），可在指定URL兑换权益"
                >
                  <Icon
                    type="info"
                    ezrd
                  />
                </Pop>
              </div>
            </Radio>
            <img
              src="https://assets-img.ezrpro.com/yiye_goods_icon12.png"
              alt="兑换链接"
              width="218"
              height="306"
            />
          </div>
          <div>
            <Radio value="3">
              <div className={`${classNamePre}-add-brand-list-radio`}>
                <span>线上兑换券码</span>
                <Pop
                  trigger="hover"
                  position="top-center"
                  content="此类型适用于第三方系统提供的券码 + URL地址，同一批次券码URL唯一，可直接跳转指定URL使用券码"
                >
                  <Icon
                    type="info"
                    ezrd
                  />
                </Pop>
              </div>
            </Radio>
            {
              Number(value.type) === 3 && (
                <div style={{ 'margin-top': '10px' }}>
                  <Input
                    width={218}
                    disabled={data}
                    maxLength={150}
                    showCount
                    onChange={this.onChangeInput}
                    value={value.link}
                    placeholder="URL"
                  />
                </div>
              )
            }
            <img
              src="https://assets-img.ezrpro.com/yiye_goods_icon13.png"
              alt="线上兑换券码"
              width="218"
              height="321"
            />
          </div>
          {
            // <div>
            //   <Radio value="4">
            //     <div className={`${classNamePre}-add-brand-list-radio`}>
            //       <span>直充卡券</span>
            //       <Pop
            //         trigger="hover"
            //         position="top-center"
            //         content="lallala"
            //       >
            //         <Icon
            //           type="info"
            //           ezrd
            //         />
            //       </Pop>
            //     </div>
            //   </Radio>
            //   <img
            //     src="https://assets-img.ezrpro.com/yiye_goods_icon14.png"
            //     alt="直冲卡券"
            //     width='218'
            //     height='306'
            //   />
            // </div>
          }
        </RadioGroup>
      </div>
    );
  }
}

export const ConstFormSearchSelect = getControlGroup(ConstFormSearchSelectTpl);
export const ConstFormProType = getControlGroup(ConstFormProTypeTpl);
