import * as React from 'react';
import {
  Input, Select, Button
} from 'ezrd';
import { merchantStatus } from "../base/constant";

const classNamePre = 'yiye-asset-manage-search';

export default class SupplierManagement extends React.Component {
  static defaultProps = {
    brandShow: true, // 是否显示品牌ID的输入框
    exportText: '',
    type: 'purchaseStore',
    oneText: '采购单号：',
    history: {},
    selectData: merchantStatus
  }

  constructor(prop) {
    super(prop);
    this.state = {
      MerchantName: '',
      Status: -9
    };
  }

  componentDidMount() {
    const { getRef } = this.props;
    getRef(this);
  }


  // 普通input框的事件回调
  onChangeInput = (type, e) => {
    this.setState({
      [type]: e.target.value
    });
  }

  // 点击查询按钮
  onSearch = (flag) => {
    const {
      MerchantName, Status
    } = this.state;
    const { onSearch } = this.props;
    const params = {
      MerchantName,
      Status
    };
    onSearch(params, flag);
  }

  // // 清空
  // onClean = () => {
  //   this.setState({
  //     currentSelect: 'all', // 默认选择全部
  //     couponId: '', // 券ID
  //     couponName: '', // 券名字
  //     brand: '', // 品牌
  //     rangeValue: [] // 时间区段
  //   });
  // }

  onChangeSelect = (e) => {
    this.setState({ Status: e.target.value || -9 });
  }

  render() {
    const {
      MerchantName, Status
    } = this.state;
    // const { selectData } = this.props;
    return (
      <div className={`${classNamePre}`}>
        <div className={`${classNamePre}-top`}>
          <div>
            <span>供应商名称：</span>
            <Input
              type="text"
              size="small"
              width={180}
              value={MerchantName}
              onChange={event => this.onChangeInput('MerchantName', event)}
            />
          </div>
          <div>
            <span>状态：</span>
            <Select
              data={merchantStatus}
              optionValue="type"
              optionText="name"
              width="180px"
              autoWidth
              showClear={false}
              value={Status}
              onChange={this.onChangeSelect}
            />
          </div>
        </div>
        <div className={`${classNamePre}-search-btn`}>
          <Button
            type="primary"
            onClick={() => this.onSearch(true)}
            className={`${classNamePre}-btn-1`}
          >
            查询
          </Button>
        </div>
      </div>
    );
  }
}
