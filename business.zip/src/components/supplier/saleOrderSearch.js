import * as React from 'react';
import {
  Select, Button, DateRangePicker, Input
} from 'ezrd';
import { saleSearchStatus } from '../base/constant';

const classNamePre = 'yiye-supplier-goods-management-search';

export default class SaleOrderSearch extends React.Component {
static defaultProps = {
  showTime: true, // 是否显示时间筛选
  format: 'YYYY-MM-DD HH:mm:ss'
}

constructor(props) {
  super(props);
  this.state = {
    SelectValue: 'all', // 默认选择全部
    value: '',
    saleNumber: '',
    couponName: '',
    brand: '',
    proName: ''
  };
  this.onSearch = this.onSearch.bind(this);
}

// 状态选择
onChangeSelect = (e) => {
  this.setState({ SelectValue: e.target.value || 'all' });
}

// 点击查询按钮
onSearch = (flag) => {
  const {
    SelectValue, value, saleNumber, couponName, brand, proName
  } = this.state;
  const { onSearch } = this.props;
  onSearch({
    typeValue: SelectValue === 'all' ? '' : SelectValue,
    StartDate: value[0] || '',
    EndDate: value[1] || '',
    saleNumber,
    couponName,
    brand,
    proName
  }, flag);
}

onChangeRange = (val) => {
  this.setState({
    value: val
  });
}

// 普通input框的事件回调
onChangeInput = (type, e) => {
  this.setState({
    [type]: e.target.value
  });
}

render() {
  const {
    value, SelectValue, saleNumber, couponName, brand, proName
  } = this.state;
  const {
    showTime, format
  } = this.props;
  return (
    <div className={`${classNamePre}`}>
      <div>
        <div>
          <span>销售单号：</span>
          <Input
            type="text"
            size="small"
            width={180}
            value={saleNumber}
            onChange={event => this.onChangeInput('saleNumber', event)}
          />
        </div>
        <div>
          <span>券名称：</span>
          <Input
            type="text"
            size="small"
            width={180}
            value={couponName}
            onChange={event => this.onChangeInput('couponName', event)}
          />
        </div>
        <div>
          <span>采购方：</span>
          <Input
            type="text"
            size="small"
            width={180}
            value={brand}
            onChange={event => this.onChangeInput('brand', event)}
          />
        </div>
        <div>
          <span>供应商：</span>
          <Input
            type="text"
            size="small"
            width={180}
            value={proName}
            onChange={event => this.onChangeInput('proName', event)}
          />
        </div>
      </div>
      <div>
        {/* 基本输入input框 */}
        <div className={`${classNamePre}-top`}>
          <div>
            <span>销售时间：</span>
            <DateRangePicker
              className=""
              width={190}
              value={value}
              format={format}
              showTime={showTime}
              onChange={this.onChangeRange}
            />
          </div>
          <div>
            <span>状态：</span>
            <Select
              data={saleSearchStatus}
              optionValue="type"
              optionText="name"
              width="120px"
              autoWidth
              showClear
              value={SelectValue}
              onChange={this.onChangeSelect}
            />
          </div>
        </div>
        {/* 查询 */}
        <div className={`${classNamePre}-search-btn`}>
          <Button
            type="primary"
            className={`${classNamePre}-btn-1`}
            onClick={this.onSearch}
          >
          查询
          </Button>
        </div>
      </div>
    </div>
  );
}
}
