import * as React from 'react';
import {
  Dialog, Button, NumberInput, Notify
} from 'ezrd';

const classNamePre = 'yiye-asset-manage-recharge-add';

export default class MerchManageZDetailDialog extends React.Component {
static defaultProps = {
  showTime: true, // 是否显示时间筛选
  show: false,
  text: '',
  decimalMoney: 0,
  loading: false,
  min: 0
}

constructor(props) {
  super(props);
  this.state = {
    money: ''
  };
}

onChangeDefault = (type, e) => {
  this.setState({
    [type]: e.target.value
  });
}

closeDialog = () => {
  const { close } = this.props;
  close();
  this.setState({
    money: ''
  });
}

// 点击确定的回调
confirm = () => {
  const {
    money
  } = this.state;
  const { confirm } = this.props;
  if (!money) {
    Notify.error('请输入赠送Z币金额');
    return;
  }
  confirm({
    money
  }, () => {
    this.setState({
      money: ''
    });
  });
}

render() {
  const {
    money
  } = this.state;
  const {
    show, text, decimalMoney, loading, min
  } = this.props;
  return (
    <div>
      <Dialog
        title={text}
        visible={show}
        style={{ width: '500px' }}
        className={`${classNamePre}`}
        maskClosable={false}
        footer={(
          <div>
            <Button
              outline
              loading={loading}
              onClick={() => this.closeDialog()}
            >
            取消
            </Button>
            <Button
              loading={loading}
              onClick={() => this.confirm()}
            >
            确定
            </Button>
          </div>
          )}
      >
        <div className={`${classNamePre}-contain`}>
          <div>
            <span className={`${classNamePre}-contain-lable`}>赠送Z币金额</span>
            <NumberInput
              width={295}
              value={money}
              min={min}
              decimal={decimalMoney}
              onChange={(event) => { this.onChangeDefault('money', event); }}
            />
            <span
              className={`${classNamePre}-contain-company`}
              style={{ 'margin-left': '10px' }}
            />
          </div>
        </div>
      </Dialog>

    </div>
  );
}
}
