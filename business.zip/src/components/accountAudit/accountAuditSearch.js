import * as React from 'react';
import {
  Select, Button, DateRangePicker, Dialog, Input, Notify
} from 'ezrd';
import moment from 'moment';
import { defaultStatusAudit, defaultTypeAudit } from '../base/constant';
import ConstBrandSelect from '../base/constBrandSelect';
import { trim } from '../../utils/common';

const classNamePre = 'merchant-account-audit-search';

export default class AccountAuditSearch extends React.Component {
static defaultProps = {
  showTime: true, // 是否显示时间筛选
  format: 'YYYY-MM-DD HH:mm:ss',
  typeName: '',
  downloadStore: {} // 接口store
}

constructor(props) {
  super(props);
  this.state = {
    value: [],
    taskName: moment().format('YYYY-MM-DD') + props.typeName,
    visible: false,
    loading: false,
    brandId: '',
    status: '',
    type: ''
  };
  this.onSearch = this.onSearch.bind(this);
}

// 点击查询按钮
onSearch = (flag) => {
  const {
    value, brandId, status, type
  } = this.state;
  const { onSearch } = this.props;
  onSearch({
    StartDate: value[0] || '',
    EndDate: value[1] || '',
    brandId,
    status: `${status || ''}` || 9,
    type: `${`${type}`}` || 9
  }, flag);
}

// 清空
onClean = () => {
  this.setState({
    value: ''
  });
}

// 导出按钮
onExport = () => {
  const { typeName } = this.props;
  this.setState({
    visible: true,
    taskName: moment().format('YYYY-MM-DD') + typeName
  });
}

// 关闭弹出框
closeDialog = () => {
  const { typeName } = this.props;
  this.setState({
    visible: false,
    taskName: moment().format('YYYY-MM-DD') + typeName
  });
}

onChangeRange = (val) => {
  this.setState({
    value: val
  });
}

onChange = (id) => {
  this.setState({
    brandId: id
  });
}

// 普通input框的事件回调
onChangeInput = (type, e) => {
  this.setState({
    [type]: e.target.value
  });
}

confirm = async () => {
  const {
    taskName
  } = this.state;
  // const { downloadStore, history } = this.props;
  if (!trim(taskName)) {
    Notify.error('请输入导出数据的文件名称');
  }
}

render() {
  const {
    value, visible, loading, taskName, status, type
  } = this.state;
  const { showTime, format } = this.props;
  return (
    <div className={`${classNamePre}`}>
      {/* 基本输入input框 */}
      <div className={`${classNamePre}-top`}>
        <div>
          <ConstBrandSelect
            onChange={this.onChange}
            filtersId="all"
            width="240px"
          />
        </div>
        <div>
          <span>状态：</span>
          <Select
            data={defaultStatusAudit}
            optionValue="id"
            optionText="name"
            width="240px"
            showClear={false}
            value={status}
            autoWidth
            onChange={event => this.onChangeInput('status', event)}
          />
        </div>
        <div>
          <span>类型：</span>
          <Select
            data={defaultTypeAudit}
            optionValue="id"
            optionText="name"
            width="240px"
            showClear={false}
            value={type}
            autoWidth
            onChange={event => this.onChangeInput('type', event)}
          />
        </div>
      </div>
      {/* 查询--导出 */}
      <div className={`${classNamePre}-bottom`}>
        <div>
          <span>入驻时间：</span>
          <DateRangePicker
            className=""
            width={190}
            value={value}
            format={format}
            showTime={showTime}
            onChange={this.onChangeRange}
          />
        </div>
        <div className={`${classNamePre}-search-btn`}>
          <Button
            type="primary"
            className={`${classNamePre}-btn-1`}
            onClick={this.onSearch}
          >
          查询
          </Button>
          {
            // <Button
            // type="primary"
            // outline
            // onClick={this.onExport}
            // >
            // 导出
            // </Button>
          }

        </div>
      </div>
      {/** 导出文件提示框 */}
      <Dialog
        title="导出数据的文件名称"
        visible={visible}
        onClose={() => this.closeDialog()}
        style={{ width: '600px' }}
        maskClosable={false}
        footer={(
          <div>
            <Button
              outline
              loading={loading}
              onClick={() => this.closeDialog()}
            >
              取消
            </Button>
            <Button
              loading={loading}
              onClick={() => this.confirm()}
            >
              确定
            </Button>
          </div>
        )}
      >
        <Input
          signleBorder
          placeholder="请输入导出数据的文件名称"
          showClear
          maxLength={30}
          width="100%"
          value={taskName}
          onChange={event => this.onChangeInput('taskName', event)}
        />
      </Dialog>
    </div>
  );
}
}
