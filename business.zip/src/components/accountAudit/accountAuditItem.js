import * as React from 'react';
import {
  Switch, Notify
} from 'ezrd';
import { Link } from 'react-router-dom';
import moment from 'moment';
import DefaultTipDialog from '../transaction/defaultTipDialog';

export default class AccountAuditItem extends React.Component {
static defaultProps = {
  classNamePre: '',
  downloadStore: {}, // 接口store
  data: {}, // 数据源
  index: '',
  store: {} // API接口对象
}

constructor(props) {
  super(props);
  this.state = {
    showEnableVisible: false,
    showEnableVisibleText: '',
    customFlag: ''
  };
}

// handleChange = (checked) => {
//   this.setState({ checked });
// }

// 禁止
disabledItem = (id) => {
  this.setState({
    showEnableVisible: true,
    customFlag: {
      type: 'disabled',
      id
    },
    showEnableVisibleText: '您确定要禁用门店吗？门店禁用后，商家将无法进行正常券交易'
  });
}

// 启用
unDisabledItem = (id) => {
  this.setState({
    showEnableVisible: true,
    customFlag: {
      type: 'unDisabled',
      id
    },
    showEnableVisibleText: '您确定要启用门店吗？门店启用后，商家将可以进行正常券交易'
  });
}

// 禁用 启用得回调
confirmEnable = async (flag, customFlag) => {
  const { store, changeData } = this.props;
  if (!flag) { // 取消
    this.setState({
      showEnableVisible: false,
      showEnableVisibleText: ''
    });
    return;
  }
  // customFlag.type === 'disabled') { // 禁用
  const status = await store.fetchMerchantEnable({
    IsEnable: customFlag.type === 'disabled' ? 0 : 1,
    Remark: '',
    MchId: customFlag.id
  });
  if (status && !status.IsError) {
    const text = customFlag.type === 'disabled' ? '禁用成功' : '启用成功';
    Notify.success(text);
    changeData(() => {
      this.setState({
        showEnableVisible: false,
        showEnableVisibleText: ''
      });
    });
  }
}

// 担保账户或者普通账户修改
changeAccoutType = async (checked) => {
  const { store, changeData, data } = this.props;
  const status = await store.fetchMerchantChangeAccountType({
    AccountType: checked ? 0 : 1,
    MchId: data.Id
  });
  if (status && !status.IsError) {
    const text = checked ? '修改普通账户成功' : '修改担保账户成功';
    Notify.success(text);
    changeData(() => {});
  }
}

// 状态的渲染
initStatusTpl = (data) => {
  // [状态]-3:平台禁用;-2:审核未通过;-1:品牌歇业;0:商户初始化;1:待审核;2:营业中; 9:查询全部
  if (data.Status === -3) {
    return (
      <React.Fragment>
        <span>平台禁用</span>
      </React.Fragment>
    );
  } if (data.Status === -2) {
    return (<span>审核未通过</span>);
  } if (data.Status === -1) {
    return (<span>品牌歇业</span>);
  } if (data.Status === 0) {
    return (<span>商户初始化</span>);
  } if (data.Status === 1) {
    return (<span>待审核</span>);
  } if (data.Status === 2) {
    return (<span>营业中</span>);
  }
  return ('--');
}

// 操作区域的模板
initContTpl = (data) => {
  // [状态]-3:平台禁用;-2:审核未通过; -1:品牌歇业; 0:商户初始化; 1:待审核; 2:营业中; 9:查询全部
  if (data.Status === -3) {
    return (
      <React.Fragment>
        <Link
          className="yiye-outline btn-default-color yiye-cursor"
          to={`/Yiye/Account/Audit/Detail/${data.Id}`}
        >
        商户详情
        </Link>
        <span
          role="button"
          tabIndex="0"
          className="yiye-outline btn-default-color yiye-cursor"
          onClick={() => this.unDisabledItem(data.Id)}
        >
          开启
        </span>
      </React.Fragment>
    );
  } if (data.Status === -2 || data.Status === -1) {
    return (
      <Link
        className="yiye-outline btn-default-color yiye-cursor"
        to={{ pathname: `/Yiye/MerchManageDetail/${data.Id}/${data.MerchantName}` }}
      >
        商户详情
      </Link>
    );
  } if (data.Status === 0) {
    return ('--');
  } if (data.Status === 1) {
    return (
      <Link
        className="yiye-outline btn-default-color yiye-cursor"
        to={`/Yiye/Account/Audit/${data.Id}`}
      >
      审核
      </Link>
    );
  } if (data.Status === 2) {
    return (
      <React.Fragment>
        <Link
          className="yiye-outline btn-default-color yiye-cursor"
          to={`/Yiye/Account/Audit/Detail/${data.Id}`}
        >
        商户详情
        </Link>
        <Link
          className="yiye-outline btn-default-color yiye-cursor"
          to={{ pathname: `/Yiye/MerchManageDetail/${data.Id}/${data.MerchantName}` }}
        >
        资产管理
        </Link>
        <span
          role="button"
          tabIndex="0"
          className="yiye-outline btn-default-color yiye-cursor"
          onClick={() => this.disabledItem(data.Id)}
        >
          禁用
        </span>
      </React.Fragment>
    );
  }
  return ('--');
}

render() {
  const { classNamePre, data } = this.props;
  const {
    showEnableVisible, showEnableVisibleText, customFlag
  } = this.state;

  return (
    <div className={`${classNamePre}`}>
      <div className={`${classNamePre}-top`}>
        <div>
          品牌ID：
          {data.Id}
          ，品牌名称：
          {data.MerchantName}
          ，公司名称：
          {data.OrganizationName}
        </div>
        <div>
          <Switch
            transfer
            checked={data.AccountType !== 1}
            onChange={this.changeAccoutType}
            checkedText="普通账户"
            uncheckedText="担保账户"
          />
        </div>

      </div>
      <div className={`${classNamePre}-bottom`}>
        <ul>
          <li>{moment(data.CreateOn).format('YYYY-MM-DD HH:mm')}</li>
          <li>{data.Zb.toFixed(2)}</li>
          <li>{data.CashDeposit.toFixed(2)}</li>
          <li>{data.CashReserve.toFixed(2)}</li>
          <li>
            {this.initStatusTpl(data)}
          </li>
          <li>
            {this.initContTpl(data)}
          </li>
        </ul>
      </div>
      {/* 禁用启用的弹出框 */}
      <DefaultTipDialog
        showEnableVisible={showEnableVisible}
        confirmEnable={this.confirmEnable}
        content={showEnableVisibleText}
        customFlag={customFlag}
      />
    </div>
  );
}
}
