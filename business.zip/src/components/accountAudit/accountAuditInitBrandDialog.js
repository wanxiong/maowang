import * as React from 'react';
import {
  Dialog, Button, NumberInput, Select, Notify, Input
} from 'ezrd';
import { inject } from 'mobx-react';
import { initBrandCloud } from '../base/constant';
import { getMchId } from '../../utils/common';

const classNamePre = 'merchant-account-audit-dialog';

@inject('accountAuditStore')
export default class AccountAuditInitBrandDialog extends React.Component {
static defaultProps = {
  show: false,
  data: [...initBrandCloud] // 下拉框的数据
}

constructor(props) {
  super(props);
  this.state = {
    selectedValue: '',
    brandNum: '',
    searchJson: '',
    loading: false,
    serchLoading: false
  };
}


selectChangeHandler = (event, selected) => {
  this.setState({
    selectedValue: selected.value || ''
  });
};

onChangeDefault = (type, e) => {
  this.setState({
    [type]: e.target.value
  });
}

closeDialog = () => {
  const { onClose } = this.props;
  onClose();
  this.setState({
    brandNum: '',
    selectedValue: '',
    searchJson: '',
    serchLoading: false
  });
}

// 点击确定的回调
confirm = async () => {
  const {
    searchJson
  } = this.state;
  const { confirm, accountAuditStore } = this.props;
  this.setState({
    loading: true
  });
  const data = await accountAuditStore.fetchMerchantInsertOfInitWithCrm({
    Id: searchJson.id,
    MerchantName: searchJson.name,
    CloudId: searchJson.cloudId,
    BrandName: searchJson.name,
    MchId: getMchId(),
    MerchantType: 1
  });
  if (data && !data.IsError) {
    Notify.success(`${searchJson.name}品牌初始化成功`);
    this.setState({
      brandNum: '',
      searchJson: '',
      selectedValue: '',
      loading: false
    });
    confirm();
  } else {
    this.setState({
      loading: false
    });
  }
}

search = async () => {
  const { brandNum, selectedValue } = this.state;
  const { accountAuditStore } = this.props;
  if (!selectedValue) {
    Notify.error('请选择云服务商');
    return;
  }
  if (!brandNum) {
    Notify.error('请输入品牌编号');
    return;
  }
  this.setState({
    serchLoading: true
  });
  const data = await accountAuditStore.fetchCrmBrandInfo({
    BrandId: brandNum,
    CloudId: selectedValue
  });
  if (data && !data.IsError) {
    this.setState({
      serchLoading: false,
      searchJson: {
        name: data.Data.BrandName,
        id: data.Data.BrandId,
        cloudId: selectedValue
      }
    });
    return;
  }
  this.setState({
    serchLoading: false
  });
}

render() {
  const {
    selectedValue, brandNum, searchJson, serchLoading, loading
  } = this.state;
  const {
    show, data
  } = this.props;
  return (
    <Dialog
      title="初始化品牌"
      visible={show}
      style={{ width: '480px' }}
      className={`${classNamePre}`}
      maskClosable={false}
      footer={(
        <div>
          <Button
            outline
            loading={loading}
            onClick={() => this.closeDialog()}
          >
          取消
          </Button>
          <Button
            loading={loading}
            disabled={!searchJson}
            onClick={() => this.confirm()}
          >
          初始化
          </Button>
        </div>
        )}
    >
      <div className={`${classNamePre}-contain`}>
        <div style={{ display: 'flex' }}>
          <div className={`${classNamePre}-contain-lable`}>
            <span>*</span>
            <span>云服务商</span>
          </div>
          <Select
            onChange={this.selectChangeHandler}
            value={selectedValue}
            data={data}
            width={250}
            optionValue="Id"
            optionText="Name"
            autoWidth
          />
        </div>
        <div className={`${classNamePre}-contain-search`}>
          <div className={`${classNamePre}-contain-lable`}>
            <span>*</span>
            <span>品牌编号</span>
          </div>
          <div>
            <NumberInput
              width={180}
              value={brandNum}
              onChange={(event) => { this.onChangeDefault('brandNum', event); }}
            />
            <Button
              onClick={this.search}
              loading={serchLoading}
            >
              查询
            </Button>
          </div>
        </div>
        {
          searchJson
            ? (
              <div className={`${classNamePre}-contain-search`}>
                <div className={`${classNamePre}-contain-lable`} />
                <div>
                  <Input
                    width={250}
                    value={searchJson.name}
                    disabled
                    placeholder=""
                  />
                </div>
              </div>
            )
            : null
        }
      </div>
    </Dialog>
  );
}
}
