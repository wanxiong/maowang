import * as React from 'react';
import {
  Dialog, Button, Input, Notify, Tree
} from 'ezrd';
import { inject } from 'mobx-react';
import { guid } from '../../utils/common';

const classNamePre = 'yiye-system-role-manage-add-dialog';

@inject('systemManageStore')
export default class RoleManageAdd extends React.Component {
static defaultProps = {
  show: false,
  loading: false,
  disabled: false,
  openAll: false,
  data: {},
  treeData: [],
  status: 'add',
  disabledCheckedKeys: []
}

constructor(props) {
  super(props);
  this.state = {
    roleNumber: '',
    roleName: '',
    remark: '',
    uuid: '',
    defaultCheckedKeys: [] // 默认选中的KEY
  };
}

componentDidMount = () => {
}

initDetail = async (id) => {
  const { systemManageStore } = this.props;
  const data = await systemManageStore.fetchSysRoleDetail({
    Id: id
  });
  if (data && !data.IsError) {
    this.setState({
      roleNumber: data.Data.Code,
      roleName: data.Data.Name,
      remark: data.Data.Remark || '',
      defaultCheckedKeys: data.Data.MenuIds || [],
      uuid: guid()
    });
  }
}

onChangeDefault = (type, e) => {
  this.setState({
    [type]: e.target.value
  });
}

componentWillReceiveProps = (props) => {
  if (props.show && props.status !== 'add') {
    const { show } = this.props;
    if (props.show !== show) {
      const id = props.data.Id;
      this.initDetail(id);
    }
  }
  if (!props.show) {
    this.setState({
      roleNumber: '',
      roleName: '',
      remark: '',
      defaultCheckedKeys: []
    });
  }
}

closeDialog = () => {
  const { onClose } = this.props;
  onClose();
  this.setState({
    roleNumber: '',
    roleName: '',
    remark: '',
    defaultCheckedKeys: []
  });
}

// 点击确定的回调
confirm = async () => {
  const {
    roleNumber, roleName, defaultCheckedKeys, remark
  } = this.state;
  const { confirm, data, status } = this.props;
  if (!roleNumber) {
    Notify.error('角色编号不能为空');
    return;
  }
  if (!roleName) {
    Notify.error('角色名称不能为空');
    return;
  }
  let arr = [];
  arr = defaultCheckedKeys.filter(item => item !== '0');
  if (!arr.length) {
    Notify.error('请选择授权页面');
    return;
  }
  confirm({
    roleNumber,
    roleName,
    list: arr,
    remark,
    id: data.Id
  }, () => {
    this.setState({
      roleNumber: '',
      roleName: '',
      remark: '',
      defaultCheckedKeys: []
    });
  }, status);
}

onCheck = (checked) => {
  this.setState({
    defaultCheckedKeys: checked
  });
}

initTitle = () => {
  const { status } = this.props;
  if (status === 'look') {
    return '查看角色';
  } if (status === 'edit') {
    return '编辑角色';
  }
  return '添加角色';
}

render() {
  const {
    roleNumber, roleName, defaultCheckedKeys, remark, uuid
  } = this.state;
  const {
    show, loading, disabledCheckedKeys, status, data, treeData
  } = this.props;
  return (
    <Dialog
      title={this.initTitle()}
      visible={show}
      style={{ width: '530px' }}
      className={`${classNamePre}`}
      maskClosable={false}
      footer={
        status === 'look'
          ? (
            <Button
              loading={loading}
              onClick={() => this.closeDialog()}
            >
            关闭
            </Button>
          )
          : (
            <div>
              <Button
                outline
                loading={loading}
                onClick={() => this.closeDialog()}
              >
              取消
              </Button>
              <Button
                loading={loading}
                onClick={() => this.confirm()}
              >
              确定
              </Button>
            </div>
          )
        }
    >
      <div className={`${classNamePre}-contain`}>
        <div style={{ display: 'flex' }}>
          <div className={`${classNamePre}-contain-lable`}>
            <span>*</span>
            <span>角色编号</span>
          </div>
          <Input
            value={data.roleNumber || roleNumber}
            width={290}
            disabled={status === 'look' || status === 'edit'}
            onChange={(event) => { this.onChangeDefault('roleNumber', event); }}
          />
        </div>
        <div className={`${classNamePre}-contain-search`}>
          <div className={`${classNamePre}-contain-lable`}>
            <span>*</span>
            <span>角色名称</span>
          </div>
          <div>
            <Input
              width={290}
              value={data.roleName || roleName}
              disabled={status === 'look'}
              showCount
              maxLength={16}
              onChange={(event) => { this.onChangeDefault('roleName', event); }}
            />
          </div>
        </div>
        <div className={`${classNamePre}-contain-search`}>
          <div className={`${classNamePre}-contain-lable`}>
            <span />
            <span>备注</span>
          </div>
          <div>
            <Input
              width={290}
              type="textarea"
              value={data.remark || remark}
              disabled={status === 'look'}
              showCount
              maxLength={15}
              onChange={(event) => { this.onChangeDefault('remark', event); }}
            />
          </div>
        </div>
        <div className={`${classNamePre}-contain-search`}>
          <div
            className={`${classNamePre}-contain-lable`}
            style={{ 'align-items': 'flex-start' }}
          >
            <span />
            <span>授权页面</span>
          </div>
          <div
            style={{ 'margin-left': '20px', width: '330px' }}
          >
            <Tree
              checkable
              useNew={false}
              size="small"
              key={uuid}
              data={treeData}
              onCheck={this.onCheck}
              expandAll={status === 'look'}
              defaultCheckedKeys={defaultCheckedKeys}
              disabledCheckedKeys={status === 'look' ? disabledCheckedKeys : []}
              // renderKey={{
              //   id: 'Id',
              //   title: 'Name',
              //   children: 'SubRoutes'
              // }}
            />
          </div>
        </div>
      </div>
    </Dialog>
  );
}
}
