import * as React from 'react';
import {
  Button, Input, Select, NumberInput
} from 'ezrd';
import ConstBrandSelect from '../base/constBrandSelect';

const classNamePre = 'yiye-system-user-manage-search';

export default class UserManageSearch extends React.Component {
static defaultProps = {
  selectData: []
}

constructor(props) {
  super(props);
  this.state = {
    phone: '',
    roleName: '',
    brandId: '',
    selected: -1
  };
  this.onSearch = this.onSearch.bind(this);
}

// 点击查询按钮
onSearch = (flag) => {
  const {
    phone, roleName, selected, brandId
  } = this.state;
  const { onSearch } = this.props;
  onSearch({
    phone,
    roleName,
    selected,
    brandId
  }, flag);
}

defaultChange = (type, e) => {
  this.setState({
    [type]: e.target.value
  });
}

onChange = (e, selected) => {
  this.setState({
    selected: selected.id || -1
  });
};

onChangeBrand = (id) => {
  this.setState({
    brandId: id
  });
}

render() {
  const {
    roleName, phone, selected
  } = this.state;
  const { selectData } = this.props;
  return (
    <div className={`${classNamePre}`}>
      {/* 基本输入input框 */}
      <div className={`${classNamePre}-top`}>
        <div>
          <ConstBrandSelect
            onChange={this.onChangeBrand}
            filtersId="all"
            width="180px"
          />
        </div>
        <div>
          <span>手机号：</span>
          <NumberInput
            width="190px"
            showClear={false}
            value={phone}
            autoWidth
            onChange={(e) => { this.defaultChange('phone', e); }}
          />
        </div>
        <div>
          <span>用户姓名：</span>
          <Input
            width="190px"
            showClear={false}
            value={roleName}
            autoWidth
            onChange={(e) => { this.defaultChange('roleName', e); }}
          />
        </div>
        <div>
          <span>用户状态：</span>
          <Select
            width="120px"
            showClear
            data={selectData}
            optionText="name"
            value={selected}
            optionValue="id"
            autoWidth
            onChange={this.onChange}
          />
        </div>
      </div>
      {/* 采购时间-- 查询--导出 */}
      <div className={`${classNamePre}-btn`}>
        <Button
          type="primary"
          className={`${classNamePre}-btn-1`}
          onClick={this.onSearch}
        >
        查询
        </Button>
      </div>
    </div>
  );
}
}
