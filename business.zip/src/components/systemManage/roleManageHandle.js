import * as React from 'react';
import {
  Dialog, Button, Input, Tree
} from 'ezrd';
import { inject } from 'mobx-react';

const classNamePre = 'yiye-system-role-manage-add-dialog';

const treeData = [{
  id: 1,
  title: '上海驿氪',
  children: [{
    id: 2,
    title: '技术',
    children: [{
      id: 3,
      title: '后端',
      children: [{
        id: 7,
        title: 'JAVA'
      }, {
        id: 8,
        title: 'PHP'
      }, {
        id: 9,
        title: 'GO'
      }, {
        id: 10,
        title: '.NET'
      }]
    }, {
      id: 4,
      title: '运维'
    }, {
      id: 5,
      title: '前端'
    }]
  }, {
    id: 6,
    title: '产品'
  }]
}];

@inject('accountStore')
export default class RoleManageHandle extends React.Component {
static defaultProps = {
  show: false,
  loading: false,
  disabled: false,
  expandAll: true,
  json: {}
}

constructor(props) {
  super(props);
  this.state = {
    roleNumber: props.json.roleNumber || '',
    roleName: props.json.roleName || '',
    defaultCheckedKeys: [3, 5],
    disabledCheckedKeys: [4, 7, 9]
  };
}

componentDidMount = () => {
  this.initAllMenu();
}

initAllMenu = async () => {
  // const { accountStore } = this.props;
  // const data = await accountStore.fetchAccountAllMenuList({});
}

onChangeDefault = (type, e) => {
  this.setState({
    [type]: e.target.value
  });
}

closeDialog = () => {
  const { onClose } = this.props;
  onClose();
  this.setState({
    roleNumber: '',
    roleName: ''
  });
}

onCheck = (checked) => {
  this.setState({
    defaultCheckedKeys: checked
  });
}

render() {
  const {
    roleNumber, roleName, defaultCheckedKeys, disabledCheckedKeys
  } = this.state;
  const {
    show, loading, json, disabled, expandAll
  } = this.props;
  return (
    <Dialog
      title="添加角色"
      visible={show}
      style={{ width: '480px' }}
      className={`${classNamePre}`}
      maskClosable={false}
      footer={(
        <div>
          {
          json.look
            ? (
              <Button
                loading={loading}
                onClick={() => this.closeDialog()}
              >
              确定
              </Button>
            )
            : (
              <React.Fragment>
                <Button
                  outline
                  loading={loading}
                  onClick={() => this.closeDialog()}
                >
                取消
                </Button>
                <Button
                  loading={loading}
                  onClick={() => this.closeDialog()}
                >
                确定
                </Button>
              </React.Fragment>
            )
        }
        </div>
        )}
    >
      <div className={`${classNamePre}-contain`}>
        <div style={{ display: 'flex' }}>
          <div className={`${classNamePre}-contain-lable`}>
            <span />
            <span>角色编号</span>
          </div>
          <Input
            value={roleNumber}
            width={250}
            disabled={disabled}
            onChange={(event) => { this.onChangeDefault('roleNumber', event); }}
          />
        </div>
        <div className={`${classNamePre}-contain-search`}>
          <div className={`${classNamePre}-contain-lable`}>
            <span />
            <span>角色名称</span>
          </div>
          <div>
            <Input
              width={250}
              value={roleName}
              disabled={disabled}
              onChange={(event) => { this.onChangeDefault('roleName', event); }}
            />
          </div>
        </div>
        <div className={`${classNamePre}-contain-search`}>
          <div
            className={`${classNamePre}-contain-lable`}
            style={{ 'align-items': 'flex-start' }}
          >
            <span />
            <span>已授权</span>
          </div>
          <div style={{ 'margin-left': '20px' }}>
            <Tree
              checkable
              size="small"
              data={treeData}
              onCheck={this.onCheck}
              expandAll={expandAll}
              defaultCheckedKeys={defaultCheckedKeys}
              disabledCheckedKeys={disabledCheckedKeys}
            />
          </div>
        </div>
      </div>
    </Dialog>
  );
}
}
