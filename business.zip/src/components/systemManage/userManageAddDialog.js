import * as React from 'react';
import {
  Dialog, Button, Form
} from 'ezrd';
import { inject, observer } from 'mobx-react';
import { sysUserStatus } from '../base/constant';
import { checkPassword } from '../../utils/common';
import ConstBrandSelect from '../base/constBrandSelect';

const classNamePre = 'yiye-system-user-manage-add-dialog';
const {
  FormInputField, createForm, FormSelectField, getControlGroup, Field
} = Form;

const brandSelect = getControlGroup(ConstBrandSelect);

@inject('accountAuditStore')
@observer
class UserManageAddDialogForm extends React.Component {
static defaultProps = {
  show: false,
  data: '',
  title: '新增用户',
  roleList: [],
  loading: false
}

constructor(props) {
  super(props);
  this.state = {
  };
}

closeDialog = () => {
  const { onClose } = this.props;
  onClose();
}

// 点击确定的回调
confirm = () => {
  const { ezrdForm } = this.props;
  ezrdForm.setFormDirty(true);
  if (ezrdForm.isValid()) {
    this.submit();
  }
}

submit = () => {
  const { ezrdForm, onConfirm, data } = this.props;
  const values = ezrdForm.getFormValues();
  onConfirm(values, data ? 'edit' : 'add');
}

render() {
  const {
    show, data, loading, roleList
  } = this.props;
  return (
    <Dialog
      title={data ? '编辑用户' : '新增用户'}
      visible={show}
      style={{ width: '550px' }}
      className={`${classNamePre}`}
      maskClosable={false}
      footer={(
        <div>
          <Button
            outline
            loading={loading}
            onClick={() => this.closeDialog()}
          >
          取消
          </Button>
          <Button
            loading={loading}
            onClick={() => this.confirm()}
          >
          确定
          </Button>
        </div>
        )}
    >
      <div className={`${classNamePre}-contain`}>
        <Form
          horizontal
        >
          <FormInputField
            label="用户账号"
            name="email"
            type="text"
            placeholder="请输入邮箱账号"
            disabled={!!data}
            autocomplete="off"
            width={280}
            value={
            data ? data.EMail : ''
          }
            validations={{
              isEmail: true,
              required: true
            }}
            validationErrors={{
              isEmail: '请填写正确的邮件',
              required: '请输入邮箱账号'
            }}
            required
          />
          <Field
            name="MchId"
            type="text"
            label="品牌"
            component={brandSelect}
            // excludeId={3}
            filtersId="all"
            textLableStyle={`${classNamePre}-brand`}
            required
            value={
              data ? data.MchId : ''
            }
            width={280}
            disabled={data}
            validations={{ required: true }}
            validationErrors={{ required: '请选择品牌' }}
          />
          <FormInputField
            label="手机号码"
            name="phone"
            type="text"
            placeholder="请输入"
            width={280}
            maxLength={11}
            value={
            data ? data.MobileNo : ''
          }
            showCount
            validations={{ required: true, matchRegex: /^1[3456789]\d{9}$/ }}
            validationErrors={{ required: '请输入手机号码', matchRegex: '请输入正确格式的手机号码' }}
            required
          />
          <FormInputField
            label="用户姓名"
            name="name"
            type="text"
            placeholder="请输入"
            showCount
            maxLength={10}
            value={
            data ? data.RealName : ''
          }
            width={280}
            validations={{ required: true, matchRegex: /^[\u4e00-\u9fa5|A-Za-z]+$/ }}
            validationErrors={{ required: '请输入用户姓名', matchRegex: '请输入正确格式的姓名' }}
            required
          />
          {
          !data && (
            <FormInputField
              label="登录密码"
              name="password"
              type="password"
              placeholder="请输入登录密码"
              autocomplete="new-password"
              width={280}
              maxLength={20}
              validations={
                {
                  required: true,
                  checkPs: (values, value) => {
                    if (checkPassword(value)) {
                      return true;
                    }
                    return false;
                  }
                }
              }
              validationErrors={{ required: '请输入登录密码', checkPs: '请输入字母和数字组合成的8-20位数登录密码' }}
              required
            />
          )
        }
          <FormSelectField
            label="角色"
            name="role"
            width={280}
            value={
            data ? data.RoleId : ''
          }
            autoWidth
            data={roleList}
            optionText="Name"
            optionValue="Id"
            showClear={false}
            required
            validations={{ required: true }}
            validationErrors={{ required: '请选择角色' }}
          />
          <FormSelectField
            label="状态"
            name="status"
            width={280}
            value={
            data ? data.Status : '2'
          }
            autoWidth
            data={sysUserStatus}
            optionText="name"
            optionValue="id"
            showClear={false}
          />
          <FormInputField
            label="备注信息"
            name="remark"
            type="textarea"
            maxLength={100}
            value={
            data ? data.Remark : ''
            }
            showCount
            width={280}
            autoWidth
            data={sysUserStatus}
            optionText="name"
            optionValue="id"
            showClear={false}
          />
        </Form>
      </div>
    </Dialog>
  );
}
}

export default createForm()(UserManageAddDialogForm);
