import * as React from 'react';
import {
  Button, Input
} from 'ezrd';

const classNamePre = 'yiye-system-role-manage-search';

export default class PlatformFeeSearch extends React.Component {
static defaultProps = {
}

constructor(props) {
  super(props);
  this.state = {
    roleNum: '',
    roleName: ''
  };
  this.onSearch = this.onSearch.bind(this);
}

// 点击查询按钮
onSearch = (flag) => {
  const {
    roleNum, roleName
  } = this.state;
  const { onSearch } = this.props;
  onSearch({
    roleNum,
    roleName
  }, flag);
}

defaultChange = (type, e) => {
  this.setState({
    [type]: e.target.value
  });
}

render() {
  const {
    roleName, roleNum
  } = this.state;
  return (
    <div className={`${classNamePre}`}>
      {/* 基本输入input框 */}
      <div className={`${classNamePre}-top`}>
        <div>
          <span>角色编号：</span>
          <Input
            width="190px"
            showClear={false}
            value={roleNum}
            autoWidth
            onChange={(e) => { this.defaultChange('roleNum', e); }}
          />
        </div>
        <div>
          <span>角色名称：</span>
          <Input
            width="190px"
            showClear={false}
            value={roleName}
            autoWidth
            onChange={(e) => { this.defaultChange('roleName', e); }}
          />
        </div>
      </div>
      {/* 采购时间-- 查询--导出 */}
      <div className={`${classNamePre}-btn`}>
        <Button
          type="primary"
          className={`${classNamePre}-btn-1`}
          onClick={this.onSearch}
        >
        查询
        </Button>
      </div>
    </div>
  );
}
}
