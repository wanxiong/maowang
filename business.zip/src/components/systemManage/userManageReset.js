import * as React from 'react';
import {
  Dialog, Button, Notify, Input
} from 'ezrd';
import { inject } from 'mobx-react';
import { checkPassword } from '../../utils/common';

const classNamePre = 'merchant-account-audit-dialog';

@inject('accountAuditStore')
export default class UserManageReset extends React.Component {
static defaultProps = {
  show: false,
  data: '',
  loading: false
}

constructor(props) {
  super(props);
  this.state = {
    password: '',
    confirmPassword: ''
  };
}

onChangeDefault = (type, e) => {
  this.setState({
    [type]: e.target.value
  });
}

closeDialog = () => {
  const { onClose } = this.props;
  onClose();
  this.setState({
    password: '',
    confirmPassword: ''
  });
}

// 点击确定的回调
confirm = async () => {
  const {
    password, confirmPassword
  } = this.state;
  const { confirm } = this.props;
  if (!password) {
    Notify.error('新密码不能为空');
    return;
  }
  if (!checkPassword(password)) {
    Notify.error('请输入字母和数字组合成的8-20位数登录密码');
    return;
  }
  if (!confirmPassword) {
    Notify.error('确认新密码不能为空');
    return;
  }
  if (password !== confirmPassword) {
    Notify.error('两次输入的密码不一致');
    return;
  }
  confirm({
    confirmPassword
  }, () => {
    this.setState({
      password: '',
      confirmPassword: ''
    });
  });
}

render() {
  const {
    password, confirmPassword
  } = this.state;
  const {
    show, data, loading
  } = this.props;
  return (
    <Dialog
      title="修改密码"
      visible={show}
      style={{ width: '480px' }}
      className={`${classNamePre}`}
      maskClosable={false}
      footer={(
        <div>
          <Button
            outline
            loading={loading}
            onClick={() => this.closeDialog()}
          >
          取消
          </Button>
          <Button
            loading={loading}
            onClick={() => this.confirm()}
          >
          确定
          </Button>
        </div>
        )}
    >
      <div className={`${classNamePre}-contain`}>
        <div style={{ display: 'flex' }}>
          <div className={`${classNamePre}-contain-lable`}>
            <span>*</span>
            <span>用户账号</span>
          </div>
          <div>
            <Input
              width={250}
              disabled
              value={(data && data.EMail) || ''}
              onChange={(event) => { this.onChangeDefault('userName', event); }}
            />
          </div>
        </div>
        <div className={`${classNamePre}-contain-search`}>
          <div className={`${classNamePre}-contain-lable`}>
            <span>*</span>
            <span>新密码</span>
          </div>
          <div>
            <Input
              width={250}
              value={password}
              type="password"
              onChange={(event) => { this.onChangeDefault('password', event); }}
            />
          </div>
        </div>
        <div className={`${classNamePre}-contain-search`}>
          <div className={`${classNamePre}-contain-lable`}>
            <span>*</span>
            <span>确认新密码</span>
          </div>
          <div>
            <Input
              width={250}
              type="password"
              value={confirmPassword}
              onChange={(event) => { this.onChangeDefault('confirmPassword', event); }}
            />
          </div>
        </div>
      </div>
    </Dialog>
  );
}
}
