
import React, { Component } from 'react';
import {
  ImageSelectorHoc
} from 'ezrpc';
import 'ezrpc/css/image-selector.css';
import 'ezrpc/css/image-selector-new.css';

export default class NewSelectImage extends Component {
  state = {
    imageList: []
  }

  onSelect = (files) => {
    const { changeValue } = this.props;
    if (files.length > 0) {
      this.setState({
        imageList: files.slice(0, 1)
      });
      const { Url, Id, FilePath } = files.slice(0, 1)[0];
      changeValue({ Url, Id, FilePath });
    }
  }

  onExchange = (newFile) => {
    const { changeValue } = this.props;
    this.setState({
      imageList: [newFile]
    });
    const { Url, Id, FilePath } = newFile;
    changeValue({ Url, Id, FilePath });
  }

  render() {
    let { imageList } = this.state;
    const { value: { Url } } = this.props;
    if (!imageList.length && Url) {
      imageList = [{
        FullThumbnail: Url
      }];
    }
    return (
      <div className="ezrd-form__control-group">
        <span
          className="ezrd-form__control-label"
          style={{ marginRight: '20px' }}
        >
          宣传图片：
        </span>
        <ImageSelectorHoc
          triggerInline
          type="image"
          tips="图片建议尺寸：宽度750像素，高度不限"
          onSelect={this.onSelect}
          onExchange={this.onExchange}
          selectedImages={imageList}
        />
      </div>
    );
  }
}
