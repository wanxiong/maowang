/*
 * @Description:
 * @Author: zjq
 * @Date: 2019-12-27 10:58:21
 * @LastEditors  : zjq
 * @LastEditTime : 2020-01-02 14:03:33
 */
import {
  Button
} from 'ezrd';
import { YiyeCouponPackageSelector } from 'ezrpc';
import React from 'react';

export default class CouponPackageSelect extends React.Component {
  state = {
    data: {}
  }

  changeGiftbags = (data) => {
    const { onChange } = this.props;
    onChange(data);
    this.setState({
      data
    });
  };

  render() {
    const { data } = this.state;
    const { id, value } = this.props;
    return (
      <div>
        {/* <Input
          name="selectCoupon"
          type="text"
          value={(data.packageInfo && data.packageInfo.Name) || value}
          placeholder="请选择"
          width={300}
          disabled
        /> */}
        {id === "0" && (
          <YiyeCouponPackageSelector
            style={{ 'margin-left': '10px' }}
            onSelect={this.changeGiftbags}
            disabled={id !== "0" || id !== 0}
          >
            <Button
              type="deauflt"
            >
              { (data.packageInfo && data.packageInfo.Name) || value || '请选择'}
            </Button>
          </YiyeCouponPackageSelector>
        )}
        {id !== "0" && (
          <Button
            type="deauflt"
            disabled
          >
            { (data.packageInfo && data.packageInfo.Name) || value || '请选择'}
          </Button>
        )}
      </div>

    );
  }
}
