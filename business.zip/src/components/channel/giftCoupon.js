import React, { Component, Fragment } from 'react';
import { observer, inject } from 'mobx-react';
// import { getGiftCouponList } from '../../services/channel/common';
// import CouponDialog from './gift-coupon';
import cx from 'classnames';
import {
  Alert,
  DateRangePicker,
  Radio,
  Input,
  Button
} from 'ezrd';

const RadioGroup = Radio.Group;

@inject('channel')
@observer
export default class Coupon extends Component {
  state = {

  }

  componentDidMount() {
    // this.getCouponList();
  }

  // 获取优惠券列表
  // getCouponList = async () => {
  //   const { channel, id } = this.props;
  //   // console.log('channel =====', channel);
  //   const { setCouponList, setTotalItem } = this.props;
  //   const { Data: { PagedList: data, TotalRowsCount } } = await channel.fetchGiftbagsList({
  //     PageSize: 10,
  //     PageIndex: 1,
  //     Id: id
  //   })
  //     .then((res) => { console.log('res =====', res); })
  //     .catch((err) => { throw new Error(err); });

  //   setCouponList(data);
  //   setTotalItem(TotalRowsCount);
  // }

  render() {
    const {
      // changeValue,
      value,
      // changeGiftbags,
      onInputChange,
      onDateChange,
      width,
      displayError,
      id,
      isDirty,
      error
    } = this.props;
    const showError = displayError === undefined ? isDirty && error !== null : displayError;
    const {
      // val: {
      //   Name
      // },
      giftbagsList
    } = value;

    const giftCouponNames = cx({
      'ezrd-form__control-group': true,
      'has-error': showError
    });
    // console.log('giftbagsList', toJS(giftbagsList));
    return (
      <Fragment>
        <div
          className={giftCouponNames}
        >
          <div className="ezrd-form__controls">
            {giftbagsList && !!giftbagsList.length
            && (
            <div
              className="ezrd-form__control-group"
              style={{ paddingTop: '20px', marginLeft: '-100px' }}
            >
              <span className="ezrd-form__control-label">
                券包
              </span>
              <div className="ezrd-form__controls">

                {giftbagsList.map((v, index) => (
                  <div
                    key={v.Id}
                    className="item-wrapper"
                    style={{ width: '800px' }}
                  >
                    <Alert>
                      券
                      {index + 1}
                    </Alert>
                    <div
                      className="ezrd-form__control-group"
                      style={{ marginTop: '20px' }}
                    >
                      <span className="ezrd-form__control-label">
                        优惠券：
                      </span>
                      <div className="ezrd-form__controls">
                        <Button
                          disabled
                          type="default"
                        >
                          {v.CouponGrpName}
                        </Button>
                        <p>
                          券ID:
                          {v.CouponGrpId}
                        </p>
                        <p>
                          赠送张数:一个券包
                          {v.CouponCount}
                          张
                        </p>
                        {/* <input
                          disabled
                          name="ceshiyouhui"
                          defaultValue={v.CouponGrpName}
                        /> */}
                        {/* <p className="ezrd-form__help-desc" /> */}
                      </div>
                    </div>
                    {
                      !((v.CouponOrigin === 0 && v.CouponType === 'YY' && v.GrpCouponValidType === 0)
                      || (v.CouponOrigin === 1 && v.CouponType === 'YY' && v.GrpCouponValidType === 0)) && (
                        <div className="ezrd-form__control-group">
                          <span className="ezrd-form__control-label">
                            <em className="ezrd-form__required">*</em>
                            有效期：
                          </span>
                          <div className="ezrd-form__controls">
                            <Input
                              width={200}
                              disabled={id !== '0' || (v.CouponOrigin === 1 && v.CouponType !== 'YY')}
                              placeholder="请填写天数"
                              value={v.CouponValidDays}
                              onChange={e => onInputChange(e, index, 'CouponValidDays')}
                              addonBefore={(
                                <RadioGroup
                                  disabled={id !== '0' || (v.CouponOrigin === 1 && v.CouponType !== 'YY')}
                                  value={v.CouponValidTypeTem}
                                  onChange={e => onInputChange(e, index, 'radio')}
                                >
                                  <Radio value="CM">自领取日起</Radio>
                                </RadioGroup>
                              )}
                              addonAfter={
                                <span style={{ paddingLeft: '5px' }}>天有效</span>
                              }
                            />
                            <div style={{ paddingTop: '10px' }}>
                              <RadioGroup
                                disabled={id !== '0' || (v.CouponOrigin === 1 && v.CouponType !== 'YY')}
                                value={v.CouponValidTypeTem}
                                onChange={e => onInputChange(e, index, 'radio')}
                              >
                                <Radio value="TS">自定义</Radio>
                              </RadioGroup>
                              <DateRangePicker
                                width={200}
                                disabled={id !== '0' || (v.CouponOrigin === 1 && v.CouponType !== 'YY')}
                                showTime
                                format="YYYY-MM-DD HH:mm:ss"
                                value={v.CouponTimes}
                                onChange={e => onDateChange(e, index)}
                              />
                            </div>

                          </div>
                        </div>
                      )
                    }
                    <div className="ezrd-form__control-group">
                      <span className="ezrd-form__control-label">
                        使用说明：
                      </span>
                      <div className="ezrd-form__controls">
                        <Input
                          name="ceshiyouhui"
                          disabled={id !== '0' || (v.CouponOrigin === 1)}
                          width={width}
                          autoSize
                          value={v.Guide || ''}
                          type="textArea"
                          onChange={e => onInputChange(e, index, 'remark')}
                          placeholder="请填写使用说明"
                        />
                      </div>
                    </div>
                  </div>

                ))}

              </div>
            </div>
            )
          }
            {/* {showError && <p className="ezrd-form__error-desc">{this.props.error}</p>} */}
          </div>
        </div>
      </Fragment>
    );
  }
}
