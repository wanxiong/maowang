import {
  Form
} from 'ezrd';
import React from 'react';
// import {
//   ConstFormValidDate
// } from '../base/constForm';

const {
  FormInputField
} = Form;

export default class Coupon extends React.Component {
  state = {
    data: {}
  }

  onSelect = (data) => {
    const { onChange } = this.props;
    onChange(data);
    this.setState({
      data
    });
  };

  render() {
    const { data } = this.state;
    // console.log('data ====', data.Name);
    return (
      <div>
        <FormInputField
          name="name"
          type="text"
          label="券1"
          required
          spellCheck={false}
          preDesc={
            <span style={{ color: '#000' }}>{data.Name}</span>
            }
          width={80}
          validations={{ required: true }}
          validationErrors={{ required: '请填写昵称' }}
        />
        <FormInputField
          name="name"
          type="text"
          label=""
          spellCheck={false}
          preDesc={
            <span style={{ color: '#000' }}>{data.Name}</span>
            }
          width={80}
          validations={{ required: true }}
          validationErrors={{ required: '请填写昵称' }}
        />
        <FormInputField
          name="name"
          type="text"
          label=""
          spellCheck={false}
          preDesc={
            <span style={{ color: '#000' }}>{data.Name}</span>
            }
          width={80}
          validations={{ required: true }}
          validationErrors={{ required: '请填写昵称' }}
        />
      </div>

    );
  }
}
