/* eslint-disable prefer-destructuring */
import React, { Component } from 'react';
import {
  Form, Radio, Button, Title, Switch, Checkbox, Notify, NumberInput, Pop, Icon
} from 'ezrd';
import { toLongDate } from 'ezrd/lib/utils/datetime';
import 'ezrpc/css/public-coupons.css';
import { inject, observer } from 'mobx-react';
import moment from 'moment';
import couponPackageSelect from './couponPackageSelect';
import couponSelect from './couponSelect';
import giftCoupon from './giftCoupon';
import {
  ConstFormValidDate
} from '../base/constForm';
import Coupon from './coupon';
// import { isEmptyTime } from '../../utils/common';

const {
  Field,
  FormInputField,
  FormSelectField,
  FormRadioGroupField,
  FormDateRangePickerField,
  createForm,
  getControlGroup
} = Form;
const WIDTH = '300px';
const couponPackageSelectForm = getControlGroup(couponPackageSelect);
const couponSelectForm = getControlGroup(couponSelect);

@inject('channel')
@observer
class FieldForm extends Component {
  state = {
    // value: 'CN',
    // isNew: false,
    // isOpenReward: true,
    // couponValue: {},
    giftCouponValue: {},
    giftbagsList: [], // 赠送券包的list
    auxiliaryState: false,
    termOfValidityValue: {
      CouponValidTypeTem: 'CM', // 自定义天数
      CouponValidStart: '',
      CouponDuration: '',
      CouponTimes: ['', ''],
      CouponValidStartTime: '',
      CouponValidEndTime: ''
    },
    id: '' // 编辑id,
  }

  componentDidMount() {
    const { getRef, id, channel } = this.props;
    this.setState({ id });
    channel.fetchBrandMsgCfg();
    channel.fetchChannelDetail({ id });
    // const { channelDetail } = channel;
    // console.log('channelDeatail ====== '.channelDetail);
    // this.setState({
    //   isNew: channelDetail.IsNewVipReward,
    //   value: channelDetail.PresentType,
    //   giftbagsList: channelDetail.GiftDtl,
    //   isOpenReward: channelDetail.IsSendReward
    // });
    getRef(this);
    // console.log("CouponValidStartTime ====== ", channelDetail.CouponValidStartTime);
    // console.log("CouponValidEndTime ====== ", channelDetail.CouponValidEndTime);
  }

  submit = (values, ezrdForm) => {
    // console.log('ezrForm ==== ', values);
    const { channel: { channelDetail } } = this.props;
    const couponAll = channelDetail.PresentType === 'BS' ? channelDetail.Bonus : channelDetail.LimitNum;
    const {
      CouponGrpName,
      PresentType,
      CouponOrigin,
      IsSendReward
    } = channelDetail;
    // CouponGrpName 优惠券名
    if (IsSendReward) {
      if (!couponAll && PresentType === 'CN') {
        Notify.error('请输入券总量');
        return false;
      }
      if (!couponAll && PresentType === 'GB') {
        Notify.error('请输入券包总量');
        return false;
      }
      if (!CouponGrpName && PresentType === 'CN') {
        Notify.error('请选择券');
        return false;
      }
      if (!CouponGrpName && PresentType === 'GB') {
        Notify.error('请选择券包');
        return false;
      }
      // eslint-disable-next-line eqeqeq
      if (CouponOrigin == '0' && values.CusValidVay && values.CusValidVay.type == '2') {
        const startTimeYiYe = values.ActivityTime[1].substr(0, 10); // 投放的结束时间
        const endTimeYiYe = values.CusValidVay.data[1][1].substr(0, 10); // 有效期结束时间
        const startTimeStrYiYe = new Date(startTimeYiYe).getTime();
        const endTimeStrYiYe = new Date(endTimeYiYe).getTime();
        // console.log(startTimeStrYiYe, endTimeStrYiYe, startTimeStrYiYe <= endTimeStrYiYe);
        if (endTimeStrYiYe < startTimeStrYiYe) {
          Notify.error('使用有效期的结束日期不能早于投放时间的结束日期');
          return false;
        }
      }
    }

    const {
      changeTab
    } = this.props;
    if (ezrdForm.isValid()) {
      changeTab('2');
    } else {
      // ezrdForm.setFormDirty();
      // channel.saveFormState(values);
    }
    return true;
  }

  rewardRadioChange = (e) => {
    const { channel } = this.props;
    const { channelDetail } = channel;
    channelDetail.PresentType = e.target.value;
    channelDetail.CouponGrpName = "";
    this.setState({
      giftbagsList: []
    });
  }

  // dateChange = (e, index) => {
  //   const { auxiliaryState, giftbagsList } = this.state;
  //   const item = giftbagsList[index];
  //   item.CouponTimes = e;
  //   this.setState({
  //     giftbagsList,
  //     auxiliaryState: !auxiliaryState
  //   });
  // }

  radioChange = () => {
    // const { target } = e;
    // this.setState({
    //   value: target.value
    // });
  }

  _onCouponTermChange = (e, val, name) => {
    const {
      termOfValidityValue
    } = this.state;
    let value;
    switch (name) {
      case 'CouponTimes':
        value = e;
        break;
      default:
      {
        const { target } = e;
        value = target.value;
        break;
      }
    }
    this.setState({
      termOfValidityValue: {
        ...termOfValidityValue,
        [name]: value
      }
    });
  }

  changeActName = (event) => {
    // console.log('event ===== ', event);
    const { channel } = this.props;
    const { channelDetail } = channel;
    channelDetail.ActName = event.target.value;
  }

  handleCheckBox = () => {
    const { channel } = this.props;
    const { channelDetail } = channel;
    channelDetail.IsNewVipReward = !channelDetail.IsNewVipReward;
  }

  changeRewardState = () => {
    const { channel } = this.props;
    const { channelDetail } = channel;
    channelDetail.IsSendReward = !channelDetail.IsSendReward;
  }

  onMessageTypeChange = (event) => {
    const { channel } = this.props;
    const { channelDetail } = channel;
    channelDetail.SendMessageType = event.target.value;
  }

  coupnCountChange = (event) => {
    const { channel } = this.props;
    const { channelDetail } = channel;
    if (channelDetail.PresentType !== 'BS') {
      channelDetail.LimitNum = event.target.value;
    } else {
      channelDetail.Bonus = event.target.value;
    }
  }

  changeLimitType = (event) => {
    // console.log('event ===== ', event);
    const { channel } = this.props;
    const { channelDetail } = channel;
    channelDetail.LimitType = event;
  }

  changeSendNote = (event) => {
    const { channel } = this.props;
    const { channelDetail } = channel;
    channelDetail.SendNote = event.target.value;
  }

  changeCouponGuide = (event) => {
    const { channel } = this.props;
    const { channelDetail } = channel;
    channelDetail.CouponGuide = event.target.value;
  }

  couponSelectChange = (params) => {
    // console.log(params);
    // console.log(params.infoList[0].CouponValidDays);

    const { channel } = this.props;
    const { channelDetail } = channel;
    // console.log('moment ====== ', moment("/Date(1575129600000+0800)/").format('YYYY-MM-DD HH:mm'));

    if (params.infoList.length) {
      const startTime = moment(params.infoList[0].CouponBeginDate).format('YYYY-MM-DD HH:mm:ss');
      const endTime = moment(params.infoList[0].CouponEndDate).format('YYYY-MM-DD HH:mm:ss');
      channelDetail.CouponValidTypeTem = startTime.includes('0001-01-01') ? 'CM' : 'TS';
      channelDetail.CopId = params.infoList[0].CopId;
      channelDetail.CouponGrpName = params.infoList[0].CouponName;
      channelDetail.CouponGrpId = params.infoList[0].Id;
      channelDetail.CouponOrigin = params.infoList[0].CouponOrigin;
      channelDetail.UnionCouponType = params.infoList[0].UnionCouponType;
      channelDetail.CouponValidType = params.infoList[0].CouponValidType;
      channelDetail.GrpCouponValidType = params.infoList[0].GrpCouponValidType;
      channelDetail.CouponType = params.infoList[0].CouponType;
      channelDetail.CouponValidStartTime = startTime;
      channelDetail.CouponValidEndTime = endTime;
      channelDetail.CouponDuration = params.infoList[0].CouponValidDays === 0 ? null : params.infoList[0].CouponValidDays;
      channelDetail.CouponGuide = params.infoList[0].Guide;
      channelDetail.CouponOrigin = params.infoList[0].CouponOrigin;
      channelDetail.UnionCouponType = params.infoList[0].UnionCouponType;
      // console.log(moment(params.infoList[0].CouponBeginDate).format('YYYY-MM-DD HH:mm:ss'), moment(params.infoList[0].CouponEndDate).format('YYYY-MM-DD HH:mm:ss'))
      // let isShowTime = true; // 是否展示有效期
      // if (id === "0") {
      //   if (channelDetail.CouponOrigin === 0 && channelDetail.CouponType === "YY" && (channelDetail.GrpCouponValidType === 0 || channelDetail.CouponValidType === 0)) {
      //     isShowTime = false;
      //   }
      //   if (channelDetail.CouponOrigin === 1 && channelDetail.UnionCouponType === 1) {
      //     isShowTime = false;
      //   }
      // }
      // if (!isShowTime) {
      //   channelDetail.CouponValidType = (params.infoList[0].CouponOrigin === 1 && params.infoList[0].UnionCouponType === 1) ? "CM" : "TS";
      // }
    }
  }

  // changeTimeRadio = (params) => {
  //   console.log('params ==== ', params);

  //   const { channel } = this.props;
  //   const { channelDetail } = channel;
  //   const { type } = params;
  //   channelDetail.CouponValidType = type === "1" ? "CM" : "TS";
  //   if (type === "1") {
  //     channelDetail.CouponValidStart = params.data[0];
  //   } else {
  //     channelDetail.CouponValidStart = params.data[0];
  //   }
  // }

  changeGiftbags = (list) => {
    // console.log('list', list);
    const { couponsList, packageInfo } = list;
    // console.log(list);
    const giftbagsList = couponsList && couponsList.map(v => ({
      ...v,
      CouponGrpName: v.CouponGrpName,
      CouponValidTypeTem: v.CouponBeginDate.includes('0001-01-01') ? 'CM' : 'TS',
      // CouponValidDays: '',
      Guide: v.CouponRemark,
      CouponCount: v.CouponCount,
      canDisabled: v.CouponBeginDate.includes('0001-01-01'),
      // eslint-disable-next-line max-len
      CouponTimes: v.CouponBeginDate.includes('0001-01-01') ? ['', ''] : [moment(v.CouponBeginDate).format('YYYY-MM-DD HH:mm:ss'), moment(v.CouponEndDate).format('YYYY-MM-DD HH:mm:ss')],
      CouponBeginDate: v.CouponBeginDate.includes('0001-01-01') ? moment(v.CouponBeginDate).format('YYYY-MM-DD HH:mm:ss') : '',
      CouponEndDate: v.CouponEndDate.includes('0001-01-01') ? moment(v.CouponEndDate).format('YYYY-MM-DD HH:mm:ss') : ''
    }));
    // console.log('giftbagsList', giftbagsList);
    this.setState({
      giftbagsList
      // id: list && list.packageInfo && list.packageInfo && list.packageInfo.Id
    });
    const { channel } = this.props;
    const { channelDetail } = channel;
    channelDetail.GiftDtl = giftbagsList;
    channelDetail.CouponGrpName = packageInfo.Name;
    channelDetail.CouponGrpId = packageInfo.Id;
  }

  renderPatyOne = () => {
    const { id } = this.state;
    const { channel } = this.props;
    const { channelDetail } = channel;
    return (
      <div>
        <FormInputField
          name="ActName"
          label="投放渠道名称"
          // autoComplete="off"
          maxLength={20}
          type="text"
          width={WIDTH}
          disabled={id !== '0'}
          value={channelDetail.ActName}
          placeholder="投放渠道名称"
          notice="为了提高活动名称的可读性，建议加注渠道名称，如：爱奇艺-渠道注册活动"
          required
          onChange={this.changeActName}
          validations={{ required: true }}
          validationErrors={{ required: '请填写投放渠道名称' }}
        />
        <FormDateRangePickerField
          width={200}
          label="投放时间"
          showTime
          required
          validateOnBlur
          disabled={id !== '0'}
          name="ActivityTime"
          type="split"
          value={[channelDetail.BeginDate, channelDetail.EndDate]}
          dateFormat="YYYY-MM-DD HH:mm:ss"
          min={new Date().getTime()}
          validations={{
            required(values, value) {
              return !!value[0] && !!value[1];
            }
          }}
          validationErrors={{
            required: '请填写投放时间'
          }}
        />
      </div>
    );
  }

  renderSwitchDiv = () => {
    const { id } = this.state;
    const { channel } = this.props;
    const { channelDetail } = channel;
    const style = {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      width: '100%',
      paddingRight: '20px'
    };
    return (
      <div style={style}>
        <div>
            渠道注册奖励
        </div>
        <Switch
          checked={channelDetail.IsSendReward}
          disabled={id !== '0'}
          value={channelDetail.IsSendReward}
          onChange={this.changeRewardState}
        />
      </div>
    );
  }

  renderIsNewRewardDiv = () => {
    const { id } = this.state;
    const { channel } = this.props;
    const { channelDetail } = channel;
    // console.log('channelDetail ====== ', channelDetail);
    return (
      <FormRadioGroupField
        label="奖励限制"
        name="IsNewVipReward"
        value={channelDetail.IsNewVipReward}
      >
        <Checkbox
          checked={channelDetail.IsNewVipReward}
          onChange={this.handleCheckBox}
          disabled={id !== '0'}
        >
          仅限新会员
        </Checkbox>
      </FormRadioGroupField>
    );
  }

  renderRewordTypeDiv = () => {
    const { id } = this.state;
    const { channel } = this.props;
    const { channelDetail } = channel;
    return (
      <FormRadioGroupField
        label="奖品"
        required
        disabled={id !== '0'}
        name="PresentType"
        value={channelDetail.PresentType}
        onChange={this.rewardRadioChange}
      >
        <Radio value="CN">优惠券</Radio>
        <Radio value="GB">优惠券包</Radio>
        {/* <Radio value="BS">积分</Radio> */}
      </FormRadioGroupField>
    );
  }

  renderCouponDiv = () => {
    const { id } = this.state;
    const { channel } = this.props;
    const { channelDetail } = channel;
    // console.log('channelDetail', channelDetail.CouponGrpId);
    return (
      <div>
        {channelDetail.PresentType === 'CN'
          && (
            <div>
              <Field
                label="优惠券"
                name="couponSelect"
                required
                disabled={id !== "0"}
                component={couponSelectForm}
                id={id}
                value={channelDetail.CouponGrpName}
                onChange={this.couponSelectChange}
                helpDesc={
                  id !== '0' && channelDetail.CouponGrpId && (
                    <p>
                      券ID:
                      {channelDetail.CouponGrpId}
                    </p>
                  )
                }
              />
            </div>
          )}
      </div>
    );
  }

  renderCouponPackageDiv = () => {
    const { channel, id } = this.props;
    const { channelDetail } = channel;
    return (
      <div>
        {channelDetail.PresentType === 'GB'
          && (
            <Field
              label="优惠券包"
              name="couponPackageSelectForm"
              required
              component={couponPackageSelectForm}
              id={id}
              value={channelDetail.CouponGrpName}
              onChange={(data) => { this.changeGiftbags(data); }}
            />
          )}
      </div>
    );
  }

  renderCouponCountDiv = () => {
    const { id } = this.state;
    const { channel } = this.props;
    const { channelDetail } = channel;
    let name = "";
    if (channelDetail.PresentType === 'BS') {
      name = "积分值";
    } else if (channelDetail.PresentType === 'CN') {
      name = "券总量";
    } else {
      name = "券包总量";
    }
    return (
      <div>
        <FormSelectField
          name="LimitType"
          label={name}
          disabled={id !== '0'}
          autoWidth
          data={[
            { value: 2, text: '累计' },
            { value: 1, text: '每日' }
          ]}
          required
          preDesc={(
            <NumberInput
              disabled={id !== '0'}
              value={channelDetail.PresentType === 'BS' ? channelDetail.Bonus : channelDetail.LimitNum}
              onChange={this.coupnCountChange}
              min={1}
              isPositive
            />
          )}
          value={channelDetail.LimitType}
          width={80}
          onChange={this.changeLimitType}
          validations={{
            required: true
          }}
          validationErrors={{ required: `请输入${name}数量` }}
        />
      </div>
    );
  }


  renderEarnedDiv = () => {
    const { id } = this.state;
    const { channel } = this.props;
    const { channelDetail } = channel;
    return (
      <div>
        {/* 积分值 */}
        {channelDetail.PresentType === 'BS'
          && (
          <FormInputField
            name="Bonus"
            label="积分值"
            value={channelDetail.Bonus}
            autoComplete="off"
            disabled={id !== '0'}
            required
            type="text"
            validations={{
              required: true,
              isGtInt(values, res) {
                return /^\d+/g.test(res);
              }
            }}
            validationErrors={{ required: '请填写积分值', isGtInt: '请填入整数' }}
          />
          )}
      </div>
    );
  }

  renderCouponDesDiv = () => {
    const { id } = this.state;
    const { channel } = this.props;
    const { channelDetail } = channel;
    let isAble = false; // 有效期和描述是否能够修改
    // if (channelDetail.CouponOrigin === 1 && channelDetail.UnionCouponType === 0 && id === "0") {
    //   isAble = true;
    // }
    // if (channelDetail.CouponOrigin === 1 && channelDetail.UnionCouponType === 1) {
    //   isAble = true;
    // }
    // if (channelDetail.CouponOrigin === 0 && channelDetail.CouponType === 'YY' && channelDetail.UnionCouponType === 0) {
    //   isAble = true;
    // }
    if (channelDetail.CouponOrigin === 1) {
      isAble = true;
    }
    // console.log(channelDetail.CouponOrigin, isAble);
    return (
      channelDetail.PresentType === 'CN' && (
        <FormInputField
          label="使用说明"
          disabled={id !== '0' || isAble}
          name="CouponGuide"
          type="textArea"
          value={channelDetail.CouponGuide}
          onChange={this.changeCouponGuide}
          maxLength={512}
          showCount
          width={WIDTH}
          autoSize
        />
      )
    );
  }

  renderBottomDiv = () => {
    const { channel, id } = this.props;
    const { channelMessageData } = channel;
    const { channelDetail } = channel;
    return (
      <div>
        <Title titleDesc="短信设置">
          <FormRadioGroupField
            label={(
              <span>
              通知短信&nbsp;
                <Pop
                  trigger="hover"
                  position="right-center"
                  content="仅以手机号为注册字段的，微信开卡注册时，如有其他必填字段，将以默认字段补全完成注册"
                  centerArrow
                >
                  <Icon
                    style={{ color: '#999' }}
                    type="info"
                    ezrd
                  />
                </Pop>
              </span>
            )}
            type="split"
            disabled={id !== '0'}
            name="SendMessageType"
            value={channelDetail.SendMessageType}
            required
            onChange={this.onMessageTypeChange}
            // validations={{
            //   required(values, value) {
            //     return value !== '';
            //   }
            // }}
            validationErrors={{
              required: '请选择发送短信类型'
            }}
            isColumn
          >
            <Radio value={1}>
              品牌短信
              <span>{`   目前剩余短信${channelMessageData.TotalBalanceCount || 0}条`}</span>
            </Radio>
            <Radio value={2}>平台短信</Radio>
          </FormRadioGroupField>
          <FormInputField
            label="自定义通知短信内容"
            maxLength={70}
            showCount
            name="SendNote"
            value={channelDetail.SendNote}
            disabled={id !== '0'}
            type="textArea"
            width={WIDTH}
            onChange={this.changeSendNote}
            autoSize
          />
        </Title>
        <div className="ezrd-form__form-actions channel-add-form-center">
          <Button
            type="primary"
            htmlType="submit"
          >
              下一步
          </Button>
        </div>
      </div>
    );
  }

  renderCouponInfoDiv = res => (
    <div>
      <Coupon
        data={res}
        index={res.index}
      />
    </div>
  )

  inputChange = (e, index, type) => {
    const { auxiliaryState, giftbagsList } = this.state;
    const { value } = e.target;
    const item = giftbagsList[index];
    switch (type) {
      case 'remark':
        // console.log('type1');
        item.CouponRemark = value;
        break;
      case 'radio':
        item.CouponValidTypeTem = value;
        break;
      case 'CouponValidDays':
        // eslint-disable-next-line no-case-declarations
        if (value && !/^[0-9]+$/g.test(value)) {
          Notify.error('请输入0-9的整数');
          return;
        }
        item.CouponValidDays = value;
        break;
      default:
        item.CouponRemark = value;
        break;
    }
    // giftbagsList[index].Date = value;
    giftbagsList.splice(index, 1, item);
    this.setState({
      giftbagsList,
      auxiliaryState: !auxiliaryState
    });
  }

  dateChange = (e, index) => {
    const { auxiliaryState, giftbagsList } = this.state;
    const item = giftbagsList[index];
    item.CouponTimes = e;
    this.setState({
      giftbagsList,
      auxiliaryState: !auxiliaryState
    });
  }


  changeGiftCouponValue = (value) => {
    // console.log('value', value);
    this.setState({
      giftCouponValue: value
    });
  }


  renderGiftListDiv = () => {
    const {
      giftCouponValue, giftbagsList, id, auxiliaryState
    } = this.state;
    const { channel } = this.props;
    const { channelDetail } = channel;
    return (
      <div>
        {channelDetail.PresentType === 'GB'
          && (
          <Field
            name="giftCoupon"
            width={WIDTH}
            id={id}
            component={giftCoupon}
            value={{ val: giftCouponValue, giftbagsList: id !== '0' ? channelDetail.GiftDtl : giftbagsList }}
            auxiliaryState={auxiliaryState}
            onInputChange={this.inputChange}
            onDateChange={this.dateChange}
            onRadioChange={this.radioChange}
            changeValue={this.changeGiftCouponValue}
            changeGiftbags={this.changeGiftbags}
          />
          )
        }
      </div>
    );
  }

  renderCouponDetailDiv = () => {
    const { channel, id } = this.props;
    const { channelDetail } = channel;
    let isShowTime = true; // 是否展示有效期
    // let isShowDescription = true; // 是都显示显示券说明
    let isAble = false; // 有效期和描述是否能够修改
    // console.log("CouponOrigin ====== ", channelDetail.CouponOrigin);
    // console.log("CouponType ====== ", channelDetail.CouponType);
    // console.log("CouponValidType ====== ", channelDetail.CouponValidType);
    // console.log("GrpCouponValidType ====== ", channelDetail.GrpCouponValidType);
    // console.log("CouponValidStartTime ====== ", channelDetail.CouponValidStartTime);
    // console.log("CouponValidEndTime ====== ", channelDetail.CouponValidEndTime);
    // console.log("channelDetail.CouponValidStart ===== ", channelDetail.CouponValidStart);
    // console.log("channelDetail.CopId ===== ", channelDetail.CopId);

    let isTimeEnable = true;
    if (id === "0") {
      const toLongDateStartTime = toLongDate(channelDetail.CouponValidStartTime);
      const toLongDateEndDate = toLongDate(channelDetail.CouponValidEndTime);
      isTimeEnable = toLongDateStartTime.indexOf("0001") === -1 && toLongDateEndDate.indexOf("0001") === -1;
    } else {
      // isTimeEnable = !isEmptyTime(channelDetail.CouponValidStartTime, channelDetail.CouponValidEndTime);
      const toLongDateStartTime = toLongDate(channelDetail.CouponValidStartTime);
      const toLongDateEndDate = toLongDate(channelDetail.CouponValidEndTime);
      isTimeEnable = toLongDateStartTime.indexOf("0001") === -1 || toLongDateEndDate.indexOf("0001") === -1;
    }
    // console.log("isTimeEnable ===== ", channelDetail);
    if (id === "0") {
      if (channelDetail.CouponOrigin === 0 && channelDetail.CouponType !== "YY") {
        isShowTime = true;
        isAble = true;
      }
      if (channelDetail.CouponOrigin === 0 && channelDetail.CouponType === "YY" && channelDetail.GrpCouponValidType === 0) {
        isShowTime = false;
      }
      if (channelDetail.CouponOrigin === 0 && channelDetail.CouponType === "YY" && channelDetail.GrpCouponValidType === 1) {
        isShowTime = true;
        isAble = true;
      }
      if (channelDetail.CouponOrigin === 1 && channelDetail.UnionCouponType === 0 && channelDetail.CouponType !== "YY") {
        isShowTime = true;
        isAble = false;
      }
      if (channelDetail.CouponOrigin === 1 && channelDetail.UnionCouponType === 1 && channelDetail.CouponType === "YY" && channelDetail.GrpCouponValidType === 0) {
        isShowTime = false;
      }
      if (channelDetail.CouponOrigin === 1 && channelDetail.UnionCouponType === 1 && channelDetail.CouponType === "YY" && channelDetail.GrpCouponValidType === 1) {
        isShowTime = true;
        isAble = true;
      }
    } else {
      if (channelDetail.CouponOrigin === 0 && channelDetail.CouponType !== "YY") {
        isShowTime = true;
      }
      if (channelDetail.CouponOrigin === 0 && channelDetail.CouponType === "YY" && channelDetail.GrpCouponValidType === 0) {
        isShowTime = false;
      }
      if (channelDetail.CouponOrigin === 0 && channelDetail.CouponType === "YY" && channelDetail.GrpCouponValidType === 1) {
        isShowTime = true;
      }
      if (channelDetail.CouponOrigin === 1 && channelDetail.UnionCouponType === 0 && channelDetail.CouponType !== "YY") {
        isShowTime = true;
      }
      if (channelDetail.CouponOrigin === 1 && channelDetail.UnionCouponType === 1 && channelDetail.CouponType === "YY" && channelDetail.GrpCouponValidType === 0) {
        isShowTime = false;
      }
      if (channelDetail.CouponOrigin === 1 && channelDetail.UnionCouponType === 1 && channelDetail.CouponType === "YY" && channelDetail.GrpCouponValidType === 1) {
        isShowTime = true;
      }
      isAble = false;
    }
    // console.log('isShowTime', channelDetail.CouponOrigin, channelDetail.CouponType, channelDetail.GrpCouponValidType, channelDetail.CouponValidType)
    // }
    const data = id === "0"
      ? {
        type: !isTimeEnable ? '1' : '2',
        data: !isTimeEnable
          ? [channelDetail.CouponDuration !== '' ? channelDetail.CouponDuration : '', ['', '']]
          : ["", [channelDetail.CouponValidStartTime || "", channelDetail.CouponValidEndTime || '']]
      }
      : {
        type: !isTimeEnable ? '1' : '2',
        data: !isTimeEnable
          ? [channelDetail.CouponDuration !== '' ? channelDetail.CouponDuration : '', ['', '']]
          : ["", [channelDetail.CouponValidStartTime || "", channelDetail.CouponValidEndTime || '']]
      };
    // console.log('data ====== ', data);
    return (
      <div>
        {(channelDetail.PresentType === 'CN' && isShowTime) && (
        <Field
          name="CusValidVay"
          type="text"
          label={(
            <span>
            使用有效期&nbsp;
            </span>
          )}
          disabled={id !== '0' ? true : !isAble}
          component={ConstFormValidDate}
          value={data}
          startTxt="自领取日起"
          endTxt="天有效"
          min={0}
          required
          validations={{
            required(values, res) {
              return !!res.type;
            },
            valueOne(values, res) {
              if (res.type && res.type === '1' && !(`${res.data[0]}`)) {
                return false;
              }
              return true;
            },
            valueTwo(values, res) {
              if (res.type && res.type === '2' && (!res.data[1][0] || !res.data[1][1])) {
                return false;
              }
              return true;
            }
          }}
          // onChange={this.changeTimeRadio}
          validationErrors={{ required: '使用有效期不能为空', valueOne: '自领取日不能为空', valueTwo: '请输入开始时间和结束时间' }}
        />
        )}
      </div>
    );
  }


  render() {
    const { handleSubmit, id } = this.props;
    const { channel } = this.props;
    const { channelDetail } = channel;
    // console.log('channelDetail', channelDetail);
    return (
      <div
        key={id}
      >
        <Form
          horizontal
          onSubmit={handleSubmit(this.submit)}
        >
          <Title titleDesc="渠道设置">
            {this.renderPatyOne()}
          </Title>
          <Title headerChildren={this.renderSwitchDiv()}>
            {channelDetail.IsSendReward && (
            <div>
              {this.renderIsNewRewardDiv()}
              {this.renderRewordTypeDiv()}
              {this.renderCouponDiv()}
              {this.renderCouponDetailDiv()}
              {this.renderCouponPackageDiv()}
              {this.renderGiftListDiv()}
              {this.renderCouponCountDiv()}
              {/* {this.renderEarnedDiv()} */}
              {this.renderCouponDesDiv()}
            </div>
            )}
          </Title>
          {this.renderBottomDiv()}
        </Form>
      </div>
    );
  }
}

const ChannelForm = createForm()(FieldForm);
export default ChannelForm;
