
import React, { Component } from 'react';
import {
  Button,
  Form,
  Notify,
  Radio,
  Drawer,
  Alert,
  Switch,
  Table,
  Pop,
  Icon
} from 'ezrd';

import { inject, observer } from 'mobx-react';
import { toJS } from 'mobx';
// import SettingView from './settingDrawer';
import { isEmptyTime } from '../../utils/common';
import { ConstFormUpload } from "../base/constFormImage";
import DefaultTipDialog from '../transaction/defaultTipDialog';

const defaultImg = require('../../assets/images/ceremony03.png');

const classNamePre = 'yiye-bottom-edit';
const {
  FormColorPickerField, createForm, Field, FormInputField, FormRadioGroupField
} = Form;

@inject('channel')
@inject('supplierStore')
@observer
class FieldForm extends Component {
  state = {
    value: {
      Id: '',
      Url: '',
      FilePath: '',
      loading: false,
      isShowDrawer: false,
      backgroundColor: ''
    },
    showErrZb: false,
    list: []
  }

  componentWillMount() {

  }

  async componentDidMount() {
    const { getRef } = this.props;
    getRef(this);
    await this.fetchRegisterFields();
    const { channel } = this.props;
    const { channelMobileList } = channel;
    // console.log('channelMobileList', channelMobileList);
    // console.log('channelMobileList ==== 222222 ==== ', channelMobileList);
    await this.setState({
      list: channelMobileList
    });
  }

  changeRegistRadio = (event) => {
    const { channel } = this.props;
    const { channelDetail } = channel;
    channelDetail.IsDefaultField = event.target.value;
  }

  colorOnChange = (color) => {
    // console.log('color ====== ', color);
    // this.setState({ backgroundColor: color });
    const { channel } = this.props;
    const { channelDetail } = channel;
    channelDetail.BackGrdColor = color;
  }

  textOnChange = (obj) => {
    // this.setState({ registerPageName: obj.target.value });
    const { channel } = this.props;
    const { channelDetail } = channel;
    channelDetail.RegisterPageName = obj.target.value;
  }

  imageChange = (imageObj) => {
    const { value } = this.state;
    // console.log('imageObj ====', imageObj);
    // this.setState({ Url: imageObj.src });
    this.setState({
      value: {
        ...value,
        Url: imageObj.src
      }
    });
  }

  /**
   * 公众号文字变化监听
   *
   * @memberof FieldForm
   */
  publicTextChange = (obj) => {
    const { channel } = this.props;
    const { channelDetail } = channel;
    channelDetail.Content = obj.target.value;
  }


  /**
   *isRequest 是否请求接口
   *
   * @memberof FieldForm
   */
  saveAccountSetting = (isRequest) => {
    // console.log('isRequest ==== ', isRequest);
    const { isShowDrawer } = this.state;
    this.setState({
      isShowDrawer: !isShowDrawer
    });
    const { channel } = this.props;
    const { channelMobileList } = channel;
    if (isRequest) {
      // const array = [];
      const array = channelMobileList.filter(res => res.isOpen);
      // console.log('array ==== ', array);
      channel.saveAccountSetting(array);
    } else {
      // console.log('channelMobileList ==== ', channelMobileList);
      this.fetchRegisterFields();
    }
  }

  fetchRegisterFields = async () => {
    const { channel } = this.props;
    await channel.fetchChannelRegisterSetting();
  }

  changeValue = (value) => {
    this.setState({ value });
  }

  handleChange = (data, rowData, key, checkedType) => {
    const tempRowData = data;
    const { list } = this.state;
    const { channel } = this.props;
    // console.log('rowData ==== ', rowData);
    // console.log('row ==== ', rowData.row);
    // console.log('key ==== ', key);
    // console.log('ascKey ==== ', ascKey);
    const { row } = rowData;
    if (key === 'isOpen') {
      tempRowData.isOpen = !tempRowData.isOpen;
      list[row] = tempRowData;
      this.setState({
        list
      });
      channel.saveMobileList(list);
    } else if (key === 'isMust') {
      // const newList = JSON.parse(JSON.stringify(list));
      tempRowData.CanEmpty = !checkedType;
      // list[row] = tempRowData;
      list.splice(row, 1, toJS(tempRowData));
      this.setState({
        list
      });
      channel.saveMobileList(list);
    } else if (key === 'Order') {
      // if (ascKey === 'ASC') {
      //   const tempData = list[row.row - 1];
      //   list[row.row - 1] = tempRowData;
      //   list[row.row] = tempData;
      //   this.setState({
      //     list
      //   });
      // } else {
      //   const tempData = list[row.row + 1];
      //   list[row.row + 1] = tempRowData;
      //   list[row.row] = tempData;
      //   this.setState({
      //     list
      //   });
      // }
    }
  }


  renderSeetingDiv = () => {
    const { list } = this.state;
    const columns = [{
      title: '字段名称',
      name: 'FieldName'
    },
    {
      title: '是否开启',
      bodyRender: (data, row) => (
        <div>
          <Switch
            disabled={data.FieldName === '手机号码' || data.FieldName === '验证码'}
            checked={data.isOpen}
            onChange={() => this.handleChange(data, row, 'isOpen')}
          />
        </div>
      )
    }, {
      title: '是否必填',
      bodyRender: (data, row) => (
        <div>
          <Switch
            disabled={data.FieldName === '手机号码' || data.FieldName === '验证码'}
            checked={!data.CanEmpty}
            onChange={checkedType => this.handleChange(data, row, 'isMust', checkedType)}
            checkedText="必填"
            uncheckedText="选填"
          />
        </div>
      )
    }];

    return (
      <div>
        <Alert type="warning">请配置会员线上注册时必须的字段，手机验证码为系统默认。</Alert>
        <Table
          columns={columns}
          pageInfo={null}
          datasets={list}
          rowKey="key"
        />
      </div>
    );
  }

  onSubmit = async (values) => {
    const {
      channelRef, channel, supplierStore, id
    } = this.props;
    const { channelDetail } = channel;
    const { props } = channelRef;
    const { ezrdForm } = props;
    let GiftDtl = [];
    const prevForm = ezrdForm;
    const step1Data = prevForm.getFormValues();
    const {
      BackGrdImage
    } = values;
    let imgUrl = '';
    const {
      giftCoupon, CusValidVay, Bonus, ActivityTime
    } = step1Data;
    this.setState({
      loading: true
    }, () => {
      if (prevForm.isValid()) {
        if (channelDetail.IsSendReward) {
          if (channelDetail.PresentType === "GB") {
            GiftDtl = (giftCoupon.giftbagsList || []).map((v) => {
              if (v.CouponValidTypeTem === 'TS') {
                const [first, second] = v.CouponTimes;
                return {
                  ...v,
                  CouponValidType: v.CouponValidTypeTem,
                  CouponBeginDate: first,
                  CouponEndDate: second
                };
              }
              return {
                ...v,
                CouponValidType: v.CouponValidTypeTem
              };
            });
          } else if (channelDetail.PresentType === "CN") {
            if (CusValidVay) {
              if (CusValidVay.type === "1") {
                channelDetail.CouponValidType = "CM";
                channelDetail.CouponDuration = CusValidVay.data[0] || "";
              } else {
                channelDetail.CouponValidType = "TS";
                channelDetail.CouponValidStartTime = CusValidVay.data[1][0] || "";
                channelDetail.CouponValidEndTime = CusValidVay.data[1][1] || "";
              }
            }
          }
        }
        // let isShowTime = true; // 是否展示有效期
        // // let isShowDescription = true; // 是都显示显示券说明
        // let isAble = false; // 有效期和描述是否能够修改
        // let couponValidType = ""
        if (id === "0") {
          if (channelDetail.CouponOrigin === 0 && channelDetail.CouponType === "YY" && (channelDetail.GrpCouponValidType === 0 || channelDetail.CouponValidType === 0)) {
            channelDetail.CouponValidType = "CM";
          }
          if (channelDetail.CouponOrigin === 1 && channelDetail.UnionCouponType === 0) { // 时间判断能不能为空
            if (!isEmptyTime(channelDetail.CouponValidStartTime, channelDetail.CouponValidEndTime)) {
              channelDetail.CouponValidType = "CM";
            } else {
              channelDetail.CouponValidType = "TS";
            }
          }
          if (channelDetail.CouponOrigin === 1 && channelDetail.UnionCouponType === 1) {
            channelDetail.CouponValidType = "CM";
          }
        }
        if (BackGrdImage) {
          if (BackGrdImage.data && BackGrdImage.data[0].file) {
            supplierStore.fetchSupplierUploadImg({ file: BackGrdImage.data[0].file })
              .then((status) => {
                if (!status.IsError && status.Data) {
                  const requestData = {
                    ...channelDetail,
                    BeginDate: ActivityTime[0],
                    EndDate: ActivityTime[1],
                    BackGrdImage: status.Data.pathfull,
                    GiftDtl,
                    Bonus,
                    ...CusValidVay
                  };
                  this.saveChannel(requestData);
                }
              });
          } else {
            imgUrl = BackGrdImage.src;
            const requestData = {
              ...channelDetail,
              BeginDate: ActivityTime[0],
              EndDate: ActivityTime[1],
              BackGrdImage: imgUrl,
              GiftDtl,
              Bonus,
              ...CusValidVay
            };
            this.saveChannel(requestData);
          }
        }
      } else {
        Notify.error('请前往上一步，完善信息');
        this.setState({
          loading: false
        });
      }
    });
  }

  // 上传图片接口
  uploadImg = async (params) => {
    const { supplierStore } = this.props;
    const status = await supplierStore.fetchSupplierUploadImg(params);
    if (!status.IsError && status.Data) {
      return status.Data.pathfull;
    }
    return null;
  }

  saveChannel = async (data) => {
    const { channel } = this.props;
    // 保存的时候多调用异步接口
    const { channelMobileList } = channel;
    const array = channelMobileList.filter(res => res.isOpen);
    if (data.IsDefaultField) { // 注册选项-只有手机号
      const status = await channel.saveAccountSetting(array, true);
      if (status && !status.IsError) {
        //
      } else {
        return;
      }
    } else { // // 注册选项-都有
      const status = await channel.saveAccountSetting(array, true);
      if (status && !status.IsError) {
        //
      } else {
        return;
      }
    }

    channel.fetchCreateNewChannel({ ...data, IsShowWxQrImg: true })
      .then(() => {
        Notify.success('保存成功');
        setTimeout(() => {
          this.setState({
            loading: false
          });
          window.location.href = "/#/Yiye/Channel/List";
        }, 1000);
      });
  }

  renderMobileListDiv = () => {
    const { channel } = this.props;
    const { channelMobileList, channelDetail } = channel;
    // const { list } = this.state;
    const images = [channelMobileList[0], channelMobileList[1]];
    // console.log('channelMobileList ---', channelMobileList);
    for (let i = 0; i < channelMobileList.length; i++) {
      // console.log('index ==== ', i);
      // console.log('index ==== ', channelMobileList[i]);

    //   for (let j = 0; j < list.length; j++) {
    //     const tempData = channelMobileList[i];
    //     const listItem = list[j];
    //     if (tempData.FieldName === listItem.FieldName) {
    //       console.log('name ==== ', tempData.FieldName);
    //       listItem.FieldName = tempData.FieldName;
    //       listItem.CanEmpty = tempData.CanEmpty;
    //       listItem.isOpen = true;
    //       list[j] = listItem;
    //     }
    //   }
    }
    // return (
    //   <div />
    // )
    return (
      <div>
        {channelDetail.IsDefaultField && images.map(v => (
          <div
            key={v && v.key}
            className="listDiv"
          >
            <img
              alt=""
              style={{ width: '20px', height: '20px' }}
              src={v && v.url}
            />
            <span
              key={v && v.key}
              className="register-input"
            >
              {`请输入${v && v.FieldName}`}
            </span>
          </div>
        ))}
        {!channelDetail.IsDefaultField && channelMobileList.map((v) => {
          // console.log('.........88888 ====', v.isOpen, v.name);
          if (v.isOpen) {
            return (
              <div
                key={v && v.key}
                className="listDiv"
              >
                <img
                  alt=""
                  style={{ width: '20px', height: '20px' }}
                  src={v && v.url}
                />
                <span
                  key={v && v.key}
                  className="register-input"
                >
                  {`请输入${v && v.FieldName}`}
                </span>
              </div>
            );
          }
          return null;
        })}
      </div>
    );
  }

  submit = async () => {
    const { ezrdForm } = this.props;
    if (ezrdForm.isValid()) {
      this.setState({
        loading: true
      }, async () => {
        this.setState({ loading: false });
      });
    }
  }

  // 是否显示ZB不足弹框
  confirmZb = (flag) => {
    const { history } = this.props;
    this.setState({
      showErrZb: false
    });
    if (flag) {
      history.push('/Yiye/Account/AccountInfo/AssetManageZDetail');
    }
  }

  render() {
    const {
      loading,
      isShowDrawer,
      value,
      showErrZb
    } = this.state;
    const { Url } = value;
    const {
      changeTab,
      handleSubmit,
      channel
    } = this.props;
    const { channelDetail, channelMobileList } = channel;
    const backgroundColor = channelDetail.BackGrdColor || '#fff';
    return (
      <div>
        <div
          className="whole-container"
        >
          <div
            className="left-container"
            style={{ background: backgroundColor }}
          >
            <div className="header-container">
              <p className="header-title">{channelDetail.RegisterPageName || ''}</p>
            </div>
            <div className="body-container">
              {channelDetail.BackGrdImage || Url ? (
                <div className="img-container">
                  <img
                    style={{ width: '100%' }}
                    src={channelDetail.BackGrdImage || Url || defaultImg}
                    alt=""
                  />
                </div>
              ) : <div style={{ height: '20px' }} />}
              <div className="field-container">
                {this.renderMobileListDiv()}
                <Button className="submit-button">注册</Button>
              </div>
            </div>
          </div>

          <div className="right-container">
            <Form
              horizontal
              onSubmit={handleSubmit(this.onSubmit)}
            >
              <FormRadioGroupField
                name="IsDefaultField"
                value={channelDetail.IsDefaultField}
                label={(
                  <span>
                  注册选项&nbsp;
                    <Pop
                      trigger="hover"
                      position="right-center"
                      content="仅以手机号为注册字段的，微信开卡注册时，如有其他必填字段，将以默认字段补全完成注册"
                      centerArrow
                    >
                      <Icon
                        style={{ color: '#999' }}
                        type="info"
                        ezrd
                      />
                    </Pop>
                  </span>
                )}
                onChange={this.changeRegistRadio}
                required
                width={80}
                validations={{
                  required(values, res) {
                    return res !== '';
                  }
                }}
                validationErrors={{
                  required: '请选择注册选项'
                }}
                isColumn
              >
                <Radio
                  value
                >
                  仅以手机号为注册字段
                </Radio>
                <Radio
                  value={false}
                >
                  <div className="ezrd-form__controls">
                    <p style={{ display: 'flex', alignItems: 'center' }}>
                      <span>注册字段统一于微信注册的字段一致</span>
                      <Button
                        isText
                        style={{ paddingLeft: '4px' }}
                        onClick={() => this.saveAccountSetting(false)}
                      >
                        立即设置&gt;
                      </Button>
                    </p>
                  </div>
                </Radio>
              </FormRadioGroupField>
              <FormInputField
                name="RegisterPageName"
                label="注册页面名称"
                width={300}
                maxLength={10}
                showCount
                onChange={this.textOnChange}
                value={channelDetail.RegisterPageName || ''}
                placeholder="请输入相关内容"
              />
              <FormColorPickerField
                label="页面背景色"
                name="BackGrdColor"
                value={channelDetail.BackGrdColor || ''}
                onChange={this.colorOnChange}
              />
              <Field
                name="BackGrdImage"
                type="text"
                label="宣传图片"
                component={ConstFormUpload}
                openBase64={false}
                tips="建议尺寸：宽度750像素，高度不限。"
                onChange={this.imageChange}
                value={
                  channelDetail.BackGrdImage
                    ? {
                      src: channelDetail.BackGrdImage
                    }
                    : {}
              }
              />
              {/* <FormCheckboxField
                name="IsShowWxQrImg"
                label="公众号设置:"
                value
              >
              显示公众号二维码
              </FormCheckboxField> */}
              <FormInputField
                name="Content"
                value={channelDetail.Content || ''}
                type="textarea"
                label="提示文案"
                width={300}
                maxLength={512}
                showCount
                onChange={this.publicTextChange}
                placeholder="感谢关注公众号，更多惊喜关注公众号可见。"
              />
            </Form>
          </div>
        </div>

        <div>
          <div className={`${classNamePre}-group-btn`}>
            <Button
              type="primary"
              onClick={() => { changeTab('1'); }}
              outline
            >
              上一步
            </Button>
            <Button
              type="primary"
              loading={loading}
              onClick={handleSubmit(this.onSubmit)}
            >
              保存
            </Button>
          </div>
        </div>
        {
          channelMobileList && (
            <Drawer
              title="注册字段设置"
              list={channelMobileList}
              visible={isShowDrawer}
              titleColor="#000"
              showFooter={false}
              topPadding="0px"
              handleClose={() => this.saveAccountSetting(false)}
              headerStyle={{
                background: '#fff',
                height: '56px',
                // lineHeight: '56px',
                textAlign: 'left',
                padding: '0 20px'
              }}
              footer={(
                <React.Fragment>
                  <Button
                    onClick={() => this.saveAccountSetting(true)}
                  >
                    保存
                  </Button>
                  <Button
                    onClick={() => this.saveAccountSetting(false)}
                  >
                    取消
                  </Button>
                </React.Fragment>
              )}
            >
              {this.renderSeetingDiv()}
            </Drawer>
          )
        }
        {/** 创建活动失败，ZB不足 去充值 */}
        <DefaultTipDialog
          showEnableVisible={showErrZb}
          title="创建活动失败"
          content="Z币余额不足，请充值Z币后再创建活动"
          confirmText="去充值"
          confirmEnable={this.confirmZb}
        />
      </div>
    );
  }
}


const DecorationWeb = createForm()(FieldForm);
export default DecorationWeb;
