import {
  Table, Switch, Alert
} from 'ezrd';
import React, { Component } from 'react';
import { inject, observer } from 'mobx-react';

@inject('channel')
@observer
export default class SetttingDrawer extends Component {
  state = {
    list: []
  }

  componentDidMount() {
    this.fetchRegisterFields();
    const { channel } = this.props;
    const { channelMobileList } = channel;
    // console.log('channelMobileList ==== 222222 ==== ', channelMobileList);
    this.setState({
      list: channelMobileList
    });
  }

  handleChange = (data, rowData, key, ascKey) => {
    const tempRowData = data;
    const { list } = this.state;
    const { channel } = this.props;
    // console.log('rowData ==== ', rowData);
    // console.log('row ==== ', rowData.row);
    // console.log('key ==== ', key);
    // console.log('ascKey ==== ', ascKey);
    const { row } = rowData;
    if (key === 'isOpen') {
      tempRowData.isOpen = !tempRowData.isOpen;
      list[row] = tempRowData;
      this.setState({
        list
      });
      channel.saveMobileList(list);
    } else if (key === 'isMust') {
      tempRowData.CanEmpty = !tempRowData.CanEmpty;
      list[row] = tempRowData;
      this.setState({
        list
      });
    } else if (key === 'Order') {
      if (ascKey === 'ASC') {
        const tempData = list[row.row - 1];
        list[row.row - 1] = tempRowData;
        list[row.row] = tempData;
        this.setState({
          list
        });
      } else {
        const tempData = list[row.row + 1];
        list[row.row + 1] = tempRowData;
        list[row.row] = tempData;
        this.setState({
          list
        });
      }
    }
  }


  fetchRegisterFields = async () => {
    const { channel } = this.props;
    // const { channelMobileList } = channel;
    channel.fetchChannelRegisterSetting();
    // const { list } = this.state;
    // this.setState({
    //   list
    // }, () => { console.log("list ===== ", list); });
    // channelMobileList.map((res, index) => {
    //   console.log('index ======', index);
    //   const result = res;
    //   console.log('result ======', res.FieldName);
    //   list.map((item, itemIndex) => {
    //     console.log('itemIndex ======', itemIndex);
    //     console.log('item ======', item);
    //     if (res.FieldName === item.FieldName) {
    //       const tempItem = item;
    //       tempItem.isOpen = true;
    //       tempItem.MchId = res.MchId;
    //       tempItem.CanEmpty = false;
    //       list[itemIndex] = tempItem;
    //     } else {
    //       const tempItem = item;
    //       tempItem.isOpen = false;
    //       tempItem.CanEmpty = true;
    //       tempItem.MchId = res.MchId;
    //       list[itemIndex] = tempItem;
    //     }
    //     return true;
    //   });
    //   this.setState({
    //     list
    //   }, () => { console.log(list); });
    //   return true;
    // });
  }

  render() {
    const { list } = this.state;
    const columns = [{
      title: '字段名称',
      name: 'FieldName'
    },
    // {
    //   title: '排序',
    //   bodyRender: (data, row) => (
    //     <div>
    //       {row.row !== 0 && (
    //         <Button
    //           isText
    //           outline
    //           style={{
    //             fontSize: 14
    //           }}
    //           onClick={() => this.handleChange(data, row, 'Order', 'ASC')}
    //         >
    //         上移
    //         </Button>
    //       )}
    //       {row.row !== 4 && (
    //         <Button
    //           isText
    //           outline
    //           style={{
    //             fontSize: 14
    //           }}
    //           onClick={() => this.handleChange(data, row, 'Order', 'DESC')}
    //         >
    //         下移
    //         </Button>
    //       )}
    //     </div>
    //   )
    // },
    {
      title: '是否开启',
      bodyRender: (data, row) => (
        <div>
          <Switch
            disabled={data.FieldName === '手机号码' || data.FieldName === '验证码'}
            checked={data.isOpen}
            onChange={() => this.handleChange(data, row, 'isOpen')}
          />
        </div>
      )
    }, {
      title: '是否必填',
      bodyRender: (data, row) => (
        <div>
          <Switch
            disabled={data.FieldName === '手机号码' || data.FieldName === '验证码'}
            checked={!data.CanEmpty}
            onChange={() => this.handleChange(data, row, 'isMust')}
            checkedText="必填"
            uncheckedText="选填"
          />
        </div>
      )
    }];

    return (
      <div>
        <Alert type="warning">请配置会员线上注册时必须的字段，手机验证码为系统默认。</Alert>
        <Table
          columns={columns}
          pageInfo={null}
          datasets={list}
          rowKey="key"
        />
      </div>
    );
  }
}
