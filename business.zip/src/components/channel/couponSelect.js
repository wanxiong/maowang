/*
 * @Description:
 * @Author: zjq
 * @Date: 2019-12-27 14:15:18
 * @LastEditors  : zjq
 * @LastEditTime : 2020-01-02 14:15:34
 */
import {
  Button
} from 'ezrd';
import { YiyeCouponSelector } from 'ezrpc';
import React from 'react';
// import { inject, observer } from 'mobx-react';

// @inject('channel')
// @observer
export default class CouponSelect extends React.Component {
  state = {
    data: {}
  }

  onSelect = (data) => {
    const { onChange } = this.props;
    // console.log('data =====', data);
    // const { onChange, channel } = this.props;
    // const { channelDetail } = channel;
    // console.log('data ===', data.infoList[0].TplName);
    // channelDetail.CouponGrpName = data.infoList.TplName || '';
    if (data.idList.length) {
      onChange(data);
      this.setState({
        data
      });
    }
  };

  render() {
    const { data } = this.state;
    const { id, value, couponId } = this.props;
    return (
      <div>
        <div>
          {id === "0" ? (
            <YiyeCouponSelector
              // style={{ 'margin-left': '10px' }}
              onSelect={this.onSelect}
              disabled={id !== "0" || id !== 0}
              CouponTypeList={[
                {
                  Id: 'DJ',
                  Name: '代金券'
                },
                {
                  Id: 'ZK',
                  Name: '折扣券'
                },
                {
                  Id: 'LP',
                  Name: '礼品券'
                },
                {
                  Id: 'YQ',
                  Name: '邀请券'
                },
                {
                  Id: 'CX',
                  Name: '促销券'
                },
                {
                  Id: 'YY',
                  Name: '异业券'
                }
              ]}
            >
              <Button
                type="deauflt"
              >
                {(data.infoList && data.infoList.length && data.infoList[0] && data.infoList[0].CouponName) || value || '请选择'}
              </Button>
            </YiyeCouponSelector>
          ) : (
            <Button
              type="deauflt"
              disabled
            >
              {(data.infoList && data.infoList.length && data.infoList[0] && data.infoList[0].CouponName) || value || '请选择'}
            </Button>
          )}
        </div>

        {((data.infoList && data.infoList.length && data.infoList[0] && data.infoList[0].Id) || couponId) && (
          <div>
            <p>
              {`券ID: ${(data.infoList[0].Id) || couponId}`}
            </p>
          </div>
        )}
      </div>
    );
  }
}
