import * as React from 'react';
import {
  Select
} from 'ezrd';
import { inject } from 'mobx-react';
@inject('CommonApi')
export default class ProductBrandSelect extends React.Component {
static defaultProps = {
  showTime: true,
  width: 190,
  optionText: 'BrandName',
  optionValue: 'Id',
  classNamePre: '',
  textLable: '品牌：',
  textLableStyle: '',
  disabled: false,
  value: '',
  onChange: () => {},
  filtersId: 1
}

constructor(props) {
  super(props);
  this.state = {
    selected: props.value || '',
    data: []
  };
}

async componentDidMount() {
  const { CommonApi } = this.props;

  const { Data } = await CommonApi.fetchProductBrandList();
  this.setState({
    data: Data.PagedList
  });
}

onChange = (e, selected) => {
  const { onChange } = this.props;
  if (!selected.Id) { // 用户删除
    this.setState({
      selected: ''
    });
  } else {
    this.setState({
      selected: selected.Id
    });
  }
  onChange(selected.Id || '');
};

// 选中为空的回调
onEmptySelected = () => {
  // console.log(data)
}

//
filter = (item, keyword) => {
  const { optionText } = this.props;
  const keyUp = keyword.toUpperCase();
  const itemUp = item[optionText].toUpperCase();
  return itemUp.indexOf(keyUp) > -1;
}

render() {
  const { selected, data } = this.state;
  const {
    showTime, width, optionText, optionValue, classNamePre, textLable, textLableStyle, disabled
  } = this.props;
  return (
    <div>
      <div>
        <span className={textLableStyle}>{textLable}</span>
        <Select
          data={data}
          value={selected}
          optionText={optionText}
          optionValue={optionValue}
          width={width}
          showTime={showTime}
          className={classNamePre}
          disabled={disabled}
          filter={this.filter}
          autoWidth
          onEmptySelected={this.onEmptySelected}
          onChange={this.onChange}
          // filter={(item, keyword) => item[optionText].indexOf(keyword) > -1}
        />
      </div>
    </div>
  );
}
}
