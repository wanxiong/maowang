import * as React from 'react';
import {
  Input, Select, Button, DateRangePicker, Dialog, Notify
} from 'ezrd';
import { inject } from 'mobx-react';
import moment from 'moment';
import { withRouter } from 'react-router-dom';
import { orderCuoponType } from './constant';
import { trim } from '../../utils/common';

const classNamePre = 'yiye-order-coupon-search';

@inject('purchaseStore')
@inject('provideStore')
@withRouter
export default class OrderCouponSearch extends React.Component {
  static defaultProps = {
    brandShow: true, // 是否显示品牌ID的输入框
    exportText: '',
    type: 'purchaseStore',
    oneText: '采购单号：',
    history: {},
    hideExport: false,
    selectData: orderCuoponType
  }

  constructor(prop) {
    super(prop);
    const { typeName } = this.props;
    this.state = {
      currentSelect: 'all', // 默认选择全部
      couponId: '', // 券ID
      couponName: '', // 券名字
      brand: '', // 品牌
      loading: false,
      rangeValue: [], // 时间区段
      taskName: moment().format('YYYY-MM-DD') + typeName
    };
  }

  componentDidMount() {
    const { getRef } = this.props;
    getRef(this);
  }

  // 券类型选择
  onChangeSelect = (e) => {
    this.setState({ currentSelect: e.target.value });
  }

  // 普通input框的事件回调
  onChangeInput = (type, e) => {
    this.setState({
      [type]: e.target.value
    });
  }

  // 点击查询按钮
  onSearch = (flag) => {
    const {
      brand, currentSelect, couponName, couponId, rangeValue
    } = this.state;
    const { onSearch, brandShow } = this.props;
    const params = {
      brand,
      currentSelect: currentSelect === 'all' ? '' : currentSelect,
      couponName,
      couponId,
      time: rangeValue
    };
    if (!brandShow) {
      delete params.brand;
    }
    onSearch(params, flag);
  }

  // 清空
  onClean = () => {
    this.setState({
      currentSelect: 'all', // 默认选择全部
      couponId: '', // 券ID
      couponName: '', // 券名字
      brand: '', // 品牌
      visible: false,
      rangeValue: [] // 时间区段
    });
  }

  // 时间选择的回调
  onChangeRange = (v) => {
    this.setState({ rangeValue: v });
  }

  // 导出事件
  onExport = () => {
    const { typeName } = this.props;
    this.setState({
      visible: true,
      taskName: moment().format('YYYY-MM-DD') + typeName
    });
  }

  // 关闭弹出框
  closeDialog = () => {
    const { typeName } = this.props;
    this.setState({
      visible: false,
      taskName: moment().format('YYYY-MM-DD') + typeName
    });
  }

  confirm = async () => {
    const UnionCouponType = 1;
    const {
      taskName, rangeValue, couponName, brand, currentSelect, couponId
    } = this.state;
    const {
      history, provideStore, type, purchaseStore
    } = this.props;
    if (!trim(taskName)) {
      Notify.error('请输入导出数据的文件名称');
      return;
    }
    this.setState({ loading: true });
    if (type === 'purchaseStore') {
      const status = await purchaseStore.fetchPurchaseOrderDownLoad({
        TaskName: taskName,
        Querys: {
          PurchaseNo: couponId,
          ProBrandName: brand,
          CouponName: couponName,
          Status: currentSelect === 'all' ? '' : currentSelect,
          StartTime: rangeValue[0] || '',
          EndTime: rangeValue[1] || '',
          UnionCouponType
        }
      });
      this.setState({ loading: false });
      if (!status.IsError) {
        this.closeDialog();
        history.push('/Yiye/Download');
      }
    } else {
      const status = await provideStore.fetchProvideOrderDownLoad({
        TaskName: taskName,
        Querys: {
          PurchaseNo: couponId,
          ProBrandName: brand,
          CouponName: couponName,
          Status: currentSelect === 'all' ? '' : currentSelect,
          StartTime: rangeValue[0] || '',
          EndTime: rangeValue[1] || '',
          UnionCouponType
        }
      });
      this.setState({ loading: false });
      if (!status.IsError) {
        this.closeDialog();
        history.push('/Yiye/Download');
      }
    }
  }

  render() {
    const {
      brand, currentSelect, couponName, couponId, rangeValue, visible, taskName, loading
    } = this.state;
    const {
      brandShow, oneText, selectData, hideExport
    } = this.props;
    return (
      <div className={`${classNamePre}`}>
        <Dialog
          title="导出数据的文件名称"
          visible={visible}
          onClose={() => this.closeDialog()}
          style={{ width: '600px' }}
          maskClosable={false}
          footer={(
            <div>
              <Button
                outline
                loading={loading}
                onClick={() => this.closeDialog()}
              >
                取消
              </Button>
              <Button
                loading={loading}
                onClick={() => this.confirm()}
              >
                确定
              </Button>
            </div>
          )}
        >
          <Input
            signleBorder
            placeholder="请输入导出数据的文件名称"
            showClear
            maxLength={30}
            width="100%"
            value={taskName}
            onChange={event => this.onChangeInput('taskName', event)}
          />
        </Dialog>
        {/* 采购时间-- 查询--导出 */}
        <div className={`${classNamePre}-search-btn`}>
          <div>
            <span>采购时间：</span>
            <DateRangePicker
              className=""
              width={180}
              format="YYYY-MM-DD"
              value={rangeValue}
              onChange={this.onChangeRange}
            />
          </div>
        </div>
        {/* 基本输入input框 */}
        <div className={`${classNamePre}-top`}>
          <div>
            <div>
              <span>{oneText}</span>
              <Input
                type="text"
                size="small"
                width={180}
                value={couponId}
                onChange={event => this.onChangeInput('couponId', event)}
              />
            </div>
            <div>
              <span>券名称：</span>
              <Input
                type="text"
                size="small"
                width={180}
                value={couponName}
                onChange={event => this.onChangeInput('couponName', event)}
              />
            </div>
            {brandShow
              ? (
                <div>
                  <span>品牌：</span>
                  <Input
                    type="text"
                    size="small"
                    width={180}
                    value={brand}
                    onChange={event => this.onChangeInput('brand', event)}
                  />
                </div>
              )
              : null
            }
            <div>
              <span>状态：</span>
              <Select
                data={selectData}
                optionValue="type"
                optionText="name"
                width="180px"
                autoWidth
                showClear={false}
                value={currentSelect}
                onChange={this.onChangeSelect}
              />
            </div>
          </div>
        </div>
        <div className={`${classNamePre}-export`}>
          <Button
            type="primary"
            onClick={this.onSearch}
          >
            查询
          </Button>
          {
            hideExport
              ? null
              : (
                <Button
                  type="primary"
                  outline
                  onClick={this.onExport}
                >
                  导出
                </Button>
              )
          }
        </div>

      </div>
    );
  }
}
