import * as React from 'react';
import {
  Button, Dialog, Radio
} from 'ezrd';
import '../../styles/base/index.less';


const RadioGroup = Radio.Group;

const classNamePre = 'yiye-pruchase-platform-dialog';
/* eslint-disable */
export class PurchasePlatformCouponDialog extends React.Component {
static defaultProps = {

}

constructor(prop) {
  super(prop);
  this.state = {
    value: '0'
  };
}

onClose = () => {
  const { onClose } = this.props;
  onClose();
  this.setState({ value: '0' });
}

onConfirm = () => {
  const { onConfirm } = this.props;
  const { value } = this.state;
  onConfirm(value);
  this.setState({
    value: '0'
  });
}

onChange = (e) => {
  this.setState({ value: e.target.value });
}

render() {
  const { show } = this.props;
  const { value } = this.state;
  return (
    <div>
      <Dialog
        visible={show}
        title="请选择您要导入的类型"
        onClose={this.onClose}
        className={`${classNamePre}`}
      >
        <div className={`${classNamePre}-con`}>
          <div className={`${classNamePre}-con-title`}>确认后不可修改类型，请谨慎操作</div>
          <div className={`${classNamePre}-con-pro`}>
            <span>选择导入类型</span>
            <RadioGroup
              onChange={
                this.onChange
              }
              value={
                value
              }
            >
              <Radio value="0">按商品</Radio>
              <Radio value="1">按SKU</Radio>
            </RadioGroup>
          </div>
          <div className={`${classNamePre}-con-btn`}>
            <Button
              type="primary"
              outline
              size="large"
              onClick={this.onClose}
            >
            取消
            </Button>
            <Button
              type="primary"
              size="large"
              onClick={this.onConfirm}
            >
            确定
            </Button>
          </div>
        </div>
      </Dialog>
    </div>
  );
}
}
/* eslint-disable */