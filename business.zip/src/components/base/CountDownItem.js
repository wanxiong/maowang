import * as React from 'react';
import { Pop, Icon } from 'ezrd';

export default class CountDownItem extends React.Component {
  constructor(props) {
    super(props);
    /* eslint-disable */
    this.state = {
      id: '',
      txt: '',
      stamp: props.endTime - props.nowDate,
      isShow: false
    };
    /* eslint-enable */
    this.parseDisplayTime = this.parseDisplayTime.bind(this);
  }

  componentDidMount() {
    const { stamp } = this.state;
    if (stamp <= 0) {
      return;
    }
    const num = setInterval(() => {
      this.parseDisplayTime();
    }, 1000);
    /* eslint-disable */
    this.setState({
      id: num,
      isShow: true
    });
    /* eslint-enable */
  }

  //
  componentWillUnmount() {
    clearInterval(this.id);
  }

  timeContent = (millisecond) => {
    const second = millisecond / 1000;
    const d = Math.floor(second / 86400);
    let h = Math.floor((second % 86400) / 3600);
    let m = Math.floor(((second % 86400) % 3600) / 60);
    let s = Math.floor(((second % 86400) % 3600) % 60);
    h = h < 10 ? `0${h}` : h;
    m = m < 10 ? `0${m}` : m;
    s = s < 10 ? `0${s}` : s;
    let countDownDOM;
    if (d > 0) {
      countDownDOM = `${d} 天 ${h} 时 ${m} 分 ${s} 秒`;
    } else {
      countDownDOM = `${h} 时 ${m} 分 ${s} 秒`;
    }
    this.setState({ txt: countDownDOM });
  }

  parseDisplayTime() {
    let { stamp } = this.state;
    if (stamp > 1000) {
      stamp -= 1000;
      this.setState({ stamp });
      this.timeContent(stamp);
    } else {
      clearInterval(this.id);
      this.setState({ isShow: false });
    }
  }

  render() {
    const { txt, isShow } = this.state;
    const { classNamePre, FreezeCosts, json } = this.props;
    return (
      <div>
        {
          isShow
            ? (
              <React.Fragment>
                剩余冻结Z币：
                <span className={`${classNamePre}-pro-item-title-money`}>
                  {FreezeCosts.toFixed(2)}
                  ，
                </span>
                <span className={`${classNamePre}-pro-item-title-countdown`}>
                  解冻倒计时：
                  <span>
                    {
                      txt
                    }
                  </span>
                </span>
                <Pop
                  trigger="hover"
                  position="left-center"
                  content={(
                    <div>
                      <div>
                        券奖励方式 =
                        {json.RewardWray === 0 ? '按券核销张数' : '按订单提成'}
                      </div>
                      <div>
                        冻结Z币：
                        {json.FreezeCostsDes}
                      </div>
                      <div>
                        冻结时间：
                        {json.FreezeDateDes}
                      </div>
                    </div>
                  )}
                >
                  <Icon
                    type="info-circle-o"
                    className={`${classNamePre}-pro-popicon`}
                  />
                </Pop>
              </React.Fragment>
            )
            : null
        }
      </div>
    );
  }
}
