import * as React from 'react';
// import { Upload } from 'antd';
import { Button, EzrUpload } from 'ezrd';

import 'ezrpc/css/image-selector-new.css';
import 'ezrpc/css/image-selector.css';

// import PropTypes from 'prop-types';
import { uploadUrl, uploadSkuUrl } from '../../services/importCenter';


export default class ConstFormUploadFile extends React.Component {
  // static propTypes = {
  //   onSuccess: PropTypes.func,
  //   onError: PropTypes.func,
  //   title: PropTypes.string,
  //   id: PropTypes.number,
  //   couponProIsExclude: PropTypes.bool,
  //   ProType: PropTypes.number
  // };

  static defaultProps = {
    onSuccess: () => { },
    onError: () => {},
    title: "选择文件导入",
    id: null,
    couponProIsExclude: true,
    ProType: 0
  };

  constructor(props) {
    super(props);
    this.state = {
      fileList: []
    };
  }

  // 上传状态
  handelChange = (info) => {
    const { onSuccess } = this.props;
    // let fileList = [info.file];
    // fileList = fileList.map((file) => {
    //   if (file.response) {
    //     file.url = file.response.url;
    //   }
    //   return file;
    // });
    // this.setState({ fileList });
    onSuccess(info);
  }

  render() {
    const {
      title, id, couponProIsExclude, ProType
    } = this.props;
    const { fileList } = this.state;
    const props = {
      name: 'file',
      action: ProType === 0 ? `${uploadUrl}?id=${id}&couponProIsExclude=${couponProIsExclude}` : `${uploadSkuUrl}?id=${id}&couponProIsExclude=${couponProIsExclude}`,
      headers: {
        authorization: 'authorization-text'
      },
      onSuccess: this.handelChange,
      onError: this.onError,
      fileList
    };
    return (
      <EzrUpload
        {...props}
        uploadText={
          <Button>{title}</Button>
      }
      />
    );
  }
}
