import React from 'react';
import { Form } from 'ezrd';
// 引入编辑器组件
import BraftEditor from 'braft-editor';
// 引入编辑器样式
import 'braft-editor/dist/index.css';

const { getControlGroup } = Form;

const classNamePre = 'yiye-const-edit';

class EditorTpl extends React.Component {
  static defaultProps = {
    disabled: false,
    readOnly: false,
    style: null,
    excludeControls: ['media', 'emoji'],
    value: {
      text: '',
      init: false
    }
  }

  constructor(prop) {
    super(prop);
    this.state = {
    // 创建一个空的editorState作为初始值
      value: ''
    };
  }

  async componentDidMount() {
  // 假设此处从服务端获取html格式的编辑器内容

  }

  componentWillReceiveProps(props) {
    const { onChange } = this.props;
    if (props.value.init) {
      this.setState({ value: BraftEditor.createEditorState(props.value.text) }, () => {
        onChange({
          text: props.value.text,
          init: false
        });
      });
    }
  }

submitContent = async () => {
  // 在编辑器获得焦点时按下ctrl+s会执行此方法
  // 编辑器内容提交到服务端之前，可直接调用editorState.toHTML()来获取HTML格式的内容
  // const htmlContent = this.state.editorState.toHTML();
  // const result = await saveEditorContent(htmlContent);
}

handleEditorChange = (editorStateVal) => {
  const { onChange } = this.props;
  this.setState({ value: editorStateVal }, () => {
    onChange({
      text: editorStateVal.toHTML(),
      init: false,
      isEmpty: editorStateVal.isEmpty()
    });
  });
}

render() {
  // const { editorState } = this.state;
  const { value } = this.state;
  const {
    readOnly, disabled, style, excludeControls
  } = this.props;
  return (
    <div
      className={`${classNamePre}`}
      style={style}
    >
      <BraftEditor
        value={value}
        readOnly={readOnly}
        onChange={this.handleEditorChange}
        onSave={this.submitContent}
        excludeControls={excludeControls}
      />
      {
        disabled
          ? (
            <div className={`${classNamePre}-modal`} />
          )
          : null
      }
    </div>
  );
}
}
/* eslint-disable */
export const Editor = getControlGroup(EditorTpl);
/* eslint-disable */