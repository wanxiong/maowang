import * as React from 'react';
import {
  EzrUpload, Button
} from 'ezrd';

// 引入样式
class ConstUploadFile extends React.Component {
  static defaultProps = {
    onSuccess: () => {},
    onError: () => {},
    onProgress: () => {},
    beforeUpload: () => {},
    component: 'div',
    url: '',
    text: '上传按钮',
    multiple: false,
    accept: '.ico,.ppt,.pptx,.xlsx,image/*'
  }

  constructor(prop) {
    super(prop);
    this.state = {
    };
  }

  render() {
    const {
      onSuccess, url, onError, onProgress, component, text, beforeUpload, multiple, accept
    } = this.props;
    return (
      <div>
        <EzrUpload
          action={url}
          onSuccess={onSuccess}
          onError={onError}
          onProgress={onProgress}
          accept={accept}
          component={component}
          multiple={multiple}
          uploadText={(
            <Button
              type="primary"
              size="middle"
            >
              {text}
            </Button>
)}
          beforeUpload={beforeUpload}
        />
      </div>
    );
  }
}

export default ConstUploadFile;
