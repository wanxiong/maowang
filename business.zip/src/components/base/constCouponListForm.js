import * as React from 'react';
import {
  Form, Select
} from 'ezrd';
import { YiyeCouponSelector } from 'ezrpc';
import { yiyeCouponTypeList, yiyeCouponTypeListYY } from './constant';

import 'ezrpc/css/public-coupons.css';
// 引入样式
const classNamePre = 'yiye-const-coupon-list-form';

const { getControlGroup } = Form;

class ConstCouponListFormTpl extends React.Component {
  static defaultProps = {
    disabled: false,
    tabsType: ['defaultTab', 'yiyeTab'],
    defaultCouponTypeForYY: 'YY',
    closeClearForYY: true,
    customCallBack: () => {} // 自定义回调
  }

  constructor(prop) {
    super(prop);
    this.state = {
    };
  }

  // 优惠券模板的回调
  onConfirm = (data) => {
    const { onChange, customCallBack } = this.props;
    this.setState({ flag: false });
    onChange({
      couponTpl: data.TplName,
      TplId: data.Id,
      CouponType: data.CouponType,
      CouponValue: data.CouponValue,
      CouponPriceLimit: data.CouponPriceLimit
    });
    customCallBack(data.CouponType);
  }

  // 优惠券的弹框
  select = (data) => {
    const { customCallBack } = this.props;
    const info = data.infoList[0];
    customCallBack(info);
  }


  render() {
    const {
      value, disabled, tabsType, defaultCouponTypeForYY, closeClearForYY
    } = this.props;
    const { flag } = this.state;
    return (
      <div className={classNamePre}>
        <Select
          width={320}
          disabled={disabled}
          className={`${classNamePre}-list-omg-txt`}
          // value={value ? value.CouponName : ''}
          // placeholder="选择优惠券"
          placeholder={value ? value.CouponName : '选择优惠券'}
        />
        {
          !disabled && (
            <YiyeCouponSelector
              show={flag}
              isSingleSelection
              tabsType={tabsType}
              // value={value ? [id: 1]value.TplName : ''}
              yiyeValue={[]}
              onSelect={this.select}
              defaultCouponType=""
              defaultCouponTypeForYY={defaultCouponTypeForYY}
              CouponTypeListForYY={yiyeCouponTypeListYY}
              closeClearForYY={closeClearForYY}
              CouponTypeList={yiyeCouponTypeList}
            >
              <div
                className={`${classNamePre}-pop`}
              />
            </YiyeCouponSelector>
          )
        }
        {
          value && value.Id && (
            <div style={{ 'margin-top': '10px' }}>
              券ID：
              {value.Id}
            </div>
          )
        }
      </div>
    );
  }
}

const ConstCouponListForm = getControlGroup(ConstCouponListFormTpl);

export default ConstCouponListForm;
