import * as React from 'react';
import {
  Input, Select, Button, Dialog, Icon, Table, Radio, Notify
} from 'ezrd';
import { CuoponTpl, couponDefaultPage } from './constant';
import CommonApi from '../../model/common';
import '../../styles/base/index.less';

const classNamePre = 'yiye-coupon-list';

const RadioGroup = Radio.Group;
const columns = [
  {
    title: '',
    width: '50px',
    bodyRender: (data, dataRow) => (
      <Radio
        name="coupon-list"
        value={dataRow.row}
      />
    )
  },
  // {
  //   title: '券ID',
  //   bodyRender: data => {
  //     return <div>{data.Id}</div>;
  //   },
  // },
  {
    title: '券类型',
    name: 'CouponTypeName',
    width: '80px'
  },
  {
    title: '券模板',
    name: 'TplName'
  }
  // {
  //   title: '是否可转赠',
  //   bodyRender: data => {
  //     return <div>{data.IsCanGiveFriend ? '是' : '否'}</div>;
  //   },
  // },
  // {
  //   title: '创建人',
  //   name: 'CreateUser',
  // },
];


export default class CouponList extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      visible: false,
      currentCouponType: '', // 默认选择全部
      TplName: '', // 券模板/券名称
      radioValue: '', // 选中单选框
      data: [], // 展示的数据源
      ...couponDefaultPage
    };
    this.initData = this.initData.bind(this);
  }

  async componentDidMount() {
    this.initData();
  }

  async componentWillReceiveProps(nextProps) {
    const { visible } = this.state;
    if (nextProps.show !== visible) {
      this.setState({ visible: nextProps.show });
      this.initData();
    }
  }

  // 券类型选择
  onChangeSelect = (e) => {
    this.setState({
      currentCouponType: e.target.value
    });
  }

  /*
  * @param data {Object} 每一行的数据
  * @param index {number} 每一行在列表中的index
  * @return {
  *  canSelect {bool} 是否可选，默认为true
  *  rowClass {string} 这一行的特殊class，默认是空字符串
  * }
  */
  static getRowConf(data, index) { // 每一行的数据和这一行在列表中的index
    return {
      canSelect: index % 2 === 0,
      rowClass: index % 2 === 1 ? 'yiye-coupon-list-con-style' : ''
    };
  }

  // 单选框的回调事件
  onChangeRadio = (e) => {
    const v = e.target.value;
    // v 是下标
    this.setState({ radioValue: v });
  }

  // 基本输入框的回调事件
  onChangeInput = (e, type) => {
    this.setState({
      [type]: e.target.value
    });
  }

  // 分页的回调
  onChange = (data) => {
    const { current, pageSize } = this.state;
    this.setState({
      current: data.current || current,
      pageSize: data.pageSize || pageSize
    }, () => {
      this.initData();
    });
  }

  onClose = () => {
    const { onClose } = this.props;
    this.setState({
      visible: false
    }, () => {
      this.clearVal();
      /* eslint-disable */
      onClose && onClose();
      /* eslint-enable */
    });
  }

  onConfirm = () => {
    const { onConfirm, errorMsg } = this.props;
    const { data, radioValue } = this.state;
    if (radioValue === '') {
      Notify.error(errorMsg || '请选择优惠券');
      return;
    }
    this.setState({
      visible: false
    }, () => {
      this.clearVal();
      /* eslint-disable */
      onConfirm && onConfirm(data[radioValue]);
      /* eslint-enable */
    });
  }

  async initData() {
    const {
      pageSize, current, TplName, currentCouponType
    } = this.state;
    const { Data } = await CommonApi.fetchBaseCouponList({
      PageIndex: current,
      PageSize: pageSize,
      CouponType: currentCouponType,
      TplName
    });
    this.setState({ data: Data.PagedList, totalItem: Data.TotalRowsCount });
  }

  // 清空数据
  clearVal() {
    this.setState({
      currentCouponType: '',
      TplName: '',
      radioValue: '',
      data: [],
      ...couponDefaultPage
    });
  }

  render() {
    const {
      currentCouponType, TplName, radioValue, data, visible, totalItem, current, pageSizeList
    } = this.state;
    return (
      <div>
        <Dialog
          visible={visible}
          title="选择优惠券"
          onClose={this.onClose}
          className={`${classNamePre}`}

        >
          <div>
            <div className={`${classNamePre}-handle`}>
              <Select
                data={CuoponTpl}
                optionValue="type"
                optionText="name"
                width="180px"
                showClear={false}
                autoWidth
                value={currentCouponType}
                onChange={event => this.onChangeSelect(event)}
              />
              <Input
                type="text"
                className={`${classNamePre}-handle-input`}
                placeholder="券模板/券名称"
                value={TplName}
                onChange={event => this.onChangeInput(event, 'TplName')}
              />

              <Button
                onClick={this.initData}
                type="primary"
              >
                <Icon type="search" />
              </Button>
            </div>
            {/* 数据展示区域 */}
            <div className={`${classNamePre}-con`}>
              <RadioGroup
                onChange={this.onChangeRadio}
                value={radioValue}
              >
                <Table
                  columns={columns}
                  datasets={data}
                  rowKey="id"
                  getRowConf={this.getRowConf}
                  pageInfo={{
                    totalItem,
                    current,
                    pageSize: pageSizeList
                  }}
                  onChange={this.onChange}
                />
              </RadioGroup>
            </div>
            {/* 点击确定或者取消的操作区域 */}
            <div className={`${classNamePre}-btn-group`}>
              <Button
                type="primary"
                size="middle"
                outline
                className={`${classNamePre}-btn-group-cancel`}
                onClick={this.onClose}
              >
              取消
              </Button>
              <Button
                type="primary"
                size="middle"
                onClick={this.onConfirm}
              >
              确定
              </Button>
            </div>
          </div>
        </Dialog>
      </div>
    );
  }
}
