import * as React from 'react';
import { Form, Upload, Icon } from 'ezrd';
import compreBase64 from '../../utils/imageCompress';

const { getControlGroup } = Form;

// 引入样式

/** 图片上传自定义表单组件
 * @params { String value | Object value }  value等于Object得结构{ url: 'http://xxxxx.jpg', FilePath: '/img/xxxx/xx.jpg'}
 * @returns {String | Object}
 */
const classNamePre = 'yiye-const-form-image';

export class ConstFormImageTpl extends React.Component {
static defaultProps = {
  disabled: false,
  value: '',
  tips: '建议尺寸：800 x 800 像素'
}

constructor(props) {
  super(props);
  this.state = {
  };
}

// 图片渲染
initImgTpl = (value) => {
  if (value && Object.prototype.toString.call(value) !== '[object Object]') {
    if (value) {
      return (
        <div className={`${classNamePre}-logo`}>
          <img
            width="100"
            height="100"
            alt="图片"
            src={value}
          />
        </div>
      );
    }
    return null;
  }
  return (
    <div className={`${classNamePre}-logo`}>
      <img
        width="100"
        height="100"
        alt="图片"
        src={value.url}
      />
    </div>
  );
}

render() {
  const {
    value, tips, disabled
  } = this.props;
  return (
    <div className={`${classNamePre}`}>
      {
        this.initImgTpl(value)
      }
      <p className={`${classNamePre}-tips`}>{tips}</p>
      {
        disabled
          ? (<div className={`${classNamePre}-modal`} />)
          : null
      }
    </div>
  );
}
}
// 目前只做成了单个上传，至于多个上传再议
export class ConstFormUploadTpl extends React.Component {
  static defaultProps = {
    disabled: false,
    maxSize: 1024 * 1024 * 1,
    guid: '',
    maxAmount: 1,
    maxSizeErr: '图片最大不能超过1MB',
    tips: '建议图片宽度 640px，高度任意。',
    accept: 'image/jpeg, image/png, image/bmp',
    openBase64: true
  }

  // 上传图片
  handleUpload = async (data) => {
    const { onChange, openBase64 } = this.props;
    const url = await compreBase64(data[0].src, data[0].file.type);
    // console.log(data[0])
    // console.log(url)
    if (openBase64) {
      onChange({
        src: url
      });
    } else {
      onChange({
        src: url,
        data
      });
    }
  }

  render() {
    const {
      maxSize, maxAmount, value, maxSizeErr, tips, accept, disabled
    } = this.props;
    return (
      <div className={`${classNamePre}`}>
        {
          value.src
            ? (
              <div style={{
                width: '100px', height: '100px', marginRight: '10px', display: 'flex', 'align-items': 'center', 'justify-content': 'center'
              }}
              >
                <img
                  alt="营业执照"
                  src={value.src}
                  style={{ 'max-width': '100%', 'max-height': '100%' }}
                />
              </div>

            )
            : null
        }
        <Upload
          maxSize={maxSize}
          localOnly
          className={`${classNamePre}-upload`}
          triggerInline
          tips={tips}
          maxAmount={maxAmount}
          accept={accept}
          onUpload={this.handleUpload}
          errorMessages={{
            overMaxSize: () => maxSizeErr,
            overMaxAmount: 'So many', // string
            wrongMimeType: false || null || '' || (() => false)
          }}
        >
          <div className={`${classNamePre}-upload-custom`}>
            <div>
              <Icon type="plus" />
              <span>上传照片</span>
            </div>
          </div>
        </Upload>
        {
          disabled
            ? (<div className={`${classNamePre}-modal`} />)
            : null
        }
      </div>
    );
  }
}

export const ConstFormImage = getControlGroup(ConstFormImageTpl);
export const ConstFormUpload = getControlGroup(ConstFormUploadTpl);
