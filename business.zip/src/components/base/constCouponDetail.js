import * as React from 'react';
import {
  Chart, Geom, Axis
} from "ezr-charts";
import moment from 'moment';
import { textAreaBr, isEmptyTime } from '../../utils/common';
// 新建
const classNamePre = 'yiye-coupon-det';

// 注入
export default class ConstCouponDetail extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      data: [],
      width: ''
    };
  }

componentDidMount = async () => {
  // const width = findDOMNode(this).offsetWidth;
  const width = this.domObj.offsetWidth;
  this.setState({ width: width - 5 - 20 - 120 - 20 });
  const { purchaseStore, MchId } = this.props;
  const { Data } = await purchaseStore.fetchPurchaseCouponDetailCity({
    SupplyBrandId: MchId
  });
    // Data = [
    //   {
    //     CityName: '上海',
    //     CityId: '1',
    //     ShopCount: 10,
    //     SupShopCount: 1
    //   },{
    //     CityName: '北京',
    //     CityId: '1',
    //     ShopCount: 10,
    //     SupShopCount: 1
    //   },{
    //     CityName: '天津',
    //     CityId: '1',
    //     ShopCount: 10,
    //     SupShopCount: 1
    //   },{
    //     CityName: '广东',
    //     CityId: '1',
    //     ShopCount: 10,
    //     SupShopCount: 1
    //   },{
    //     CityName: '深圳',
    //     CityId: '1',
    //     ShopCount: 10,
    //     SupShopCount: 1
    //   }
    // ]
  const data = [];
  for (let i = 0; i < Data.length; i++) {
    data.push({
      month: Data[i].CityName,
      city: '我的',
      temperature: Data[i].SupShopCount
    });
    data.push({
      month: Data[i].CityName,
      city: '其他的',
      temperature: Data[i].ShopCount
    });
  }
  this.setState({ data });
  // 设置折线图的宽度
}

render() {
  const { width, data } = this.state;
  const { couponDetail, detail } = this.props;
  const cols = {
    month: {
      range: [0, 1]
    }
  };
  return (

    <div
      className={`${classNamePre}-wrapper`}
      ref={(ref) => { this.domObj = ref; }}
    >
      <div className={`${classNamePre}-info`}>
        <div className={`${classNamePre}-info-coupon`}>
          <div>
            <font>发放有效期</font>
            自采购日
            {couponDetail.CouponTradeCfg.ValidDate}
            天内有效
          </div>
          <div>
            <font>使用有效期</font>
            自领取日
            {
              isEmptyTime(couponDetail.CouponTradeCfg.BeginDate, couponDetail.CouponTradeCfg.EndDate)
                ? couponDetail.CouponTradeCfg.ValidVay
                : `${moment(couponDetail.CouponTradeCfg.BeginDate).format('YYYY-MM-DD HH:mm:ss')} - ${moment(couponDetail.CouponTradeCfg.EndDate).format('YYYY-MM-DD HH:mm:ss')}`
            }
            天内有效
          </div>
          <div className={`${classNamePre}-info-coupon-explain`}>
            <font>使用说明</font>
            <div>
              {/* eslint-disable */}
              <p dangerouslySetInnerHTML={{ __html: textAreaBr(couponDetail.Guide) }} />
              {/* eslint-enable */}
            </div>
          </div>
          {
            detail.IsShowRpt
              ? (
                <div className={`${classNamePre}-info-coupon-range`}>
                  <div>使用范围</div>
                  <div className={`${classNamePre}-info-coupon-charts`}>
                    <p className={`${classNamePre}-info-coupon-charts-shoptip`}>
                      <span>
                        {detail.OutSysName}
                        <span className={`${classNamePre}-info-coupon-charts-shoptip-txt`}>按供货方门店数最多的30个城市展示，供参考门店覆盖程度（曲线重合度越高，覆盖程度越相似）</span>
                      </span>
                      <div className={`${classNamePre}-info-coupon-charts-shoptip-name`}>
                        <span>
                          <i />
                          {couponDetail.MchName}
                        </span>
                        <span>
                          <i />
                          我的
                        </span>
                      </div>
                    </p>
                    <div>
                      <Chart
                        height={400}
                        width={width}
                        data={data}
                        scale={cols}
                        padding="auto"
                      >
                        {
                          //  <Legend />
                        }
                        <Axis name="month" />
                        <Axis
                          name="temperature"
                          visible={false}
                        />

                        {
                          // <Tooltip
                          //   crosshairs={{
                          //     type: "y"
                          //   }}
                          // />
                        }
                        <Geom
                          type="line"
                          position="month*temperature"
                          size={2}
                          color={
                            ['city', ['#8BC34A', '#F76857']]
                          }
                          shape="smooth"
                        />
                      </Chart>
                    </div>
                  </div>
                </div>
              )
              : null
          }
          {
            detail.WxQrCode
              ? (
                <div className={`${classNamePre}-info-coupon-code`}>
                  <font>线上商城</font>
                  <img
                    alt="二维码图片"
                    src="https://test.ezrpro.com:8444/img/13/01387524493fd6.jpg"
                  />
                </div>
              )
              : null
          }
        </div>
      </div>
    </div>
  );
}
}
