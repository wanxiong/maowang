// 优惠券默认配置
export const couponDefaultPage = {
  current: 1,
  pageSize: 10,
  pageSizeList: [{ value: 10, isCurrent: true }, 20, 30, 50, 100],
  totalItem: '0'
};
// 账号管理-资产管理-充值明细状态
export const assetManageRechargeDetailStatus = [
  {
    id: -9, name: '全部'
  },
  {
    id: 0, name: '待审核'
  },
  {
    id: 2, name: '已入账'
  },
  {
    id: -2, name: '审核失败'
  }
];

// 账号管理-资产管理-明细Z币类型-品牌
export const assetManageZDetailStatus = [
  {
    id: -9, name: '全部'
  },
  {
    id: 12, name: '充值Z币'
  },
  {
    id: 32, name: '采购冻结'
  },
  {
    id: 38, name: '权益商品采购'
  },
  {
    id: 39, name: '权益商品结算'
  },
  {
    id: 60, name: '到期解冻'
  },
  {
    id: 61, name: '解冻'
  },
  {
    id: 35, name: '采购方核销服务费'
  },
  {
    id: 33, name: '供货方核销服务费'
  },
  {
    id: 70, name: '拉新服务费'
  },
  {
    id: 71, name: '拉新佣金'
  },
  {
    id: 34, name: '核销佣金'
  },
  {
    id: 30, name: '平台赠送'
  }, {
    id: 22, name: '活动收益'
  }
];

// 账号管理-资产管理-明细保证金类型
export const assetManageBondDetailStatus = [
  // {
  //   id: '0', name: '全部'
  // },
  {
    id: 11, name: '充值'
  }
  // {
  //   id: 2, name: '扣款'
  // }
];

// 采购单 供货单
export const orderCuoponType = [
  { id: 0, name: '全部', type: 'all' },
  { id: 1, name: '待审核', type: '0' },
  { id: 2, name: '已入库', type: '3' },
  { id: 3, name: '审核未通过', type: '1' }
];

export const merchantStatus = [
  { type: -9, name: '全部' },
  { type: 2, name: '启用' },
  { type: -3, name: '禁用' }
];


export const defaultRechargeDetailStatus = 9;
export const defaultZDetailStatus = -9;
export const defaultBondDetailStatus = '11';
export const defaultZDetailStatusArr = {
  0: '全部',
  1: '平台赠送金额',
  2: '充值',
  3: '核销券'
};
export const defaultBondDetailStatusArr = {
  0: '全部',
  1: '充值'
  // 2: '扣款'
};

export const defaultRechargeApiType = {
  ZType: 12,
  BondType: 11,
  RechargeType: 10,
  ZGive: 30
};
// 屏蔽类目查询 适用场景；[1:券;2:积分;3:商品;]
export const defaultCategorySettingType = {
  coupon: 1,
  point: 2,
  goods: 3
};
// 充值接口需要传递的类型
// 充值余额 10
// 余额充值保证金11
// 余额充值Z币12
// 保证金到余额 20
// 平台赠送Zb 30
// Zb冻结到冻结资金 32
// 券核销供货方付平台佣金33
// 券核销供货方付采购方佣金34
// 券核销采购方付平台佣金35
// 券冻结到期解冻冻结金额到Zb60
// 券核销解冻冻结金额到Zb61
// 商户状态[ -3:平台禁用;-2:审核未通过;-1:品牌歇业;0:商户初始化;1:待审核;2:营业中;9:全部]
export const LoginToken = 'LOGIN_INFO';
export const LoginTYPE = 'LOGIN_STATUS_TYPE';


// 券交易-核销率-状态类型
export const defaultTrancationWriteStatusType = [
  {
    id: '9', name: '全部'
  }, {
    id: '2', name: '营业中'
  }, {
    id: '-3', name: '平台禁用'
  }
];

// 券交易-平台手续费优惠-状态类型
export const defaultTrancationPlatformFeeStatusType = [
  {
    id: '9', name: '全部'
  }, {
    id: '0', name: '禁用中'
  }, {
    id: '1', name: '启用中'
  }
];

// 平台手续费默认参数
export const defaultTrancationSettingFee = {
  writeOf: 3,
  freezeRatio: 2,
  fee: 1
};

export const defaultStatusAudit = [
  {
    id: 9, name: '全部'
  },
  {
    id: 1, name: '待审核'
  },
  {
    id: 2, name: '营业中'
  },
  {
    id: -3, name: '平台禁用'
  },
  {
    id: -1, name: '品牌歇业'
  },
  {
    id: -2, name: '审核未通过'
  }
];

export const defaultTypeAudit = [
  {
    id: 9, name: '全部'
  },
  {
    id: 0, name: '普通账户'
  },
  {
    id: 1, name: '担保账户'
  }
];

// 驿业采购单
export const orderYiyeCuoponType = [
  { id: 0, name: '全部', type: 'all' },
  { id: 30, name: '入库中', type: '30' },
  { id: 3, name: '已入库', type: '3' },
  { id: 21, name: '采购失败', type: '21' }
];

// 我要采购-优惠券-驿业优惠券详情取的sessionSto key 名字
export const sessPurchaseYiyeCouponDtlKey = 'yiye-purchase-yiyeCoupon-dtl';

// 供应商-商品管理-搜索状态
export const goodsManagementSearchStatus = [
  {
    id: 0, name: '全部', type: 'all'
  },
  {
    id: 1, name: '上架', type: '1'
  },
  {
    id: 2, name: '下架', type: '2'
  }
];
// 供应商-商品管理-搜索状态
export const goodsManagementSearchProduct = [
  {
    id: 0, name: '全部', type: 'all'
  },
  {
    id: 1, name: '券码', type: '1'
  },
  {
    id: 2, name: '兑换链接', type: '2'
  },
  {
    id: 3, name: '线上兑换券码', type: '3'
  },
  {
    id: 4, name: '直充卡券', type: '4'
  }
];
export const yiyeCouponProType = {
  1: '券码',
  2: '兑换链接',
  3: '线上兑换券码',
  4: '直充卡券'
};

// 供应商-商品管理-详情字段 session key 名字
export const sessSupplierCouponDtlKey = 'yiye-supplier-coupon-dtl';
export const sessSupplierCouponDtlType = 'yiye-supplier-coupon-dtl-type';

// 我要采购-驿业券-详情字段 session key 名字
export const sessPurchaseNewYiyeCouponDtlKey = 'yiye-purchase-newYiyeCoupon-dtl';

// 供应商-销售管理-搜索状态
export const saleSearchStatus = [
  {
    id: 0, name: '全部', type: 'all'
  },
  {
    id: 30, name: '入库中', type: '30'
  },
  {
    id: 3, name: '已入库', type: '3'
  },
  {
    id: 21, name: '入库异常', type: '21'
  }
];

// 供应商-导入券码-key
export const sessSupplierCouponCodeKey = 'yiye-supplier-coupon-code-params';


// 账号管理-资产管理-明细Z币类型-平台
export const merchantManageZDetailStatus = [
  {
    id: '-9', name: '全部'
  },
  {
    id: 2, name: '充值Z币'
  },
  {
    id: 3, name: '购买商品'
  },
  {
    id: 4, name: '平台充值'
  },
  {
    id: 5, name: '拉新服务费'
  },
  {
    id: 6, name: '券核销服务费'
  }
];
// 初始化品牌对应的云
export const initBrandCloud = [{
  Name: '腾讯云',
  Id: 3
}, {
  Name: 'ucloud',
  Id: 1
}, {
  Name: '微软云',
  Id: 4
}];

// 系统管理-用户管理-用户状态
export const sysUserStatus = [{
  id: '2',
  name: '正常'
}, {
  id: '3',
  name: '冻结'
}];

// 系统管理-账号类型-账号状态
export const sysUserTypeStatus = [{
  id: '1',
  name: '全部'
}, {
  id: '2',
  name: '平台账号'
}, {
  id: '3',
  name: '品牌用户'
}];

// 迁移~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// 优惠券列表-类别常量
export const purchaseCoupon = [{
  title: '类型',
  params: 'LX',
  type: 2,
  index: -1,
  all: '全部',
  children: [
    { Name: '代金券', Id: 'DJ' },
    { Name: '折扣券', Id: 'ZK' },
    { Name: '礼品券', Id: 'LP' },
    { Name: '邀请券', Id: 'YQ' },
    { Name: '促销券', Id: 'CX' }
  ]
}, {
  title: '佣金',
  params: 'YJ',
  type: 3,
  index: -1,
  all: '全部',
  children: [{
    Name: '按订单提成',
    Id: 1
  }, {
    Name: '按券核销张数',
    Id: 0
  }]
}];
// 我要采购-优惠券-优惠券详情取的sessionSto key 名字
export const sessPurchaseCouponDtlKey = 'yiye-purchase-coupon-dtl';

// 我要供货-平台券-详情取的sessionSto key 名字
export const sessProvidePlatformcouponDtlKey = 'yiye-provide-platformcoupon-dtl';
// 我要供货-平台券-查看 编辑 复制 名字
export const sessProvidePlatformcouponStatusKey = 'yiye-provide-platformcoupon-status';
export const sessProvidePlatformcouponTypeKey = 'yiye-provide-platformcoupon-type';
// 商户审核未通过
export const sessPageAuditFailure = 'yiye-page-audit-failure';

// 平台券
export const platformCuoponType = [
  { id: 0, name: '全部', type: 'all' },
  { id: 1, name: '代金券', type: 'DJ' },
  { id: 2, name: '折扣券', type: 'ZK' },
  { id: 3, name: '礼品券', type: 'LP' },
  { id: 4, name: '邀请券', type: 'YQ' },
  { id: 5, name: '促销券', type: 'CX' },
  { id: 6, name: '异业券', type: 'YY' }
];

// 我要供货平台券-跳转导入商品页面的key
export const sessToImportCenter = 'yiye-import-center-par';

// 用户店铺状态供货还是采购
export const pageShopStatus = {
  0: 'provide',
  1: 'purchase'
};

export const sessProvidePlatformCouponDtlType = {
  0: 'see', // 查看
  1: 'edit', // 编辑
  2: 'copy' // 复制
};

// 平台券
export const CuoponTpl = [
  { id: 0, name: '全部', type: '' },
  { id: 1, name: '代金券', type: 'DJ' },
  { id: 2, name: '折扣券', type: 'ZK' },
  { id: 3, name: '礼品券', type: 'LP' },
  { id: 4, name: '邀请券', type: 'YQ' }
];

// 券码状态
export const CouponOriginStatus = [
  { id: '-1', name: '全部' },
  { id: 0, name: '已提交' },
  { id: 1, name: '制券中' },
  { id: 2, name: '已生效' },
  { id: 3, name: '未生效' },
  { id: 4, name: '已失效' }
];

export const yiyeCouponTypeList = [{
  Id: '',
  Name: '全部'
}, {
  Id: 'DJ',
  Name: '代金券'
}, {
  Id: 'ZK',
  Name: '折扣券'
}, {
  Id: 'LP',
  Name: '礼品券'
}, {
  Id: 'YQ',
  Name: '邀请券'
}, {
  Id: 'CX',
  Name: '促销券'
}
// , {
//   Id: 'YY',
//   Name: '异业券'
// }
];

export const yiyeCouponTypeListYY = [{
  Id: 'YY',
  Name: '异业券'
}];

// 平台付费方案检索条件状态
export const platformChargingScheme = [{
  Id: 0,
  Name: '全部'
}, {
  Id: 1,
  Name: '启用中'
}, {
  Id: 2,
  Name: '已禁用'
}];
