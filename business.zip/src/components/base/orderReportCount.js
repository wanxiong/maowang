import * as React from 'react';

const classNamePre = 'yiye-order-report-count';

export default class OrderReportCount extends React.Component {
// 为了画面不显得那么空 分开2个数组
static defaultProps = {
  titleList: [], // 标题数组
  keyList: []
}

constructor(prop) {
  super(prop);
  this.state = {

  };
}

render() {
  const { keyList, titleList } = this.props;
  return (
    <div className={`${classNamePre}`}>
      <div className={`${classNamePre}-con`}>
        {
          titleList.length
            ? (
              <ul>
                {
                  titleList.map((item, index) => (
                    <li key={item}>
                      <span>{item}</span>
                      <span>{keyList[index]}</span>
                    </li>
                  ))
              }
              </ul>
            )
            : null
        }
      </div>
    </div>
  );
}
}
