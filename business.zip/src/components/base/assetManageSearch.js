import * as React from 'react';
import {
  Select, Button, DateRangePicker
} from 'ezrd';
import '../../styles/base/index.less';

const classNamePre = 'yiye-asset-manage-search';

export default class AssetManageSearch extends React.Component {
static defaultProps = {
  showTime: true, // 是否显示时间筛选
  format: 'YYYY-MM-DD hh-mm-ss',
  data: [], // 下拉框得数据源
  defautlSelect: '',
  statusKey: 'Status' // 默认的类型返回字段
}

constructor(props) {
  super(props);
  this.state = {
    SelectValue: props.defautlSelect || '', // 默认选择全部
    value: ''
  };
  this.onSearch = this.onSearch.bind(this);
}

// 券类型选择
onChangeSelect = (e) => {
  this.setState({ SelectValue: e.target.value });
}

// 点击查询按钮
onSearch = (flag) => {
  const {
    SelectValue, value
  } = this.state;
  const { onSearch, statusKey } = this.props;
  onSearch({
    [statusKey]: SelectValue,
    CreateOn: value
  }, flag);
}

// 清空
onClean = () => {
  this.setState({
    value: '',
    SelectValue: ''
  });
}

onChangeRange = (val) => {
  this.setState({
    value: val
  });
}
// 导出事件
// onExport = () => {
//   const { onExport, brandShow } = this.props;
//   const {
//     brand, value
//   } = this.state;
//   const params = {
//     time: value
//   };
//   if (!brandShow) {
//     delete params.brand;
//   }

//   onExport(params);
// }

render() {
  const {
    value, SelectValue
  } = this.state;
  const { showTime, format, data } = this.props;
  return (
    <div className={`${classNamePre}`}>
      {/* 基本输入input框 */}
      <div className={`${classNamePre}-top`}>
        <div>
          <span>新增时间：</span>
          <DateRangePicker
            className=""
            width={190}
            value={value}
            format={format}
            showTime={showTime}
            onChange={this.onChangeRange}
          />
        </div>
        <div>
          <span>状态：</span>
          <Select
            data={data}
            optionValue="id"
            optionText="name"
            width="120px"
            showClear={false}
            value={SelectValue}
            onChange={this.onChangeSelect}
          />
        </div>
      </div>
      {/* 采购时间-- 查询--导出 */}
      <div className={`${classNamePre}-search-btn`}>
        <Button
          type="primary"
          className={`${classNamePre}-btn-1`}
          onClick={this.onSearch}
        >
        查询
        </Button>
        { /* <Button type='primary' onClick={this.onExport}>导出</Button> */}
      </div>
    </div>
  );
}
}
