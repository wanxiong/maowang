import * as React from 'react';
import {
  Input, Button, Dialog, Icon, Table, Radio, Notify
} from 'ezrd';
import { couponDefaultPage } from './constant';
import CommonApi from '../../model/common';

const classNamePre = 'yiye-coupon-list';

const RadioGroup = Radio.Group;
const columns = [
  {
    title: '',
    width: '50px',
    bodyRender: (data, dataRow) => (
      <Radio
        name="coupon-list"
        value={dataRow.row}
      />
    )
  },
  {
    title: '促销编号',
    name: 'PromotionCode',
    width: '80px'
  },
  {
    title: '促销名称',
    name: 'PromotionName'
  }
];


export default class CouponPromotionList extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      visible: false,
      TplName: '', // 券模板/券名称
      radioValue: '', // 选中单选框
      code: '',
      loading: false,
      data: [], // 展示的数据源
      ...couponDefaultPage
    };
    this.initData = this.initData.bind(this);
  }

  async componentDidMount() {
    this.initData();
  }

  async componentWillReceiveProps(nextProps) {
    const { visible } = this.state;
    if (nextProps.show !== visible) {
      this.setState({ visible: nextProps.show });
      this.initData();
    }
  }

  /*
  * @param data {Object} 每一行的数据
  * @param index {number} 每一行在列表中的index
  * @return {
  *  canSelect {bool} 是否可选，默认为true
  *  rowClass {string} 这一行的特殊class，默认是空字符串
  * }
  */
  static getRowConf(data, index) { // 每一行的数据和这一行在列表中的index
    return {
      canSelect: index % 2 === 0,
      rowClass: index % 2 === 1 ? 'yiye-coupon-list-con-style' : ''
    };
  }

  // 单选框的回调事件
  onChangeRadio = (e) => {
    const v = e.target.value;
    // v 是下标
    this.setState({ radioValue: v });
  }

  // 基本输入框的回调事件
  onChangeInput = (e, type) => {
    this.setState({
      [type]: e.target.value
    });
  }

  // 分页的回调
  onChange = (data) => {
    const { current, pageSize } = this.state;
    this.setState({
      current: data.current || current,
      pageSize: data.pageSize || pageSize
    }, () => {
      this.initData();
    });
  }

  onClose = () => {
    const { onClose } = this.props;
    this.setState({
      visible: false
    }, () => {
      this.clearVal();
      /* eslint-disable */
      onClose && onClose();
      /* eslint-enable */
    });
  }

  onConfirm = () => {
    const { onConfirm, errorMsg } = this.props;
    const { data, radioValue } = this.state;
    if (radioValue === '') {
      Notify.error(errorMsg || '请选择促销券');
      return;
    }
    if (data[radioValue].PromotionValidType === 1) {
      Notify.error('请选择固定效期的促销券');
      return;
    }
    this.setState({
      visible: false
    }, () => {
      this.clearVal();
      /* eslint-disable */
      onConfirm && onConfirm(data[radioValue]);
      /* eslint-enable */
    });
  }

  initData = async () => {
    const {
      pageSize, current, TplName, code
    } = this.state;
    this.setState({ loading: true });
    const { Data } = await CommonApi.fetchBasePromotionCouponList({
      PageIndex: current,
      PageSize: pageSize,
      PromotionCode: code,
      PromotionName: TplName
    });
    this.setState({ data: Data.PagedList, totalItem: Data.TotalRowsCount, loading: false });
  }

  // 清空数据
  clearVal = () => {
    this.setState({
      code: '',
      TplName: '',
      radioValue: '',
      data: [],
      ...couponDefaultPage
    });
  }

  // 检索
  search = () => {
    this.setState({
      current: 1
    }, () => {
      this.initData();
    });
  }

  render() {
    const {
      TplName, radioValue, data, visible, totalItem, current, pageSizeList, code, loading
    } = this.state;
    return (
      <div>
        <Dialog
          visible={visible}
          title="选择促销券"
          onClose={this.onClose}
          className={`${classNamePre}`}
        >
          <div>
            <div className={`${classNamePre}-handle`}>
              <Input
                type="text"
                className={`${classNamePre}-handle-input`}
                placeholder="输入促销编号"
                value={code}
                onChange={event => this.onChangeInput(event, 'code')}
              />
              <Input
                type="text"
                className={`${classNamePre}-handle-input`}
                placeholder="输入促销名称"
                value={TplName}
                onChange={event => this.onChangeInput(event, 'TplName')}
              />

              <Button
                onClick={this.search}
                type="primary"
              >
                <Icon type="search" />
              </Button>
            </div>
            {/* 数据展示区域 */}
            <div className={`${classNamePre}-con`}>
              <RadioGroup
                onChange={this.onChangeRadio}
                value={radioValue}
              >
                <Table
                  columns={columns}
                  datasets={data}
                  rowKey="id"
                  loading={loading}
                  getRowConf={this.getRowConf}
                  pageInfo={{
                    totalItem,
                    current,
                    pageSize: pageSizeList
                  }}
                  onChange={this.onChange}
                />
              </RadioGroup>
            </div>
            {/* 点击确定或者取消的操作区域 */}
            <div className={`${classNamePre}-btn-group`}>
              <Button
                type="primary"
                size="middle"
                outline
                className={`${classNamePre}-btn-group-cancel`}
                onClick={this.onClose}
              >
              取消
              </Button>
              <Button
                type="primary"
                size="middle"
                onClick={this.onConfirm}
              >
              确定
              </Button>
            </div>
          </div>
        </Dialog>
      </div>
    );
  }
}
