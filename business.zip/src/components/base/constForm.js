import * as React from 'react';
import {
  Input, NumberInput, Form, Radio, DateRangePicker, Checkbox, Select, Cascader
} from 'ezrd';
import { Selector } from 'ezrpc';
import CouponList from './couponList';
import CouponPromotionList from './couponPromotionList';

// 引入样式
import 'ezrpc/css/selector.css';

const classNamePre = 'yiye-const-form';

const { getControlGroup } = Form;
const RadioGroup = Radio.Group;

class ConstFormCoupon extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
    };
  }

  // 优惠券模板的回调
  onConfirm = (data) => {
    const { onChange } = this.props;
    this.setState({ flag: false });
    onChange({
      couponTpl: data.TplName,
      TplId: data.Id,
      CouponType: data.CouponType,
      CouponValue: data.CouponValue,
      CouponPriceLimit: data.CouponPriceLimit
    });
  }

  // 优惠券的弹框
  search = () => {
    this.setState({
      flag: true
    });
  }

  render() {
    const { disabled, value: { couponTpl } } = this.props;
    const { flag } = this.state;
    return (
      <div>
        <Input
          btn="查询"
          width={320}
          onSearch={disabled ? () => { } : this.search}
          onChange={this.onChange}
          value={couponTpl}
          placeholder="选择优惠券"
          disabled
        />
        {/* 优惠券呢 */}
        <CouponList
          show={flag}
          onConfirm={this.onConfirm}
        />
      </div>
    );
  }
}
/**
 * 参数
 * */
class ConstFormDayTpl extends React.Component {
  static defaultProps = {
    toFixLen: 0, // 默认显示小数点的长度为0
    startTxt: '', // 输入框的前部分文字
    endTxt: '', // 输入框的后半部分文字
    showTips: false, // 是否显示提醒文字
    min: 0,
    width: 80,
    max: 99999999999999
  }

  constructor(prop) {
    super(prop);
    this.state = {
    };
  }

  onChange = (e) => {
    const { onChange } = this.props;
    const v = e.target.value;
    onChange(v);
  }

  render() {
    // let { couponTpl } = this.props.value
    const {
      disabled, value, startTxt, endTxt, toFixLen, min, max, width
    } = this.props;
    return (
      <div className={`${classNamePre}-day`}>
        {startTxt
          ? <span className={`${classNamePre}-day-left`}>{startTxt}</span>
          : null
        }
        <NumberInput
          min={min}
          max={max}
          decimal={toFixLen}
          disabled={disabled}
          onChange={this.onChange}
          className={`${classNamePre}-valid-date-input`}
          value={value}
          width={width}
        />
        {endTxt
          ? <span className={`${classNamePre}-day-right`}>{endTxt}</span>
          : null
        }
      </div>
    );
  }
}

/**
 * 参数
 * */
class ConstFormBetweenTpl extends React.Component {
  static defaultProps = {
    toFixLen: 0, // 默认显示小数点的长度为0
    startTxt: '', // 输入框的前部分文字
    centerTxt: '', // 输入框的中部分文字
    endTxt: '', // 输入框的后半部分文字
    value: [], // 输入框的区间值
    tip: '', // 显示提醒文字
    min1: 0,
    min2: 0,
    max2: 99999999999
  }

  constructor(prop) {
    super(prop);
    this.state = {
      value: []
    };
  }

  onChange = (e, i) => {
    const v = e.target.value;
    const { value } = this.state;
    const { onChange } = this.props;
    value[i] = v;
    this.setState({
      value
    }, () => {
      onChange(value);
    });
  }

  render() {
    // let { couponTpl } = this.props.value
    const {
      disabled, value, centerTxt, startTxt, endTxt, toFixLen, tip, min1, min2, max2
    } = this.props;
    return (
      <div className={`${classNamePre}-between`}>
        <div>
          {startTxt
            ? <span className={`${classNamePre}-between-left`}>{startTxt}</span>
            : null
          }
          <NumberInput
            min={min1}
            decimal={toFixLen}
            disabled={disabled}
            onChange={event => this.onChange(event, '0')}
            className={`${classNamePre}-between-input`}
            value={value[0] || ''}
          />
          {centerTxt
            ? <span className={`${classNamePre}-between-center`}>{centerTxt}</span>
            : null
          }
          <NumberInput
            min={min2}
            max={max2}
            decimal={toFixLen}
            disabled={disabled}
            onChange={event => this.onChange(event, '1')}
            className={`${classNamePre}-between-input`}
            value={value[1] || ''}
          />
          {endTxt
            ? <span className={`${classNamePre}-between-right`}>{endTxt}</span>
            : null
          }
        </div>
        {/* tip */}
        {tip
          ? <span className={`${classNamePre}-between-tip`}>{tip}</span>
          : ''
        }

      </div>
    );
  }
}

class ConstFormValidDateTpl extends React.Component {
  static defaultProps = {
    toFixLen: 0, // 默认显示小数点的长度为0
    startTxt: '', // 输入框的前部分文字
    centerTxt: '', // 输入框的中部分文字
    endTxt: '', // 输入框的后半部分文字
    startVal: '', // 第一个输入框的值
    endVal: '', // 第二个输入框的值
    value: [], // 输入框的区间值
    tip: '', // 显示提醒文字
    min: 0
  }

  constructor(prop) {
    super(prop);
    this.state = {
    };
  }

  onChangeValOne = (e) => {
    const v = e.target.value;
    const { value, onChange } = this.props;
    onChange({
      type: value.type,
      data: [v, value.data[1]]
    });
  }

  onChange = (e) => {
    const v = e.target.value;
    const { value, onChange } = this.props;
    onChange({
      type: v,
      data: value.data
    });
  }

  onChangeRange = (val) => {
    const { value, onChange } = this.props;
    onChange({
      type: value.type,
      data: [value.data[0], val]
    });
  }

  render() {
    // let { couponTpl } = this.props.value
    const {
      disabled, value, startTxt, endTxt, toFixLen, min
    } = this.props;
    return (
      <div className={`${classNamePre}-valid-date`}>
        <RadioGroup
          onChange={this.onChange}
          value={value.type}
          disabled={disabled}
        >
          <div className={`${classNamePre}-valid-date-day`}>
            <Radio value="1" />
            {startTxt
              ? <span className={`${classNamePre}-valid-date-left`}>{startTxt}</span>
              : null
            }
            <NumberInput
              decimal={toFixLen}
              disabled={disabled}
              onChange={this.onChangeValOne}
              className={`${classNamePre}-valid-date-input`}
              value={value.data[0]}
              min={min}
            />
            {endTxt
              ? <span className={`${classNamePre}-valid-date-right`}>{endTxt}</span>
              : null
            }
          </div>
          {/* */}
          <div className={`${classNamePre}-valid-date-time`}>
            <Radio value="2" />
            <DateRangePicker
              min={new Date().getTime()}
              value={value.data[1]}
              width={190}
              disabled={disabled}
              defaultValue={["", ""]}
              onChange={this.onChangeRange}
            />
          </div>
        </RadioGroup>
      </div>
    );
  }
}

/**
 * 参数
 * */
class ConstFormDayCheckBoxTpl extends React.Component {
  static defaultProps = {
    toFixLen: 0, // 默认显示小数点的长度为0
    startTxt: '', // 输入框的前部分文字
    endTxt: '', // 输入框的后半部分文字
    max: 9999999999999999999999999999999999999999999999999, // 最大值
    min: 0, // 最小值
    value: {
      type: false,
      data: ''
    }
  }

  constructor(prop) {
    super(prop);
    this.state = {
    };
  }

  onChange = (e) => {
    const v = e.target.value;
    const { value, onChange } = this.props;
    onChange({
      type: value.type,
      data: v
    });
  }

  onChangeBox = (e) => {
    const v = e.target.checked;
    const { value, onChange } = this.props;
    onChange({
      type: v,
      data: value.data
    });
  }

  render() {
    // let { couponTpl } = this.props.value
    const {
      disabled, value, startTxt, endTxt, toFixLen, max, min
    } = this.props;
    return (
      <div className={`${classNamePre}-day-check`}>
        <Checkbox
          disabled={disabled}
          className={`${classNamePre}-day-check-box`}
          checked={value.type}
          onChange={this.onChangeBox}
        />
        {startTxt
          ? <span className={`${classNamePre}-day-check-left`}>{startTxt}</span>
          : null
        }
        <NumberInput
          decimal={toFixLen}
          disabled={disabled}
          onChange={this.onChange}
          min={min}
          max={max}
          className={`${classNamePre}-day-check-input`}
          value={value.data}
        />
        {endTxt
          ? <span className={`${classNamePre}-day-check-right`}>{endTxt}</span>
          : null
        }
      </div>
    );
  }
}

/**
 * 参数
 * */
class ConstFormSelectTpl extends React.Component {
  static defaultProps = {
    text: '选择门店', // 默认显示内容
    max: '1000', // 最大门店
    isSelectDisabled: false, // 是否禁止切换
    selectValue: 'hasActive', // 默认选中的店铺
    showItems: ['SH', 'GP', 'PQ', 'myGroup'],
    value: {
      type: false,
      data: ''
    },
    selectInfo: {}
  }

  onChangeBox = (e) => {
    const v = e.target.checked;
    const { value, onChange } = this.props;
    onChange({
      type: v,
      data: value.data
    });
  }

  onSelect = async (res) => {
    const { value, onChange } = this.props;
    onChange({
      type: value.type,
      data: res
    });
  }

  render() {
    const {
      disabled, value, text, max, selectValue, isSelectDisabled, showItems, selectInfo
    } = this.props;
    return (
      <div className={`${classNamePre}-select`}>
        <Checkbox
          className={`${classNamePre}-select-box`}
          disabled={disabled}
          checked={value.type}
          onChange={this.onChangeBox}
        />
        <Selector
          label={text}
          showItems={showItems}
          labelStyle={{}}
          selectValue={selectValue}
          isSelectDisabled={isSelectDisabled}
          max={max}
          onSave={this.onSelect}
          selectInfo={selectInfo}
          disabled={disabled}
        />
      </div>
    );
  }
}

/**
 * 参数
 * */
class ConstFormSelectIndustryTpl extends React.Component {
  static defaultProps = {
    parent: [],
    disabled: false,
    value: {
      type: false,
      data: ''
    }
  }

  constructor(prop) {
    super(prop);
    this.state = {
    };
  }

  onSelect = async (res) => {
    const { onChange } = this.props;
    onChange(res.target.value);
  }

  render() {
    const { parent, value, disabled } = this.props;
    return (
      <div className={`${classNamePre}-select`}>
        <Select
          data={parent}
          value={value}
          showClear={false}
          disabled={disabled}
          onChange={this.onSelect}
          optionText="Name"
          optionValue="Id"
        />
      </div>
    );
  }
}

/** 经营类目
 *
 * */
class ConstFormCascaderCategoryTpl extends React.Component {
  static defaultProps = {
    data: [],
    disabled: false,
    value: {
      type: false,
      data: []
    }
  }

  constructor(prop) {
    super(prop);
    this.state = {
      changeValue: ''
    };
  }

  onChange = (data) => {
    const { value, onChange } = this.props;
    // 数组需要去重操作
    if (!value.length) {
      value.push(data);
    } else {
      let isDup = false;
      let isDupIndex = '';
      value.forEach((item, index) => {
        if (data[0].id === item[0].id && data[1].id === item[1].id) {
          // 数据重合 直接覆盖
          isDup = true;
          isDupIndex = index;
        }
      });
      if (isDup) {
        value.splice(isDupIndex, 1, data);
      } else {
        value.push(data);
      }
    }
    onChange(value);
    this.setState({
      changeValue: ''
    });
  }

  // 删除多余item
  removeItem = (index) => {
    const { value, onChange } = this.props;
    value.splice(index, 1);
    onChange(value);
    this.setState({ changeValue: '' });
  }

  render() {
    const { changeValue } = this.state;
    const { value, data, disabled } = this.props;
    return (
      <div className={`${classNamePre}-cascader-category`}>
        <Cascader
          value={changeValue}
          options={data}
          onChange={this.onChange}
          placeholder="请选择"
          type="menu"
          title={[
            '省',
            '市'
          ]}
        />
        { /* 页面回显选择区域 */}

        {
          value.length
            ? (
              <div className={`${classNamePre}-cascader-con`}>
                {
                  value.map((item, index) => (
                    <div
                      key={item.Id}
                      className={`${classNamePre}-cascader-con-item`}
                    >
                      {item[0].title}
                      {' '}
                      &gt;
                      {item[1].title}
                      <span
                        role="button"
                        tabIndex="0"
                        className="yiye-outline"
                        onClick={() => this.removeItem(index)}
                      >
                        <i />
                      </span>
                    </div>
                  ))
                }
              </div>
            )
            : null
        }
        {
          disabled
            ? (<div className={`${classNamePre}-cascader-category-modal`} />)
            : null
        }
      </div>
    );
  }
}


class ConstFormDateAndRadioTpl extends React.Component {
  static defaultProps = {
    firstTxt: '', // 第一个单选框的文字
    secondTxt: '', // 第二个单选框的文字
    value: [], // 输入框的区间值
    tip: '' // 显示提醒文字
  }

  constructor(prop) {
    super(prop);
    this.state = {
    };
  }

  onChange = (e) => {
    const v = e.target.value;
    const { value, onChange } = this.props;
    onChange({
      type: v,
      data: value.data
    });
  }

  onChangeRange = (val) => {
    const { value, onChange } = this.props;
    onChange({
      type: value.type,
      data: [val]
    });
  }

  render() {
    const {
      disabled, value, firstTxt, secondTxt
    } = this.props;
    return (
      <div className={`${classNamePre}-valid-date`}>
        <RadioGroup
          onChange={this.onChange}
          value={value.type}
          disabled={disabled}
        >
          <div className={`${classNamePre}-valid-date-day`}>
            <Radio value="1" />
            {firstTxt
              ? <span className={`${classNamePre}-valid-only-radio`}>{firstTxt}</span>
              : null
            }
          </div>
          {/* */}
          <div className={`${classNamePre}-valid-date-time`}>
            <Radio value="2" />
            {secondTxt
              ? <span style={{ 'margin-right': '10px' }}>{secondTxt}</span>
              : null
              }
            <DateRangePicker
              min={new Date().getTime()}
              value={value.data}
              width={190}
              defaultValue={["", ""]}
              onChange={this.onChangeRange}
            />
          </div>
        </RadioGroup>
      </div>
    );
  }
}

// 促销券模板的回调
class ConstFormPromotionCoupon extends React.Component {
  static defaultProps = {
    customCallBack: () => {} // 自定义回调
  }

  constructor(prop) {
    super(prop);
    this.state = {
    };
  }

  // 促销券模板的回调
  onConfirm = (data) => {
    const { onChange, customCallBack } = this.props;
    this.setState({ flag: false });
    let shopsArr = [];
    if (data.ApplyShops) {
      shopsArr = data.ApplyShops.split(',');
    }
    const obj = {
      couponTpl: '',
      TplId: '',
      CouponValue: data.CouponValue,
      PromotionCode: data.PromotionCode,
      PromotionValidType: data.PromotionValidType,
      ApplyType: data.ApplyType,
      ApplyShops: shopsArr, // 需要输入处理
      CouponType: 'CX',
      CouponPriceLimit: data.PriceLimit,
      CouponName: data.PromotionName,
      BeginDate: data.BegDate,
      EndDate: data.EndDate,
      IsAllowUserMore: data.IsMore,
      CouponRemark: data.PromotionDescription

    };
    onChange(obj);
    customCallBack(data.PromotionCode, obj);
  }

  // 促销券的弹框
  search = () => {
    this.setState({
      flag: true
    });
  }

  render() {
    const { disabled, value: { PromotionCode } } = this.props;
    const { flag } = this.state;
    return (
      <div>
        <Input
          btn="查询"
          width={320}
          onSearch={disabled ? () => { } : this.search}
          onChange={this.onChange}
          value={PromotionCode}
          placeholder="选择促销券"
          disabled
        />
        {/* 促销券呢 */}
        <CouponPromotionList
          show={flag}
          onConfirm={this.onConfirm}
        />
      </div>
    );
  }
}

export const ConstFormDay = getControlGroup(ConstFormDayTpl);
export const ConstFormBetween = getControlGroup(ConstFormBetweenTpl);
export const ConstFormCouponList = getControlGroup(ConstFormCoupon);
export const ConstFormValidDate = getControlGroup(ConstFormValidDateTpl);
export const ConstFormDayCheckBox = getControlGroup(ConstFormDayCheckBoxTpl);
export const ConstFormSelect = getControlGroup(ConstFormSelectTpl);
export const ConstFormSelectIndustry = getControlGroup(ConstFormSelectIndustryTpl);
export const ConstFormCascaderCategory = getControlGroup(ConstFormCascaderCategoryTpl);
export const ConstFormDateAndRadio = getControlGroup(ConstFormDateAndRadioTpl);
export const ConstFormPromotionCouponList = getControlGroup(ConstFormPromotionCoupon);
