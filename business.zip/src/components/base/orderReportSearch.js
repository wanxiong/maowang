import * as React from 'react';
import {
  Input, DateRangePicker, Button, NumberInput, Dialog, Notify
} from 'ezrd';
import { inject } from 'mobx-react';
import moment from 'moment';
import { withRouter } from "react-router-dom";
import { trim } from '../../utils/common';

const classNamePre = 'yiye-order-report-search';

@withRouter
@inject('purchaseStore')
@inject('provideStore')
export default class OrderReportSearch extends React.Component {
  // 为了画面不显得那么空 分开2个数组
  static defaultProps = {
    keyList: [],
    valList: [],
    brandShow: true,
    exportText: '',
    type: 'purchaseStore',
    defaultTime: ['', '']
  }

  constructor(prop) {
    super(prop);
    const { typeName } = this.props;
    this.state = {
      visible: false,
      taskName: moment().format('YYYY-MM-DD') + typeName,
      loading: false,
      couponId: '', // 券ID
      couponName: '', // 券名字
      brandName: '', // 品牌名称
      rangeValue: [] // [prop.defaultTime[0], prop.defaultTime[1]] // 时间区段
    };
  }

  componentDidMount() {
    const { getRef } = this.props;
    getRef(this);
  }

  // 普通input框的事件回调
  onChangeInput = (type, e) => {
    this.setState({
      [type]: e.target.value
    });
  }

  // 时间选择的回调
  onChangeRange = (v) => {
    this.setState({ rangeValue: v });
  }

  // 点击查询按钮
  onSearch = (flag) => {
    const {
      rangeValue, couponName, couponId, brandName
    } = this.state;
    const { onSearch } = this.props;
    const params = {
      couponName,
      couponId,
      rangeValue,
      brandName
    };
    onSearch(params, flag);
  }

  // 导出按钮
  onExport = () => {
    // const { rangeValue } = this.state;
    // if (!rangeValue[0] && !rangeValue[1]) {
    //   Notify.error('请选择导出时间');
    //   return;
    // }
    // if (!rangeValue[0] && rangeValue[1]) {
    //   Notify.error('导出结束时间不能为空');
    //   return;
    // }
    // if (rangeValue[0] && !rangeValue[1]) {
    //   Notify.error('导出开始时间不能为空');
    //   return;
    // }
    // if (rangeValue[0].substring(0, 4) !== rangeValue[1].substring(0, 4)) {
    //   Notify.error('导出时间不能跨年');
    //   return;
    // }
    const { typeName } = this.props;
    this.setState({
      visible: true,
      taskName: moment().format('YYYY-MM-DD') + typeName
    });
  }

  // 关闭弹出框
  closeDialog = () => {
    const { typeName } = this.props;
    this.setState({
      visible: false,
      taskName: moment().format('YYYY-MM-DD') + typeName
    });
  }

  confirm = async () => {
    const {
      taskName, rangeValue, couponName, couponId, brandName
    } = this.state;
    const {
      provideStore, type, purchaseStore, history
    } = this.props;
    if (!trim(taskName)) {
      Notify.error('请输入导出数据的文件名称');
      return;
    }
    this.setState({ loading: true });
    if (type === 'purchaseStore') {
      const status = await purchaseStore.fetchPurchaseOrderReportDownLoad({
        TaskName: taskName,
        Querys: {
          CouponGrpId: couponId,
          CouponGrpName: couponName,
          BeginDate: rangeValue[0] || '',
          EndDate: rangeValue[1] || '',
          ProvideMchName: brandName
        }
      });
      this.setState({ loading: false });
      if (!status.IsError) {
        this.closeDialog();
        history.push('/Yiye/Download');
      }
    } else {
      const status = await provideStore.fetchProvideOrderReportDownLoad({
        TaskName: taskName,
        Querys: {
          CouponGrpId: couponId,
          CouponGrpName: couponName,
          BeginDate: rangeValue[0] || '',
          EndDate: rangeValue[1] || ''
        }
      });
      this.setState({ loading: false });
      if (!status.IsError) {
        this.closeDialog();
        history.push('/Yiye/Download');
      }
    }
  }

  render() {
    const {
      couponId, couponName, rangeValue, brandName, loading, taskName, visible
    } = this.state;
    const { brandShow } = this.props;
    return (
      <div className={`${classNamePre}`}>
        <Dialog
          title="导出数据的文件名称"
          visible={visible}
          onClose={() => this.closeDialog()}
          style={{ width: '600px' }}
          maskClosable={false}
          footer={(
            <div>
              <Button
                outline
                loading={loading}
                onClick={() => this.closeDialog()}
              >
                取消
              </Button>
              <Button
                loading={loading}
                onClick={() => this.confirm()}
              >
                确定
              </Button>
            </div>
          )}
        >
          <Input
            signleBorder
            placeholder="请输入导出数据的文件名称"
            showClear
            maxLength={30}
            width="100%"
            value={taskName}
            onChange={event => this.onChangeInput('taskName', event)}
          />
        </Dialog>
        {
          brandShow
            ? (
              <div className={`${classNamePre}-date`}>
                <span>采购时间：</span>
                <DateRangePicker
                  className=""
                  width={200}
                  format="YYYY-MM-DD"
                  value={rangeValue}
                  onChange={this.onChangeRange}
                />
              </div>
            )
            : null
        }
        <div className={`${classNamePre}-con`}>
          <div className={`${classNamePre}-input`}>
            {
              brandShow
                ? (
                  <React.Fragment>
                    <div>
                      <span>券ID：</span>
                      <NumberInput
                        value={couponId}
                        width={230}
                        className={`${classNamePre}-input-con`}
                        onChange={event => this.onChangeInput('couponId', event)}
                      />
                    </div>
                    <div>
                      <span>券名称：</span>
                      <Input
                        type="text"
                        value={couponName}
                        width={230}
                        className={`${classNamePre}-input-con`}
                        onChange={event => this.onChangeInput('couponName', event)}
                      />
                    </div>
                    <div>
                      <span>品牌：</span>
                      <Input
                        type="text"
                        size="small"
                        width={230}
                        value={brandName}
                        onChange={event => this.onChangeInput('brandName', event)}
                      />
                    </div>
                  </React.Fragment>
                )
                : (
                  <React.Fragment>
                    <div>
                      <span>券ID：</span>
                      <NumberInput
                        value={couponId}
                        width={240}
                        className={`${classNamePre}-input-media-con`}
                        onChange={event => this.onChangeInput('couponId', event)}
                      />
                    </div>
                    <div>
                      <span>券名称：</span>
                      <Input
                        type="text"
                        value={couponName}
                        width={240}
                        className={`${classNamePre}-input-media-con`}
                        onChange={event => this.onChangeInput('couponName', event)}
                      />
                    </div>
                    <div>
                      <span>采购时间：</span>
                      <DateRangePicker
                        width={240}
                        format="YYYY-MM-DD"
                        value={rangeValue}
                        className={`${classNamePre}-input-media-date`}
                        onChange={this.onChangeRange}
                      />
                    </div>
                  </React.Fragment>
                )
            }
          </div>
        </div>
        <div className={`${classNamePre}-export`}>
          <Button
            type="primary"
            onClick={this.onSearch}
          >
            查询
          </Button>
          <Button
            type="primary"
            outline
            onClick={this.onExport}
          >
            导出
          </Button>
        </div>
      </div>
    );
  }
}
