import * as React from 'react';
import {
  Input, Select, Button, NumberInput
} from 'ezrd';
import { platformCuoponType } from './constant';

const classNamePre = 'yiye-coupon-platform-search';

export default class PlatformCouponSearch extends React.Component {
static defaultProps = {
  brandShow: true // 是否显示品牌ID的输入框
}

constructor(prop) {
  super(prop);
  this.state = {
    currentSelect: 'all', // 默认选择全部
    couponId: '', // 券ID
    couponName: '', // 券名字
    brand: '' // 品牌

  };
}

// 券类型选择
onChangeSelect = (e) => {
  this.setState({
    currentSelect: e.target.value
  });
}

// 普通input框的事件回调
onChangeInput = (type, e) => {
  this.setState({
    [type]: e.target.value
  });
}

// 点击查询按钮
onSearch = (flag) => {
  const {
    brand, currentSelect, couponName, couponId
  } = this.state;
  const { onSearch, brandShow } = this.props;
  const params = {
    brand,
    currentSelect: currentSelect === 'all' ? '' : currentSelect,
    couponName,
    couponId
  };
  if (!brandShow) {
    delete params.brand;
  }
  onSearch(params, flag);
}

render() {
  const {
    brand, currentSelect, couponName, couponId
  } = this.state;
  const { brandShow } = this.props;
  return (
    <div className={`${classNamePre}`}>
      <div>
        <div>
          <span>券ID：</span>
          <NumberInput
            value={couponId}
            onChange={event => this.onChangeInput('couponId', event)}
          />
        </div>
        <div>
          <span>券名称：</span>
          <Input
            type="text"
            value={couponName}
            onChange={event => this.onChangeInput('couponName', event)}
          />
        </div>
        {
        brandShow
          ? (
            <div>
              <span>品牌：</span>
              <Input
                type="text"
                value={brand}
                onChange={event => this.onChangeInput('brand', event)}
              />
            </div>
          )
          : null
      }
        <div>
          <span>券类型：</span>
          <Select
            data={platformCuoponType}
            optionValue="type"
            optionText="name"
            width="110px"
            autoWidth
            showClear={false}
            value={currentSelect}
            onChange={this.onChangeSelect}
          />
        </div>
      </div>
      <div>
        <Button
          type="primary"
          onClick={this.onSearch}
        >
        查询
        </Button>
      </div>
    </div>
  );
}
}
