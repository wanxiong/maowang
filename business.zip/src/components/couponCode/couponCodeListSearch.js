import * as React from 'react';
import {
  Input, Select, Button, DateRangePicker
} from 'ezrd';
import { CouponOriginStatus } from '../base/constant';

const classNamePre = 'yiye-coupon-code-search';

export default class CouponCodeListSearch extends React.Component {
static defaultProps = {
  format: 'YYYY-MM-DD',
  showTime: false
}

constructor(prop) {
  super(prop);
  this.state = {
    currentSelect: '-1',
    couponNum: '',
    couponName: '',
    value: ''
  };
}

// 券类型选择
onChangeSelect = (e) => {
  this.setState({
    currentSelect: e.target.value
  });
}

// 普通input框的事件回调
onChangeInput = (type, e) => {
  this.setState({
    [type]: e.target.value
  });
}

onChangeRange = (val) => {
  this.setState({
    value: val
  });
}

// 点击查询按钮
onSearch = (flag) => {
  const {
    currentSelect, couponName, value, couponNum
  } = this.state;
  const { onSearch } = this.props;
  const params = {
    couponName,
    status: currentSelect,
    couponNum,
    time: value
  };
  onSearch(params, flag);
}

render() {
  const {
    currentSelect, couponName, value, couponNum
  } = this.state;
  const { format, showTime } = this.props;
  return (
    <React.Fragment>
      <div className={`${classNamePre}`}>
        <div />
        <div className={`${classNamePre}-top`}>
          <div>
            <div>
              <span>创建时间：</span>
              <DateRangePicker
                className=""
                width={190}
                value={value}
                format={format}
                showTime={showTime}
                onChange={this.onChangeRange}
              />
            </div>
            <div>
              <span>批次号：</span>
              <Input
                type="text"
                value={couponNum}
                onChange={event => this.onChangeInput('couponNum', event)}
              />
            </div>
            <div>
              <span>券码名称：</span>
              <Input
                type="text"
                value={couponName}
                onChange={event => this.onChangeInput('couponName', event)}
              />
            </div>
            <div>
              <span>状态：</span>
              <Select
                data={CouponOriginStatus}
                optionValue="id"
                optionText="name"
                width="180px"
                autoWidth
                showClear={false}
                value={currentSelect}
                onChange={this.onChangeSelect}
              />
            </div>
          </div>
          <div>
            <Button
              type="primary"
              onClick={this.onSearch}
            >
          查询
            </Button>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
}
}
