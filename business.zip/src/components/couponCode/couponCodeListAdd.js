import * as React from 'react';
import {
  Button, Dialog, NumberInput, Notify, Input, DateRangePicker, Radio
} from 'ezrd';
import DefaultTipDialog from '../transaction/defaultTipDialog';

const RadioGroup = Radio.Group;
const classNamePre = 'yiye-coupon-code-dialog';

export default class CouponCodeListAdd extends React.Component {
static defaultProps = {
  showEnableVisible: false,
  onConfim: () => {},
  content: '',
  customFlag: '', // 自定义数据回传
  loading: false,
  data: '',
  maskClosable: false,
  stockNum: ''
}

constructor(props) {
  super(props);
  this.state = {
    value: '',
    showTipDialog: false,
    showYYTip: false
  };
}

triggerDialog = (flag) => {
  const { value } = this.state;
  const { confirmEnable, data } = this.props;
  if (flag && !value) {
    Notify.error('制券数量不能为空');
    return;
  }
  if (!flag) {
    confirmEnable(flag, { value }, () => {
      this.setState({
        value: ''
      });
    });
    return;
  }
  let boo = false;
  if (data.CouponOrigin === 1 && data.CouponType === 'YY') {
    boo = true;
  } else {
    boo = false;
  }
  this.setState({
    showTipDialog: true,
    showYYTip: boo
  });
}

confirm = (flag) => {
  const { confirmEnable, stockNum, data } = this.props;
  const { value } = this.state;
  this.setState({
    showTipDialog: false,
    showYYTip: false
  });
  if (data.CouponOrigin === 1 && data.CouponType === 'YY') {
    if (flag && value > stockNum) {
      Notify.error(`制券所需“${data.CouponGrpName}”库存不足，请补充权益券库存`);
      return;
    }
  }

  if (flag) {
    confirmEnable(true, { value }, () => {
      this.setState({
        value: ''
      });
    });
  }
}

onChange = (e) => {
  this.setState({
    value: e.target.value
  });
}

render() {
  const {
    showEnableVisible, loading, maskClosable, data, stockNum
  } = this.props;
  const { value, showTipDialog, showYYTip } = this.state;
  return (
    <Dialog
      title="增加制券"
      visible={showEnableVisible}
      maskClosable={maskClosable}
      onClose={() => this.triggerDialog(false)}
      style={{ width: '530px' }}
      footer={(
        <div>
          <Button
            loading={loading}
            outline
            onClick={() => this.triggerDialog(false)}
          >
          取消
          </Button>
          <Button
            loading={loading}
            onClick={() => this.triggerDialog(true)}
          >
          确定
          </Button>
        </div>
      )}
    >
      <div className={`${classNamePre}-contain`}>
        <div className={`${classNamePre}-contain-box`}>
          <span className={`${classNamePre}-contain-lable`}>券码名称</span>
          <Input
            width={290}
            value={data.ActName}
            disabled
          />
        </div>
        <div className={`${classNamePre}-contain-box`}>
          <span className={`${classNamePre}-contain-lable`}>券有效期</span>
          <div className={`${classNamePre}-contain-lable-children`}>
            自领取之日起
            <div>
              <Input
                width={80}
                value={data.CouponValidType === 1 ? data.CouponValidDays : ''}
                disabled
              />
            </div>
            天有效
          </div>
        </div>
        <div className={`${classNamePre}-contain-box`}>
          <span className={`${classNamePre}-contain-lable`}>兑换有效期</span>
          <DateRangePicker
            value={data.CouponValidType === 2 ? [data.CouponBeginDate, data.CouponEndDate] : []}
            disabled
          />
        </div>
        <div className={`${classNamePre}-contain-box`}>
          <span className={`${classNamePre}-contain-lable`}>券说明</span>
          <Input
            width={290}
            value={data.CouponRemark}
            type="textarea"
            disabled
          />
        </div>
        <div className={`${classNamePre}-contain-box`}>
          <span className={`${classNamePre}-contain-lable`}>制券方式</span>
          <RadioGroup
            value="1"
            disabled
          >
            <Radio value="1">批次号发券</Radio>
            {
              // <Radio value="2">女</Radio>
            }
          </RadioGroup>
        </div>
        <div className={`${classNamePre}-contain-box`}>
          <span className={`${classNamePre}-contain-lable`}>已制券数量</span>
          <span>
            {data.TotalCount}
          张
          </span>
        </div>
        <div className={`${classNamePre}-contain-box`}>
          <span className={`${classNamePre}-contain-lable`}>加制数量</span>
          <NumberInput
            value={value}
            width={100}
            max={1000000}
            min={1}
            onChange={this.onChange}
            style={{ 'margin-right': '10px' }}
          />
          张
        </div>
      </div>
      { /** 弹出框 */}
      <DefaultTipDialog
        title="确认增加制券"
        content={(
          <React.Fragment>
            {
              showYYTip && (<div style={{ color: 'red' }}>{`制券所需“${data.CouponGrpName}”库存剩余${stockNum}个`}</div>)
            }
            <div>{`确定增加${value}个 “${data.ActName}”券码吗？`}</div>
          </React.Fragment>
        )}
        showEnableVisible={showTipDialog}
        confirmEnable={this.confirm}
        loading={false}
      />
    </Dialog>
  );
}
}
