import * as React from 'react';
import {
  Dialog, Button, NumberInput, Notify, DateRangePicker
} from 'ezrd';
import moment from 'moment';
import ConstBrandSelect from '../base/constBrandSelect';

const classNamePre = 'yiye-couponWriteOff-add';

export default class ChargingSchemeDefaultAdd extends React.Component {
static defaultProps = {
  show: false,
  title: '',
  loading: false,
  serviceMin: 0,
  serviceDecimal: 2,
  serviceLable: '',
  serviceAfterText: '',
  serviceTips: '',
  rateDecimal: 2,
  rateMin: 0,
  rateMax: 100,
  rateLable: '',
  rateTips: '',
  format: 'YYYY-MM-DD',
  filtersId: 'all',
  excludeId: 3,
  defaultMinTime: moment().format('YYYY-MM-DD'),
  timeLable: '方案有效期',
  showRate: false,
  data: ''
}

constructor(props) {
  const { data } = props;
  super(props);
  this.state = {
    serviceCharge: data ? data.serviceCharge : '',
    rate: data ? data.rate : '',
    timeRange: data ? data.timeRange : [],
    brandId: data ? data.brandId : ''
  };
}

onChangeDefault = (type, e) => {
  this.setState({
    [type]: e.target.value
  });
}

closeDialog = () => {
  const { close } = this.props;
  close();
  this.setState({
    serviceCharge: '',
    rate: '',
    timeRange: [],
    brandId: ''
  });
}

onChangeRange = (val) => {
  this.setState({
    timeRange: val
  });
}

// 点击确定的回调
confirm = () => {
  const {
    serviceCharge, rate, timeRange, brandId
  } = this.state;
  const {
    confirm, serviceLable, rateLable, timeLable, showRate
  } = this.props;
  if (!brandId) {
    Notify.error('请选择品牌');
    return;
  }
  if (!serviceCharge && serviceCharge !== 0) {
    Notify.error(`${serviceLable}不能为空`);
    return;
  }
  // 显示费率输入框
  if (showRate) {
    if (!rate && rate !== 0) {
      Notify.error(`${rateLable}不能为空`);
      return;
    }
  }
  if (!timeRange[0] || !timeRange[1]) {
    Notify.error(`${timeLable}不能为空`);
    return;
  }
  confirm({
    serviceCharge,
    rate,
    timeRange,
    brandId
  }, () => {
    this.setState({
      serviceCharge: '',
      rate: '',
      timeRange: [],
      brandId: ''
    });
  });
}

onChange = (value) => {
  this.setState({
    brandId: value
  });
}

componentWillReceiveProps = (props) => {
  if (props.show && props.data) { // 编辑
    const { data } = props;
    this.setState({
      serviceCharge: data ? data.serviceCharge : '',
      rate: data ? data.rate : '',
      timeRange: data ? data.timeRange : [],
      brandId: data ? data.brandId : ''
    });
  }
}

render() {
  const {
    serviceCharge, rate, brandId, timeRange
  } = this.state;
  const {
    show, title, serviceMin, loading, serviceDecimal, rateDecimal, rateMin, format, rateMax, excludeId, rateTips,
    filtersId, serviceLable, rateLable, timeLable, defaultMinTime, serviceAfterText, showRate, serviceTips, data
  } = this.props;
  return (
    <div>
      <Dialog
        title={title}
        visible={show}
        style={{ width: '550px' }}
        className={`${classNamePre}`}
        maskClosable={false}
        footer={(
          <div>
            <Button
              outline
              loading={loading}
              onClick={() => this.closeDialog()}
            >
            取消
            </Button>
            <Button
              loading={loading}
              onClick={() => this.confirm()}
            >
            确定
            </Button>
          </div>
          )}
      >
        <div className={`${classNamePre}-contain`}>
          <div>
            <ConstBrandSelect
              onChange={this.onChange}
              textLable="品牌"
              textLableStyle={`${classNamePre}-contain-lable`}
              width={240}
              value={brandId}
              disabled={data}
              excludeId={excludeId}
              filtersId={filtersId}
            />
          </div>
          <div className={`${classNamePre}-contain-newStyle`}>
            <span className={`${classNamePre}-contain-lable`}>{serviceLable}</span>
            <div>
              <div>
                <NumberInput
                  width={240}
                  value={serviceCharge}
                  min={serviceMin}
                  decimal={serviceDecimal}
                  onChange={(event) => { this.onChangeDefault('serviceCharge', event); }}
                />
                <span
                  className={`${classNamePre}-contain-company`}
                  style={{ 'margin-left': '10px' }}
                >
                  {serviceAfterText}
                </span>
              </div>
              {
                serviceTips && (<div className={`${classNamePre}-contain-tips`}>{serviceTips}</div>)
              }
            </div>
          </div>
          {
            showRate && (
              <div className={`${classNamePre}-contain-newStyle`}>
                <span className={`${classNamePre}-contain-lable`}>{rateLable}</span>
                <div>
                  <div>
                    <NumberInput
                      width={240}
                      value={rate}
                      min={rateMin}
                      max={rateMax}
                      decimal={rateDecimal}
                      onChange={(event) => { this.onChangeDefault('rate', event); }}
                    />
                    <span
                      className={`${classNamePre}-contain-company`}
                      style={{ 'margin-left': '10px' }}
                    >
%
                    </span>
                  </div>
                  {
                    rateTips && (<div className={`${classNamePre}-contain-tips`}>{rateTips}</div>)
                  }
                </div>
              </div>
            )
          }
          <div>
            <span className={`${classNamePre}-contain-lable`}>{timeLable}</span>
            <DateRangePicker
              value={timeRange}
              onChange={this.onChangeRange}
              format={format}
              min={defaultMinTime}
            />
          </div>
        </div>
      </Dialog>

    </div>
  );
}
}
