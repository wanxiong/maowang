import React from 'react';
import { Button, Select } from 'ezrd';
import { platformChargingScheme } from '../base/constant';
import ConstBrandSelect from '../base/constBrandSelect';

const classNamePre = 'yiye-couponWriteOff-search';

class CouponWriteOffSearch extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {
      brandId: '',
      selectValue: ''
    };
  }

  onChange = (value) => {
    this.setState({
      brandId: value
    });
  }

  onChangeSelect = (e) => {
    this.setState({
      selectValue: e.target.value
    });
  }

  // 点击查询按钮
  onSearch = (flag) => {
    const {
      selectValue, brandId
    } = this.state;
    const { onSearch } = this.props;
    const params = {
      selectValue,
      brandId
    };
    onSearch(params, flag);
  }

  render() {
    const { selectValue } = this.state;
    return (
      <div className={classNamePre}>
        <div className={`${classNamePre}-input`}>
          <div>
            <ConstBrandSelect
              onChange={this.onChange}
              textLable="品牌："
              textLableStyle={`${classNamePre}-contain-lable`}
              width={240}
              // filtersId={filtersId}
            />
          </div>
          <div>
            <span>状态：</span>
            <Select
              autoWidth
              data={platformChargingScheme}
              optionText="Name"
              optionValue="Id"
              width={180}
              value={selectValue}
              onChange={this.onChangeSelect}
            />
          </div>
        </div>
        <div>
          <Button onClick={this.onSearch}>查询</Button>
        </div>
      </div>
    );
  }
}

export default CouponWriteOffSearch;
