import * as React from 'react';
import {
  Dialog, Button, DateRangePicker, NumberInput, Notify
} from 'ezrd';
import ConstBrandSelect from '../base/constBrandSelect';
import { division, multiplication } from '../../utils/common';

const classNamePre = 'merchant-transaction-platform-add';

export default class PlatformFeeAdd extends React.Component {
static defaultProps = {
  showTime: true, // 是否显示时间筛选
  show: false,
  text: '',
  decimalRate: 0,
  data: '' // 回显的数据
}

constructor(props) {
  super(props);
  this.state = {
    brandId: props.data.MchId || '',
    fee: props.data.PreferentialFee || '', // 优惠手续费
    newFee: (typeof props.data.ReferrerFee) === 'number' ? props.data.ReferrerFee : '', // 优惠手续费
    feeRate: props.data.PreferentialRate ? multiplication(props.data.PreferentialRate, 100) : '', // 优惠手续费率
    rangeValue: props.data.PreferentialStartDate ? [props.data.PreferentialStartDate, props.data.PreferentialEndDate] : []
  };
}

componentWillReceiveProps(props) {
  if (props.data) {
    this.setState({
      brandId: props.data.MchId || '',
      fee: props.data.PreferentialFee || '', // 优惠手续费
      newFee: (typeof props.data.ReferrerFee) === 'number' ? props.data.ReferrerFee : '', // 优惠手续费
      feeRate: props.data.PreferentialRate ? multiplication(props.data.PreferentialRate, 100) : '', // 优惠手续费率
      rangeValue: props.data.PreferentialStartDate ? [props.data.PreferentialStartDate, props.data.PreferentialEndDate] : []
    });
  }
}

onChange = (id) => {
  this.setState({
    brandId: id
  });
}

onChangeDefault = (type, e) => {
  this.setState({
    [type]: e.target.value
  });
}

closeDialog = () => {
  const { close } = this.props;
  close();
  this.setState({
    brandId: '',
    fee: '',
    feeRate: '',
    newFee: '',
    rangeValue: []
  });
}

onChangeRange = (val) => {
  this.setState({
    rangeValue: val
  });
}

// 点击确定的回调
confirmEdit = () => {
  const {
    brandId, fee, feeRate, rangeValue, newFee
  } = this.state;
  const { confirmAddOrEdit } = this.props;
  if (!brandId) {
    Notify.error('请选择优惠品牌');
    return;
  }
  if (!(`${fee}`)) {
    Notify.error('请输入优惠服务费');
    return;
  }
  // if (!(`${newFee}`)) {
  //   Notify.error('请输入拉新服务费');
  //   return;
  // }
  if (!(`${feeRate}`)) {
    Notify.error('请输入优惠服务费率');
    return;
  }
  if (!rangeValue[0] || !rangeValue[1]) {
    Notify.error('请输入优惠时长');
    return;
  }
  confirmAddOrEdit({
    brandId,
    fee,
    feeRate: division(feeRate, 100),
    rangeValue,
    newFee
  }, () => {
    this.setState({
      brandId: '',
      fee: '',
      newFee: '',
      feeRate: '',
      rangeValue: []
    });
  });
}

render() {
  const {
    rangeValue, feeRate, fee, newFee
  } = this.state;
  const {
    show, decimalRate, text, data: { MchId }
  } = this.props;
  return (
    <Dialog
      title={text}
      visible={show}
      style={{ width: '600px' }}
      className={`${classNamePre}`}
      maskClosable={false}
      footer={(
        <div>
          <Button
            outline
            onClick={() => this.closeDialog()}
          >
          取消
          </Button>
          <Button
            onClick={() => this.confirmEdit()}
          >
          确定
          </Button>
        </div>
        )}
    >
      <div className={`${classNamePre}-contain`}>
        <div>
          <ConstBrandSelect
            onChange={this.onChange}
            textLable="品牌"
            textLableStyle={`${classNamePre}-contain-lable`}
            value={MchId}
            disabled={!!MchId}
            width={395}
          />
        </div>
        <div>
          <span className={`${classNamePre}-contain-lable`}>优惠服务费</span>
          <NumberInput
            width={370}
            value={fee}
            min={0}
            decimal={2}
            onChange={(event) => { this.onChangeDefault('fee', event); }}
          />
          <span className={`${classNamePre}-contain-company`}>元</span>
        </div>
        <div>
          <span className={`${classNamePre}-contain-lable`}>拉新服务费</span>
          <NumberInput
            width={370}
            value={newFee}
            min={0}
            decimal={2}
            onChange={(event) => { this.onChangeDefault('newFee', event); }}
          />
          <span
            className={`${classNamePre}-contain-company`}
            style={{ width: '50px' }}
          >
元/人
          </span>
        </div>
        <div>
          <span className={`${classNamePre}-contain-lable`}>优惠服务费率</span>
          <NumberInput
            width={370}
            value={feeRate}
            min={0}
            max={100}
            decimal={decimalRate}
            onChange={(event) => { this.onChangeDefault('feeRate', event); }}
          />
          <span className={`${classNamePre}-contain-company`}>%</span>
        </div>
        <div>
          <span className={`${classNamePre}-contain-lable`}>优惠时长</span>
          <DateRangePicker
            value={rangeValue}
            showTime
            format="YYYY-MM-DD HH:mm:ss"
            onChange={this.onChangeRange}
            width={180}
          />
        </div>
      </div>
    </Dialog>
  );
}
}
