import * as React from 'react';
import {
  Select, Button, DateRangePicker, Dialog, Input, Notify
} from 'ezrd';
import moment from 'moment';
import { trim } from '../../utils/common';
import ConstBrandSelect from '../base/constBrandSelect';
import { defaultCategorySettingType } from '../base/constant';

const classNamePre = 'merchant-transaction-write-off-search';

export default class WriteOffRateSearch extends React.Component {
static defaultProps = {
  showTime: true, // 是否显示时间筛选
  format: 'YYYY-MM-DD HH:mm:ss',
  data: [], // 下拉框得数据源
  defautlSelect: '',
  show: false,
  typeName: '',
  downloadType: '', // 导出类型
  downloadStore: {}, // 接口store
  statusKey: 'Status' // 默认的类型返回字段
}

constructor(props) {
  super(props);
  this.state = {
    SelectValue: props.defautlSelect || '', // 默认选择全部
    value: '',
    brandId: '',
    taskName: moment().format('YYYY-MM-DD') + props.typeName,
    visible: false,
    loading: false
  };
  this.onSearch = this.onSearch.bind(this);
}

// 券类型选择
onChangeSelect = (e) => {
  this.setState({ SelectValue: e.target.value });
}

onChange = (id) => {
  this.setState({
    brandId: id
  });
}

// 点击查询按钮
onSearch = (flag) => {
  const {
    SelectValue, value, brandId
  } = this.state;
  const { onSearch, statusKey } = this.props;
  onSearch({
    [statusKey]: SelectValue,
    StartDate: value[0] || '',
    EndDate: value[1] || '',
    brandId
  }, flag);
}

onChangeRange = (val) => {
  this.setState({
    value: val
  });
}

// 导出按钮
onExport = () => {
  const { typeName } = this.props;
  this.setState({
    visible: true,
    taskName: moment().format('YYYY-MM-DD') + typeName
  });
}

// 关闭弹出框
closeDialog = () => {
  const { typeName } = this.props;
  this.setState({
    visible: false,
    taskName: moment().format('YYYY-MM-DD') + typeName
  });
}

confirm = async () => {
  const {
    taskName, value, brandId
  } = this.state;
  const { downloadStore, downloadType, history } = this.props;
  if (!trim(taskName)) {
    Notify.error('请输入导出数据的文件名称');
    return;
  }
  this.setState({ loading: true });
  if (downloadType === 'writeOff') {
    const status = await downloadStore.fetchMerchantDefaultExport({
      FileName: taskName,
      SettingType: defaultCategorySettingType.coupon,
      StartDate: value[0],
      EndDate: value[1],
      Status: 9,
      MchId: brandId || 0
    });
    if (status && !status.IsError) {
      this.closeDialog();
      history.push('/Yiye/Download');
    }
  } else if (downloadType === 'assetManage') {
    //
  }
  this.setState({ loading: false });
}

// 普通input框的事件回调
onChangeInput = (type, e) => {
  this.setState({
    [type]: e.target.value
  });
}

render() {
  const {
    value, SelectValue, visible, loading, taskName
  } = this.state;
  const {
    showTime, format, data, show
  } = this.props;
  return (
    <div className={`${classNamePre}`}>
      {/* 基本输入input框 */}
      <div className={`${classNamePre}-top`}>
        <div>
          <span>入驻时间：</span>
          <DateRangePicker
            className=""
            width={190}
            value={value}
            format={format}
            showTime={showTime}
            onChange={this.onChangeRange}
          />
        </div>
        <div>
          <ConstBrandSelect onChange={this.onChange} />
        </div>
        {
          show
            ? (
              <div>
                <span>状态：</span>
                <Select
                  data={data}
                  optionValue="id"
                  optionText="name"
                  width="190px"
                  showClear={false}
                  value={SelectValue}
                  autoWidth
                  onChange={this.onChangeSelect}
                />
              </div>
            )
            : null
        }
      </div>
      {/* 查询--导出 */}
      <div className={`${classNamePre}-btn`}>
        <Button
          type="primary"
          className={`${classNamePre}-btn-1`}
          onClick={this.onSearch}
        >
        查询
        </Button>
        <Button
          type="primary"
          outline
          onClick={this.onExport}
        >
        导出
        </Button>
      </div>
      {/** 导出文件提示框 */}
      <Dialog
        title="导出数据的文件名称"
        visible={visible}
        onClose={() => this.closeDialog()}
        style={{ width: '600px' }}
        maskClosable={false}
        footer={(
          <div>
            <Button
              outline
              loading={loading}
              onClick={() => this.closeDialog()}
            >
              取消
            </Button>
            <Button
              loading={loading}
              onClick={() => this.confirm()}
            >
              确定
            </Button>
          </div>
        )}
      >
        <Input
          signleBorder
          placeholder="请输入导出数据的文件名称"
          showClear
          maxLength={30}
          width="100%"
          value={taskName}
          onChange={event => this.onChangeInput('taskName', event)}
        />
      </Dialog>
    </div>
  );
}
}
