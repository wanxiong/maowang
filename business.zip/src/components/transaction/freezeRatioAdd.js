import * as React from 'react';
import {
  Dialog, Button, DateRangePicker, NumberInput, Notify
} from 'ezrd';
import ConstBrandSelect from '../base/constBrandSelect';
import { division, multiplication } from '../../utils/common';

const classNamePre = 'merchant-transaction-platform-add';

export default class FreezeRatioAdd extends React.Component {
static defaultProps = {
  showTime: true, // 是否显示时间筛选
  show: false,
  text: '',
  decimalRate: 0,
  max: 100,
  data: '' // 回显的数据
}

constructor(props) {
  super(props);
  this.state = {
    brandId: props.data.MchId || '',
    feeRate: props.data.DiscountRate ? multiplication(props.data.DiscountRate, 100) : '', // 优惠手续费率
    rangeValue: props.data.StartDate ? [props.data.StartDate, props.data.EndDate] : []
  };
}

componentWillReceiveProps(props) {
  if (props.data) {
    this.setState({
      brandId: props.data.MchId || '',
      feeRate: props.data.DiscountRate ? multiplication(props.data.DiscountRate, 100) : '', // 优惠手续费率
      rangeValue: props.data.StartDate ? [props.data.StartDate, props.data.EndDate] : []
    });
  }
}

onChange = (id) => {
  this.setState({
    brandId: id
  });
}

onChangeDefault = (type, e) => {
  this.setState({
    [type]: e.target.value
  });
}

closeDialog = () => {
  const { close } = this.props;
  close();
  this.setState({
    brandId: '',
    feeRate: '',
    rangeValue: []
  });
}

onChangeRange = (val) => {
  this.setState({
    rangeValue: val
  });
}

// 点击确定的回调
confirmEdit = () => {
  const {
    brandId, feeRate, rangeValue
  } = this.state;
  const { confirmAddOrEdit } = this.props;
  if (!brandId) {
    Notify.error('请选择优惠品牌');
    return;
  }
  if (!(`${feeRate}`)) {
    Notify.error('请输入优惠冻结比例');
    return;
  }
  if (!rangeValue[0] || !rangeValue[1]) {
    Notify.error('请输入优惠时长');
    return;
  }
  confirmAddOrEdit({
    brandId,
    feeRate: division(feeRate, 100),
    rangeValue
  }, () => {
    this.setState({
      brandId: '',
      feeRate: '',
      rangeValue: []
    });
  });
}

render() {
  const {
    rangeValue, feeRate
  } = this.state;
  const {
    max, show, decimalRate, text, data: { MchId }
  } = this.props;
  return (
    <Dialog
      title={text}
      visible={show}
      style={{ width: '600px' }}
      className={`${classNamePre}`}
      maskClosable={false}
      footer={(
        <div>
          <Button
            outline
            onClick={() => this.closeDialog()}
          >
          取消
          </Button>
          <Button
            onClick={() => this.confirmEdit()}
          >
          确定
          </Button>
        </div>
        )}
    >
      <div className={`${classNamePre}-contain`}>
        <div>
          <ConstBrandSelect
            onChange={this.onChange}
            textLable="品牌"
            textLableStyle={`${classNamePre}-contain-lable`}
            value={MchId}
            disabled={!!MchId}
            width={395}
          />
        </div>
        <div>
          <span className={`${classNamePre}-contain-lable`}>优惠冻结比例</span>
          <NumberInput
            width={370}
            value={feeRate}
            min={0}
            max={max}
            decimal={decimalRate}
            onChange={(event) => { this.onChangeDefault('feeRate', event); }}
          />
          <span className={`${classNamePre}-contain-company`}>%</span>
        </div>
        <div>
          <span className={`${classNamePre}-contain-lable`}>优惠时长</span>
          <DateRangePicker
            value={rangeValue}
            showTime
            format="YYYY-MM-DD HH:mm:ss"
            onChange={this.onChangeRange}
            width={180}
          />
        </div>
      </div>
    </Dialog>
  );
}
}
