import * as React from 'react';
import {
  Button, Dialog
} from 'ezrd';

const classNamePre = 'merchant-transaction-tip-dialog';

export default class DefaultTipDialog extends React.Component {
static defaultProps = {
  showEnableVisible: false,
  onConfim: () => {},
  content: '',
  customFlag: '', // 自定义数据回传
  loading: false,
  maskClosable: true,
  title: ((
    <div className={classNamePre}>
      操作提示
    </div>
  )),
  cancelText: '取消',
  confirmText: '确定'
}

constructor(props) {
  super(props);
  this.state = {
  };
}

triggerDialog = (flag) => {
  const { confirmEnable, customFlag } = this.props;
  confirmEnable(flag, customFlag);
}

render() {
  const {
    showEnableVisible, content, title, loading, maskClosable, cancelText, confirmText
  } = this.props;
  return (
    <Dialog
      title={title}
      visible={showEnableVisible}
      maskClosable={maskClosable}
      onClose={() => this.triggerDialog(false)}
      style={{ width: '450px' }}
      footer={(
        <div>
          <Button
            loading={loading}
            outline
            onClick={() => this.triggerDialog(false)}
          >
            {cancelText}
          </Button>
          <Button
            loading={loading}
            onClick={() => this.triggerDialog(true)}
          >
            {confirmText}
          </Button>
        </div>
      )}
    >
      <div>{content}</div>
    </Dialog>
  );
}
}
