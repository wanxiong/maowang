import * as React from 'react';
import {
  Dialog, Button, NumberInput, Notify
} from 'ezrd';
import ConstBrandSelect from '../base/constBrandSelect';
import { division, multiplication } from '../../utils/common';

const classNamePre = 'merchant-transaction-platform-add';

export default class WriteOffDialog extends React.Component {
static defaultProps = {
  showTime: true, // 是否显示时间筛选
  show: false,
  text: '',
  decimalRate: 0,
  decimalPrice: 0,
  loading: false,
  data: '' // 回显的数据
}

constructor(props) {
  super(props);
  this.state = {
    brandId: props.data.MchId || '',
    price: props.data.price || '',
    feeRate: props.data.PreferentialRate ? multiplication(props.data.PreferentialRate, 100) : '' // 优惠手续费率
  };
}

// componentWillReceiveProps(props) {
//   if (props.data) {
//     this.setState({
//       brandId: props.data.MchId || '',
//       feeRate: props.data.PreferentialRate ? multiplication(props.data.PreferentialRate, 100) : '', // 优惠手续费率
//     });
//   }
// }

onChange = (id) => {
  this.setState({
    brandId: id
  });
}

onChangeDefault = (type, e) => {
  this.setState({
    [type]: e.target.value
  });
}

closeDialog = () => {
  const { close } = this.props;
  close();
  this.setState({
    brandId: '',
    feeRate: '',
    price: ''
  });
}

// 点击确定的回调
confirmEdit = () => {
  const {
    brandId, feeRate, price
  } = this.state;
  const { confirm } = this.props;
  if (!brandId) {
    Notify.error('请选择品牌');
    return;
  }
  if (!price) {
    Notify.error('请输入客单价');
    return;
  }
  if (!feeRate) {
    Notify.error('请输入初始核销率');
    return;
  }

  confirm({
    brandId,
    price,
    feeRate: division(feeRate, 100)
  }, () => {
    this.setState({
      brandId: '',
      feeRate: '',
      price: ''
    });
  });
}

render() {
  const {
    feeRate, price
  } = this.state;
  const {
    show, decimalRate, text, data: { MchId }, decimalPrice, loading
  } = this.props;
  return (
    <Dialog
      title={text}
      visible={show}
      style={{ width: '600px' }}
      className={`${classNamePre}`}
      maskClosable={false}
      footer={(
        <div>
          <Button
            outline
            loading={loading}
            onClick={() => this.closeDialog()}
          >
          取消
          </Button>
          <Button
            loading={loading}
            onClick={() => this.confirmEdit()}
          >
          确定
          </Button>
        </div>
        )}
    >
      <div className={`${classNamePre}-contain`}>
        <div>
          <ConstBrandSelect
            onChange={this.onChange}
            textLable="品牌"
            textLableStyle={`${classNamePre}-contain-lable`}
            value={MchId}
            disabled={!!MchId}
            width={395}
          />
        </div>
        <div>
          <span className={`${classNamePre}-contain-lable`}>客单价</span>
          <NumberInput
            width={370}
            value={price}
            min={0}
            max={100}
            decimal={decimalPrice}
            onChange={(event) => { this.onChangeDefault('price', event); }}
          />
          <span className={`${classNamePre}-contain-company`}>元</span>
        </div>
        <div>
          <span className={`${classNamePre}-contain-lable`}>初始核销率</span>
          <NumberInput
            width={370}
            value={feeRate}
            min={0}
            decimal={decimalRate}
            onChange={(event) => { this.onChangeDefault('feeRate', event); }}
          />
          <span className={`${classNamePre}-contain-company`}>%</span>
        </div>

      </div>
    </Dialog>
  );
}
}
