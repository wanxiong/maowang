import * as React from 'react';
import {
  Select, Button
} from 'ezrd';
import ConstBrandSelect from '../base/constBrandSelect';

const classNamePre = 'merchant-transaction-write-off-search';

export default class PlatformFeeSearch extends React.Component {
static defaultProps = {
  showTime: true, // 是否显示时间筛选
  format: 'YYYY-MM-DD HH:mm:ss',
  data: [], // 下拉框得数据源
  defautlSelect: '',
  statusKey: 'Status' // 默认的类型返回字段
}

constructor(props) {
  super(props);
  this.state = {
    SelectValue: props.defautlSelect || '', // 默认选择全部
    value: '',
    brandId: ''
  };
  this.onSearch = this.onSearch.bind(this);
}

// 券类型选择
onChangeSelect = (e) => {
  this.setState({ SelectValue: e.target.value });
}

onChange = (id) => {
  this.setState({
    brandId: id
  });
}

// 点击查询按钮
onSearch = (flag) => {
  const {
    SelectValue, value, brandId
  } = this.state;
  const { onSearch, statusKey } = this.props;
  onSearch({
    [statusKey]: SelectValue,
    CreateOn: value,
    brandId
  }, flag);
}

onChangeRange = (val) => {
  this.setState({
    value: val
  });
}

// 导出事件
onExport = () => {
  const { onExport, brandShow } = this.props;
  const {
    value
  } = this.state;
  const params = {
    time: value
  };
  if (!brandShow) {
    delete params.brand;
  }

  onExport(params);
}

render() {
  const {
    SelectValue
  } = this.state;
  const { data } = this.props;
  return (
    <div className={`${classNamePre}`}>
      {/* 基本输入input框 */}
      <div className={`${classNamePre}-top`}>
        <div>
          <ConstBrandSelect onChange={this.onChange} />
        </div>
        <div>
          <span>状态：</span>
          <Select
            data={data}
            optionValue="id"
            optionText="name"
            width="190px"
            showClear={false}
            value={SelectValue}
            autoWidth
            onChange={this.onChangeSelect}
          />
        </div>
      </div>
      {/* 采购时间-- 查询--导出 */}
      <div className={`${classNamePre}-btn`}>
        <Button
          type="primary"
          className={`${classNamePre}-btn-1`}
          onClick={this.onSearch}
        >
        查询
        </Button>
      </div>
    </div>
  );
}
}
