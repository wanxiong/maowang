import * as React from 'react';
import {
  DateRangePicker, Button
} from 'ezrd';
import moment from 'moment';
import { downBlob } from '../../utils/common';

const classNamePre = 'yiye-import-coupon-code-search';
export default class ImportYiyeSearch extends React.Component {
// 为了画面不显得那么空 分开2个数组
static defaultProps = {
  data: [],
  importCenterStore: {}
}

constructor(prop) {
  super(prop);
  const nowDate = moment().format("YYYY-MM-DD");
  this.state = {
    rangeValue: [nowDate, nowDate] // 时间区段
  };
}

// 普通input框的事件回调
onChangeInput = (type, e) => {
  this.setState({
    [type]: e.target.value
  });
}

// 时间选择的回调
onChangeRange = (v) => {
  this.setState({ rangeValue: v });
}

// 点击查询按钮
onSearch = (flag) => {
  const {
    rangeValue
  } = this.state;
  const { onSearch } = this.props;
  const params = {
    JobBegDate: rangeValue[0],
    JobDate: rangeValue[1]
  };
  onSearch(params, flag);
}

// 导入模板
onDownLoadExcl = async () => {
  const { importCenterStore } = this.props;
  const blob = await importCenterStore.fetchCouponCodeDownExcel();
  downBlob(blob, '商品模板.xlsx');
}

render() {
  const { rangeValue } = this.state;
  return (
    <div className={`${classNamePre}`}>
      <div className={`${classNamePre}-con`}>
        <div>
          <span>导入日期：</span>
          <DateRangePicker
            width={180}
            format="YYYY-MM-DD"
            value={rangeValue}
            onBeforeClear={() => 0}
            onChange={this.onChangeRange}
          />
        </div>
      </div>
      <div>
        {/* 按钮区域 */}
        <Button
          className={`${classNamePre}-con-btn`}
          type="primary"
          onClick={this.onSearch}
        >
        查询
        </Button>
        <Button
          type="primary"
          outline
          onClick={this.onDownLoadExcl}
        >
        下载导入模板
        </Button>
      </div>
    </div>
  );
}
}
