import * as React from 'react';
import {
  Drawer, Radio, Input, Notify
} from 'ezrd';
import { Chart, Geom, Axis } from "ezr-charts";
// 新建
import '../styles/base/index.less';

const RadioGroup = Radio.Group;
const classNamePre = 'yiye-provide-examine';

// 注入
export default class ProvideOrderExamineDtl extends React.Component {
static defaultProps = {
  visible: false,
  title: '审核',
  saveText: '确定',
  detail: {}
}

constructor(prop) {
  super(prop);
  this.state = {
    width: 755,
    textvalue: '',
    value: ''

  };
}

componentDidMount = async () => {

}

close = () => {
  const { close } = this.props;
  close();
  this.setState({
    value: '',
    textvalue: ''
  });
}

save = () => {
  const { save, Json } = this.props;
  const { value, textvalue } = this.state;
  if (!value) {
    Notify.error('请选择审核同意或者拒绝');
    return;
  }
  if (value === '1' && !textvalue) {
    Notify.error('请输入拒绝原因');
    return;
  }
  save({
    Status: value,
    BackReason: value === '1' ? textvalue : '',
    Id: Json.Id
  });
  this.setState({
    value: '',
    textvalue: ''
  });
}

onChange = (e) => {
  this.setState({ value: e.target.value });
}

handleChange = (e) => {
  this.setState({ textvalue: e.target.value });
}

render() {
  const { width, textvalue, value } = this.state;
  const {
    detail, visible, title, saveText, Json
  } = this.props;
  const cols = {
    month: {
      range: [0, 1]
    }
  };
  return (
    <Drawer
      visible={visible}
      title={title}
      handleClose={this.close}
      handleSave={this.save}
      saveText={saveText}
      width={800}
    >
      <div className={`${classNamePre}-wrapper`}>
        <div className={`${classNamePre}-info`}>
          <div className={`${classNamePre}-info-coupon`}>
            <div className={`${classNamePre}-info-coupon-money`}>
              预计冻结Z币：
              <span>{parseFloat(detail.FreezeCosts).toFixed(2)}</span>
              （
              {detail.ConsumeRateDes}
              ）
            </div>
            {
              detail.IsShowRpt
                ? (
                  <div className={`${classNamePre}-info-coupon-range`}>
                    <div className={`${classNamePre}-info-coupon-charts`}>
                      <p className={`${classNamePre}-info-coupon-charts-shoptip`}>
                        <span>
                          {detail.OutSysName}
                          {/** <font>最多展示供货方门店数最多的30个城市，供参考门店覆盖程度</font> */}
                        </span>
                        <div className={`${classNamePre}-info-coupon-charts-shoptip-name`}>
                          <span>
                            <i />
                            {Json.PurchaseName}
                          </span>
                          <span>
                            <i />
                            我的
                          </span>
                        </div>
                      </p>
                      <div>
                        <Chart
                          height={200}
                          width={width}
                          data={detail.ShopCount || []}
                          scale={cols}
                          padding="auto"
                        >
                          {
                            //  <Legend />
                          }
                          <Axis name="month" />
                          <Axis
                            name="temperature"
                            visible={false}
                          />

                          {
                            // <Tooltip
                            //   crosshairs={{
                            //     type: "y"
                            //   }}
                            // />
                          }
                          <Geom
                            type="line"
                            position="month*temperature"
                            size={2}
                            color={['city', ['#8BC34A', '#F76857']]}
                            shape="smooth"
                          />
                        </Chart>
                      </div>
                    </div>
                  </div>
                )
                : null
            }
            <div className={`${classNamePre}-info-coupon-status`}>
              <span>审核：</span>
              <RadioGroup
                onChange={
                  this.onChange
                }
                value={
                  value
                }
              >
                <Radio value="2">同意</Radio>
                <Radio value="1">拒绝</Radio>
              </RadioGroup>
            </div>
            {
              value === '1'
                ? (
                  <div className={`${classNamePre}-info-coupon-reason`}>
                    <span>拒绝原因:</span>
                    <Input
                      type="textarea"
                      width={320}
                      className={`${classNamePre}-info-coupon-area`}
                      value={textvalue}
                      onChange={this.handleChange}
                    />
                  </div>
                )
                : null
            }
          </div>
        </div>
      </div>
    </Drawer>
  );
}
}
