import * as React from 'react';
import {
  Input, DateRangePicker, Button, Select
} from 'ezrd';

const classNamePre = 'yiye-download-search';

export default class DownloadSearch extends React.Component {
// 为了画面不显得那么空 分开2个数组
static defaultProps = {
  data: []
}

constructor(prop) {
  super(prop);
  this.state = {
    currentSelect: '', // 下载类型
    fileName: '', // 文件名称
    rangeValue: [] // 时间区段
  };
}

// 普通input框的事件回调
onChangeInput = (type, e) => {
  this.setState({
    [type]: e.target.value
  });
}

// 时间选择的回调
onChangeRange = (v) => {
  this.setState({ rangeValue: v });
}

// 下拉框的回调
onChangeSelect = (e, select) => {
  this.setState({
    currentSelect: select.value === null ? '' : select.value
  });
}

// 点击查询按钮
onSearch = (flag) => {
  const {
    rangeValue, fileName, currentSelect
  } = this.state;
  const { onSearch } = this.props;
  const params = {
    fileName,
    currentSelect,
    rangeValue
  };
  onSearch(params, flag);
}

render() {
  const { fileName, rangeValue, currentSelect } = this.state;
  const { data } = this.props;
  return (
    <div className={`${classNamePre}`}>
      <div className={`${classNamePre}-con`}>
        <div>
          <span>下载类型：</span>
          <Select
            data={data}
            optionValue="Id"
            optionText="Name"
            width="190px"
            showClear
            autoWidth
            value={currentSelect}
            onChange={this.onChangeSelect}
          />
        </div>
        <div>
          <span>文件名称：</span>
          <Input
            type="text"
            value={fileName}
            width="190px"
            onChange={event => this.onChangeInput('fileName', event)}
          />
        </div>
        <div>
          <span>下载日期：</span>
          <DateRangePicker
            width={180}
            format="YYYY-MM-DD"
            value={rangeValue}
            onChange={this.onChangeRange}
          />
        </div>
      </div>
      <div>
        {/* 按钮区域 */}
        <Button
          className={`${classNamePre}-con-btn`}
          type="primary"
          onClick={this.onSearch}
        >
        查询
        </Button>
      </div>
    </div>
  );
}
}
