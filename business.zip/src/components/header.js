import * as React from 'react';
import { inject } from 'mobx-react';
import {
  Notify, Loading
} from 'ezrd';
import { LoginToken } from './base/constant';
import { delCookie } from '../utils/common';

const classNamePre = 'yiye-header-contain-con';

@inject('loginStore')
export default class ProvideOrderExamineDtl extends React.Component {
static defaultProps = {
  visible: false
}

constructor(prop) {
  super(prop);
  this.state = {
    loading: false,
    userName: '',
    imgUrl: 'http://assets-img.ezrpro.com/pc/icon/goods/yiye_avatar_icon.png'
  };
}

componentDidMount = async () => {
  const { imgUrl } = this.state;
  const loginInfo = localStorage.getItem(LoginToken);
  if (loginInfo) {
    try {
      const parseInfo = JSON.parse(loginInfo);
      const name = parseInfo.UserName || parseInfo.MchName || '';
      const url = parseInfo.MchLogoFull || imgUrl;
      this.setState({
        userName: name,
        imgUrl: url
      });
    } catch (error) {
      // console.log(error)
    }
  }
}

// 退出登陆
logout = async () => {
  const { history, loginStore } = this.props;
  this.setState({ loading: true });
  const status = await loginStore.fetchLogout({});
  if (status && !status.IsError) {
    Notify.success('退出成功');
    localStorage.clear();
    delCookie('MerchantId');
    history.push('/login');
  }
  this.setState({ loading: false });
}

render() {
  const { loading, userName, imgUrl } = this.state;
  return (
    <div className={classNamePre}>
      <div className={`${classNamePre}-img`}>
        <img
          src="http://assets-img.ezrpro.com/pc/icon/goods/yiye_logo_icon.png"
          alt="logo"
        />
      </div>
      <div className={`${classNamePre}-login-menu`}>
        <img
          src={imgUrl}
          alt="头像"
        />
        <ul>
          <li className={`${classNamePre}-login-menu-item`}>{userName}</li>
          <li className={`${classNamePre}-login-menu-item`}>
            <span
              onClick={this.logout}
              role="button"
              tabIndex="0"
              className="yiye-outline "
            >
              退出
            </span>
          </li>
        </ul>
      </div>
      {/** loading */}
      <Loading
        float
        show={loading}
      />
    </div>
  );
}
}
