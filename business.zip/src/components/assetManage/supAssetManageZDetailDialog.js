import * as React from 'react';
import {
  Dialog, Button, NumberInput, Notify
} from 'ezrd';
import ConstBrandSelect from '../base/constBrandSelect';
import DefaultTipDialog from '../transaction/defaultTipDialog';

const classNamePre = 'yiye-asset-manage-recharge-add';

export default class SupAssetManageZDetailDialog extends React.Component {
static defaultProps = {
  showTime: true, // 是否显示时间筛选
  show: false,
  text: '',
  decimalMoney: 0,
  loading: false,
  min: 0,
  filtersId: 1
}

constructor(props) {
  super(props);
  this.state = {
    brandId: '',
    money: '',
    showConfirm: false,
    name: ''
  };
}


onChange = (id, name) => {
  this.setState({
    brandId: id,
    name
  });
}

onChangeDefault = (type, e) => {
  this.setState({
    [type]: e.target.value
  });
}

closeDialog = () => {
  const { close } = this.props;
  close();
  this.setState({
    brandId: '',
    money: ''
  });
}

// 点击确定的回调
confirmEdit = () => {
  const {
    brandId, money
  } = this.state;
  if (!brandId) {
    Notify.error('请选择品牌');
    return;
  }
  if (!money) {
    Notify.error('请输入赠送金额');
    return;
  }
  this.setState({
    showConfirm: true
  });
}

// 最终的弹框
finalyConfirm = (falg) => {
  const { confirm } = this.props;
  const {
    brandId, money
  } = this.state;
  if (!falg) {
    this.setState({ showConfirm: false });
    return;
  }
  this.setState({
    showConfirm: false
  });
  confirm({
    brandId,
    money
  }, () => {
    this.setState({
      brandId: '',
      money: '',
      showConfirm: false,
      name: ''
    });
  });
}

render() {
  const {
    money, showConfirm, name
  } = this.state;
  const {
    show, text, decimalMoney, loading, min, filtersId
  } = this.props;
  return (
    <div>
      <Dialog
        title={text}
        visible={show}
        style={{ width: '500px' }}
        className={`${classNamePre}`}
        maskClosable={false}
        footer={(
          <div>
            <Button
              outline
              loading={loading}
              onClick={() => this.closeDialog()}
            >
            取消
            </Button>
            <Button
              loading={loading}
              onClick={() => this.confirmEdit()}
            >
            确定
            </Button>
          </div>
          )}
      >
        <div className={`${classNamePre}-contain`}>
          <div>
            <ConstBrandSelect
              onChange={this.onChange}
              textLable="品牌"
              textLableStyle={`${classNamePre}-contain-lable`}
              width={295}
              filtersId={filtersId}
            />
          </div>
          <div>
            <span className={`${classNamePre}-contain-lable`}>赠送金额</span>
            <NumberInput
              width={295}
              value={money}
              min={min}
              decimal={decimalMoney}
              onChange={(event) => { this.onChangeDefault('money', event); }}
            />
            <span
              className={`${classNamePre}-contain-company`}
              style={{ 'margin-left': '10px' }}
            >
            Z币
            </span>
          </div>
        </div>
      </Dialog>
      {/** 最终确认弹出框 */}
      <DefaultTipDialog
        showEnableVisible={showConfirm}
        content="确认操作后，入账到品牌客户的Z币账户"
        loading={false}
        confirmEnable={this.finalyConfirm}
        title={`确定给${name}赠送${money}Z币吗`}
      />
    </div>
  );
}
}
