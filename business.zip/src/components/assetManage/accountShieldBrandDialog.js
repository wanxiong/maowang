import * as React from 'react';
import {
  Button, Table, Notify, Dialog, Select
} from 'ezrd';
// 新建
// import moment from 'moment';
import { couponDefaultPage } from "../base/constant";
import { getMchId } from '../../utils/common';
import ConstBrandSelect from '../base/constBrandSelect';

// 注入
export default class AccountShieldBrandDialog extends React.Component {
static defaultProps = {
  classNamePre: '',
  showDialog: false,
  category: [], // 分类的数据源
  industry: [], // 行业数据 一级
  radioValue: '2' // 接口需要的参数
}

constructor(prop) {
  super(prop);
  this.state = {
    selectedRowKeys: [],
    industryValue: '',
    data: [],
    brandId: '',
    count: 0,
    ...couponDefaultPage
  };
}

componentDidMount = async () => {

}

componentWillReceiveProps(props) {
  if (props.showDialog) {
    this.initData();
  }
}

onChange(conf) {
  const { pageSize, current } = this.state;
  if (conf.pageSize && conf.pageSize !== pageSize) {
    this.setState({
      pageSize: conf.pageSize,
      current: 1
    }, () => {
      this.initData();
    });
  }
  if (conf.current && conf.current !== current) {
    this.setState({
      current: conf.current
    }, () => {
      this.initData();
    });
  }
}

// 获取所有可添加的品牌数据
initData = async () => {
  const { accountStore } = this.props;
  const {
    pageSize, current, brandId, industryValue
  } = this.state;
  const params = {
    MchId: getMchId(),
    PageSize: pageSize,
    Page: current,
    QueryMchId: brandId,
    IndustryId: industryValue,
    MerchantType: '1'
  };
  const status = await accountStore.fetchAccountBrandList(params);
  if (!status.IsError) {
    this.setState({
      count: status.Data.Count,
      data: status.Data.Data
    });
  }
}

onSelect = (selectedRowKeys) => {
  // if (selectedRowKeys.length) {
  //   Notify.success(JSON.stringify(selectedRowKeys));
  // }
  this.setState({
    selectedRowKeys
  });
}

// 取消弹框
cancel = () => {
  const { cancel } = this.props;
  cancel(() => {
    this.setState({
      selectedRowKeys: [],
      brandId: '',
      industryValue: '',
      pageSize: couponDefaultPage.pageSize,
      current: couponDefaultPage.current
    });
  });
}

confirm = () => {
  const { selectedRowKeys } = this.state;
  const { confirm } = this.props;
  if (!selectedRowKeys.length) {
    Notify.error('请选择需要屏蔽的品牌');
    return;
  }
  confirm(selectedRowKeys.join(','), () => {
    this.setState({
      selectedRowKeys: [],
      brandId: '',
      industryValue: '',
      pageSize: couponDefaultPage.pageSize,
      current: couponDefaultPage.current
    });
  });
}

// 品牌的回调
onBrandChange = (id) => {
  this.setState({
    brandId: id
  });
}


// 行业的回调
onIndustryChange = async (e) => {
  this.setState({
    industryValue: e.target.value
  });
}

// 点击查询的回调
onSearch = () => {
  const { current } = this.state;
  if (current !== 1) {
    this.setState({
      current: 1
    }, () => {
      this.initData();
    });
    return;
  }
  this.initData();
}

// 添加屏蔽类目的回调
render() {
  const { classNamePre, showDialog, industry } = this.props;
  const {
    current, pageSizeList, count, data, selectedRowKeys, brandId, industryValue
  } = this.state;
  const columns = [
    {
      title: '品牌',
      bodyRender: item => <div>{item.MerchantName}</div>
    },
    {
      title: '所属行业',
      bodyRender: item => <div>{item.IndustryName}</div>
    }
  ];
  return (
    <Dialog
      title="添加品牌"
      visible={showDialog}
      style={{ width: '650px' }}
      maskClosable={false}
      footer={(
        <div className={`${classNamePre}-btn`}>
          <Button
            outline
            onClick={this.cancel}
          >
          取消
          </Button>
          <Button onClick={this.confirm}>添加</Button>
        </div>
      )}
      className={`${classNamePre}-dialog`}
    >
      <div className={`${classNamePre}`}>
        {/* 检索区域 */}
        <div className={`${classNamePre}-search`}>
          <div className={`${classNamePre}-search-box`}>
            <ConstBrandSelect
              onChange={this.onBrandChange}
              value={brandId}
            />
            <div>
              <span>行业：</span>
              <Select
                showClear
                data={industry}
                value={industryValue}
                onChange={this.onIndustryChange}
                optionText="Name"
                optionValue="Id"
                autoWidth
                width="180px"
              />
            </div>
            <Button onClick={this.onSearch}>查询</Button>
          </div>
        </div>
        {/* 已经添加的品牌列表 */}
        <div>
          <Table
            columns={columns}
            datasets={data}
            className={`${classNamePre}-table`}
            rowKey="Id"
            pageInfo={{
              pageSize: pageSizeList,
              current,
              totalItem: count
            }}
            onChange={(conf) => {
              this.onChange(conf);
            }}
            selection={{
              selectedRowKeys,
              needCrossPage: true,
              onSelect: (selectedRowkeys, selectedRows, currentRow) => {
                this.onSelect(selectedRowkeys, selectedRows, currentRow);
              }
            }}
          />
        </div>
      </div>
    </Dialog>
  );
}
}
