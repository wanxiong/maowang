import * as React from 'react';
import {
  Button, Dialog, NumberInput, Select, Input, Notify, Radio
} from 'ezrd';
import { ConstFormUpload } from '../base/constFormImage';
import { trim, textAreaBr } from '../../utils/common';

const classNameRechargePre = 'merchant-asset-recharge-dialog';
const RadioGroup = Radio.Group;

export default class RechargeDialog extends React.Component {
  static defaultProps = {
    show: true,
    title: '新增转账',
    money: 0,
    selectList: [],
    selectKey: 'BankName',
    selectValue: 'BankName',
    maskClosable: false,
    min1: 0,
    isCheckNumber: false, // 校验充值是否超过余额
    updateJson: {}, // 需要填充的数据源
    isUpdate: false, // 自定义Boolean回传参数
    loading: false,
    decimal: 2,
    isShowAudit: false, // 是否显示充值审核输入框
    isShowBank: false, // 是否显示银行配置
    showMoney: true, // 是否显示账户余额
    moneyTitle: '金额',
    moneyCkeckText: '充值金额',
    disabled: false,
    isShowRemark: false,
    footerGrp: 'default' // 自定义确定 返回控制
  }

  constructor(props) {
    super(props);
    this.state = {
      selectChangeValue: props.updateJson.BankName || '',
      moneyValue: props.updateJson.CashCount || '',
      flowValue: props.updateJson.BankRecordNo || '',
      imageValue: {
        src: props.updateJson.ImageData || ''
      },
      auditStatus: '1',
      remark: ''
    };
  }

  componentWillReceiveProps(props) {
    this.setState({
      selectChangeValue: props.updateJson.BankName,
      moneyValue: props.updateJson.CashCount || '',
      flowValue: props.updateJson.BankRecordNo || '',
      imageValue: {
        src: props.updateJson.ImageData || ''
      }
    });
  }

  inputChange = (type, event) => {
    this.setState({ [type]: event.target.value });
  }

  onClose = () => {
    const { onClose } = this.props;
    onClose();
  }

  onConfirm = () => {
    const {
      onConfirm, isShowBank, isUpdate, isCheckNumber, money, isShowAudit, moneyCkeckText
    } = this.props;
    const {
      selectChangeValue, flowValue, moneyValue, imageValue, auditStatus, remark
    } = this.state;
    // 充值审核弹框
    if (isShowAudit) {
      if (!trim(remark) && auditStatus === '0') {
        Notify.error('拒绝原因不能为空');
        return;
      }
      const par = auditStatus === '1'
        ? { auditStatus }
        : { auditStatus, remark: trim(remark) };
      onConfirm(
        par, () => {
          this.setState({
            auditStatus: 1,
            remark: ''
          });
        }, isUpdate
      );
      return;
    }
    // 充值新增编辑弹框
    if (isShowBank) {
      if (!moneyValue) {
        Notify.error('转账金额不能为空');
        return;
      }
      if (!flowValue) {
        Notify.error('转账流水不能为空');
        return;
      }
      if (!selectChangeValue) {
        Notify.error('转账银行不能为空');
        return;
      }
      if (!imageValue.src) {
        Notify.error('流水凭证照片不能为空');
        return;
      }
      onConfirm({
        selectChangeValue,
        moneyValue,
        flowValue,
        file: imageValue
      }, () => {
        this.setState({
          selectChangeValue: '',
          moneyValue: '',
          flowValue: '',
          imageValue: {}
        });
      }, isUpdate);
    } else {
      if (!moneyValue) {
        Notify.error(`${moneyCkeckText}不能为空`);
        return;
      }
      if (isCheckNumber && moneyValue > money) {
        Notify.error(`${moneyCkeckText}不能超过${money}元`);
        return;
      }
      onConfirm({ moneyValue }, () => {
        this.setState({
          moneyValue: ''
        });
      }, isUpdate);
    }
  }

  selectChange = (event, data) => {
    this.setState({ selectChangeValue: data.BankName });
  }

  onChangeImage = (data) => {
    this.setState({
      imageValue: data
    });
  }

  onChangeAudit = (e) => {
    this.setState({
      auditStatus: e.target.value
    });
  }

  toPage = () => {
    const { history, url } = this.props;
    history.push(url);
  }

  render() {
    const {
      selectChangeValue, moneyValue, flowValue, imageValue, auditStatus, remark
    } = this.state;
    const {
      show, title, money, selectList, selectKey, selectValue, isShowBank, maskClosable, min1,
      loading, decimal, isShowAudit, disabled, moneyTitle, footerGrp, isShowRemark, showMoney, updateJson
    } = this.props;
    return (
      <div>
        <Dialog
          visible={show}
          title={title}
          onClose={this.onClose}
          style={{ width: '450px' }}
          maskClosable={maskClosable}
          className={`${classNameRechargePre}`}
          footer={
            footerGrp === 'default'
              ? (
                <div className={`${classNameRechargePre}-con-btn`}>
                  <Button
                    type="primary"
                    outline
                    size="middle"
                    loading={loading}
                    onClick={this.onClose}
                  >
                  取消
                  </Button>
                  <Button
                    type="primary"
                    size="middle"
                    loading={loading}
                    onClick={this.onConfirm}
                  >
                  确定
                  </Button>
                </div>
              )
              : (
                <div className={`${classNameRechargePre}-con-btn`}>
                  <Button
                    type="primary"
                    size="middle"
                    loading={loading}
                    onClick={this.onClose}
                  >
                返回
                  </Button>
                </div>
              )
          }
        >

          <div className={`${classNameRechargePre}-con`}>
            {/** 是否显示余额 */}
            {
              showMoney
                ? (
                  <div className={`${classNameRechargePre}-con-title`}>
                    <span>余额</span>
                    <div>
                      <span>{money.toFixed(2)}</span>
                      <span>元</span>
                      {
                        isShowBank
                          ? null
                          : (
                            <span
                              role="button"
                              tabIndex="0"
                              onClick={this.toPage}
                              className={`${classNameRechargePre}-con-title-recharge`}
                            >
                            充值
                            </span>
                          )
                      }
                    </div>
                  </div>
                )
                : null
            }
            {
              isShowBank
                ? (
                  <React.Fragment>
                    <div className={`${classNameRechargePre}-con-form`}>
                      <span>
                        <font>*</font>
                        {' '}
                        {moneyTitle}
                      </span>
                      <div>
                        <NumberInput
                          min={min1}
                          width={240}
                          decimal={decimal}
                          value={moneyValue}
                          disabled={disabled}
                          onChange={event => this.inputChange('moneyValue', event)}
                        />
                        <font>元</font>
                      </div>
                    </div>
                    <div className={`${classNameRechargePre}-con-form`}>
                      <span>
                        <font>*</font>
                        {' '}
                        转账银行
                      </span>
                      <div>
                        <Select
                          width={240}
                          autoWidth
                          data={selectList}
                          optionText={selectKey}
                          optionValue={selectValue}
                          onChange={this.selectChange}
                          value={selectChangeValue}
                          disabled={disabled}
                        />
                      </div>
                    </div>
                    <div className={`${classNameRechargePre}-con-form`}>
                      <span>
                        <font>*</font>
                        {' '}
                        转账流水
                        {' '}
                      </span>
                      <div>
                        <Input
                          width={240}
                          value={flowValue}
                          disabled={disabled}
                          onChange={event => this.inputChange('flowValue', event)}
                        />
                      </div>
                    </div>
                    <div className={`${classNameRechargePre}-con-form ${classNameRechargePre}-con-form-img`}>
                      <span>
                        <font>*</font>
                        {' '}
                        流水凭证照片
                        {' '}
                      </span>
                      <div>
                        <ConstFormUpload
                          tips=""
                          disabled={disabled}
                          value={imageValue}
                          maxSizeErr="图片最大不能超过1MB"
                          maxSize={1024 * 1024 * 1}
                          onChange={this.onChangeImage}
                        />
                      </div>
                    </div>
                  </React.Fragment>
                )
                : (
                  <div className={`${classNameRechargePre}-con-form`}>
                    <span>
                      <font>*</font>
                      {' '}
                      {moneyTitle}
                    </span>
                    <div>
                      <NumberInput
                        value={moneyValue}
                        decimal={decimal}
                        min={min1}
                        onChange={event => this.inputChange('moneyValue', event)}
                        width={240}
                      />
                    </div>
                  </div>
                )
            }
            {/** 是否显示充值审核弹出框 */}
            {
              isShowAudit
                ? (
                  <React.Fragment>
                    <div className={`${classNameRechargePre}-con-form`}>
                      <span>
                        <font>*</font>
                        {' '}
                      审核
                      </span>
                      <div>
                        <RadioGroup
                          onChange={this.onChangeAudit}
                          value={auditStatus}
                        >
                          <Radio value="1">通过</Radio>
                          <Radio value="0">拒绝</Radio>
                        </RadioGroup>
                      </div>
                    </div>
                    {
                    auditStatus === '0'
                      && (
                        <div className={`${classNameRechargePre}-con-form`}>
                          <span>
                            <font>*</font>
                            {' '}
                          拒绝原因
                          </span>
                          <div>
                            <Input
                              type="textarea"
                              width={240}
                              value={remark}
                              onChange={event => this.inputChange('remark', event)}
                              autoSize
                            />
                          </div>
                        </div>
                      )
                  }
                  </React.Fragment>
                )
                : null
            }
            {/** 是否显示审核通过或者失败的原因 */}
            {
              isShowRemark
                ? (
                  <React.Fragment>
                    <div className={`${classNameRechargePre}-con-form`}>
                      <span>
                      状态
                      </span>
                      <div>
                        {
                        updateJson.Status === 2
                          ? (
                            '已入账'
                          )
                          : null
                      }
                        {
                        updateJson.Status === -2
                          ? (
                            '审核失败'
                          )
                          : null
                      }
                      </div>
                    </div>
                    {
                      (isShowRemark && updateJson.Status === -2) ? (
                        <div className={`${classNameRechargePre}-con-form`}>
                          <span />
                          { /* eslint-disable */ }
                          <div dangerouslySetInnerHTML={{ __html: textAreaBr(updateJson.Remark) }} />
                          { /* eslint-enable */ }
                        </div>
                      ) : null
                    }
                  </React.Fragment>
                )
                : null
            }
          </div>
        </Dialog>
      </div>
    );
  }
}
