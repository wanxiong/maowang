import * as React from 'react';
import {
  Button, Table, Notify
} from 'ezrd';
// 新建
import moment from 'moment';
import { couponDefaultPage, defaultCategorySettingType } from "../base/constant";
import { getMchId } from '../../utils/common';
import AccountShieldBrandDialog from './accountShieldBrandDialog';
import DefaultTipDialog from '../transaction/defaultTipDialog';

// 注入
export default class AccountShieldBrand extends React.Component {
static defaultProps = {
  classNamePre: '',
  industry: [], // 行业数据
  radioValue: '2', // 接口需要的参数
  chooseCateList: [{ Id: 1 }] // 已选择的类目
}

constructor(prop) {
  super(prop);
  this.state = {
    showDialog: false,
    showDelDialog: false,
    dataList: [],
    delJson: {},
    delLoading: false,
    count: 0,
    ...couponDefaultPage
  };
}

componentDidMount = async () => {
  this.initBrandList();
}

triggerDialog = () => {
  this.setState({ showDialog: true });
};

// 分页的回调
onChange = (data) => {
  let { current } = this.state;
  const { pageSize } = this.state;
  if (data.pageSize) {
    if (data.pageSize === pageSize) {
      return;
    }
    current = 1;
  }
  this.setState({
    pageSize: data.pageSize || pageSize,
    current: data.current || current
  }, () => {
    this.initBrandList();
  });
}

// 删除的回调
removeItem = async (data) => {
  const { accountStore, radioValue } = this.props;
  this.setState({ delLoading: true });
  const params = {
    MchId: getMchId(),
    SettingType: defaultCategorySettingType.coupon,
    SelectedType: radioValue,
    SelectedId: data.SelectedId
  };
  const status = await accountStore.fetchGetAccountShieldDelItem(params);
  if (!status.IsError) {
    Notify.success('删除成功');
    this.initBrandList();
    this.delConfirm(false);
  }
  this.setState({ delLoading: false });
}

// 获取屏蔽的品牌列表
initBrandList = async () => {
  const { accountStore, radioValue } = this.props;
  const { pageSize, current } = this.state;
  const params = {
    MchId: getMchId(),
    SettingType: defaultCategorySettingType.coupon,
    SelectedType: radioValue,
    PageSize: pageSize,
    Page: current
  };
  const status = await accountStore.fetchGetAccountShieldItemList(params);
  if (status && !status.IsError) {
    this.setState({
      dataList: status.Data.Data,
      count: status.Data.Count
    });
  }
}

// 关闭弹出框
onCancel = (fn) => {
  this.setState({ showDialog: false });
  fn();
}

// 确认的回调事件
onConfirm = async (value, fn) => {
  const { accountStore, radioValue } = this.props;
  const params = {
    MchId: getMchId(),
    SettingType: defaultCategorySettingType.coupon,
    SelectedType: radioValue,
    SelectedIds: value
  };
  const status = await accountStore.fetchGetAccountShieldItem(params);
  if (status && !status.IsError) {
    Notify.success('添加成功');
    this.initBrandList();
    fn();
  }
  this.setState({ showDialog: false });
}

// 删除提示框的回调
delConfirm = (flag) => {
  const { delJson } = this.state;
  if (!flag) {
    this.setState({
      showDelDialog: false,
      delJson: {}
    });
  } else {
    this.removeItem(delJson);
  }
}

// 显示删除提示
showDelTip = (data) => {
  this.setState({ showDelDialog: true, delJson: data });
}

// 添加屏蔽类目的回调
render() {
  const { classNamePre, accountStore, industry } = this.props;
  const {
    current, pageSizeList, showDialog, dataList, count, showDelDialog, delLoading
  } = this.state;
  const columns = [
    {
      title: '品牌',
      bodyRender: data => <div>{data.SelecteName}</div>
    },
    {
      title: '所属行业',
      bodyRender: data => <div>{data.Label}</div>
    },
    {
      title: '添加时间',
      bodyRender: data => <div>{moment(data.CreateOn).format('YYYY-MM-DD HH:mm:ss')}</div>
    },
    {
      title: '操作',
      bodyRender: data => (
        <span
          role="button"
          tabIndex="0"
          className="yiye-outline btn-default-color yiye-cursor"
          onClick={() => this.showDelTip(data)}
        >
            删除
        </span>
      )
    }
  ];
  return (
    <div className={`${classNamePre}-right`}>
      <div className={`${classNamePre}-right-grp-btn`}>
        <Button onClick={() => this.triggerDialog()}>添加品牌</Button>
      </div>
      {/* 已经添加的品牌列表 */}
      <div>
        <Table
          columns={columns}
          datasets={dataList}
          rowKey="id"
          pageInfo={{
            totalItem: count,
            current,
            pageSize: pageSizeList
          }}
          onChange={this.onChange}
        />
      </div>
      {}

      <AccountShieldBrandDialog
        accountStore={accountStore}
        classNamePre={`${classNamePre}-right-brand`}
        showDialog={showDialog}
        cancel={this.onCancel}
        confirm={this.onConfirm}
        industry={industry}
      />
      {/** 删除提示框 */}
      <DefaultTipDialog
        showEnableVisible={showDelDialog}
        confirmEnable={this.delConfirm}
        delLoading={delLoading}
        content="是否确认删除"

      />
    </div>
  );
}
}
