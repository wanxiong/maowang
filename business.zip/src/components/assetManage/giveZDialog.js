import * as React from 'react';
import {
  Button, Dialog, NumberInput, Notify
} from 'ezrd';

const classNameRechargePre = 'merchant-asset-recharge-dialog';

export default class GiveZDialog extends React.Component {
  static defaultProps = {
    show: true,
    title: '赠送',
    titleEmpty: '赠送金额不能为空',
    maskClosable: false,
    min1: 0,
    isUpdate: false, // 自定义Boolean回传参数
    loading: false,
    decimal: 2
  }

  constructor(props) {
    super(props);
    this.state = {
      moneyValue: ''
    };
  }

  inputChange = (type, event) => {
    this.setState({ [type]: event.target.value });
  }

  onClose = () => {
    const { onClose } = this.props;
    onClose();
  }

  onConfirm = () => {
    const {
      onConfirm, isUpdate, titleEmpty
    } = this.props;
    const {
      moneyValue
    } = this.state;

    if (!moneyValue) {
      Notify.error(titleEmpty);
      return;
    }
    onConfirm({ moneyValue }, () => {
      this.setState({
        moneyValue: ''
      });
    }, isUpdate);
  }

  render() {
    const {
      moneyValue
    } = this.state;
    const {
      show, title, maskClosable, min1, loading, decimal
    } = this.props;
    return (
      <div>
        <Dialog
          visible={show}
          title={title}
          onClose={this.onClose}
          style={{ width: '450px' }}
          maskClosable={maskClosable}
          className={`${classNameRechargePre}`}
          footer={(
            <div className={`${classNameRechargePre}-con-btn`}>
              <Button
                type="primary"
                outline
                size="middle"
                loading={loading}
                onClick={this.onClose}
              >
              取消
              </Button>
              <Button
                type="primary"
                size="middle"
                loading={loading}
                onClick={this.onConfirm}
              >
              确定
              </Button>
            </div>
          )}
        >
          <div className={`${classNameRechargePre}-con`}>
            <div className={`${classNameRechargePre}-con-form`}>
              <span>
                <font>*</font>
                {' '}
                赠送金额
              </span>
              <div>
                <NumberInput
                  value={moneyValue}
                  decimal={decimal}
                  min={min1}
                  onChange={event => this.inputChange('moneyValue', event)}
                  width={240}
                />
              </div>
            </div>
          </div>
        </Dialog>
      </div>
    );
  }
}
