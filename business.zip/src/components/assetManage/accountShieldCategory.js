import * as React from 'react';
import {
  Button, Dialog, Cascader, Notify
} from 'ezrd';

// 注入
export default class AccountShieldCategory extends React.Component {
static defaultProps = {
  classNamePre: '',
  category: [], // 分类的数据源
  chooseCateList: [] // 已选择的类目
}

constructor(prop) {
  super(prop);
  this.state = {
    visible: false,
    changeValue: '',
    changeData: []
  };
}

componentDidMount = async () => {

}

triggerDialog = (visible) => {
  this.setState({ visible, changeValue: '', changeData: [] });
};

// 点击确定的回调
onConfirm = () => {
  const { onConfirm } = this.props;
  const { changeData } = this.state;
  if (!changeData.length) {
    Notify.error('请选择要添加的屏蔽类目');
    return;
  }
  onConfirm(changeData, () => {
    this.setState({ visible: false });
  });
}

onChange = (data) => {
  this.setState({
    changeValue: data.map(item => item.id),
    changeData: data
  });
}

// 删除多余item
removeItem = (data, index) => {
  const { onRemoveItem } = this.props;
  onRemoveItem(data, index);
}

render() {
  const { classNamePre, category, chooseCateList } = this.props;
  const { visible, changeValue } = this.state;
  return (
    <div className={`${classNamePre}-left`}>
      {/* 类目模板 */}
      <div className={`${classNamePre}-left-grp-btn`}>
        <Button onClick={() => this.triggerDialog(true)}>添加类目</Button>
      </div>
      {/* 列表展示区域 */}
      {
        chooseCateList.length
          ? (
            <div className={`${classNamePre}-left-con`}>
              {
                chooseCateList.map((item, index) => (
                  <div
                    key={item.Id}
                    className={`${classNamePre}-left-con-item`}
                  >
                    {item[0].Name}
                      &gt;
                    {item[1].Name}
                    <span
                      role="button"
                      tabIndex="0"
                      className="yiye-outline"
                      onClick={() => this.removeItem(item, index)}
                    >
                      <i />
                    </span>
                  </div>
                ))
              }
            </div>
          )
          : null
      }
      {/** 弹出框 */}
      <Dialog
        title="新增屏蔽类目"
        visible={visible}
        maskClosable={false}
        onClose={() => this.triggerDialog(false)}
        style={{ width: '500px' }}
        footer={(
          <div>
            <Button
              outline
              onClick={() => this.triggerDialog(false)}
            >
            取消
            </Button>
            <Button onClick={this.onConfirm}>确定</Button>
          </div>
        )}
      >
        <Cascader
          value={changeValue}
          options={category}
          onChange={this.onChange}
          placeholder="请选择"
          type="menu"
          title={[
            '省',
            '市'
          ]}
        />
      </Dialog>
    </div>
  );
}
}
