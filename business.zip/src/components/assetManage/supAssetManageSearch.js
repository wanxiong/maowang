import * as React from 'react';
import {
  Select, Button, DateRangePicker, Dialog, Input, Notify
} from 'ezrd';
import moment from 'moment';
import { defaultCategorySettingType } from '../base/constant';
import ConstBrandSelect from '../base/constBrandSelect';

import { trim } from '../../utils/common';

const classNamePre = 'yiye-sup-asset-manage-search';

export default class SupAssetManageSearch extends React.Component {
static defaultProps = {
  showTime: true, // 是否显示时间筛选
  format: 'YYYY-MM-DD HH:mm:ss',
  data: [], // 下拉框得数据源
  defautlSelect: '',
  typeSelectText: '状态：',
  typeName: '',
  mchId: '',
  downloadType: '', // 导出类型
  downloadStore: {}, // 接口store
  DateRangePickerText: '新增时间：',
  defaultDate: '', // 默认初始时间
  filtersId: 'all',
  statusKey: 'Status' // 默认的类型返回字段
}

constructor(props) {
  super(props);
  this.state = {
    SelectValue: props.defautlSelect || '', // 默认选择全部
    value: props.defaultDate || '',
    taskName: moment().format('YYYY-MM-DD') + props.typeName,
    visible: false,
    brandId: '',
    loading: false
  };
  this.onSearch = this.onSearch.bind(this);
}

// 券类型选择
onChangeSelect = (e) => {
  this.setState({ SelectValue: e.target.value });
}

// 点击查询按钮
onSearch = (flag) => {
  const {
    SelectValue, value, brandId
  } = this.state;
  const { onSearch, statusKey } = this.props;
  onSearch({
    [statusKey]: SelectValue,
    StartDate: value[0] || '',
    brandId,
    EndDate: value[1] || ''
  }, flag);
}

// 清空
onClean = () => {
  this.setState({
    value: '',
    SelectValue: '',
    brandId: ''
  });
}

// 导出按钮
onExport = () => {
  const { typeName, downloadType, mchId } = this.props;
  const { brandId } = this.state;
  // <!-- 1.3.4迭代特殊用法  后期开了es全部检索即可注销   -->
  if (downloadType === 'recharge') {
    if (!mchId && !brandId) {
      return;
    }
  }
  // <!-- 1.3.4迭代特殊用法  后期开了es全部检索即可注销   -->
  this.setState({
    visible: true,
    taskName: moment().format('YYYY-MM-DD') + typeName
  });
}

// 关闭弹出框
closeDialog = () => {
  const { typeName } = this.props;
  this.setState({
    visible: false,
    taskName: moment().format('YYYY-MM-DD') + typeName
  });
}

onChangeRange = (val) => {
  this.setState({
    value: val
  });
}

// 普通input框的事件回调
onChangeInput = (type, e) => {
  this.setState({
    [type]: e.target.value
  });
}

onChange = (id) => {
  this.setState({
    brandId: id
  });
}

confirm = async () => {
  const {
    taskName, value, SelectValue, brandId
  } = this.state;
  const {
    downloadStore, downloadType, history, mchId
  } = this.props;
  if (!trim(taskName)) {
    Notify.error('请输入导出数据的文件名称');
    return;
  }
  this.setState({ loading: true });
  if (downloadType === 'recharge') {
    const status = await downloadStore.fetchAccountRechargeExport({
      FileName: taskName,
      SettingType: defaultCategorySettingType.coupon,
      StartDate: value[0],
      EndDate: value[1],
      Status: SelectValue,
      MchId: mchId || brandId
    });
    if (status && !status.IsError) {
      this.closeDialog();
      history.push('/Yiye/Download');
    }
  } else if (downloadType === 'rechargeZB') {
    const status = await downloadStore.fetchAccountRechargeZExport({
      FileName: taskName,
      SettingType: defaultCategorySettingType.coupon,
      StartDate: value[0],
      EndDate: value[1],
      TradeType: SelectValue,
      MchId: mchId || brandId
    });
    if (status && !status.IsError) {
      this.closeDialog();
      history.push('/Yiye/Download');
    }
  }
  this.setState({ loading: false });
}

render() {
  const {
    value, SelectValue, visible, loading, taskName
  } = this.state;
  const {
    showTime, format, data, typeSelectText, DateRangePickerText, filtersId
  } = this.props;
  return (
    <div className={`${classNamePre}`}>
      {/* 基本输入input框 */}
      <div className={`${classNamePre}-top`}>
        <div>
          <ConstBrandSelect
            onChange={this.onChange}
            filtersId={filtersId}
            width="180px"
          />
        </div>
        <div>
          <span>{DateRangePickerText}</span>
          <DateRangePicker
            className=""
            width={190}
            value={value}
            format={format}
            showTime={showTime}
            onChange={this.onChangeRange}
          />
        </div>
        <div>
          <span>{typeSelectText}</span>
          <Select
            data={data}
            optionValue="id"
            optionText="name"
            width="160px"
            autoWidth
            showClear={false}
            value={SelectValue}
            onChange={this.onChangeSelect}
          />
        </div>
      </div>
      {/* 查询--导出 */}
      <div className={`${classNamePre}-search-btn`}>
        <Button
          type="primary"
          className={`${classNamePre}-btn-1`}
          onClick={this.onSearch}
        >
        查询
        </Button>
        <Button
          type="primary"
          outline
          onClick={this.onExport}
        >
        导出
        </Button>
      </div>
      {/** 导出文件提示框 */}
      <Dialog
        title="导出数据的文件名称"
        visible={visible}
        onClose={() => this.closeDialog()}
        style={{ width: '600px' }}
        maskClosable={false}
        footer={(
          <div>
            <Button
              outline
              loading={loading}
              onClick={() => this.closeDialog()}
            >
              取消
            </Button>
            <Button
              loading={loading}
              onClick={() => this.confirm()}
            >
              确定
            </Button>
          </div>
        )}
      >
        <Input
          signleBorder
          placeholder="请输入导出数据的文件名称"
          showClear
          maxLength={30}
          width="100%"
          value={taskName}
          onChange={event => this.onChangeInput('taskName', event)}
        />
      </Dialog>
    </div>
  );
}
}
