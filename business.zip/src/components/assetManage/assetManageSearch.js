import * as React from 'react';
import {
  Select, Button, DateRangePicker, Dialog, Input, Notify
} from 'ezrd';
import moment from 'moment';
import { defaultCategorySettingType } from '../base/constant';

import { trim, getMchId } from '../../utils/common';

const classNamePre = 'yiye-asset-manage-search';

export default class AssetManageSearch extends React.Component {
static defaultProps = {
  showTime: true, // 是否显示时间筛选
  format: 'YYYY-MM-DD HH:mm:ss',
  data: [], // 下拉框得数据源
  defautlSelect: '',
  typeSelectText: '状态：',
  typeName: '',
  mchId: '',
  downloadType: '', // 导出类型
  downloadStore: {}, // 接口store
  DateRangePickerText: '新增时间：',
  defaultDate: '', // 默认时间区间
  statusKey: 'Status' // 默认的类型返回字段
}

constructor(props) {
  super(props);
  this.state = {
    SelectValue: props.defautlSelect || '', // 默认选择全部
    value: props.defaultDate || '',
    taskName: moment().format('YYYY-MM-DD') + props.typeName,
    visible: false,
    loading: false
  };
  this.onSearch = this.onSearch.bind(this);
}

// 券类型选择
onChangeSelect = (e) => {
  this.setState({ SelectValue: e.target.value });
}

// 点击查询按钮
onSearch = (flag) => {
  const {
    SelectValue, value
  } = this.state;
  const { onSearch, statusKey } = this.props;
  onSearch({
    [statusKey]: SelectValue,
    StartDate: value[0] || '',
    EndDate: value[1] || ''
  }, flag);
}

// 清空
onClean = () => {
  this.setState({
    value: '',
    SelectValue: ''
  });
}

// 导出按钮
onExport = () => {
  const { typeName } = this.props;
  this.setState({
    visible: true,
    taskName: moment().format('YYYY-MM-DD') + typeName
  });
}

// 关闭弹出框
closeDialog = () => {
  const { typeName } = this.props;
  this.setState({
    visible: false,
    taskName: moment().format('YYYY-MM-DD') + typeName
  });
}

onChangeRange = (val) => {
  this.setState({
    value: val
  });
}

// 普通input框的事件回调
onChangeInput = (type, e) => {
  this.setState({
    [type]: e.target.value
  });
}

confirm = async () => {
  const {
    taskName, value, SelectValue
  } = this.state;
  const {
    downloadStore, downloadType, history, mchId
  } = this.props;
  if (!trim(taskName)) {
    Notify.error('请输入导出数据的文件名称');
    return;
  }
  this.setState({ loading: true });
  if (downloadType === 'recharge') {
    const status = await downloadStore.fetchAccountRechargeExport({
      FileName: taskName,
      SettingType: defaultCategorySettingType.coupon,
      StartDate: value[0],
      EndDate: value[1],
      Status: SelectValue,
      MchId: mchId || getMchId()
    });
    if (status && !status.IsError) {
      this.closeDialog();
      history.push('/Yiye/Download');
    }
  } else if (downloadType === 'rechargeBond') {
    const status = await downloadStore.fetchAccountRechargeBondExport({
      FileName: taskName,
      StartDate: value[0],
      EndDate: value[1],
      TradeType: SelectValue,
      MchId: getMchId()
    });
    if (status && !status.IsError) {
      this.closeDialog();
      history.push('/Yiye/Download');
    }
  } else if (downloadType === 'rechargeZB') {
    const status = await downloadStore.fetchAccountRechargeZExport({
      FileName: taskName,
      SettingType: defaultCategorySettingType.coupon,
      StartDate: value[0],
      EndDate: value[1],
      TradeType: SelectValue,
      MchId: mchId || getMchId()
    });
    if (status && !status.IsError) {
      this.closeDialog();
      history.push('/Yiye/Download');
    }
  }

  this.setState({ loading: false });
}

render() {
  const {
    value, SelectValue, visible, loading, taskName
  } = this.state;
  const {
    showTime, format, data, typeSelectText, DateRangePickerText
  } = this.props;
  return (
    <div className={`${classNamePre}`}>
      {/* 基本输入input框 */}
      <div className={`${classNamePre}-top`}>
        <div>
          <span>{DateRangePickerText}</span>
          <DateRangePicker
            className=""
            width={190}
            value={value}
            format={format}
            showTime={showTime}
            onChange={this.onChangeRange}
          />
        </div>
        <div>
          <span>{typeSelectText}</span>
          <Select
            data={data}
            optionValue="id"
            optionText="name"
            width="160px"
            autoWidth
            showClear={false}
            value={SelectValue}
            onChange={this.onChangeSelect}
          />
        </div>
      </div>
      {/* 查询--导出 */}
      <div className={`${classNamePre}-search-btn`}>
        <Button
          type="primary"
          className={`${classNamePre}-btn-1`}
          onClick={this.onSearch}
        >
        查询
        </Button>
        <Button
          type="primary"
          outline
          onClick={this.onExport}
        >
        导出
        </Button>
      </div>
      {/** 导出文件提示框 */}
      <Dialog
        title="导出数据的文件名称"
        visible={visible}
        onClose={() => this.closeDialog()}
        style={{ width: '600px' }}
        maskClosable={false}
        footer={(
          <div>
            <Button
              outline
              loading={loading}
              onClick={() => this.closeDialog()}
            >
              取消
            </Button>
            <Button
              loading={loading}
              onClick={() => this.confirm()}
            >
              确定
            </Button>
          </div>
        )}
      >
        <Input
          signleBorder
          placeholder="请输入导出数据的文件名称"
          showClear
          maxLength={30}
          width="100%"
          value={taskName}
          onChange={event => this.onChangeInput('taskName', event)}
        />
      </Dialog>
    </div>
  );
}
}
