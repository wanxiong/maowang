import * as React from 'react';
import { inject } from 'mobx-react';
import {
  Switch, Route, Link
} from 'react-router-dom';
import { Layout, Menu, Icon } from 'antd';
import Head from './components/header';
import subRoutes from './routes/subRoute';
import supRoutes from './routes/supRoute';
import allRoutes from './routes/index';
import { LoginTYPE } from './components/base/constant';
import { isDev } from './config';
import './Layout.css';

const { Footer, Sider, Content, Header } = Layout;
const MenuItem = Menu.Item;
const { SubMenu } = Menu;
const indexUrl = '/Yiye/Account/AccountInfo/AssetManageList';

@inject('accountStore')
class BasicLayout extends React.Component {
  state = {
    collapsed: false,
    mode: 'inline',
    winHeight: 0,
    selectedMenuKey: 0,
    mentList: []
  }

  onCollapse(collapsed) {
    this.setState({
      collapsed,
      mode: collapsed ? 'vertical' : 'inline'
    });
  }

  async componentDidMount() {
    // this.activeMenu();
    await this.initMent()
    this.resizeWindow();
  }
  initMent = async () => {
    const { accountStore } = this.props;
    let data = await accountStore.fetchAccountSelfMenuList({})
    if (data && !data.IsError) {
      // console.log(data.Data)
      let mentList = data.Data.MenuDtos || [];
      let list = this.sortMenu(mentList)
      this.setState({
        mentList: list
      })
    }
  }

  sortMenu = (data) => {
    let list = data.map((item) => {
      if (item['component'] && !item.subRoutes ) {
        // 页面
        item['component'] = allRoutes[item.component]
      } else if(item.subRoutes){
        item['subRoutes'] = this.sortMenu(item['subRoutes'])
      }
      return item
    })
    return list;
  }

  resizeWindow() {
    this.setState({
      winHeight: document.body.clientHeight
    });
  }

  // activeMenu() {
  //   routes.forEach((r, i) => {
  //     if (new RegExp(r.path).test(window.location.hash)) {
  //       if (i > 0) {
  //         this.setState({
  //           selectedMenuKey: i
  //         });
  //       }
  //     }
  //   });
  // }

  // 重置routes数据
  resetRoutes = (data, path) => {
    if (!data) return []
    for (let i = 0; i < data.length; i++) {
      data[i].comPath = path ? path + data[i].path : data[i].path;
      if (data[i].subRoutes) {
        data[i].subRoutes = this.resetRoutes(data[i].subRoutes, data[i].comPath)
      }
    }
    return data
  }

  // 获取父级节点path 用于刷新展开
  getParentPath = (tree, func, path = []) => {
    if (!tree) return []
    for (const data of tree) {
      // 这里按照你的需求来存放最后返回的内容吧
      if (func(data)) return path
      path.push(data.comPath)
      if (data.subRoutes) {
        const findChildren = this.getParentPath(data.subRoutes, func, path)
        if (findChildren.length) return findChildren
      }
      path.pop()
    }
    return []
  }

  // shouldComponentUpdate = () => {

  // }

  render() {
    const { history } = this.props;
    const { mentList } = this.state;
    //
    let routes = [];
    // let indexUrl = 'Yiye/Account/AccountInfo/AssetManageList';
    // 呆改造动态路由
    if (isDev) {
      try {
        let list = JSON.parse(localStorage.getItem(LoginTYPE));
        if (list.MerchantType === 0) { // 超级VIP/平台账号
          routes= supRoutes;
        } else if (list.MerchantType === 1) { // 商户账号
          routes= subRoutes;
        } else {
          routes= [];
        }
      } catch (error) {
        routes = subRoutes;
      }
    } else {
        routes = mentList;
    }
    const newRoutes = this.resetRoutes(routes, "");
    const defaultOpenKeys = this.getParentPath(newRoutes, data => data.comPath === this.props.history.location.pathname);
    //
    return (
      <Layout className='app-height'>
        <Header className={'yiye-header-contain'}>
          <Head history={ history }/>
        </Header>
        <Layout>

          <Sider
            style={{ minHeight: this.state.winHeight }}
            collapsible
            collapsed={this.state.collapsed}
            className={'yiye-sider-contain'}
            onCollapse={this.onCollapse.bind(this)}
          >

            <Menu
              theme="light"
              mode={this.state.collapsed ? 'vertical' : 'inline'}
              // defaultSelectedKeys={[`${this.state.selectedMenuKey}`]}
              defaultSelectedKeys={indexUrl}
              className={'yiye-sider-contain-menu'}
              selectedKeys={[this.props.history.location.pathname]}
              defaultOpenKeys={defaultOpenKeys}
            >
              {
                routes.map((route, index) => {
                  if (route.subRoutes && route.subRoutes.length && !route.hide) {
                    return (
                      <SubMenu
                        key={route.path}
                        title={(
                          <span>
                            <Icon type={route.icon || ''} />
                            <span className="nav-text">{route.name}</span>
                          </span>
                        )}
                      >
                        {
                          route.subRoutes.map((subRoute, subIndex) => {
                            if (!subRoute.hide) {
                              if (subRoute.subRoutes && subRoute.subRoutes.length) { // 三级路由
                                return (
                                  <SubMenu
                                    key={route.path + subRoute.path}
                                    className={'yiye-sider-second-menu'}
                                    title={(
                                      <span>
                                        <Icon type={subRoute.icon || ''} />
                                        <span className="nav-text">{subRoute.name}</span>
                                      </span>
                                    )}
                                  >
                                  {
                                    subRoute.subRoutes.map((threeRoute, index) => {
                                      if (!threeRoute.hide) {
                                        return (
                                          <MenuItem key={route.path + subRoute.path + threeRoute.path}>
                                            <Link to={route.path + subRoute.path + threeRoute.path}>{threeRoute.name}</Link>
                                          </MenuItem>
                                        )
                                      }
                                    })
                                  }
                                  </SubMenu>
                                )
                              } else {
                                return (
                                  <MenuItem key={route.path + subRoute.path}>
                                    <Link to={route.path + subRoute.path}>{subRoute.name}</Link>
                                  </MenuItem>
                                )
                              }
                            }
                          })
                        }
                      </SubMenu>
                    );
                  }
                  return !route.hide && (
                    // <MenuItem key={index}>
                    <MenuItem key={route.path}>
                      <Link to={route.path}>
                        <Icon type={route.icon || ''} />
                        <span className="nav-text">{route.name}</span>
                      </Link>
                    </MenuItem>
                  );
                })
              }
            </Menu>
          </Sider>
          <Layout>

            <Content className="main-content">
              {
                routes.map((route, index) => { 
                  if (route.subRoutes && route.subRoutes.length) { // 二级路由
                    return (
                      <Switch key={index}>
                        {
                          route.subRoutes.map((subRoute, subIndex) => {
                            if (subRoute.subRoutes && subRoute.subRoutes.length) { // // 三级路由 只有路由 没有文件夹
                              return (
                                  subRoute.subRoutes.map((threeRoute, threeIndex) => {
                                    return (
                                      <Route
                                        key={`${index}-1-${threeIndex}`}
                                        exact={threeRoute.exact}
                                        path={route.path + subRoute.path + threeRoute.path}
                                        component={threeRoute.component}
                                      />
                                    )
                                })
                              )
                            }
                            return (
                              <Route
                                key={`${index}-${subIndex}`}
                                exact={subRoute.exact}
                                path={route.path + subRoute.path}
                                component={subRoute.component}
                              />
                            )
                          })
                        }
                      </Switch>
                    );
                  }
                  // 一级路由
                  return (
                    <Route
                      key={index}
                      exact={route.exact}
                      path={route.path}
                      component={route.component}
                    />
                  );
                })
              }
            </Content>
          </Layout>
        </Layout>
      </Layout>
    );
  }
}

export default BasicLayout;
