#!/bin/bash

set -e

yarn
